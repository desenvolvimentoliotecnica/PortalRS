--
-- PostgreSQL database dump
--

\restrict 4eYtXaQlGhTapfNWsW0rRcwulxJcsx17v9vLKTi61rfdLgCxF6qWEMmxxLaV7bP

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_SolicitacoesDesligamento_DesligamentoId";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_Funcionarios_ResponsavelId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Users_RecrutadorResponsavelUserId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Turnos_TurnoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Hierarquias_HierarquiaId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_EixosVaga_EixoVagaId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Desligamentos_OrigemDesligamentoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_DescricoesCargo_DescricaoCargoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_CategoriasSalariais_CategoriaSalarialId";
ALTER TABLE IF EXISTS ONLY public."VagaUnifiedMatchingCaches" DROP CONSTRAINT IF EXISTS "FK_VagaUnifiedMatchingCaches_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaRequisitos" DROP CONSTRAINT IF EXISTS "FK_VagaRequisitos_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaPerguntas" DROP CONSTRAINT IF EXISTS "FK_VagaPerguntas_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaEtapas" DROP CONSTRAINT IF EXISTS "FK_VagaEtapas_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaBeneficios" DROP CONSTRAINT IF EXISTS "FK_VagaBeneficios_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."Users" DROP CONSTRAINT IF EXISTS "FK_Users_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."UserUnits" DROP CONSTRAINT IF EXISTS "FK_UserUnits_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."UserUnits" DROP CONSTRAINT IF EXISTS "FK_UserUnits_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "FK_UserRoles_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "FK_UserRoles_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."Units" DROP CONSTRAINT IF EXISTS "FK_Units_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."UnidadesLotacao" DROP CONSTRAINT IF EXISTS "FK_UnidadesLotacao_UnidadesLotacao_ParentId";
ALTER TABLE IF EXISTS ONLY public."UnidadesLotacao" DROP CONSTRAINT IF EXISTS "FK_UnidadesLotacao_Funcionarios_OwnerFuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Turnos" DROP CONSTRAINT IF EXISTS "FK_Turnos_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."TenantConfiguracoes" DROP CONSTRAINT IF EXISTS "FK_TenantConfiguracoes_Funcionarios_AprovadorRhId";
ALTER TABLE IF EXISTS ONLY public."Talentos" DROP CONSTRAINT IF EXISTS "FK_Talentos_Pessoas_PessoaId";
ALTER TABLE IF EXISTS ONLY public."TalentoTreinamentos" DROP CONSTRAINT IF EXISTS "FK_TalentoTreinamentos_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoFormacoes" DROP CONSTRAINT IF EXISTS "FK_TalentoFormacoes_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoExperiencias" DROP CONSTRAINT IF EXISTS "FK_TalentoExperiencias_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoDocumentos" DROP CONSTRAINT IF EXISTS "FK_TalentoDocumentos_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoCvImportJobs" DROP CONSTRAINT IF EXISTS "FK_TalentoCvImportJobs_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoCvImportJobs" DROP CONSTRAINT IF EXISTS "FK_TalentoCvImportJobs_TalentoDocumentos_TalentoDocumentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoCompetencias" DROP CONSTRAINT IF EXISTS "FK_TalentoCompetencias_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."SurveyResponses" DROP CONSTRAINT IF EXISTS "FK_SurveyResponses_Surveys_SurveyId";
ALTER TABLE IF EXISTS ONLY public."SurveyQuestions" DROP CONSTRAINT IF EXISTS "FK_SurveyQuestions_Surveys_SurveyId";
ALTER TABLE IF EXISTS ONLY public."SurveyOptions" DROP CONSTRAINT IF EXISTS "FK_SurveyOptions_SurveyQuestions_QuestionId";
ALTER TABLE IF EXISTS ONLY public."SurveyAnswers" DROP CONSTRAINT IF EXISTS "FK_SurveyAnswers_SurveyResponses_ResponseId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_MotivosRequisicaoVagaConfig_MotivoRequisic~";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_SubstituidoFuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_DecisaoRHRevisadoPorId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_AprovadorId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Candidatos_CandidatoContratadoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Units_NovaUnidadeId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_JobPositions_NovoCargoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_JobPositions_CargoAtualId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_CentrosCusto_NovoCentroCustoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoAtualId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPagamentoExtra_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPagamentoExtra_Funcionarios_ImportadoPorId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPagamentoExtra_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesFerias" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesFerias_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesEndereco" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesEndereco_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDependente" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDependente_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDependente" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDependente_Dependentes_DependenteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesBeneficio" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesBeneficio_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesAprovacaoEtapas" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesAprovacaoEtapas_Funcionarios_AprovadorId";
ALTER TABLE IF EXISTS ONLY public."Skills" DROP CONSTRAINT IF EXISTS "FK_Skills_Skills_ParentSkillId";
ALTER TABLE IF EXISTS ONLY public."SkillAliases" DROP CONSTRAINT IF EXISTS "FK_SkillAliases_Skills_SkillId";
ALTER TABLE IF EXISTS ONLY public."RoleMenus" DROP CONSTRAINT IF EXISTS "FK_RoleMenus_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."RoleMenus" DROP CONSTRAINT IF EXISTS "FK_RoleMenus_Menus_MenuId";
ALTER TABLE IF EXISTS ONLY public."RespostasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "FK_RespostasEntrevistaSaida_PerguntasEntrevistaSaida_PerguntaId";
ALTER TABLE IF EXISTS ONLY public."RespostasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "FK_RespostasEntrevistaSaida_EntrevistasSaida_EntrevistaId";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "FK_RespostasCampoPersonalizadoVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "FK_RespostasCampoPersonalizadoVaga_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "FK_RespostasCampoPersonalizadoVaga_CamposPersonalizadosVaga_Ca~";
ALTER TABLE IF EXISTS ONLY public."RenderCoinTransactions" DROP CONSTRAINT IF EXISTS "FK_RenderCoinTransactions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."RenderCoinBalances" DROP CONSTRAINT IF EXISTS "FK_RenderCoinBalances_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "FK_PropostasVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "FK_PropostasVaga_Candidaturas_CandidaturaId";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "FK_PropostasVaga_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."ProjetosVaga" DROP CONSTRAINT IF EXISTS "FK_ProjetosVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "FK_ProjetoCandidatos_ProjetosVaga_ProjetoId";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "FK_ProjetoCandidatos_FasesProcesso_FaseAtualId";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "FK_ProjetoCandidatos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Funcionarios_RevisadoPorId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Funcionarios_AprovadoPorId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentos" DROP CONSTRAINT IF EXISTS "FK_PreAdmissaoDocumentos_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentosSolicitados" DROP CONSTRAINT IF EXISTS "FK_PreAdmissaoDocumentosSolicitados_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDependentes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissaoDependentes_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."PessoaBloqueios" DROP CONSTRAINT IF EXISTS "FK_PessoaBloqueios_Pessoas_PessoaId";
ALTER TABLE IF EXISTS ONLY public."PermissoesNivelVaga" DROP CONSTRAINT IF EXISTS "FK_PermissoesNivelVaga_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."PermissoesNivelVaga" DROP CONSTRAINT IF EXISTS "FK_PermissoesNivelVaga_NiveisHierarquicos_NivelHierarquicoId";
ALTER TABLE IF EXISTS ONLY public."PerguntasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "FK_PerguntasEntrevistaSaida_TemplatesEntrevistaSaida_TemplateId";
ALTER TABLE IF EXISTS ONLY public."OneOnOneMeetings" DROP CONSTRAINT IF EXISTS "FK_OneOnOneMeetings_Users_ManagerId";
ALTER TABLE IF EXISTS ONLY public."OneOnOneMeetings" DROP CONSTRAINT IF EXISTS "FK_OneOnOneMeetings_Users_CollaboratorId";
ALTER TABLE IF EXISTS ONLY public."OcupacoesHistorico" DROP CONSTRAINT IF EXISTS "FK_OcupacoesHistorico_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."OcupacoesHistorico" DROP CONSTRAINT IF EXISTS "FK_OcupacoesHistorico_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Notifications" DROP CONSTRAINT IF EXISTS "FK_Notifications_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "FK_NineBoxAssessments_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "FK_NineBoxAssessments_Funcionarios_AvaliadorId";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "FK_NineBoxAssessments_AvaliacaoCiclos_CicloAvaliacaoId";
ALTER TABLE IF EXISTS ONLY public."MoodEntries" DROP CONSTRAINT IF EXISTS "FK_MoodEntries_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."Metas" DROP CONSTRAINT IF EXISTS "FK_Metas_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Metas" DROP CONSTRAINT IF EXISTS "FK_Metas_Funcionarios_CriadaPorId";
ALTER TABLE IF EXISTS ONLY public."LogsComunicacao" DROP CONSTRAINT IF EXISTS "FK_LogsComunicacao_ProjetosVaga_ProjetoId";
ALTER TABLE IF EXISTS ONLY public."LogsComunicacao" DROP CONSTRAINT IF EXISTS "FK_LogsComunicacao_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "FK_JobPositions_NiveisHierarquicos_NivelHierarquicoId";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "FK_JobPositions_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "FK_JobPositions_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."InboxItems" DROP CONSTRAINT IF EXISTS "FK_InboxItems_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."InboxItems" DROP CONSTRAINT IF EXISTS "FK_InboxItems_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."InboxAttachments" DROP CONSTRAINT IF EXISTS "FK_InboxAttachments_InboxItems_InboxItemId";
ALTER TABLE IF EXISTS ONLY public."Holerites" DROP CONSTRAINT IF EXISTS "FK_Holerites_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Holerites" DROP CONSTRAINT IF EXISTS "FK_Holerites_Funcionarios_EnviadoPorId";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_HistoricosAlteracaoWorkflowRH_WorkflowsRH_WorkflowId";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_HistoricosAlteracaoWorkflowRH_Funcionarios_AlteradoPorId";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_HistoricosAlteracaoWorkflowRH_EtapasWorkflowRH_EtapaWorkflo~";
ALTER TABLE IF EXISTS ONLY public."Hierarquias" DROP CONSTRAINT IF EXISTS "FK_Hierarquias_Hierarquias_HierarquiaSuperiorId";
ALTER TABLE IF EXISTS ONLY public."GamificationDailyStates" DROP CONSTRAINT IF EXISTS "FK_GamificationDailyStates_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Pessoas_PessoaId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_NiveisHierarquicos_NivelHierarquicoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Hierarquias_HierarquiaId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Funcionarios_GestorDiretoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."FuncionarioMovimentacoes" DROP CONSTRAINT IF EXISTS "FK_FuncionarioMovimentacoes_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."FeedbackItems" DROP CONSTRAINT IF EXISTS "FK_FeedbackItems_Users_ToUserId";
ALTER TABLE IF EXISTS ONLY public."FeedbackItems" DROP CONSTRAINT IF EXISTS "FK_FeedbackItems_Users_FromUserId";
ALTER TABLE IF EXISTS ONLY public."FeedbackItemRatings" DROP CONSTRAINT IF EXISTS "FK_FeedbackItemRatings_FeedbackItems_FeedbackItemId";
ALTER TABLE IF EXISTS ONLY public."FasesProcesso" DROP CONSTRAINT IF EXISTS "FK_FasesProcesso_ProjetosVaga_ProjetoId";
ALTER TABLE IF EXISTS ONLY public."FaixasSalariais" DROP CONSTRAINT IF EXISTS "FK_FaixasSalariais_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."EtapasWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_EtapasWorkflowRH_WorkflowsRH_WorkflowId";
ALTER TABLE IF EXISTS ONLY public."EtapasWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_EtapasWorkflowRH_Funcionarios_ResponsavelId";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_EtapasConfigWorkflowRH_Roles_RoleFilaId";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigAprovacao" DROP CONSTRAINT IF EXISTS "FK_EtapasConfigAprovacao_Roles_RoleFilaId";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigAprovacao" DROP CONSTRAINT IF EXISTS "FK_EtapasConfigAprovacao_Funcionarios_FuncionarioFixoId";
ALTER TABLE IF EXISTS ONLY public."EmailAttempts" DROP CONSTRAINT IF EXISTS "FK_EmailAttempts_EmailMessages_EmailMessageId";
ALTER TABLE IF EXISTS ONLY public."DocumentosColaborador" DROP CONSTRAINT IF EXISTS "FK_DocumentosColaborador_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorNivelCargoConfigs" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoPorNivelCargoConfigs_NiveisCargo_NivelCar~";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorCargoConfigs" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoPorCargoConfigs_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoHistoricos" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoHistoricos_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoHistoricos" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoHistoricos_JobPositions_CargoId";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlans" DROP CONSTRAINT IF EXISTS "FK_DevelopmentPlans_Users_TargetUserId";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlans" DROP CONSTRAINT IF EXISTS "FK_DevelopmentPlans_Users_OwnerUserId";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlanGoals" DROP CONSTRAINT IF EXISTS "FK_DevelopmentPlanGoals_DevelopmentPlans_PlanId";
ALTER TABLE IF EXISTS ONLY public."Desligamentos" DROP CONSTRAINT IF EXISTS "FK_Desligamentos_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."DescricoesCargo" DROP CONSTRAINT IF EXISTS "FK_DescricoesCargo_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItens" DROP CONSTRAINT IF EXISTS "FK_DescricaoCargoItens_DescricoesCargo_DescricaoCargoId";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItemEmbeddings" DROP CONSTRAINT IF EXISTS "FK_DescricaoCargoItemEmbeddings_Item";
ALTER TABLE IF EXISTS ONLY public."Dependentes" DROP CONSTRAINT IF EXISTS "FK_Dependentes_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."DadosBancarios" DROP CONSTRAINT IF EXISTS "FK_DadosBancarios_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "FK_CentrosCusto_Funcionarios_OwnerFuncionarioId";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "FK_CentrosCusto_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "FK_CentrosCusto_CentrosCusto_ParentId";
ALTER TABLE IF EXISTS ONLY public."CelebrationPosts" DROP CONSTRAINT IF EXISTS "FK_CelebrationPosts_Users_AuthorId";
ALTER TABLE IF EXISTS ONLY public."CelebrationMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationMentions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."CelebrationMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationMentions_CelebrationPosts_PostId";
ALTER TABLE IF EXISTS ONLY public."CelebrationComments" DROP CONSTRAINT IF EXISTS "FK_CelebrationComments_Users_AuthorId";
ALTER TABLE IF EXISTS ONLY public."CelebrationComments" DROP CONSTRAINT IF EXISTS "FK_CelebrationComments_CelebrationPosts_PostId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentReactions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentReactions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentReactions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentReactions_CelebrationComments_CommentId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentMentions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentMentions_CelebrationComments_CommentId";
ALTER TABLE IF EXISTS ONLY public."CategoriasSalariais" DROP CONSTRAINT IF EXISTS "FK_CategoriasSalariais_Units_EstabelecimentoId";
ALTER TABLE IF EXISTS ONLY public."CategoriasSalariais" DROP CONSTRAINT IF EXISTS "FK_CategoriasSalariais_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."CategoriaSalarialSteps" DROP CONSTRAINT IF EXISTS "FK_CategoriaSalarialSteps_CategoriasSalariais_CategoriaSalaria~";
ALTER TABLE IF EXISTS ONLY public."Candidaturas" DROP CONSTRAINT IF EXISTS "FK_Candidaturas_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."Candidaturas" DROP CONSTRAINT IF EXISTS "FK_Candidaturas_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidaturaEtapaHistoricos" DROP CONSTRAINT IF EXISTS "FK_CandidaturaEtapaHistoricos_Candidaturas_CandidaturaId";
ALTER TABLE IF EXISTS ONLY public."Candidatos" DROP CONSTRAINT IF EXISTS "FK_Candidatos_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."Candidatos" DROP CONSTRAINT IF EXISTS "FK_Candidatos_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaMatchingScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaMatchingScores_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaMatchingScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaMatchingScores_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaLlmScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaLlmScores_Vaga";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaLlmScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaLlmScores_Candidato";
ALTER TABLE IF EXISTS ONLY public."CandidatoStatusHistories" DROP CONSTRAINT IF EXISTS "FK_CandidatoStatusHistories_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoReferencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoReferencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoProjetos" DROP CONSTRAINT IF EXISTS "FK_CandidatoProjetos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoPreferenciasVaga" DROP CONSTRAINT IF EXISTS "FK_CandidatoPreferenciasVaga_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoPortfolios" DROP CONSTRAINT IF EXISTS "FK_CandidatoPortfolios_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoNotificacaoPreferencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoNotificacaoPreferencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoLgpdConsents" DROP CONSTRAINT IF EXISTS "FK_CandidatoLgpdConsents_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoExperiencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoExperiencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoEmbeddings" DROP CONSTRAINT IF EXISTS "FK_CandidatoEmbeddings_Candidato";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoResumos" DROP CONSTRAINT IF EXISTS "FK_CandidatoEducacaoResumos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoItens" DROP CONSTRAINT IF EXISTS "FK_CandidatoEducacaoItens_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoDocumentos" DROP CONSTRAINT IF EXISTS "FK_CandidatoDocumentos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoCompetencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoCompetencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoCertificacoes" DROP CONSTRAINT IF EXISTS "FK_CandidatoCertificacoes_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaPreferencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoAgendaPreferencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaBloqueios" DROP CONSTRAINT IF EXISTS "FK_CandidatoAgendaBloqueios_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoAcessibilidades" DROP CONSTRAINT IF EXISTS "FK_CandidatoAcessibilidades_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CamposPersonalizadosVaga" DROP CONSTRAINT IF EXISTS "FK_CamposPersonalizadosVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."BatchMatchingRunVagas" DROP CONSTRAINT IF EXISTS "FK_BatchMatchingRunVagas_BatchMatchingRuns_RunId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoRespostas_Funcionarios_AvaliandoId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoRespostas_Funcionarios_AvaliadorId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoRespostas_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoPerguntas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoPerguntas_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoConvites_Funcionarios_AvaliandoId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoConvites_Funcionarios_AvaliadorId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoConvites_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCiclos" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCiclos_Funcionarios_CriadoPorId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCalibragens_NineBoxAssessments_NineBoxAssessmentId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCalibragens_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCalibragens_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AuditEvents" DROP CONSTRAINT IF EXISTS "FK_AuditEvents_AuditTransactions_AuditTransactionId";
ALTER TABLE IF EXISTS ONLY public."AuditEntityPropertyChanges" DROP CONSTRAINT IF EXISTS "FK_AuditEntityPropertyChanges_AuditEntityChanges_AuditEntityCha";
ALTER TABLE IF EXISTS ONLY public."AuditEntityChanges" DROP CONSTRAINT IF EXISTS "FK_AuditEntityChanges_AuditTransactions_AuditTransactionId";
ALTER TABLE IF EXISTS ONLY public."AuditEntityChanges" DROP CONSTRAINT IF EXISTS "FK_AuditEntityChanges_AuditEvents_AuditEventId";
ALTER TABLE IF EXISTS ONLY public."AspNetUserTokens" DROP CONSTRAINT IF EXISTS "FK_AspNetUserTokens_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."AspNetUserLogins" DROP CONSTRAINT IF EXISTS "FK_AspNetUserLogins_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."AspNetUserClaims" DROP CONSTRAINT IF EXISTS "FK_AspNetUserClaims_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."AspNetRoleClaims" DROP CONSTRAINT IF EXISTS "FK_AspNetRoleClaims_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."AprovadoresAlternativos" DROP CONSTRAINT IF EXISTS "FK_AprovadoresAlternativos_Gestor";
ALTER TABLE IF EXISTS ONLY public."AprovadoresAlternativos" DROP CONSTRAINT IF EXISTS "FK_AprovadoresAlternativos_Aprovador";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "FK_AprovacoesFaixaSalarial_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "FK_AprovacoesFaixaSalarial_Funcionarios_AprovadorId";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "FK_AprovacoesFaixaSalarial_FaixasSalariais_FaixaSalarialId";
ALTER TABLE IF EXISTS ONLY public."AgendaEvents" DROP CONSTRAINT IF EXISTS "FK_AgendaEvents_AgendaEventTypes_TypeId";
DROP INDEX IF EXISTS public."UserNameIndex";
DROP INDEX IF EXISTS public."RoleNameIndex";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_VagaId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_TenantId_TipoWorkflow_Status";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_ResponsavelId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_DesligamentoId";
DROP INDEX IF EXISTS public."IX_Vagas_UnidadeLotacaoId";
DROP INDEX IF EXISTS public."IX_Vagas_TurnoId";
DROP INDEX IF EXISTS public."IX_Vagas_TenantId_Status";
DROP INDEX IF EXISTS public."IX_Vagas_TenantId_CentroCustoId";
DROP INDEX IF EXISTS public."IX_Vagas_RecrutadorResponsavelUserId";
DROP INDEX IF EXISTS public."IX_Vagas_OrigemTipo";
DROP INDEX IF EXISTS public."IX_Vagas_OrigemDesligamentoId";
DROP INDEX IF EXISTS public."IX_Vagas_JobPositionId";
DROP INDEX IF EXISTS public."IX_Vagas_IdReqRmOrigem";
DROP INDEX IF EXISTS public."IX_Vagas_HierarquiaId";
DROP INDEX IF EXISTS public."IX_Vagas_EixoVagaId";
DROP INDEX IF EXISTS public."IX_Vagas_DescricaoCargoId";
DROP INDEX IF EXISTS public."IX_Vagas_CentroCustoId";
DROP INDEX IF EXISTS public."IX_Vagas_CategoriaSalarialId";
DROP INDEX IF EXISTS public."IX_VagaUnifiedMatchingCaches_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaUnifiedMatchingCaches_TenantId_Status";
DROP INDEX IF EXISTS public."IX_VagaRequisitos_VagaId";
DROP INDEX IF EXISTS public."IX_VagaRequisitos_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaPerguntas_VagaId";
DROP INDEX IF EXISTS public."IX_VagaPerguntas_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaEtapas_VagaId";
DROP INDEX IF EXISTS public."IX_VagaEtapas_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaBeneficios_VagaId";
DROP INDEX IF EXISTS public."IX_VagaBeneficios_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_Users_TenantId_NormalizedUserName";
DROP INDEX IF EXISTS public."IX_Users_TenantId_NormalizedEmail";
DROP INDEX IF EXISTS public."IX_Users_FuncionarioId";
DROP INDEX IF EXISTS public."IX_UserUnits_UnitId";
DROP INDEX IF EXISTS public."IX_UserRoles_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_UserRoles_TenantId_RoleId";
DROP INDEX IF EXISTS public."IX_UserRoles_RoleId";
DROP INDEX IF EXISTS public."IX_Units_TenantId_EmpresaId_Code";
DROP INDEX IF EXISTS public."IX_Units_EmpresaId";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_TenantId_CdnPlanoLotac_Code";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_ParentId";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_OwnerFuncionarioId";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_IsActive";
DROP INDEX IF EXISTS public."IX_Turnos_UnidadeLotacaoId";
DROP INDEX IF EXISTS public."IX_Turnos_TenantId_Code";
DROP INDEX IF EXISTS public."IX_Turnos_IsActive";
DROP INDEX IF EXISTS public."IX_TenantConfiguracoes_TenantId";
DROP INDEX IF EXISTS public."IX_TenantConfiguracoes_AprovadorRhId";
DROP INDEX IF EXISTS public."IX_TenantBrandings_TenantId";
DROP INDEX IF EXISTS public."IX_TemplatesEntrevistaSaida_TenantId_Ativo";
DROP INDEX IF EXISTS public."IX_Talentos_TenantId_PessoaId";
DROP INDEX IF EXISTS public."IX_Talentos_PessoaId";
DROP INDEX IF EXISTS public."IX_TalentoTreinamentos_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoTreinamentos_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoFormacoes_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoFormacoes_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoExperiencias_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoExperiencias_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoDocumentos_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoDocumentos_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TenantId_Status";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TalentoDocumentoId";
DROP INDEX IF EXISTS public."IX_TalentoCompetencias_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCompetencias_TalentoId";
DROP INDEX IF EXISTS public."IX_Surveys_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_SurveyResponses_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_SurveyResponses_TenantId_SurveyId_UserId";
DROP INDEX IF EXISTS public."IX_SurveyResponses_TenantId_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyResponses_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyQuestions_TenantId_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyQuestions_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyOptions_TenantId_QuestionId";
DROP INDEX IF EXISTS public."IX_SurveyOptions_QuestionId";
DROP INDEX IF EXISTS public."IX_SurveyAnswers_TenantId_ResponseId";
DROP INDEX IF EXISTS public."IX_SurveyAnswers_ResponseId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_UnitId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_TenantId_Status";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_TenantId_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_SubstituidoFuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_MotivoRequisicaoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_JobPositionId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_DecisaoRHRevisadoPorId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_CandidatoContratadoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_AprovadorId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_UnitId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_NovoCentroCustoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_NovoCargoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_NovaUnidadeId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_FuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_CentroCustoAtualId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_CargoAtualId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPagamentoExtra_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPagamentoExtra_ImportadoPorId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPagamentoExtra_FuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesFerias_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesEndereco_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_UnitId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_FuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_EmpresaId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDependente_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDependente_DependenteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesBeneficio_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_TenantId_SolicitacaoId_TipoFluxo";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_TenantId_RoleFilaId_Status";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_Solicitacao";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_FilaPendente";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_AprovadorId";
DROP INDEX IF EXISTS public."IX_SlaStatusConfigs_TenantId_TipoEntidade_Status";
DROP INDEX IF EXISTS public."IX_Skills_TenantId_CanonicalName";
DROP INDEX IF EXISTS public."IX_Skills_ParentSkillId";
DROP INDEX IF EXISTS public."IX_SkillAliases_TenantId_AliasName";
DROP INDEX IF EXISTS public."IX_SkillAliases_SkillId";
DROP INDEX IF EXISTS public."IX_Roles_TenantId_NormalizedName";
DROP INDEX IF EXISTS public."IX_RoleMenus_TenantId_RoleId_MenuId_PermissionKey";
DROP INDEX IF EXISTS public."IX_RoleMenus_RoleId";
DROP INDEX IF EXISTS public."IX_RoleMenus_MenuId";
DROP INDEX IF EXISTS public."IX_RmSyncRuns_TenantId_Status";
DROP INDEX IF EXISTS public."IX_RmSyncRuns_TenantId_Entidade_StartedAtUtc";
DROP INDEX IF EXISTS public."IX_RmSyncCheckpoints_TenantId_Entidade";
DROP INDEX IF EXISTS public."IX_RmSyncAlertas_TenantId_Tipo_ChaveRm";
DROP INDEX IF EXISTS public."IX_RmSyncAlertas_TenantId_ResolvidoEmUtc";
DROP INDEX IF EXISTS public."IX_RespostasEntrevistaSaida_TenantId_EntrevistaId";
DROP INDEX IF EXISTS public."IX_RespostasEntrevistaSaida_PerguntaId";
DROP INDEX IF EXISTS public."IX_RespostasEntrevistaSaida_EntrevistaId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_VagaId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_TenantId_VagaId_CandidatoId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_CandidatoId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_CampoId";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_TransactionId";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_StatusCode";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_StartedAt";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_Path";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_EnvironmentNormalized_StartedAt";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_DeviceId_StartedAt";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_UserId";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_TenantId_UserId_SourceType_SourceId";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_RenderCoinBalances_UserId";
DROP INDEX IF EXISTS public."IX_RenderCoinBalances_TenantId_Balance";
DROP INDEX IF EXISTS public."IX_RecruiterMatchingFeedbacks_VagaId_CandidatoId";
DROP INDEX IF EXISTS public."IX_RecruiterMatchingFeedbacks_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_VagaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_TenantId_CandidaturaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_CandidaturaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_CandidatoId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_AccessToken";
DROP INDEX IF EXISTS public."IX_ProjetosVaga_VagaId";
DROP INDEX IF EXISTS public."IX_ProjetosVaga_TenantId_VagaId_Numero";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_TenantId_ProjetoId_CandidatoId";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_ProjetoId";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_FaseAtualId";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_CandidatoId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_VagaId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_UnitId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_TenantId_Status";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_TenantId_Cpf";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_TenantId_AccessToken";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_RevisadoPorId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_JobPositionId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_CentroCustoId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_CandidatoId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_AprovadoPorId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentos_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentos_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentosSolicitados_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentosSolicitados_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDependentes_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDependentes_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_Pessoas_TenantId_Email";
DROP INDEX IF EXISTS public."IX_Pessoas_TenantId_Cpf";
DROP INDEX IF EXISTS public."IX_PessoaBloqueios_TenantId_PessoaId";
DROP INDEX IF EXISTS public."IX_PessoaBloqueios_PessoaId";
DROP INDEX IF EXISTS public."IX_PermissoesNivelVaga_TenantId_NivelHierarquicoId_RoleId";
DROP INDEX IF EXISTS public."IX_PermissoesNivelVaga_RoleId";
DROP INDEX IF EXISTS public."IX_PermissoesNivelVaga_NivelHierarquicoId";
DROP INDEX IF EXISTS public."IX_PerguntasEntrevistaSaida_TenantId_TemplateId_Ordem";
DROP INDEX IF EXISTS public."IX_PerguntasEntrevistaSaida_TemplateId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_TenantId_MeetingDate";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_TenantId_ManagerId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_TenantId_CollaboratorId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_ManagerId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_CollaboratorId";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_VagaId";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_TenantId_FuncionarioId_DataSaida";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Notifications_UserId";
DROP INDEX IF EXISTS public."IX_Notifications_TenantId_UserId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_Notifications_TenantId_IsRead";
DROP INDEX IF EXISTS public."IX_Notifications_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_NotificationReceipts_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_NotificationReceipts_TenantId_NotificationId_UserId";
DROP INDEX IF EXISTS public."IX_NotificationReceipts_TenantId_NotificationId";
DROP INDEX IF EXISTS public."IX_NotificacoesTemplates_TenantId_Etapa_Canal_Idioma";
DROP INDEX IF EXISTS public."IX_NotificacoesCandidaturaLogs_TenantId_CandidaturaId";
DROP INDEX IF EXISTS public."IX_NotificacoesCandidaturaLogs_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_NiveisHierarquicos_TenantId_Ordem";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_TenantId_CriadoEmUtc";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_TenantId_CicloAvaliacaoId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_FuncionarioId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_CicloAvaliacaoId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_AvaliadorId";
DROP INDEX IF EXISTS public."IX_MotivosRequisicaoVagaConfig_TenantId_IsActive_Ordem";
DROP INDEX IF EXISTS public."IX_MotivosRequisicaoVagaConfig_TenantId_Codigo";
DROP INDEX IF EXISTS public."IX_MoodEntries_UserId";
DROP INDEX IF EXISTS public."IX_MoodEntries_TenantId_UserId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_Metas_TenantId_Status";
DROP INDEX IF EXISTS public."IX_Metas_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Metas_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Metas_CriadaPorId";
DROP INDEX IF EXISTS public."IX_Menus_TenantId_Route";
DROP INDEX IF EXISTS public."IX_Menus_TenantId_PermissionKey";
DROP INDEX IF EXISTS public."IX_LogsComunicacao_TenantId_CandidatoId_DataUtc";
DROP INDEX IF EXISTS public."IX_LogsComunicacao_ProjetoId";
DROP INDEX IF EXISTS public."IX_LogsComunicacao_CandidatoId";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_OccurredAt";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_Level";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_EnvironmentNormalized_OccurredAt";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_DeviceId_OccurredAt";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_Category";
DROP INDEX IF EXISTS public."IX_LogEntries_RequestLogId_Order";
DROP INDEX IF EXISTS public."IX_LocalizationConfigs_TenantId";
DROP INDEX IF EXISTS public."IX_JobPositions_TenantId_TotvsCargoBasicId_TotvsNivCargoId";
DROP INDEX IF EXISTS public."IX_JobPositions_TenantId_Code";
DROP INDEX IF EXISTS public."IX_JobPositions_NivelHierarquicoId";
DROP INDEX IF EXISTS public."IX_JobPositions_NivelCargoId";
DROP INDEX IF EXISTS public."IX_JobPositions_CentroCustoId";
DROP INDEX IF EXISTS public."IX_InboxItems_VagaId";
DROP INDEX IF EXISTS public."IX_InboxItems_TenantId_Status";
DROP INDEX IF EXISTS public."IX_InboxItems_TenantId_RecebidoEm";
DROP INDEX IF EXISTS public."IX_InboxItems_TenantId_Origem";
DROP INDEX IF EXISTS public."IX_InboxItems_CandidatoId";
DROP INDEX IF EXISTS public."IX_InboxAttachments_TenantId_InboxItemId";
DROP INDEX IF EXISTS public."IX_InboxAttachments_InboxItemId";
DROP INDEX IF EXISTS public."IX_Holerites_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Holerites_EnviadoPorId";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_TipoEntidade_StatusNovo";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_TipoEntidade_EntidadeId";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_TipoEntidade_DentroDoSla";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_AlteradoEmUtc";
DROP INDEX IF EXISTS public."IX_HistoricosAlteracaoWorkflowRH_WorkflowId_DataAlteracaoUtc";
DROP INDEX IF EXISTS public."IX_HistoricosAlteracaoWorkflowRH_EtapaWorkflowId";
DROP INDEX IF EXISTS public."IX_HistoricosAlteracaoWorkflowRH_AlteradoPorId";
DROP INDEX IF EXISTS public."IX_Hierarquias_TenantId_IdHierarquiaRm";
DROP INDEX IF EXISTS public."IX_Hierarquias_IdHierarquiaSuperiorRm";
DROP INDEX IF EXISTS public."IX_Hierarquias_HierarquiaSuperiorId";
DROP INDEX IF EXISTS public."IX_Hierarquias_Estrutura";
DROP INDEX IF EXISTS public."IX_GamificationDailyStates_UserId";
DROP INDEX IF EXISTS public."IX_GamificationDailyStates_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_GamificationDailyStates_TenantId_LastCheckInDate";
DROP INDEX IF EXISTS public."IX_Funcionarios_UserId";
DROP INDEX IF EXISTS public."IX_Funcionarios_UnitId";
DROP INDEX IF EXISTS public."IX_Funcionarios_UnidadeLotacaoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_MatriculaRm";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_Email";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_CodSituacaoRm";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_CdnEmpresa_CdnEstab_CdnFuncionario";
DROP INDEX IF EXISTS public."IX_Funcionarios_PessoaId";
DROP INDEX IF EXISTS public."IX_Funcionarios_NivelHierarquicoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_NivelCargoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_JobPositionId";
DROP INDEX IF EXISTS public."IX_Funcionarios_HierarquiaId";
DROP INDEX IF EXISTS public."IX_Funcionarios_GestorDiretoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_CentroCustoId";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_TipoMovimentacao";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_TenantId_IdReqRm";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_FuncionarioId";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_ChapaRm";
DROP INDEX IF EXISTS public."IX_FluxosAprovacaoConfig_TenantId_TipoFluxo";
DROP INDEX IF EXISTS public."IX_FeedbackItems_ToUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItems_TenantId_ToUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItems_TenantId_FromUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItems_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_FeedbackItems_FromUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItemRatings_FeedbackItemId";
DROP INDEX IF EXISTS public."IX_FasesProcesso_TenantId_ProjetoId_Ordem";
DROP INDEX IF EXISTS public."IX_FasesProcesso_ProjetoId";
DROP INDEX IF EXISTS public."IX_FaixasSalariais_TenantId_JobPositionId_EstabelecimentoCodigo";
DROP INDEX IF EXISTS public."IX_FaixasSalariais_JobPositionId";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_TransactionId";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_StatusCode";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_OccurredAt";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_ExceptionType";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_EnvironmentNormalized_OccurredAt";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_DeviceId_OccurredAt";
DROP INDEX IF EXISTS public."IX_EtapasWorkflowRH_WorkflowId_Ordem";
DROP INDEX IF EXISTS public."IX_EtapasWorkflowRH_ResponsavelId";
DROP INDEX IF EXISTS public."IX_EtapasConfigWorkflowRH_TenantId_TipoWorkflow_Ordem";
DROP INDEX IF EXISTS public."IX_EtapasConfigWorkflowRH_RoleFilaId";
DROP INDEX IF EXISTS public."IX_EtapasConfigAprovacao_TenantId_TipoFluxo_Ordem";
DROP INDEX IF EXISTS public."IX_EtapasConfigAprovacao_RoleFilaId";
DROP INDEX IF EXISTS public."IX_EtapasConfigAprovacao_FuncionarioFixoId";
DROP INDEX IF EXISTS public."IX_EntrevistasSaida_TenantId_Token";
DROP INDEX IF EXISTS public."IX_EntrevistasSaida_TenantId_DesligamentoId";
DROP INDEX IF EXISTS public."IX_EntraIdConfigs_TenantId";
DROP INDEX IF EXISTS public."IX_Empresas_TenantId_Code";
DROP INDEX IF EXISTS public."IX_EmailTemplates_TenantId_Name_Version";
DROP INDEX IF EXISTS public."IX_EmailTemplates_TenantId_Name_IsActive";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_Status";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_OwnerUserId";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_IsSystem";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_EmailConfigs_TenantId";
DROP INDEX IF EXISTS public."IX_EmailAttempts_TenantId_StartedAtUtc";
DROP INDEX IF EXISTS public."IX_EmailAttempts_TenantId_EmailMessageId";
DROP INDEX IF EXISTS public."IX_EmailAttempts_EmailMessageId";
DROP INDEX IF EXISTS public."IX_EixosVaga_TenantId_Code";
DROP INDEX IF EXISTS public."IX_EixosVaga_IsActive";
DROP INDEX IF EXISTS public."IX_DocumentosColaborador_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_DocumentosColaborador_FuncionarioId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoI~";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorNivelCargoConfigs_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId_Ti~";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorCargoConfigs_JobPositionId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_CargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_TenantId_CriadoEmUtc";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_CargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoConfigs_TenantId_TipoDocumento";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_TenantId_TargetUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_TenantId_OwnerUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_TargetUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_OwnerUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlanGoals_PlanId";
DROP INDEX IF EXISTS public."IX_Desligamentos_TenantId_IdReqRm";
DROP INDEX IF EXISTS public."IX_Desligamentos_GerouSubstituicao";
DROP INDEX IF EXISTS public."IX_Desligamentos_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Desligamentos_CodStatus";
DROP INDEX IF EXISTS public."IX_Desligamentos_ChapaRm";
DROP INDEX IF EXISTS public."IX_DescricoesCargo_TenantId_Code";
DROP INDEX IF EXISTS public."IX_DescricoesCargo_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DescricoesCargo_IsActive";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItens_TenantId_DescricaoCargoId_Categoria";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItens_TenantId_DescricaoCargoId";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItens_DescricaoCargoId";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_Tenant_Item";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_TenantId";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_Item";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_Ann";
DROP INDEX IF EXISTS public."IX_Dependentes_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Dependentes_FuncionarioId";
DROP INDEX IF EXISTS public."IX_DadosBancarios_FuncionarioId";
DROP INDEX IF EXISTS public."IX_CentrosCusto_TenantId_EmpresaId_Code";
DROP INDEX IF EXISTS public."IX_CentrosCusto_ParentId";
DROP INDEX IF EXISTS public."IX_CentrosCusto_OwnerFuncionarioId";
DROP INDEX IF EXISTS public."IX_CentrosCusto_IsActive";
DROP INDEX IF EXISTS public."IX_CentrosCusto_EmpresaId";
DROP INDEX IF EXISTS public."IX_CelebrationPosts_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_CelebrationPosts_AuthorId";
DROP INDEX IF EXISTS public."IX_CelebrationMentions_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationMentions_PostId";
DROP INDEX IF EXISTS public."IX_CelebrationComments_TenantId_PostId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_CelebrationComments_PostId";
DROP INDEX IF EXISTS public."IX_CelebrationComments_AuthorId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_CommentId_UserId_Type";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_CommentId_Type";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_CommentId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentMentions_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentMentions_CommentId_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentMentions_CommentId";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Co~";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Cod";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_IsActive";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_EstabelecimentoId";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_EmpresaId";
DROP INDEX IF EXISTS public."IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId_Percentu";
DROP INDEX IF EXISTS public."IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId";
DROP INDEX IF EXISTS public."IX_CategoriaSalarialSteps_CategoriaSalarialId";
DROP INDEX IF EXISTS public."IX_Cargos_TenantId_Code";
DROP INDEX IF EXISTS public."IX_Cargos_IsActive";
DROP INDEX IF EXISTS public."IX_Candidaturas_VagaId";
DROP INDEX IF EXISTS public."IX_Candidaturas_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_Candidaturas_TenantId_CandidatoId_VagaId";
DROP INDEX IF EXISTS public."IX_Candidaturas_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_Candidaturas_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidaturaEtapaHistoricos_TenantId_CandidaturaId";
DROP INDEX IF EXISTS public."IX_CandidaturaEtapaHistoricos_CandidaturaId";
DROP INDEX IF EXISTS public."IX_Candidatos_VagaId";
DROP INDEX IF EXISTS public."IX_Candidatos_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_Candidatos_TenantId_Email";
DROP INDEX IF EXISTS public."IX_Candidatos_TalentoId";
DROP INDEX IF EXISTS public."IX_CandidatoVagaMatchingScores_VagaId_Score";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_Vaga";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_Tenant_Vaga_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_TenantId";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoStatusHistories_TenantId_CandidatoId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_CandidatoStatusHistories_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoStatusHistories_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoReferencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoReferencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoProjetos_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoProjetos_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPreferenciasVaga_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPreferenciasVaga_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPortfolios_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPortfolios_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoNotificacaoPreferencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoNotificacaoPreferencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoLgpdConsents_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoLgpdConsents_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoExperiencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoExperiencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_Tenant_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_TenantId";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_Ann";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoResumos_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoResumos_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoItens_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoItens_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoDocumentos_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoDocumentos_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCompetencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCompetencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCertificacoes_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCertificacoes_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaPreferencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaPreferencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaBloqueios_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaBloqueios_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAcessibilidades_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAcessibilidades_CandidatoId";
DROP INDEX IF EXISTS public."IX_CamposPersonalizadosVaga_VagaId";
DROP INDEX IF EXISTS public."IX_CamposPersonalizadosVaga_TenantId_VagaId_Ordem";
DROP INDEX IF EXISTS public."IX_BatchMatchingRuns_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_BatchMatchingRunVagas_RunId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_TenantId_CicloId_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_CicloId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_AvaliadorId";
DROP INDEX IF EXISTS public."IX_AvaliacaoPerguntas_CicloId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_TenantId_CicloId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_TenantId_CicloId_AvaliadorId_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_TenantId_AvaliadorId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_CicloId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_AvaliadorId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCiclos_TenantId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoCiclos_CriadoPorId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_TenantId_CicloId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_TenantId_CicloId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_NineBoxAssessmentId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_FuncionarioId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_CicloId";
DROP INDEX IF EXISTS public."IX_AuditTransactions_UserId";
DROP INDEX IF EXISTS public."IX_AuditTransactions_TransactionId";
DROP INDEX IF EXISTS public."IX_AuditTransactions_TenantId_StartedAt";
DROP INDEX IF EXISTS public."IX_AuditTransactions_StatusCode";
DROP INDEX IF EXISTS public."IX_AuditTransactions_StartedAt";
DROP INDEX IF EXISTS public."IX_AuditTransactions_Path";
DROP INDEX IF EXISTS public."IX_AuditEvents_AuditTransactionId_Order";
DROP INDEX IF EXISTS public."IX_AuditEntityPropertyChanges_AuditEntityChangeId";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_TenantId_OccurredAt";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_TenantId_EntityName";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_AuditTransactionId";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_AuditEventId";
DROP INDEX IF EXISTS public."IX_AspNetUserLogins_UserId";
DROP INDEX IF EXISTS public."IX_AspNetUserClaims_UserId";
DROP INDEX IF EXISTS public."IX_AspNetRoleClaims_RoleId";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_TenantId_GestorId";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_TenantGestor";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_GestorId";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_AprovadorId";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_TenantId_Status";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_SolicitanteId";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_FaixaSalarialId";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_AprovadorId";
DROP INDEX IF EXISTS public."IX_ApprovalMagicLinks_TenantId_Token";
DROP INDEX IF EXISTS public."IX_ApiKeys_TenantId_Name";
DROP INDEX IF EXISTS public."IX_ApiKeys_TenantId_KeyHash";
DROP INDEX IF EXISTS public."IX_AgendaEvents_TypeId";
DROP INDEX IF EXISTS public."IX_AgendaEvents_TenantId_StartAtUtc";
DROP INDEX IF EXISTS public."IX_AgendaEventTypes_TenantId_Code";
DROP INDEX IF EXISTS public."EmailIndex";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "PK_WorkflowsRH";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "PK_Vagas";
ALTER TABLE IF EXISTS ONLY public."VagaUnifiedMatchingCaches" DROP CONSTRAINT IF EXISTS "PK_VagaUnifiedMatchingCaches";
ALTER TABLE IF EXISTS ONLY public."VagaRequisitos" DROP CONSTRAINT IF EXISTS "PK_VagaRequisitos";
ALTER TABLE IF EXISTS ONLY public."VagaPerguntas" DROP CONSTRAINT IF EXISTS "PK_VagaPerguntas";
ALTER TABLE IF EXISTS ONLY public."VagaEtapas" DROP CONSTRAINT IF EXISTS "PK_VagaEtapas";
ALTER TABLE IF EXISTS ONLY public."VagaBeneficios" DROP CONSTRAINT IF EXISTS "PK_VagaBeneficios";
ALTER TABLE IF EXISTS ONLY public."Users" DROP CONSTRAINT IF EXISTS "PK_Users";
ALTER TABLE IF EXISTS ONLY public."UserUnits" DROP CONSTRAINT IF EXISTS "PK_UserUnits";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "PK_UserRoles";
ALTER TABLE IF EXISTS ONLY public."Units" DROP CONSTRAINT IF EXISTS "PK_Units";
ALTER TABLE IF EXISTS ONLY public."UnidadesLotacao" DROP CONSTRAINT IF EXISTS "PK_UnidadesLotacao";
ALTER TABLE IF EXISTS ONLY public."Turnos" DROP CONSTRAINT IF EXISTS "PK_Turnos";
ALTER TABLE IF EXISTS ONLY public."TenantConfiguracoes" DROP CONSTRAINT IF EXISTS "PK_TenantConfiguracoes";
ALTER TABLE IF EXISTS ONLY public."TenantBrandings" DROP CONSTRAINT IF EXISTS "PK_TenantBrandings";
ALTER TABLE IF EXISTS ONLY public."TenantAwsSettings" DROP CONSTRAINT IF EXISTS "PK_TenantAwsSettings";
ALTER TABLE IF EXISTS ONLY public."TemplatesEntrevistaSaida" DROP CONSTRAINT IF EXISTS "PK_TemplatesEntrevistaSaida";
ALTER TABLE IF EXISTS ONLY public."Talentos" DROP CONSTRAINT IF EXISTS "PK_Talentos";
ALTER TABLE IF EXISTS ONLY public."TalentoTreinamentos" DROP CONSTRAINT IF EXISTS "PK_TalentoTreinamentos";
ALTER TABLE IF EXISTS ONLY public."TalentoFormacoes" DROP CONSTRAINT IF EXISTS "PK_TalentoFormacoes";
ALTER TABLE IF EXISTS ONLY public."TalentoExperiencias" DROP CONSTRAINT IF EXISTS "PK_TalentoExperiencias";
ALTER TABLE IF EXISTS ONLY public."TalentoDocumentos" DROP CONSTRAINT IF EXISTS "PK_TalentoDocumentos";
ALTER TABLE IF EXISTS ONLY public."TalentoCvImportJobs" DROP CONSTRAINT IF EXISTS "PK_TalentoCvImportJobs";
ALTER TABLE IF EXISTS ONLY public."TalentoCompetencias" DROP CONSTRAINT IF EXISTS "PK_TalentoCompetencias";
ALTER TABLE IF EXISTS ONLY public."Surveys" DROP CONSTRAINT IF EXISTS "PK_Surveys";
ALTER TABLE IF EXISTS ONLY public."SurveyResponses" DROP CONSTRAINT IF EXISTS "PK_SurveyResponses";
ALTER TABLE IF EXISTS ONLY public."SurveyQuestions" DROP CONSTRAINT IF EXISTS "PK_SurveyQuestions";
ALTER TABLE IF EXISTS ONLY public."SurveyOptions" DROP CONSTRAINT IF EXISTS "PK_SurveyOptions";
ALTER TABLE IF EXISTS ONLY public."SurveyAnswers" DROP CONSTRAINT IF EXISTS "PK_SurveyAnswers";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesVaga";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesPromocao";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesPagamentoExtra";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesFerias" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesFerias";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesEndereco" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesEndereco";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesDesligamento";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDependente" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesDependente";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesBeneficio" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesBeneficio";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesAprovacaoEtapas" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesAprovacaoEtapas";
ALTER TABLE IF EXISTS ONLY public."SlaStatusConfigs" DROP CONSTRAINT IF EXISTS "PK_SlaStatusConfigs";
ALTER TABLE IF EXISTS ONLY public."Skills" DROP CONSTRAINT IF EXISTS "PK_Skills";
ALTER TABLE IF EXISTS ONLY public."SkillAliases" DROP CONSTRAINT IF EXISTS "PK_SkillAliases";
ALTER TABLE IF EXISTS ONLY public."Roles" DROP CONSTRAINT IF EXISTS "PK_Roles";
ALTER TABLE IF EXISTS ONLY public."RoleMenus" DROP CONSTRAINT IF EXISTS "PK_RoleMenus";
ALTER TABLE IF EXISTS ONLY public."RmSyncRuns" DROP CONSTRAINT IF EXISTS "PK_RmSyncRuns";
ALTER TABLE IF EXISTS ONLY public."RmSyncCheckpoints" DROP CONSTRAINT IF EXISTS "PK_RmSyncCheckpoints";
ALTER TABLE IF EXISTS ONLY public."RmSyncAlertas" DROP CONSTRAINT IF EXISTS "PK_RmSyncAlertas";
ALTER TABLE IF EXISTS ONLY public."RespostasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "PK_RespostasEntrevistaSaida";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "PK_RespostasCampoPersonalizadoVaga";
ALTER TABLE IF EXISTS ONLY public."RequestLogs" DROP CONSTRAINT IF EXISTS "PK_RequestLogs";
ALTER TABLE IF EXISTS ONLY public."RenderCoinTransactions" DROP CONSTRAINT IF EXISTS "PK_RenderCoinTransactions";
ALTER TABLE IF EXISTS ONLY public."RenderCoinBalances" DROP CONSTRAINT IF EXISTS "PK_RenderCoinBalances";
ALTER TABLE IF EXISTS ONLY public."RecruiterMatchingFeedbacks" DROP CONSTRAINT IF EXISTS "PK_RecruiterMatchingFeedbacks";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "PK_PropostasVaga";
ALTER TABLE IF EXISTS ONLY public."ProjetosVaga" DROP CONSTRAINT IF EXISTS "PK_ProjetosVaga";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "PK_ProjetoCandidatos";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "PK_PreAdmissoes";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentosSolicitados" DROP CONSTRAINT IF EXISTS "PK_PreAdmissaoDocumentosSolicitados";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentos" DROP CONSTRAINT IF EXISTS "PK_PreAdmissaoDocumentos";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDependentes" DROP CONSTRAINT IF EXISTS "PK_PreAdmissaoDependentes";
ALTER TABLE IF EXISTS ONLY public."Pessoas" DROP CONSTRAINT IF EXISTS "PK_Pessoas";
ALTER TABLE IF EXISTS ONLY public."PessoaBloqueios" DROP CONSTRAINT IF EXISTS "PK_PessoaBloqueios";
ALTER TABLE IF EXISTS ONLY public."PermissoesNivelVaga" DROP CONSTRAINT IF EXISTS "PK_PermissoesNivelVaga";
ALTER TABLE IF EXISTS ONLY public."PerguntasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "PK_PerguntasEntrevistaSaida";
ALTER TABLE IF EXISTS ONLY public."OneOnOneMeetings" DROP CONSTRAINT IF EXISTS "PK_OneOnOneMeetings";
ALTER TABLE IF EXISTS ONLY public."OcupacoesHistorico" DROP CONSTRAINT IF EXISTS "PK_OcupacoesHistorico";
ALTER TABLE IF EXISTS ONLY public."Notifications" DROP CONSTRAINT IF EXISTS "PK_Notifications";
ALTER TABLE IF EXISTS ONLY public."NotificationReceipts" DROP CONSTRAINT IF EXISTS "PK_NotificationReceipts";
ALTER TABLE IF EXISTS ONLY public."NotificacoesTemplates" DROP CONSTRAINT IF EXISTS "PK_NotificacoesTemplates";
ALTER TABLE IF EXISTS ONLY public."NotificacoesCandidaturaLogs" DROP CONSTRAINT IF EXISTS "PK_NotificacoesCandidaturaLogs";
ALTER TABLE IF EXISTS ONLY public."NiveisHierarquicos" DROP CONSTRAINT IF EXISTS "PK_NiveisHierarquicos";
ALTER TABLE IF EXISTS ONLY public."NiveisCargo" DROP CONSTRAINT IF EXISTS "PK_NiveisCargo";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "PK_NineBoxAssessments";
ALTER TABLE IF EXISTS ONLY public."MoodEntries" DROP CONSTRAINT IF EXISTS "PK_MoodEntries";
ALTER TABLE IF EXISTS ONLY public."Metas" DROP CONSTRAINT IF EXISTS "PK_Metas";
ALTER TABLE IF EXISTS ONLY public."Menus" DROP CONSTRAINT IF EXISTS "PK_Menus";
ALTER TABLE IF EXISTS ONLY public."LogsComunicacao" DROP CONSTRAINT IF EXISTS "PK_LogsComunicacao";
ALTER TABLE IF EXISTS ONLY public."LogEntries" DROP CONSTRAINT IF EXISTS "PK_LogEntries";
ALTER TABLE IF EXISTS ONLY public."LocalizationConfigs" DROP CONSTRAINT IF EXISTS "PK_LocalizationConfigs";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "PK_JobPositions";
ALTER TABLE IF EXISTS ONLY public."InboxItems" DROP CONSTRAINT IF EXISTS "PK_InboxItems";
ALTER TABLE IF EXISTS ONLY public."InboxAttachments" DROP CONSTRAINT IF EXISTS "PK_InboxAttachments";
ALTER TABLE IF EXISTS ONLY public."Holerites" DROP CONSTRAINT IF EXISTS "PK_Holerites";
ALTER TABLE IF EXISTS ONLY public."HistoricosStatus" DROP CONSTRAINT IF EXISTS "PK_HistoricosStatus";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "PK_HistoricosAlteracaoWorkflowRH";
ALTER TABLE IF EXISTS ONLY public."Hierarquias" DROP CONSTRAINT IF EXISTS "PK_Hierarquias";
ALTER TABLE IF EXISTS ONLY public."GamificationDailyStates" DROP CONSTRAINT IF EXISTS "PK_GamificationDailyStates";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "PK_Funcionarios";
ALTER TABLE IF EXISTS ONLY public."FuncionarioMovimentacoes" DROP CONSTRAINT IF EXISTS "PK_FuncionarioMovimentacoes";
ALTER TABLE IF EXISTS ONLY public."FluxosAprovacaoConfig" DROP CONSTRAINT IF EXISTS "PK_FluxosAprovacaoConfig";
ALTER TABLE IF EXISTS ONLY public."FeedbackItems" DROP CONSTRAINT IF EXISTS "PK_FeedbackItems";
ALTER TABLE IF EXISTS ONLY public."FeedbackItemRatings" DROP CONSTRAINT IF EXISTS "PK_FeedbackItemRatings";
ALTER TABLE IF EXISTS ONLY public."FasesProcesso" DROP CONSTRAINT IF EXISTS "PK_FasesProcesso";
ALTER TABLE IF EXISTS ONLY public."FaixasSalariais" DROP CONSTRAINT IF EXISTS "PK_FaixasSalariais";
ALTER TABLE IF EXISTS ONLY public."ExceptionLogs" DROP CONSTRAINT IF EXISTS "PK_ExceptionLogs";
ALTER TABLE IF EXISTS ONLY public."EtapasWorkflowRH" DROP CONSTRAINT IF EXISTS "PK_EtapasWorkflowRH";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigWorkflowRH" DROP CONSTRAINT IF EXISTS "PK_EtapasConfigWorkflowRH";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigAprovacao" DROP CONSTRAINT IF EXISTS "PK_EtapasConfigAprovacao";
ALTER TABLE IF EXISTS ONLY public."EntrevistasSaida" DROP CONSTRAINT IF EXISTS "PK_EntrevistasSaida";
ALTER TABLE IF EXISTS ONLY public."EntraIdConfigs" DROP CONSTRAINT IF EXISTS "PK_EntraIdConfigs";
ALTER TABLE IF EXISTS ONLY public."Empresas" DROP CONSTRAINT IF EXISTS "PK_Empresas";
ALTER TABLE IF EXISTS ONLY public."EmailTemplates" DROP CONSTRAINT IF EXISTS "PK_EmailTemplates";
ALTER TABLE IF EXISTS ONLY public."EmailMessages" DROP CONSTRAINT IF EXISTS "PK_EmailMessages";
ALTER TABLE IF EXISTS ONLY public."EmailConfigs" DROP CONSTRAINT IF EXISTS "PK_EmailConfigs";
ALTER TABLE IF EXISTS ONLY public."EmailAttempts" DROP CONSTRAINT IF EXISTS "PK_EmailAttempts";
ALTER TABLE IF EXISTS ONLY public."EixosVaga" DROP CONSTRAINT IF EXISTS "PK_EixosVaga";
ALTER TABLE IF EXISTS ONLY public."DocumentosColaborador" DROP CONSTRAINT IF EXISTS "PK_DocumentosColaborador";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorNivelCargoConfigs" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoPorNivelCargoConfigs";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorCargoConfigs" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoPorCargoConfigs";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoHistoricos" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoHistoricos";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoConfigs" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoConfigs";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlans" DROP CONSTRAINT IF EXISTS "PK_DevelopmentPlans";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlanGoals" DROP CONSTRAINT IF EXISTS "PK_DevelopmentPlanGoals";
ALTER TABLE IF EXISTS ONLY public."Desligamentos" DROP CONSTRAINT IF EXISTS "PK_Desligamentos";
ALTER TABLE IF EXISTS ONLY public."DescricoesCargo" DROP CONSTRAINT IF EXISTS "PK_DescricoesCargo";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItens" DROP CONSTRAINT IF EXISTS "PK_DescricaoCargoItens";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItemEmbeddings" DROP CONSTRAINT IF EXISTS "PK_DescricaoCargoItemEmbeddings";
ALTER TABLE IF EXISTS ONLY public."Dependentes" DROP CONSTRAINT IF EXISTS "PK_Dependentes";
ALTER TABLE IF EXISTS ONLY public."DadosBancarios" DROP CONSTRAINT IF EXISTS "PK_DadosBancarios";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "PK_CentrosCusto";
ALTER TABLE IF EXISTS ONLY public."CelebrationPosts" DROP CONSTRAINT IF EXISTS "PK_CelebrationPosts";
ALTER TABLE IF EXISTS ONLY public."CelebrationMentions" DROP CONSTRAINT IF EXISTS "PK_CelebrationMentions";
ALTER TABLE IF EXISTS ONLY public."CelebrationComments" DROP CONSTRAINT IF EXISTS "PK_CelebrationComments";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentReactions" DROP CONSTRAINT IF EXISTS "PK_CelebrationCommentReactions";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentMentions" DROP CONSTRAINT IF EXISTS "PK_CelebrationCommentMentions";
ALTER TABLE IF EXISTS ONLY public."CategoriasSalariais" DROP CONSTRAINT IF EXISTS "PK_CategoriasSalariais";
ALTER TABLE IF EXISTS ONLY public."CategoriaSalarialSteps" DROP CONSTRAINT IF EXISTS "PK_CategoriaSalarialSteps";
ALTER TABLE IF EXISTS ONLY public."Cargos" DROP CONSTRAINT IF EXISTS "PK_Cargos";
ALTER TABLE IF EXISTS ONLY public."Candidaturas" DROP CONSTRAINT IF EXISTS "PK_Candidaturas";
ALTER TABLE IF EXISTS ONLY public."CandidaturaEtapaHistoricos" DROP CONSTRAINT IF EXISTS "PK_CandidaturaEtapaHistoricos";
ALTER TABLE IF EXISTS ONLY public."Candidatos" DROP CONSTRAINT IF EXISTS "PK_Candidatos";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaMatchingScores" DROP CONSTRAINT IF EXISTS "PK_CandidatoVagaMatchingScores";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaLlmScores" DROP CONSTRAINT IF EXISTS "PK_CandidatoVagaLlmScores";
ALTER TABLE IF EXISTS ONLY public."CandidatoStatusHistories" DROP CONSTRAINT IF EXISTS "PK_CandidatoStatusHistories";
ALTER TABLE IF EXISTS ONLY public."CandidatoReferencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoReferencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoProjetos" DROP CONSTRAINT IF EXISTS "PK_CandidatoProjetos";
ALTER TABLE IF EXISTS ONLY public."CandidatoPreferenciasVaga" DROP CONSTRAINT IF EXISTS "PK_CandidatoPreferenciasVaga";
ALTER TABLE IF EXISTS ONLY public."CandidatoPortfolios" DROP CONSTRAINT IF EXISTS "PK_CandidatoPortfolios";
ALTER TABLE IF EXISTS ONLY public."CandidatoNotificacaoPreferencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoNotificacaoPreferencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoLgpdConsents" DROP CONSTRAINT IF EXISTS "PK_CandidatoLgpdConsents";
ALTER TABLE IF EXISTS ONLY public."CandidatoExperiencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoExperiencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoEmbeddings" DROP CONSTRAINT IF EXISTS "PK_CandidatoEmbeddings";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoResumos" DROP CONSTRAINT IF EXISTS "PK_CandidatoEducacaoResumos";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoItens" DROP CONSTRAINT IF EXISTS "PK_CandidatoEducacaoItens";
ALTER TABLE IF EXISTS ONLY public."CandidatoDocumentos" DROP CONSTRAINT IF EXISTS "PK_CandidatoDocumentos";
ALTER TABLE IF EXISTS ONLY public."CandidatoCompetencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoCompetencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoCertificacoes" DROP CONSTRAINT IF EXISTS "PK_CandidatoCertificacoes";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaPreferencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoAgendaPreferencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaBloqueios" DROP CONSTRAINT IF EXISTS "PK_CandidatoAgendaBloqueios";
ALTER TABLE IF EXISTS ONLY public."CandidatoAcessibilidades" DROP CONSTRAINT IF EXISTS "PK_CandidatoAcessibilidades";
ALTER TABLE IF EXISTS ONLY public."CamposPersonalizadosVaga" DROP CONSTRAINT IF EXISTS "PK_CamposPersonalizadosVaga";
ALTER TABLE IF EXISTS ONLY public."BatchMatchingRuns" DROP CONSTRAINT IF EXISTS "PK_BatchMatchingRuns";
ALTER TABLE IF EXISTS ONLY public."BatchMatchingRunVagas" DROP CONSTRAINT IF EXISTS "PK_BatchMatchingRunVagas";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoRespostas";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoPerguntas" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoPerguntas";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoConvites";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCiclos" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoCiclos";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoCalibragens";
ALTER TABLE IF EXISTS ONLY public."AuditTransactions" DROP CONSTRAINT IF EXISTS "PK_AuditTransactions";
ALTER TABLE IF EXISTS ONLY public."AuditEvents" DROP CONSTRAINT IF EXISTS "PK_AuditEvents";
ALTER TABLE IF EXISTS ONLY public."AuditEntityPropertyChanges" DROP CONSTRAINT IF EXISTS "PK_AuditEntityPropertyChanges";
ALTER TABLE IF EXISTS ONLY public."AuditEntityChanges" DROP CONSTRAINT IF EXISTS "PK_AuditEntityChanges";
ALTER TABLE IF EXISTS ONLY public."AspNetUserTokens" DROP CONSTRAINT IF EXISTS "PK_AspNetUserTokens";
ALTER TABLE IF EXISTS ONLY public."AspNetUserLogins" DROP CONSTRAINT IF EXISTS "PK_AspNetUserLogins";
ALTER TABLE IF EXISTS ONLY public."AspNetUserClaims" DROP CONSTRAINT IF EXISTS "PK_AspNetUserClaims";
ALTER TABLE IF EXISTS ONLY public."AspNetRoleClaims" DROP CONSTRAINT IF EXISTS "PK_AspNetRoleClaims";
ALTER TABLE IF EXISTS ONLY public."AprovadoresAlternativos" DROP CONSTRAINT IF EXISTS "PK_AprovadoresAlternativos";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "PK_AprovacoesFaixaSalarial";
ALTER TABLE IF EXISTS ONLY public."ApprovalMagicLinks" DROP CONSTRAINT IF EXISTS "PK_ApprovalMagicLinks";
ALTER TABLE IF EXISTS ONLY public."ApiKeys" DROP CONSTRAINT IF EXISTS "PK_ApiKeys";
ALTER TABLE IF EXISTS ONLY public."AgendaEvents" DROP CONSTRAINT IF EXISTS "PK_AgendaEvents";
ALTER TABLE IF EXISTS ONLY public."AgendaEventTypes" DROP CONSTRAINT IF EXISTS "PK_AgendaEventTypes";
ALTER TABLE IF EXISTS ONLY public."MotivosRequisicaoVagaConfig" DROP CONSTRAINT IF EXISTS "MotivosRequisicaoVagaConfig_pkey";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS public."WorkflowsRH";
DROP TABLE IF EXISTS public."Vagas";
DROP TABLE IF EXISTS public."VagaUnifiedMatchingCaches";
DROP TABLE IF EXISTS public."VagaRequisitos";
DROP TABLE IF EXISTS public."VagaPerguntas";
DROP TABLE IF EXISTS public."VagaEtapas";
DROP TABLE IF EXISTS public."VagaBeneficios";
DROP TABLE IF EXISTS public."Users";
DROP TABLE IF EXISTS public."UserUnits";
DROP TABLE IF EXISTS public."UserRoles";
DROP TABLE IF EXISTS public."Units";
DROP TABLE IF EXISTS public."UnidadesLotacao";
DROP TABLE IF EXISTS public."Turnos";
DROP TABLE IF EXISTS public."TenantConfiguracoes";
DROP TABLE IF EXISTS public."TenantBrandings";
DROP TABLE IF EXISTS public."TenantAwsSettings";
DROP TABLE IF EXISTS public."TemplatesEntrevistaSaida";
DROP TABLE IF EXISTS public."Talentos";
DROP TABLE IF EXISTS public."TalentoTreinamentos";
DROP TABLE IF EXISTS public."TalentoFormacoes";
DROP TABLE IF EXISTS public."TalentoExperiencias";
DROP TABLE IF EXISTS public."TalentoDocumentos";
DROP TABLE IF EXISTS public."TalentoCvImportJobs";
DROP TABLE IF EXISTS public."TalentoCompetencias";
DROP TABLE IF EXISTS public."Surveys";
DROP TABLE IF EXISTS public."SurveyResponses";
DROP TABLE IF EXISTS public."SurveyQuestions";
DROP TABLE IF EXISTS public."SurveyOptions";
DROP TABLE IF EXISTS public."SurveyAnswers";
DROP TABLE IF EXISTS public."SolicitacoesVaga";
DROP TABLE IF EXISTS public."SolicitacoesPromocao";
DROP TABLE IF EXISTS public."SolicitacoesPagamentoExtra";
DROP TABLE IF EXISTS public."SolicitacoesFerias";
DROP TABLE IF EXISTS public."SolicitacoesEndereco";
DROP TABLE IF EXISTS public."SolicitacoesDesligamento";
DROP TABLE IF EXISTS public."SolicitacoesDependente";
DROP TABLE IF EXISTS public."SolicitacoesBeneficio";
DROP TABLE IF EXISTS public."SolicitacoesAprovacaoEtapas";
DROP TABLE IF EXISTS public."SlaStatusConfigs";
DROP TABLE IF EXISTS public."Skills";
DROP TABLE IF EXISTS public."SkillAliases";
DROP TABLE IF EXISTS public."Roles";
DROP TABLE IF EXISTS public."RoleMenus";
DROP TABLE IF EXISTS public."RmSyncRuns";
DROP TABLE IF EXISTS public."RmSyncCheckpoints";
DROP TABLE IF EXISTS public."RmSyncAlertas";
DROP TABLE IF EXISTS public."RespostasEntrevistaSaida";
DROP TABLE IF EXISTS public."RespostasCampoPersonalizadoVaga";
DROP TABLE IF EXISTS public."RequestLogs";
DROP TABLE IF EXISTS public."RenderCoinTransactions";
DROP TABLE IF EXISTS public."RenderCoinBalances";
DROP TABLE IF EXISTS public."RecruiterMatchingFeedbacks";
DROP TABLE IF EXISTS public."PropostasVaga";
DROP TABLE IF EXISTS public."ProjetosVaga";
DROP TABLE IF EXISTS public."ProjetoCandidatos";
DROP TABLE IF EXISTS public."PreAdmissoes";
DROP TABLE IF EXISTS public."PreAdmissaoDocumentosSolicitados";
DROP TABLE IF EXISTS public."PreAdmissaoDocumentos";
DROP TABLE IF EXISTS public."PreAdmissaoDependentes";
DROP TABLE IF EXISTS public."Pessoas";
DROP TABLE IF EXISTS public."PessoaBloqueios";
DROP TABLE IF EXISTS public."PermissoesNivelVaga";
DROP TABLE IF EXISTS public."PerguntasEntrevistaSaida";
DROP TABLE IF EXISTS public."OneOnOneMeetings";
DROP TABLE IF EXISTS public."OcupacoesHistorico";
DROP TABLE IF EXISTS public."Notifications";
DROP TABLE IF EXISTS public."NotificationReceipts";
DROP TABLE IF EXISTS public."NotificacoesTemplates";
DROP TABLE IF EXISTS public."NotificacoesCandidaturaLogs";
DROP TABLE IF EXISTS public."NiveisHierarquicos";
DROP TABLE IF EXISTS public."NiveisCargo";
DROP TABLE IF EXISTS public."NineBoxAssessments";
DROP TABLE IF EXISTS public."MotivosRequisicaoVagaConfig";
DROP TABLE IF EXISTS public."MoodEntries";
DROP TABLE IF EXISTS public."Metas";
DROP TABLE IF EXISTS public."Menus";
DROP TABLE IF EXISTS public."LogsComunicacao";
DROP TABLE IF EXISTS public."LogEntries";
DROP TABLE IF EXISTS public."LocalizationConfigs";
DROP TABLE IF EXISTS public."JobPositions";
DROP TABLE IF EXISTS public."InboxItems";
DROP TABLE IF EXISTS public."InboxAttachments";
DROP TABLE IF EXISTS public."Holerites";
DROP TABLE IF EXISTS public."HistoricosStatus";
DROP TABLE IF EXISTS public."HistoricosAlteracaoWorkflowRH";
DROP TABLE IF EXISTS public."Hierarquias";
DROP TABLE IF EXISTS public."GamificationDailyStates";
DROP TABLE IF EXISTS public."Funcionarios";
DROP TABLE IF EXISTS public."FuncionarioMovimentacoes";
DROP TABLE IF EXISTS public."FluxosAprovacaoConfig";
DROP TABLE IF EXISTS public."FeedbackItems";
DROP TABLE IF EXISTS public."FeedbackItemRatings";
DROP TABLE IF EXISTS public."FasesProcesso";
DROP TABLE IF EXISTS public."FaixasSalariais";
DROP TABLE IF EXISTS public."ExceptionLogs";
DROP TABLE IF EXISTS public."EtapasWorkflowRH";
DROP TABLE IF EXISTS public."EtapasConfigWorkflowRH";
DROP TABLE IF EXISTS public."EtapasConfigAprovacao";
DROP TABLE IF EXISTS public."EntrevistasSaida";
DROP TABLE IF EXISTS public."EntraIdConfigs";
DROP TABLE IF EXISTS public."Empresas";
DROP TABLE IF EXISTS public."EmailTemplates";
DROP TABLE IF EXISTS public."EmailMessages";
DROP TABLE IF EXISTS public."EmailConfigs";
DROP TABLE IF EXISTS public."EmailAttempts";
DROP TABLE IF EXISTS public."EixosVaga";
DROP TABLE IF EXISTS public."DocumentosColaborador";
DROP TABLE IF EXISTS public."DocumentacaoPadraoPorNivelCargoConfigs";
DROP TABLE IF EXISTS public."DocumentacaoPadraoPorCargoConfigs";
DROP TABLE IF EXISTS public."DocumentacaoPadraoHistoricos";
DROP TABLE IF EXISTS public."DocumentacaoPadraoConfigs";
DROP TABLE IF EXISTS public."DevelopmentPlans";
DROP TABLE IF EXISTS public."DevelopmentPlanGoals";
DROP TABLE IF EXISTS public."Desligamentos";
DROP TABLE IF EXISTS public."DescricoesCargo";
DROP TABLE IF EXISTS public."DescricaoCargoItens";
DROP TABLE IF EXISTS public."DescricaoCargoItemEmbeddings";
DROP TABLE IF EXISTS public."Dependentes";
DROP TABLE IF EXISTS public."DadosBancarios";
DROP TABLE IF EXISTS public."CentrosCusto";
DROP TABLE IF EXISTS public."CelebrationPosts";
DROP TABLE IF EXISTS public."CelebrationMentions";
DROP TABLE IF EXISTS public."CelebrationComments";
DROP TABLE IF EXISTS public."CelebrationCommentReactions";
DROP TABLE IF EXISTS public."CelebrationCommentMentions";
DROP TABLE IF EXISTS public."CategoriasSalariais";
DROP TABLE IF EXISTS public."CategoriaSalarialSteps";
DROP TABLE IF EXISTS public."Cargos";
DROP TABLE IF EXISTS public."Candidaturas";
DROP TABLE IF EXISTS public."CandidaturaEtapaHistoricos";
DROP TABLE IF EXISTS public."Candidatos";
DROP TABLE IF EXISTS public."CandidatoVagaMatchingScores";
DROP TABLE IF EXISTS public."CandidatoVagaLlmScores";
DROP TABLE IF EXISTS public."CandidatoStatusHistories";
DROP TABLE IF EXISTS public."CandidatoReferencias";
DROP TABLE IF EXISTS public."CandidatoProjetos";
DROP TABLE IF EXISTS public."CandidatoPreferenciasVaga";
DROP TABLE IF EXISTS public."CandidatoPortfolios";
DROP TABLE IF EXISTS public."CandidatoNotificacaoPreferencias";
DROP TABLE IF EXISTS public."CandidatoLgpdConsents";
DROP TABLE IF EXISTS public."CandidatoExperiencias";
DROP TABLE IF EXISTS public."CandidatoEmbeddings";
DROP TABLE IF EXISTS public."CandidatoEducacaoResumos";
DROP TABLE IF EXISTS public."CandidatoEducacaoItens";
DROP TABLE IF EXISTS public."CandidatoDocumentos";
DROP TABLE IF EXISTS public."CandidatoCompetencias";
DROP TABLE IF EXISTS public."CandidatoCertificacoes";
DROP TABLE IF EXISTS public."CandidatoAgendaPreferencias";
DROP TABLE IF EXISTS public."CandidatoAgendaBloqueios";
DROP TABLE IF EXISTS public."CandidatoAcessibilidades";
DROP TABLE IF EXISTS public."CamposPersonalizadosVaga";
DROP TABLE IF EXISTS public."BatchMatchingRuns";
DROP TABLE IF EXISTS public."BatchMatchingRunVagas";
DROP TABLE IF EXISTS public."AvaliacaoRespostas";
DROP TABLE IF EXISTS public."AvaliacaoPerguntas";
DROP TABLE IF EXISTS public."AvaliacaoConvites";
DROP TABLE IF EXISTS public."AvaliacaoCiclos";
DROP TABLE IF EXISTS public."AvaliacaoCalibragens";
DROP TABLE IF EXISTS public."AuditTransactions";
DROP TABLE IF EXISTS public."AuditEvents";
DROP TABLE IF EXISTS public."AuditEntityPropertyChanges";
DROP TABLE IF EXISTS public."AuditEntityChanges";
DROP TABLE IF EXISTS public."AspNetUserTokens";
DROP TABLE IF EXISTS public."AspNetUserLogins";
DROP TABLE IF EXISTS public."AspNetUserClaims";
DROP TABLE IF EXISTS public."AspNetRoleClaims";
DROP TABLE IF EXISTS public."AprovadoresAlternativos";
DROP TABLE IF EXISTS public."AprovacoesFaixaSalarial";
DROP TABLE IF EXISTS public."ApprovalMagicLinks";
DROP TABLE IF EXISTS public."ApiKeys";
DROP TABLE IF EXISTS public."AgendaEvents";
DROP TABLE IF EXISTS public."AgendaEventTypes";
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AgendaEventTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AgendaEventTypes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(40) NOT NULL,
    "Label" character varying(120) NOT NULL,
    "Color" character varying(20) NOT NULL,
    "Icon" character varying(80) NOT NULL,
    "SortOrder" integer NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: AgendaEvents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AgendaEvents" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TypeId" uuid NOT NULL,
    "Title" character varying(240) NOT NULL,
    "StartAtUtc" timestamp with time zone NOT NULL,
    "EndAtUtc" timestamp with time zone NOT NULL,
    "AllDay" boolean NOT NULL,
    "Status" character varying(40) NOT NULL,
    "Location" character varying(160),
    "Owner" character varying(120),
    "Candidate" character varying(160),
    "VagaTitle" character varying(200),
    "VagaCode" character varying(40),
    "Notes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: ApiKeys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ApiKeys" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "KeyHash" character varying(64) NOT NULL,
    "Description" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "LastUsedAtUtc" timestamp with time zone
);


--
-- Name: ApprovalMagicLinks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ApprovalMagicLinks" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Token" character varying(64) NOT NULL,
    "EtapaId" uuid NOT NULL,
    "SolicitacaoId" uuid NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "AprovadorFuncionarioId" uuid NOT NULL,
    "ExpiresAtUtc" timestamp with time zone NOT NULL,
    "UsedAtUtc" timestamp with time zone,
    "AcaoRealizada" smallint,
    "IpAddress" character varying(45),
    "UserAgent" character varying(512),
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: AprovacoesFaixaSalarial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AprovacoesFaixaSalarial" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FaixaSalarialId" uuid NOT NULL,
    "SolicitanteId" uuid,
    "ValorProposto" numeric(18,2) NOT NULL,
    "Justificativa" character varying(1000),
    "Status" smallint NOT NULL,
    "AprovadorId" uuid,
    "ObservacaoAprovador" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "AprovadoEmUtc" timestamp with time zone
);


--
-- Name: AprovadoresAlternativos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AprovadoresAlternativos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "GestorId" uuid NOT NULL,
    "AprovadorId" uuid NOT NULL,
    "DataInicio" date NOT NULL,
    "DataFim" date,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: AspNetRoleClaims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetRoleClaims" (
    "Id" integer NOT NULL,
    "RoleId" uuid NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."AspNetRoleClaims" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."AspNetRoleClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: AspNetUserClaims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetUserClaims" (
    "Id" integer NOT NULL,
    "UserId" uuid NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."AspNetUserClaims" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."AspNetUserClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: AspNetUserLogins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetUserLogins" (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" uuid NOT NULL
);


--
-- Name: AspNetUserTokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetUserTokens" (
    "UserId" uuid NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


--
-- Name: AuditEntityChanges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditEntityChanges" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuditTransactionId" uuid NOT NULL,
    "AuditEventId" uuid,
    "Order" integer NOT NULL,
    "EntityName" character varying(200) NOT NULL,
    "TableName" character varying(200),
    "State" character varying(20) NOT NULL,
    "PrimaryKeyJson" jsonb NOT NULL,
    "BeforeJson" jsonb,
    "AfterJson" jsonb,
    "ChangedColumns" character varying(500),
    "DataJson" jsonb,
    "OccurredAt" timestamp with time zone NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AuditEntityPropertyChanges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditEntityPropertyChanges" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuditEntityChangeId" uuid NOT NULL,
    "PropertyName" character varying(200) NOT NULL,
    "BeforeValue" character varying(2000),
    "AfterValue" character varying(2000),
    "IsSensitive" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AuditEvents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditEvents" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuditTransactionId" uuid NOT NULL,
    "Order" integer NOT NULL,
    "EventType" character varying(40) NOT NULL,
    "Name" character varying(200) NOT NULL,
    "OccurredAt" timestamp with time zone NOT NULL,
    "DataJson" jsonb,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AuditTransactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditTransactions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "CorrelationId" character varying(200),
    "TraceId" character varying(200),
    "SpanId" character varying(200),
    "ParentSpanId" character varying(200),
    "Environment" character varying(40) NOT NULL,
    "AppVersion" character varying(40) NOT NULL,
    "StartedAt" timestamp with time zone NOT NULL,
    "EndedAt" timestamp with time zone,
    "DurationMs" bigint NOT NULL,
    "UserId" character varying(120),
    "UserName" character varying(200),
    "ClientId" character varying(120),
    "Ip" character varying(80),
    "UserAgent" character varying(400),
    "Host" character varying(200),
    "Method" character varying(16) NOT NULL,
    "Path" character varying(512) NOT NULL,
    "QueryString" character varying(1024),
    "RouteTemplate" character varying(512),
    "Controller" character varying(120),
    "Action" character varying(120),
    "StatusCode" integer,
    "IsSuccess" boolean NOT NULL,
    "RequestContentType" text,
    "ResponseContentType" text,
    "RequestBody" text,
    "ResponseBody" text,
    "RequestBodyHash" character varying(64),
    "ResponseBodyHash" character varying(64),
    "RequestIsTruncated" boolean NOT NULL,
    "ResponseIsTruncated" boolean NOT NULL,
    "RequestTruncatedBytes" integer NOT NULL,
    "ResponseTruncatedBytes" integer NOT NULL,
    "ErrorMessage" text,
    "ErrorStackTrace" text,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AvaliacaoCalibragens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoCalibragens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CicloId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "ScoreGestor" numeric(5,2) NOT NULL,
    "DesempenhoGestor" integer,
    "PotencialGestor" integer,
    "ScoreComite" numeric(5,2),
    "DesempenhoComite" integer,
    "PotencialComite" integer,
    "JustificativaComite" character varying(2000),
    "Status" smallint NOT NULL,
    "Decisao" smallint NOT NULL,
    "DecididoPorUserId" uuid,
    "DecididoEmUtc" timestamp with time zone,
    "ObservacaoDecisao" character varying(2000),
    "NineBoxAssessmentId" uuid,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: AvaliacaoCiclos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoCiclos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(200) NOT NULL,
    "Periodo" character varying(50) NOT NULL,
    "Status" smallint NOT NULL,
    "CriadoPorId" uuid NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL,
    "DataFim" date,
    "DataInicio" date,
    "Descricao" character varying(2000)
);


--
-- Name: AvaliacaoConvites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoConvites" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CicloId" uuid NOT NULL,
    "AvaliadorId" uuid NOT NULL,
    "AvaliandoId" uuid NOT NULL,
    "Tipo" smallint NOT NULL,
    "Status" smallint NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "NotificadoEmUtc" timestamp with time zone,
    "RespondidoEmUtc" timestamp with time zone
);


--
-- Name: AvaliacaoPerguntas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoPerguntas" (
    "Id" uuid NOT NULL,
    "CicloId" uuid NOT NULL,
    "Texto" character varying(500) NOT NULL,
    "Ordem" integer NOT NULL
);


--
-- Name: AvaliacaoRespostas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoRespostas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CicloId" uuid NOT NULL,
    "AvaliadorId" uuid NOT NULL,
    "AvaliandoId" uuid NOT NULL,
    "Score" numeric(5,2) NOT NULL,
    "RespostasJson" text NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: BatchMatchingRunVagas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BatchMatchingRunVagas" (
    "Id" uuid NOT NULL,
    "RunId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Status" smallint NOT NULL,
    "ScoresGenerated" integer NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "CompletedAtUtc" timestamp with time zone,
    "ErrorMessage" character varying(2000)
);


--
-- Name: BatchMatchingRuns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BatchMatchingRuns" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Status" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "CompletedAtUtc" timestamp with time zone,
    "TotalVagas" integer NOT NULL,
    "ProcessedVagas" integer NOT NULL,
    "FailedVagas" integer NOT NULL,
    "TotalCandidatesScored" integer NOT NULL,
    "LastProcessedVagaId" uuid,
    "LastError" character varying(2000)
);


--
-- Name: CamposPersonalizadosVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CamposPersonalizadosVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Label" character varying(200) NOT NULL,
    "Tipo" smallint NOT NULL,
    "Obrigatorio" boolean NOT NULL,
    "Ordem" integer NOT NULL,
    "Opcoes" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "IsReadOnly" boolean DEFAULT false NOT NULL,
    "ValorPadrao" character varying(500)
);


--
-- Name: CandidatoAcessibilidades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoAcessibilidades" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Idioma" character varying(40),
    "Canal" character varying(40),
    "MelhorHorario" character varying(40),
    "ObservacoesComunicacao" character varying(400),
    "PrecisaLegendas" boolean NOT NULL,
    "PrecisaInterprete" boolean NOT NULL,
    "PrecisaLeitorTela" boolean NOT NULL,
    "PrecisaBaixaEstimulo" boolean NOT NULL,
    "PrecisaMobilidade" boolean NOT NULL,
    "PrecisaTempoExtra" boolean NOT NULL,
    "DetalhesNecessidades" character varying(1200),
    "ConsentimentoPcd" boolean NOT NULL,
    "PcdIdentificacao" character varying(40),
    "PcdTipo" character varying(60),
    "PcdComprovacao" character varying(40),
    "PcdObservacoes" character varying(1200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoAgendaBloqueios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoAgendaBloqueios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Tipo" character varying(40),
    "Titulo" character varying(120),
    "Data" character varying(40),
    "Horario" character varying(40),
    "Observacoes" character varying(400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoAgendaPreferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoAgendaPreferencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "FormatoEntrevista" character varying(40),
    "InicioDisponivel" character varying(40),
    "AvisoPrevio" character varying(40),
    "Observacoes" character varying(400),
    "DiaSeg" boolean DEFAULT false NOT NULL,
    "DiaTer" boolean DEFAULT false NOT NULL,
    "DiaQua" boolean DEFAULT false NOT NULL,
    "DiaQui" boolean DEFAULT false NOT NULL,
    "DiaSex" boolean DEFAULT false NOT NULL,
    "DiaSab" boolean DEFAULT false NOT NULL,
    "DiaDom" boolean DEFAULT false NOT NULL,
    "PeriodoManha" boolean DEFAULT false NOT NULL,
    "PeriodoTarde" boolean DEFAULT false NOT NULL,
    "PeriodoNoite" boolean DEFAULT false NOT NULL,
    "HorarioPreferido" character varying(40),
    "FusoHorario" character varying(60),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoCertificacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoCertificacoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Ano" character varying(10),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoCompetencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoCompetencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Tipo" character varying(40) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Nivel" character varying(40) NOT NULL,
    "Evidencia" character varying(300),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoDocumentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoDocumentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Tipo" integer NOT NULL,
    "NomeArquivo" character varying(200) NOT NULL,
    "ContentType" character varying(120),
    "Descricao" character varying(240),
    "StorageFileName" character varying(260),
    "TamanhoBytes" bigint,
    "Url" character varying(400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ArquivoNome" character varying(260),
    "DataReferencia" character varying(20)
);


--
-- Name: CandidatoEducacaoItens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoEducacaoItens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Curso" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Tipo" character varying(40),
    "Status" character varying(40),
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Observacoes" character varying(800),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoEducacaoResumos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoEducacaoResumos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nivel" character varying(60),
    "AreaPrincipal" character varying(120),
    "Situacao" character varying(40),
    "Destaques" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoEmbeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoEmbeddings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "ModelVersion" character varying(60) NOT NULL,
    "Dimensions" integer NOT NULL,
    "Embedding" public.vector(1024),
    "TextoSource" character varying(8000) DEFAULT ''::character varying NOT NULL,
    "ConteudoHash" character varying(64) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoExperiencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoExperiencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Empresa" character varying(160) NOT NULL,
    "Cargo" character varying(160) NOT NULL,
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Local" character varying(160),
    "Atividades" character varying(2400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoLgpdConsents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoLgpdConsents" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "ProcessarCandidatura" boolean NOT NULL,
    "PermitirContato" boolean NOT NULL,
    "BancoTalentos" boolean NOT NULL,
    "RetencaoMeses" integer,
    "Compartilhamento" smallint,
    "DadosSensiveis" boolean NOT NULL,
    "Comunicacoes" boolean NOT NULL,
    "ConsentidoEmUtc" timestamp with time zone,
    "RevogadoEmUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoNotificacaoPreferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoNotificacaoPreferencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "CanalEmail" boolean NOT NULL,
    "CanalWhatsapp" boolean NOT NULL,
    "CanalSms" boolean NOT NULL,
    "CanalPush" boolean NOT NULL,
    "Frequencia" character varying(40),
    "Idioma" character varying(20),
    "Email" character varying(180),
    "Telefone" character varying(40),
    "PermiteContato" boolean NOT NULL,
    "AlertaNovasVagas" boolean NOT NULL,
    "AlertaAtualizacoes" boolean NOT NULL,
    "AlertaEntrevistas" boolean NOT NULL,
    "AlertaMensagens" boolean NOT NULL,
    "AlertaDocumentos" boolean NOT NULL,
    "AlertaLembretes" boolean NOT NULL,
    "SilencioAtivo" character varying(10),
    "SilencioInicio" character varying(10),
    "SilencioFim" character varying(10),
    "SilencioPrioridade" character varying(20),
    "Assinatura" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "WhatsAppRateLimitMaxMensagens" integer,
    "WhatsAppRateLimitJanelaMinutos" integer
);


--
-- Name: CandidatoPortfolios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoPortfolios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "WorkModel" character varying(40),
    "Availability" character varying(40),
    "Salary" character varying(40),
    "Shift" character varying(40),
    "Note" character varying(200),
    "Linkedin" character varying(260),
    "Github" character varying(260),
    "Portfolio" character varying(260),
    "Drive" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Tags" character varying(400)
);


--
-- Name: CandidatoPreferenciasVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoPreferenciasVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "CargoAlvo" character varying(160),
    "Senioridade" character varying(60),
    "InicioDisponivel" character varying(60),
    "Resumo" character varying(1200),
    "AreasInteresse" character varying(240),
    "ModeloTrabalho" character varying(40),
    "Jornada" character varying(40),
    "TipoContrato" character varying(40),
    "Viagens" character varying(40),
    "Mudanca" character varying(40),
    "CidadePreferida" character varying(160),
    "DistanciaMaxKm" character varying(20),
    "ObsDeslocamento" character varying(200),
    "PretensaoSalarial" character varying(40),
    "PretensaoNegociavel" character varying(40),
    "BeneficiosDesejados" character varying(200),
    "NaoAbreMaoDe" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoProjetos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoProjetos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Periodo" character varying(60),
    "Descricao" character varying(600),
    "Link" character varying(260),
    "Stack" character varying(400),
    "Destaques" character varying(1600),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoReferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoReferencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Relacao" character varying(80),
    "Empresa" character varying(160),
    "Cargo" character varying(120),
    "Contato" character varying(220),
    "Periodo" character varying(60),
    "Linkedin" character varying(260),
    "Observacoes" character varying(1200),
    "PodeContatar" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoStatusHistories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoStatusHistories" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "FromStatus" integer NOT NULL,
    "ToStatus" integer NOT NULL,
    "Reason" character varying(120),
    "Note" character varying(400),
    "Source" character varying(60),
    "UserId" character varying(120),
    "UserName" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoVagaLlmScores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoVagaLlmScores" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "ScoreFinal" integer DEFAULT 0 NOT NULL,
    "PassouMatchMinimo" boolean DEFAULT false NOT NULL,
    "JustificativaTexto" character varying(4000) DEFAULT ''::character varying NOT NULL,
    "CriteriosJson" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "PontosFortes" character varying(2000),
    "Gaps" character varying(2000),
    "InputHash" character varying(64) NOT NULL,
    "ModelVersion" character varying(60) NOT NULL,
    "DurationMs" integer DEFAULT 0 NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoVagaMatchingScores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoVagaMatchingScores" (
    "CandidatoId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "Score" integer NOT NULL,
    "CalculatedAtUtc" timestamp with time zone NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Justificativa" character varying(2000),
    "RuleVersion" character varying(30),
    "ScoreCompetencia" integer,
    "ScoreExperiencia" integer,
    "ScoreFormacao" integer,
    "ScoreLocalidade" integer,
    "Source" character varying(20)
);


--
-- Name: Candidatos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Candidatos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Email" character varying(180) NOT NULL,
    "Fone" character varying(40),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "Fonte" integer NOT NULL,
    "Status" integer NOT NULL,
    "VagaId" uuid,
    "Obs" character varying(2000),
    "CvText" text,
    "LastMatchScore" integer,
    "LastMatchPass" boolean,
    "LastMatchAtUtc" timestamp with time zone,
    "LastMatchVagaId" uuid,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "PortalAccessKey" character varying(80),
    "PortalPasswordHash" character varying(400),
    "AvatarContentType" character varying(120),
    "AvatarFileName" character varying(260),
    "LinkedinUrl" character varying(260),
    "ResumoProfissional" character varying(2000),
    "ApplicationRecruiterUserId" character varying(120),
    "ApplicationRecruiterUserName" character varying(200),
    "TalentoId" uuid,
    "TrabalhandoAtualmente" boolean,
    "Celular" character varying(40),
    "PretensaoSalarial" numeric(18,2)
);


--
-- Name: CandidaturaEtapaHistoricos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidaturaEtapaHistoricos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidaturaId" uuid NOT NULL,
    "EtapaAnterior" smallint NOT NULL,
    "EtapaNova" smallint NOT NULL,
    "Observacao" character varying(2000),
    "UserId" uuid,
    "EmUtc" timestamp with time zone NOT NULL
);


--
-- Name: Candidaturas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Candidaturas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "Status" smallint NOT NULL,
    "EtapaMacro" smallint NOT NULL,
    "Fonte" character varying(60),
    "Observacoes" character varying(2000),
    "AplicadaEmUtc" timestamp with time zone NOT NULL,
    "EtapaAtualDesdeUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Cargos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Cargos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "OccupationalClassification" character varying(30),
    "CargoType" character varying(30),
    "SimilarityIndicator" character varying(1),
    "FullDescription" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CategoriaSalarialSteps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CategoriaSalarialSteps" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CategoriaSalarialId" uuid NOT NULL,
    "Percentual" numeric(8,2) NOT NULL,
    "ValorOverride" numeric(18,2),
    "Ordem" integer DEFAULT 0 NOT NULL,
    "Observacao" character varying(200),
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL,
    "UpdatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: CategoriasSalariais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CategoriasSalariais" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(10) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "EmpresaId" uuid,
    "EstabelecimentoId" uuid,
    "ValorBase" numeric(18,2)
);


--
-- Name: CelebrationCommentMentions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationCommentMentions" (
    "Id" uuid NOT NULL,
    "CommentId" uuid NOT NULL,
    "UserId" uuid NOT NULL
);


--
-- Name: CelebrationCommentReactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationCommentReactions" (
    "Id" uuid NOT NULL,
    "CommentId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "Type" character varying(20) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CelebrationComments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationComments" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PostId" uuid NOT NULL,
    "AuthorId" uuid NOT NULL,
    "Content" character varying(2000) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CelebrationMentions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationMentions" (
    "Id" uuid NOT NULL,
    "PostId" uuid NOT NULL,
    "UserId" uuid NOT NULL
);


--
-- Name: CelebrationPosts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationPosts" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuthorId" uuid NOT NULL,
    "Content" character varying(4000) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CentrosCusto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CentrosCusto" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "Manager" character varying(120),
    "Notes" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "EmpresaId" uuid,
    "ValidFrom" date,
    "ValidUntil" date,
    "ParentId" uuid,
    "BranchOrLocation" character varying(160),
    "Description2" character varying(1000),
    "Headcount" integer DEFAULT 0 NOT NULL,
    "OwnerFuncionarioId" uuid,
    "Phone" character varying(40)
);


--
-- Name: DadosBancarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DadosBancarios" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "Banco" character varying(200) NOT NULL,
    "Agencia" character varying(20) NOT NULL,
    "Conta" character varying(30) NOT NULL,
    "TipoConta" smallint NOT NULL,
    "Pix" character varying(150),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Dependentes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Dependentes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "NomeCompleto" character varying(200) NOT NULL,
    "Parentesco" smallint NOT NULL,
    "Cpf" character varying(14),
    "DataNascimento" date NOT NULL,
    "IsPcd" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DescricaoCargoItemEmbeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DescricaoCargoItemEmbeddings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DescricaoCargoItemId" uuid NOT NULL,
    "ModelVersion" character varying(60) NOT NULL,
    "Dimensions" integer NOT NULL,
    "Embedding" public.vector(1024),
    "TextoSource" character varying(4000) DEFAULT ''::character varying NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DescricaoCargoItens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DescricaoCargoItens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DescricaoCargoId" uuid NOT NULL,
    "Categoria" smallint NOT NULL,
    "Texto" character varying(500) NOT NULL,
    "IsObrigatoria" boolean DEFAULT true NOT NULL,
    "NivelMinimo" character varying(40),
    "Subcategoria" character varying(80),
    "Ordem" integer DEFAULT 0 NOT NULL,
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL,
    "UpdatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: DescricoesCargo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DescricoesCargo" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Summary" character varying(2000),
    "Responsibilities" text,
    "Requirements" text,
    "NiceToHave" text,
    "Benefits" text,
    "IsTemplate" boolean NOT NULL,
    "NivelCargoId" uuid,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "AreaTemplate" character varying(120),
    "CboCodigo" character varying(20),
    "FormacaoMinima" character varying(200),
    "FormacaoDesejavel" character varying(200),
    "FormacaoAreaEstudo" character varying(200),
    "ExperienciaTempoMinimo" character varying(80),
    "ExperienciaTempoDesejavel" character varying(80),
    "ExperienciaEspecificacao" character varying(500),
    "RevisaoNumero" character varying(10),
    "RevisaoData" date,
    "RevisaoNatureza" character varying(200),
    "GestorNome" character varying(200),
    "GestorEmail" character varying(200)
);


--
-- Name: Desligamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Desligamentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "IdReqRm" character varying(40) NOT NULL,
    "ChapaRm" character varying(20) NOT NULL,
    "FuncionarioId" uuid,
    "CodMotivoRescisao" character varying(10),
    "MotivoRescisaoDescricao" character varying(120),
    "CodTipoRescisao" integer,
    "TipoRescisaoDescricao" character varying(120),
    "GerouSubstituicao" boolean NOT NULL,
    "DataAbertura" timestamp with time zone NOT NULL,
    "DataPrevista" timestamp with time zone,
    "DataConclusao" timestamp with time zone,
    "DataCancelamento" timestamp with time zone,
    "CodStatus" integer NOT NULL,
    "Justificativa" text,
    "NumDiasAviso" integer,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DevelopmentPlanGoals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DevelopmentPlanGoals" (
    "Id" uuid NOT NULL,
    "PlanId" uuid NOT NULL,
    "Description" character varying(500) NOT NULL,
    "DueDate" timestamp with time zone,
    "ConcludedAt" timestamp with time zone,
    "Order" integer NOT NULL
);


--
-- Name: DevelopmentPlans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DevelopmentPlans" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "OwnerUserId" uuid NOT NULL,
    "TargetUserId" uuid,
    "Title" character varying(200) NOT NULL,
    "Description" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentacaoPadraoConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Configuracao" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentacaoPadraoHistoricos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoHistoricos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Escopo" smallint NOT NULL,
    "NivelCargoId" uuid,
    "TipoDocumento" smallint NOT NULL,
    "ConfiguracaoAnterior" smallint,
    "ConfiguracaoNova" smallint,
    "Acao" smallint NOT NULL,
    "UserId" uuid,
    "UserNome" character varying(200),
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "CargoId" uuid
);


--
-- Name: DocumentacaoPadraoPorCargoConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoPorCargoConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "JobPositionId" uuid NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Configuracao" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentacaoPadraoPorNivelCargoConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoPorNivelCargoConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NivelCargoId" uuid NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Configuracao" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentosColaborador; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentosColaborador" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "Tipo" smallint NOT NULL,
    "NomeArquivo" character varying(260) NOT NULL,
    "ContentType" character varying(100) NOT NULL,
    "TamanhoBytes" bigint NOT NULL,
    "StoragePath" character varying(500) NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoRh" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EixosVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EixosVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "Description" character varying(400),
    "SlaDiasMetaFechamento" integer,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EmailAttempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailAttempts" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EmailMessageId" uuid NOT NULL,
    "AttemptNumber" integer NOT NULL,
    "Provider" character varying(40) NOT NULL,
    "StartedAtUtc" timestamp with time zone NOT NULL,
    "CompletedAtUtc" timestamp with time zone,
    "IsSuccess" boolean NOT NULL,
    "ErrorMessage" character varying(1200),
    "ErrorStackTrace" character varying(2000)
);


--
-- Name: EmailConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Provider" character varying(20) NOT NULL,
    "SmtpHost" character varying(200),
    "SmtpPort" integer NOT NULL,
    "SmtpEnableSsl" boolean NOT NULL,
    "SmtpUserName" character varying(200),
    "SmtpPasswordEncrypted" text,
    "SmtpFromName" character varying(200),
    "SmtpFromAddress" character varying(200),
    "ImapHost" character varying(200),
    "ImapPort" integer NOT NULL,
    "ImapEnableSsl" boolean NOT NULL,
    "ImapUserName" character varying(200),
    "ImapPasswordEncrypted" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EmailMessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailMessages" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "OwnerUserId" character varying(120),
    "OwnerUserName" character varying(200),
    "IsSystem" boolean NOT NULL,
    "Source" character varying(120),
    "To" character varying(320) NOT NULL,
    "Cc" character varying(640),
    "Bcc" character varying(640),
    "Subject" character varying(260) NOT NULL,
    "BodyHtml" text NOT NULL,
    "BodyText" text,
    "TemplateId" uuid,
    "TemplateName" character varying(120),
    "TemplateVersion" integer,
    "PayloadJson" text,
    "Status" integer NOT NULL,
    "AttemptCount" integer NOT NULL,
    "MaxAttempts" integer NOT NULL,
    "NextAttemptAtUtc" timestamp with time zone,
    "LastError" character varying(1200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EmailTemplates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailTemplates" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "SubjectTemplate" character varying(200) NOT NULL,
    "BodyHtml" text NOT NULL,
    "Version" integer NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Empresas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Empresas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Cep" character varying(20),
    "Logradouro" character varying(200),
    "Numero" character varying(40),
    "Bairro" character varying(120),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "Latitude" numeric,
    "Longitude" numeric,
    "GeocodificadoEmUtc" timestamp with time zone
);


--
-- Name: EntraIdConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EntraIdConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EntraTenantId" character varying(120),
    "ClientId" character varying(120),
    "ClientSecretEncrypted" character varying(400),
    "IsEnabled" boolean NOT NULL,
    "CallbackPath" character varying(120),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EntrevistasSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EntrevistasSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DesligamentoId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "TemplateId" uuid NOT NULL,
    "Token" character varying(64) NOT NULL,
    "ExpiresAtUtc" timestamp with time zone NOT NULL,
    "SubmittedAtUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EtapasConfigAprovacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EtapasConfigAprovacao" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "Ordem" integer NOT NULL,
    "Label" character varying(120) NOT NULL,
    "TipoAprovador" smallint NOT NULL,
    "FuncionarioFixoId" uuid,
    "RoleFilaId" uuid,
    "Ativo" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "AcaoEtapa" smallint DEFAULT 0 NOT NULL,
    "MomentoAcao" smallint DEFAULT 0 NOT NULL,
    "SlaHoras" integer
);


--
-- Name: EtapasConfigWorkflowRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EtapasConfigWorkflowRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoWorkflow" smallint NOT NULL,
    "Ordem" integer NOT NULL,
    "Codigo" character varying(50) NOT NULL,
    "Label" character varying(160) NOT NULL,
    "Descricao" character varying(500),
    "SlaPrazoDias" integer,
    "Obrigatoria" boolean NOT NULL,
    "RoleFilaId" uuid,
    "Ativo" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EtapasWorkflowRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EtapasWorkflowRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "WorkflowId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Codigo" character varying(50) NOT NULL,
    "Label" character varying(160) NOT NULL,
    "Descricao" character varying(500),
    "Status" smallint NOT NULL,
    "Obrigatoria" boolean NOT NULL,
    "ResponsavelId" uuid,
    "RoleFilaId" uuid,
    "SlaPrazoDias" integer,
    "DataInicio" timestamp with time zone,
    "DataConclusao" timestamp with time zone,
    "DadosJson" text,
    "Observacoes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: ExceptionLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ExceptionLogs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RequestLogId" uuid NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "EnvironmentName" character varying(80) NOT NULL,
    "EnvironmentNormalized" character varying(16) NOT NULL,
    "DeviceId" character varying(64) NOT NULL,
    "DeviceType" character varying(40),
    "Platform" character varying(40),
    "Browser" character varying(40),
    "DeviceAppVersion" character varying(120),
    "Locale" character varying(200),
    "Order" integer NOT NULL,
    "OccurredAt" timestamp with time zone NOT NULL,
    "IsHandled" boolean NOT NULL,
    "StatusCode" integer NOT NULL,
    "ExceptionType" character varying(300) NOT NULL,
    "Message" character varying(4096) NOT NULL,
    "StackTrace" character varying(16384),
    "InnerExceptionType" character varying(300),
    "InnerMessage" character varying(4096),
    "ProblemTitle" character varying(4096),
    "ProblemDetail" character varying(4096),
    "ProblemType" character varying(200),
    "ValidationErrorsJson" jsonb,
    "Tags" character varying(200),
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: FaixasSalariais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FaixasSalariais" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EstabelecimentoCodigo" character varying(10),
    "JobPositionId" uuid,
    "SalarioMinimo" numeric(18,2) NOT NULL,
    "SalarioMaximo" numeric(18,2) NOT NULL,
    "Descricao" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: FasesProcesso; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FasesProcesso" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ProjetoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Ordem" integer NOT NULL,
    "ResponsavelTipo" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Descricao" character varying(500),
    "Observacoes" character varying(2000),
    "SlaDias" integer
);


--
-- Name: FeedbackItemRatings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FeedbackItemRatings" (
    "Id" uuid NOT NULL,
    "FeedbackItemId" uuid NOT NULL,
    "ItemName" character varying(120) NOT NULL,
    "Stars" integer NOT NULL
);


--
-- Name: FeedbackItems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FeedbackItems" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FromUserId" uuid NOT NULL,
    "ToUserId" uuid NOT NULL,
    "Content" character varying(4000) NOT NULL,
    "Tipo" character varying(40),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "InternalNotes" character varying(4000),
    "IsPresencial" boolean DEFAULT false NOT NULL
);


--
-- Name: FluxosAprovacaoConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FluxosAprovacaoConfig" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "ReferenciaUnidade" smallint NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: FuncionarioMovimentacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FuncionarioMovimentacoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid,
    "ChapaRm" character varying(20) NOT NULL,
    "IdReqRm" character varying(40) NOT NULL,
    "TipoMovimentacao" smallint NOT NULL,
    "TipoDescricao" character varying(60),
    "DataAbertura" timestamp with time zone NOT NULL,
    "DataConclusao" timestamp with time zone,
    "DataCancelamento" timestamp with time zone,
    "CodStatus" integer NOT NULL,
    "StatusDescricao" character varying(60),
    "CodFuncaoOrigem" character varying(20),
    "FuncaoOrigemNome" character varying(160),
    "CodSecaoOrigem" character varying(60),
    "CodSecaoDestino" character varying(60),
    "CodFuncaoDestino" character varying(20),
    "FuncaoDestinoNome" character varying(160),
    "HierarquiaOrigemId" uuid,
    "HierarquiaDestinoId" uuid,
    "IdHierarquiaOrigemRm" integer,
    "IdHierarquiaDestinoRm" integer,
    "SalarioOrigem" numeric(18,2),
    "SalarioDestino" numeric(18,2),
    "Justificativa" text,
    "GerouSubstituicao" boolean,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Funcionarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Funcionarios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(160) NOT NULL,
    "Email" character varying(180),
    "Phone" character varying(40),
    "Status" integer NOT NULL,
    "UserId" uuid,
    "UnitId" uuid,
    "Headcount" integer NOT NULL,
    "JobPositionId" uuid,
    "Notes" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "PessoaId" uuid,
    "AvatarFileName" text,
    "GestorDiretoId" uuid,
    "NivelHierarquicoId" uuid,
    "CdnEmpresa" character varying(3),
    "CdnEstab" character varying(5),
    "CdnFuncionario" character varying(12),
    "UnidadeLotacaoId" uuid,
    "NivelCargoId" uuid,
    "CdnNivCargo" integer,
    "CentroCustoId" uuid,
    "HasIncompleteData" boolean DEFAULT false NOT NULL,
    "DataAdmissao" date,
    "DataNascimento" date,
    "PeriodoExperienciaDias" integer DEFAULT 90 NOT NULL,
    "Sexo" character varying(1),
    "MatriculaRm" character varying(20),
    "HierarquiaId" uuid,
    "CodSituacaoRm" character varying(5),
    "SituacaoRmDescricao" character varying(60),
    "CodFuncaoRm" character varying(20),
    "FuncaoNomeRm" character varying(160),
    "CiclosAusenteRm" integer DEFAULT 0 NOT NULL,
    "UltimoCicloRmObservadoUtc" timestamp with time zone
);


--
-- Name: GamificationDailyStates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GamificationDailyStates" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "CurrentStreak" integer NOT NULL,
    "BestStreak" integer NOT NULL,
    "LastCheckInDate" date,
    "LastActivityDate" date,
    "FeedbackSentToday" integer NOT NULL,
    "CelebrationPostsToday" integer NOT NULL,
    "CelebrationCommentsToday" integer NOT NULL,
    "OneOnOneCompletedToday" integer NOT NULL,
    "DevelopmentPlansCreatedToday" integer NOT NULL,
    "SurveyAnsweredToday" integer NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Hierarquias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Hierarquias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "IdHierarquiaRm" integer NOT NULL,
    "Descricao" character varying(200) NOT NULL,
    "IdHierarquiaSuperiorRm" integer,
    "HierarquiaSuperiorId" uuid,
    "Estrutura" character varying(200),
    "IdNivelHierarquiaRm" integer,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: HistoricosAlteracaoWorkflowRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HistoricosAlteracaoWorkflowRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "WorkflowId" uuid NOT NULL,
    "EtapaWorkflowId" uuid,
    "Campo" character varying(120) NOT NULL,
    "ValorAnterior" character varying(2000),
    "ValorNovo" character varying(2000),
    "OrigemPreenchimento" smallint NOT NULL,
    "AlteradoPorId" uuid NOT NULL,
    "AlteradoPorNome" character varying(200) NOT NULL,
    "DataAlteracaoUtc" timestamp with time zone NOT NULL,
    "Observacao" character varying(2000)
);


--
-- Name: HistoricosStatus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HistoricosStatus" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoEntidade" smallint NOT NULL,
    "EntidadeId" uuid NOT NULL,
    "StatusAnterior" character varying(80) NOT NULL,
    "StatusNovo" character varying(80) NOT NULL,
    "AlteradoPorFuncionarioId" uuid,
    "AlteradoPorUserId" uuid,
    "AlteradoPorNome" character varying(200) NOT NULL,
    "AlteradoEmUtc" timestamp with time zone NOT NULL,
    "SlaEsperadoHoras" integer,
    "TempoNoStatusAnteriorHoras" double precision,
    "DentroDoSla" boolean,
    "Observacao" character varying(1000)
);


--
-- Name: Holerites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Holerites" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "MesReferencia" integer NOT NULL,
    "AnoReferencia" integer NOT NULL,
    "ArquivoPath" character varying(500) NOT NULL,
    "ArquivoNome" character varying(255) NOT NULL,
    "TamanhoBytes" bigint NOT NULL,
    "EnviadoPorId" uuid,
    "EnviadoEmUtc" timestamp with time zone NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: InboxAttachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InboxAttachments" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "InboxItemId" uuid NOT NULL,
    "Nome" character varying(200) NOT NULL,
    "Tipo" character varying(20),
    "TamanhoKB" integer NOT NULL,
    "Hash" character varying(120),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: InboxItems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InboxItems" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Origem" integer NOT NULL,
    "Status" integer NOT NULL,
    "RecebidoEm" timestamp with time zone NOT NULL,
    "Remetente" character varying(180),
    "Assunto" character varying(220),
    "Destinatario" character varying(200),
    "VagaId" uuid,
    "PreviewText" text,
    "ProcessamentoPct" integer NOT NULL,
    "ProcessamentoEtapa" character varying(120),
    "ProcessamentoTentativas" integer NOT NULL,
    "ProcessamentoUltimoErro" character varying(400),
    "ProcessamentoLogRaw" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "SuggestedVagasJson" jsonb,
    "CandidatoId" uuid
);


--
-- Name: JobPositions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobPositions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(40) NOT NULL,
    "Name" character varying(160) NOT NULL,
    "Status" integer NOT NULL,
    "CentroCustoId" uuid,
    "Seniority" integer NOT NULL,
    "Type" character varying(180),
    "Description" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DescricaoPublicacao" text,
    "NivelHierarquicoId" uuid,
    "OccupationalClassification" text,
    "FullDescription" character varying(500),
    "SimilarityIndicator" character varying(1),
    "DesEnvelPagto" character varying(40),
    "NivelCargoId" uuid,
    "TotvsCargoBasicId" integer,
    "TotvsNivCargoId" integer
);


--
-- Name: LocalizationConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LocalizationConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Culture" character varying(20),
    "UiCulture" character varying(20),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: LogEntries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LogEntries" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RequestLogId" uuid NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "EnvironmentName" character varying(80) NOT NULL,
    "EnvironmentNormalized" character varying(16) NOT NULL,
    "DeviceId" character varying(64) NOT NULL,
    "DeviceType" character varying(40),
    "Platform" character varying(40),
    "Browser" character varying(40),
    "DeviceAppVersion" character varying(120),
    "Locale" character varying(200),
    "Order" integer NOT NULL,
    "Level" character varying(20) NOT NULL,
    "Category" character varying(200) NOT NULL,
    "EventId" integer,
    "EventName" character varying(200),
    "Message" character varying(8192) NOT NULL,
    "ExceptionType" character varying(300),
    "ExceptionMessage" character varying(8192),
    "ExceptionStackTrace" character varying(16384),
    "PropertiesJson" jsonb,
    "OccurredAt" timestamp with time zone NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: LogsComunicacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LogsComunicacao" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "ProjetoId" uuid,
    "Tipo" smallint NOT NULL,
    "Assunto" character varying(200),
    "Mensagem" character varying(4000),
    "Destinatario" character varying(200),
    "UsuarioNome" character varying(120),
    "DataUtc" timestamp with time zone NOT NULL
);


--
-- Name: Menus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Menus" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DisplayName" character varying(160) NOT NULL,
    "Route" character varying(240) NOT NULL,
    "Icon" character varying(120) NOT NULL,
    "Order" integer NOT NULL,
    "ParentId" uuid,
    "PermissionKey" character varying(160) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "OpenInNewTab" boolean DEFAULT false NOT NULL,
    "DisplayNameKey" character varying(200)
);


--
-- Name: Metas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Metas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "CriadaPorId" uuid NOT NULL,
    "Titulo" character varying(300) NOT NULL,
    "Descricao" character varying(2000),
    "ValorMeta" numeric(18,4) NOT NULL,
    "ValorAtual" numeric(18,4) NOT NULL,
    "Unidade" character varying(20) NOT NULL,
    "Prazo" date,
    "Status" smallint NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: MoodEntries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MoodEntries" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "Mood" character varying(20) NOT NULL,
    "Note" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: MotivosRequisicaoVagaConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MotivosRequisicaoVagaConfig" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Codigo" character varying(60) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Descricao" character varying(500),
    "EfeitoHeadcount" smallint NOT NULL,
    "IsActive" boolean NOT NULL,
    "Ordem" integer NOT NULL,
    "IsSystem" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: NineBoxAssessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NineBoxAssessments" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "AvaliadorId" uuid NOT NULL,
    "Desempenho" integer NOT NULL,
    "Potencial" integer NOT NULL,
    "Observacoes" character varying(2000),
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL,
    "CicloAvaliacaoId" uuid
);


--
-- Name: NiveisCargo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NiveisCargo" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "CdnNivCargo" integer NOT NULL,
    "NomReduz" character varying(6) NOT NULL,
    "NomComplet" character varying(40) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: NiveisHierarquicos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NiveisHierarquicos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Ordem" integer NOT NULL,
    "Ativo" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: NotificacoesCandidaturaLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificacoesCandidaturaLogs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidaturaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "EtapaMacro" smallint NOT NULL,
    "Canal" smallint NOT NULL,
    "Status" smallint NOT NULL,
    "Destino" character varying(200),
    "Mensagem" character varying(4000),
    "ErroMensagem" character varying(1000),
    "CriadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: NotificacoesTemplates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificacoesTemplates" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Etapa" smallint NOT NULL,
    "Canal" smallint NOT NULL,
    "Assunto" character varying(240),
    "Corpo" character varying(4000) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Idioma" character varying(10)
);


--
-- Name: NotificationReceipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificationReceipts" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NotificationId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "SeenAtUtc" timestamp with time zone,
    "ReadAtUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notifications" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Message" character varying(2000) NOT NULL,
    "Level" character varying(20) NOT NULL,
    "Url" character varying(500),
    "IsRead" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UserId" uuid
);


--
-- Name: OcupacoesHistorico; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OcupacoesHistorico" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid,
    "FuncionarioId" uuid,
    "DataEntrada" timestamp with time zone NOT NULL,
    "DataSaida" timestamp with time zone,
    "MotivoSaida" text,
    "SolicitacaoOrigemId" uuid,
    "IsProvisorio" boolean DEFAULT false NOT NULL,
    "ProvisorioExpiresAtUtc" timestamp with time zone
);


--
-- Name: OneOnOneMeetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OneOnOneMeetings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ManagerId" uuid NOT NULL,
    "CollaboratorId" uuid NOT NULL,
    "MeetingDate" timestamp with time zone NOT NULL,
    "Subject" character varying(200),
    "Notes" character varying(4000),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PerguntasEntrevistaSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PerguntasEntrevistaSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TemplateId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Texto" character varying(500) NOT NULL,
    "TipoResposta" smallint NOT NULL,
    "Opcoes" character varying(1000),
    "Obrigatoria" boolean DEFAULT false NOT NULL
);


--
-- Name: PermissoesNivelVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PermissoesNivelVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NivelHierarquicoId" uuid NOT NULL,
    "RoleId" uuid NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PessoaBloqueios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PessoaBloqueios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PessoaId" uuid NOT NULL,
    "Motivo" character varying(500),
    "OrigemBloqueio" integer NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "CreatedByUserId" character varying(120)
);


--
-- Name: Pessoas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Pessoas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Email" character varying(180) NOT NULL,
    "Fone" character varying(40),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "LinkedinUrl" character varying(260),
    "ResumoProfissional" character varying(2000),
    "Obs" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Origem" integer DEFAULT 0 NOT NULL,
    "Bairro" character varying(120),
    "Cep" character varying(20),
    "Complemento" character varying(120),
    "Cpf" character varying(14),
    "FoneContato" character varying(40),
    "Logradouro" character varying(200),
    "Numero" character varying(40),
    "Rg" character varying(20),
    "DataNascimento" timestamp with time zone,
    "Latitude" numeric,
    "Longitude" numeric,
    "GeocodificadoEmUtc" timestamp with time zone,
    "Sexo" character varying(1),
    "EstadoCivil" character varying(2),
    "Naturalidade" character varying(120),
    "EstadoNatal" character varying(2),
    "GrauInstrucao" character varying(5),
    "RgOrgEmissor" character varying(20),
    "RgUf" character varying(2),
    "RgDataEmissao" timestamp with time zone,
    "CarteiraTrabalho" character varying(20),
    "CarteiraTrabalhoSerie" character varying(10),
    "CarteiraTrabalhoUf" character varying(2),
    "CarteiraTrabalhoData" timestamp with time zone,
    "NumeroPis" character varying(20),
    "TituloEleitor" character varying(20),
    "TituloEleitorZona" character varying(10),
    "TituloEleitorSecao" character varying(10),
    "CertificadoReservista" character varying(20),
    "CategoriaMilitar" character varying(2),
    "NomePai" character varying(160),
    "NomeMae" character varying(160),
    "Nacionalidade" character varying(60)
);


--
-- Name: PreAdmissaoDependentes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissaoDependentes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PreAdmissaoId" uuid NOT NULL,
    "NomeCompleto" character varying(200) NOT NULL,
    "Parentesco" smallint NOT NULL,
    "Cpf" character varying(14),
    "DataNascimento" date NOT NULL,
    "IsPcd" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PreAdmissaoDocumentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissaoDocumentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PreAdmissaoId" uuid NOT NULL,
    "Tipo" smallint NOT NULL,
    "NomeArquivo" character varying(260) NOT NULL,
    "ContentType" character varying(100) NOT NULL,
    "TamanhoBytes" bigint NOT NULL,
    "StoragePath" character varying(500) NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoRh" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Lado" smallint DEFAULT 0 NOT NULL
);


--
-- Name: PreAdmissaoDocumentosSolicitados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissaoDocumentosSolicitados" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PreAdmissaoId" uuid NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Obrigatorio" boolean DEFAULT true NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PreAdmissoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Status" smallint NOT NULL,
    "PreenchidoPor" smallint NOT NULL,
    "CandidatoId" uuid,
    "RevisadoPorId" uuid,
    "AprovadoPorId" uuid,
    "ObservacaoRh" character varying(2000),
    "MotivoRejeicao" character varying(2000),
    "Nome" character varying(160) NOT NULL,
    "Cpf" character varying(14),
    "Rg" character varying(20),
    "RgOrgaoExpedidor" character varying(20),
    "RgDataExpedicao" date,
    "DataNascimento" date,
    "Sexo" smallint NOT NULL,
    "EstadoCivil" smallint NOT NULL,
    "Nacionalidade" character varying(60),
    "NomeMae" character varying(160),
    "NomePai" character varying(160),
    "NaturalCidade" character varying(120),
    "NaturalUf" character varying(2),
    "Passaporte" character varying(30),
    "RnmRne" character varying(30),
    "ValidadeVisto" date,
    "TipoVisto" character varying(60),
    "Cep" character varying(10),
    "Logradouro" character varying(200),
    "Numero" character varying(20),
    "Complemento" character varying(120),
    "Bairro" character varying(120),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "Email" character varying(180),
    "Telefone" character varying(20),
    "Celular" character varying(20),
    "ContatoEmergenciaNome" character varying(160),
    "ContatoEmergenciaFone" character varying(20),
    "BancoCodigo" character varying(10),
    "BancoNome" character varying(80),
    "Agencia" character varying(10),
    "AgenciaDigito" character varying(2),
    "Conta" character varying(20),
    "ContaDigito" character varying(2),
    "TipoConta" smallint,
    "EstabelecimentoCodigo" character varying(10),
    "MatriculaRM" character varying(20),
    "UnitId" uuid,
    "CentroCustoId" uuid,
    "JobPositionId" uuid,
    "DataAdmissao" date,
    "Salario" numeric(18,2),
    "TipoContratacao" smallint,
    "CargaHorariaSemanal" smallint,
    "PisPasep" character varying(20),
    "TituloEleitorNumero" character varying(20),
    "TituloEleitorZona" character varying(10),
    "TituloEleitorSecao" character varying(10),
    "ReservistaNumero" character varying(20),
    "CategoriaCnh" character varying(10),
    "ValidadeCnh" date,
    "Ctps" character varying(20),
    "CtpsSerie" character varying(10),
    "CtpsUf" character varying(2),
    "ValidacaoCpfOk" boolean NOT NULL,
    "ValidacaoCepOk" boolean NOT NULL,
    "ValidacaoBancoOk" boolean NOT NULL,
    "ValidacaoSalarioOk" boolean NOT NULL,
    "ValidacaoSalarioJustificativa" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "SubmittedAtUtc" timestamp with time zone,
    "ApprovedAtUtc" timestamp with time zone,
    "AccessToken" character varying(64),
    "Altura" integer,
    "CartaoSus" character varying(30),
    "CategoriaSalarial" integer,
    "CentroCustoTotvs" character varying(30),
    "CodCargoTotvs" integer,
    "CodTurno" integer,
    "CodVinculoEmpregaticio" integer,
    "CtpsModelo" integer,
    "DocMilitarNumero" character varying(30),
    "DocMilitarRegiao" integer,
    "DocMilitarSerie" character varying(20),
    "DocMilitarTipo" integer,
    "FatorRh" integer,
    "GrauInstrucao" integer,
    "GrupoSanguineo" integer,
    "Peso" integer,
    "PossuiDeficiencia" character varying(1),
    "TipoFuncionario" integer,
    "TituloEleitorCidade" character varying(120),
    "TituloEleitorUf" character varying(2),
    "UnidadeLotacao" character varying(30),
    "Avos13SalCalc" integer,
    "Avos13SalCalcAnterior" integer,
    "Cabelo" integer,
    "Calcula13" character varying(1),
    "CargaAutomTurno" character varying(1),
    "CategoriaTrabalhoESocial" integer,
    "CnhDataExpedicao" date,
    "CnhNumero" character varying(20),
    "CnhOrgaoEmissor" character varying(20),
    "CnhPrimeiraHabilitacao" date,
    "CnhUf" character varying(2),
    "CodClassFuncPontoEletronico" integer,
    "CodEmpresa" character varying(10),
    "CodFpas" integer,
    "CodLocalMarcacao" integer,
    "CodLocalidade" integer,
    "CodNivel" integer,
    "CodPlanoLotacao" integer,
    "CodSindicato" integer,
    "CodTurma" integer,
    "ConsidEmissRAIS" character varying(1),
    "ContribSindicDia" character varying(1),
    "CtpsSerieESocial" character varying(10),
    "Cutis" integer,
    "DataTerminoContrato" integer,
    "DddTelContato" integer,
    "DddTelefone" integer,
    "DescContribSindical" character varying(1),
    "DiasProvFeriasMesAnterior" numeric,
    "DiasProvFeriasMesAtual" numeric,
    "EmailAlternativo" character varying(180),
    "EmitCartPonto" character varying(1),
    "FormaPagamento" integer,
    "FuncDoador" character varying(1),
    "FuncQualificado" character varying(1),
    "IndAdmissao" integer,
    "IndFuncVinculado" integer,
    "Manequim" integer,
    "MatriculaESocial" character varying(30),
    "MunicipioEnderecoIbge" integer,
    "MunicipioNascimentoIbge" integer,
    "NaturezaAtividade" integer,
    "NomeAbreviado" character varying(20),
    "NumCartaoPonto" integer,
    "OcorrenciaCAGED" integer,
    "Olhos" integer,
    "OptanteFgts" character varying(1),
    "OrigemFuncionario" integer,
    "PaisLocalidade" character varying(10),
    "PaisNascimento" character varying(10),
    "PontoReferencia" character varying(120),
    "ProvAcum13Sal" numeric,
    "ProvAcumFerias" numeric,
    "ProvAcumFerias13" numeric,
    "ProvAcumFgts13Sal" numeric,
    "ProvAcumFgtsFerias" numeric,
    "ProvAcumInss13Sal" numeric,
    "ProvAcumInssFerias" numeric,
    "RecebeAdiantamento" character varying(1),
    "RecebeFerias" character varying(1),
    "RecebeInsalub" character varying(1),
    "RecebePericul" character varying(1),
    "RecolheFgts" character varying(1),
    "RecolheInss" character varying(1),
    "RegimeJornada" integer,
    "RegimePrevidenciario" integer,
    "RegimeTrabalhista" integer,
    "RgUfExpedidor" character varying(2),
    "SalarioSimulado" numeric,
    "Sapato" integer,
    "Sindicalizado" character varying(1),
    "TipoAdmissaoESocial" integer,
    "TipoAdmissaoFgts" integer,
    "TipoLogradouroESocial" character varying(5),
    "TipoMaoDeObra" character varying(10),
    "TipoVistoEstrangeiro" integer,
    "CodRegistroExterior" character varying(30),
    "DataOpcaoFgts" date,
    "DocMilitarCircunscricao" integer,
    "LastActivityUtc" timestamp with time zone,
    "NomeSocial" character varying(160),
    "PaisNacionalidade" character varying(10),
    "ResideExterior" character varying(1),
    "WizardCompletionPercent" integer,
    "WizardCurrentStep" integer,
    "AnoChegada" integer,
    "CidadeExterior" character varying(120),
    "CodEnderecoPostalExterior" character varying(20),
    "DataObitoCivil" date,
    "OrgaoEmisPassaporte" integer,
    "PaisEmisPassaporte" character varying(10),
    "PortariaNaturalizacao" character varying(60),
    "Naturalizacao" character varying(60),
    "TipoCertidaoCivil" integer,
    "TipoEstatistica" integer,
    "ValidadeIdentEstrangeiro" date,
    "FuncionarioIdMaterializado" uuid,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "RegIdentidCivilNumero" character varying(20),
    "RegIdentidCivilUf" character varying(2),
    "RegIdentidCivilCidade" character varying(120),
    "RegIdentidCivilOrgEmiss" character varying(20),
    "RegIdentidCivilDataExped" date,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone,
    "VagaId" uuid,
    "IntegracaoResultado" smallint,
    "IntegracaoMensagem" character varying(2000),
    "IntegradaEmUtc" timestamp with time zone,
    "RequisitoCategoriaId" uuid
);


--
-- Name: ProjetoCandidatos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjetoCandidatos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ProjetoId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Status" smallint NOT NULL,
    "FaseAtualId" uuid,
    "Observacoes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: ProjetosVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjetosVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Numero" integer NOT NULL,
    "Descricao" character varying(240),
    "Status" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DataInicio" date,
    "DataEncerramento" date
);


--
-- Name: PropostasVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PropostasVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Status" smallint NOT NULL,
    "Moeda" character varying(3),
    "SalarioOferecido" numeric(18,2),
    "DescricaoBeneficios" character varying(2000),
    "DataPrevistaInicio" date,
    "MensagemPersonalizada" character varying(8000),
    "AccessToken" character varying(64),
    "EnviadaEmUtc" timestamp with time zone,
    "ExpiraEmUtc" timestamp with time zone,
    "VisualizadaEmUtc" timestamp with time zone,
    "RespondidaEmUtc" timestamp with time zone,
    "NomeConfirmadoCandidato" character varying(160),
    "IpOrigemResposta" character varying(60),
    "UserAgentResposta" character varying(400),
    "MotivoRecusa" character varying(2000),
    "CriadaPorUserId" uuid,
    "EnviadaPorUserId" uuid,
    "ObservacaoInternaRh" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "CandidaturaId" uuid
);


--
-- Name: RecruiterMatchingFeedbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RecruiterMatchingFeedbacks" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "RecruiterUserId" character varying(120),
    "Action" smallint NOT NULL,
    "MatchScoreAtAction" integer,
    "RankPositionAtAction" integer,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RenderCoinBalances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RenderCoinBalances" (
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "Balance" numeric(18,4) NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RenderCoinTransactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RenderCoinTransactions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "Amount" numeric(18,4) NOT NULL,
    "Reason" character varying(200),
    "SourceType" character varying(40),
    "SourceId" character varying(100),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RequestLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RequestLogs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "CorrelationId" character varying(200),
    "TraceId" character varying(200),
    "EnvironmentName" character varying(80) NOT NULL,
    "EnvironmentNormalized" character varying(16) NOT NULL,
    "DeviceId" character varying(64) NOT NULL,
    "DeviceType" character varying(40),
    "Platform" character varying(40),
    "Browser" character varying(40),
    "DeviceAppVersion" character varying(120),
    "Locale" character varying(200),
    "StartedAt" timestamp with time zone NOT NULL,
    "EndedAt" timestamp with time zone,
    "DurationMs" bigint NOT NULL,
    "Method" character varying(16) NOT NULL,
    "Path" character varying(512) NOT NULL,
    "QueryString" character varying(1024),
    "StatusCode" integer,
    "IsSuccess" boolean NOT NULL,
    "UserId" character varying(120),
    "UserName" character varying(200),
    "ClientId" character varying(120),
    "Ip" character varying(80),
    "UserAgent" character varying(400),
    "Host" character varying(200),
    "Controller" character varying(120),
    "Action" character varying(120),
    "RouteTemplate" character varying(512),
    "RequestBodySnippet" character varying(4096),
    "ResponseBodySnippet" character varying(4096),
    "ErrorCount" integer NOT NULL,
    "WarningCount" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: RespostasCampoPersonalizadoVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RespostasCampoPersonalizadoVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "CampoId" uuid NOT NULL,
    "ValorTexto" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RespostasEntrevistaSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RespostasEntrevistaSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EntrevistaId" uuid NOT NULL,
    "PerguntaId" uuid NOT NULL,
    "ValorTexto" character varying(2000),
    "ValorEscala" integer,
    "ValorOpcao" character varying(200)
);


--
-- Name: RmSyncAlertas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RmSyncAlertas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Tipo" character varying(40) NOT NULL,
    "EntidadeNome" character varying(40) NOT NULL,
    "EntidadeId" uuid,
    "ChaveRm" character varying(80) NOT NULL,
    "DetectadoEmUtc" timestamp with time zone NOT NULL,
    "CiclosAusente" integer NOT NULL,
    "ResolvidoEmUtc" timestamp with time zone,
    "ResolvidoPorId" uuid,
    "Acao" character varying(120),
    "RunId" uuid
);


--
-- Name: RmSyncCheckpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RmSyncCheckpoints" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Entidade" character varying(60) NOT NULL,
    "LastRecModifiedOn" timestamp with time zone,
    "LastRunAtUtc" timestamp with time zone,
    "LastRunStatus" character varying(20),
    "Notes" character varying(500)
);


--
-- Name: RmSyncRuns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RmSyncRuns" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Entidade" character varying(60) NOT NULL,
    "Operacao" character varying(20) NOT NULL,
    "StartedAtUtc" timestamp with time zone NOT NULL,
    "EndedAtUtc" timestamp with time zone,
    "Status" smallint NOT NULL,
    "TotalLidos" integer NOT NULL,
    "Criados" integer NOT NULL,
    "Atualizados" integer NOT NULL,
    "Ignorados" integer NOT NULL,
    "ErroMensagem" character varying(2000),
    "WatermarkAplicadoUtc" timestamp with time zone,
    "WatermarkNovoUtc" timestamp with time zone
);


--
-- Name: RoleMenus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RoleMenus" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RoleId" uuid NOT NULL,
    "MenuId" uuid NOT NULL,
    "PermissionKey" character varying(160) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Roles" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Description" character varying(400) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Name" character varying(256),
    "NormalizedName" character varying(256),
    "ConcurrencyStamp" text,
    "AccessMode" smallint DEFAULT 0 NOT NULL,
    "VagasDataScope" smallint DEFAULT 0 NOT NULL,
    "VisibilityScope" smallint DEFAULT 0 NOT NULL,
    "Tipo" smallint DEFAULT 1 NOT NULL
);


--
-- Name: SkillAliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SkillAliases" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SkillId" uuid NOT NULL,
    "AliasName" character varying(180) NOT NULL
);


--
-- Name: Skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Skills" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CanonicalName" character varying(180) NOT NULL,
    "Category" character varying(80),
    "ParentSkillId" uuid,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone
);


--
-- Name: SlaStatusConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SlaStatusConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoEntidade" smallint NOT NULL,
    "Status" character varying(80) NOT NULL,
    "SlaHoras" integer NOT NULL,
    "Ativo" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: SolicitacoesAprovacaoEtapas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesAprovacaoEtapas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SolicitacaoId" uuid NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "Ordem" integer NOT NULL,
    "Label" character varying(120) NOT NULL,
    "AprovadorId" uuid,
    "RoleFilaId" uuid,
    "Status" smallint NOT NULL,
    "Observacao" text,
    "DataUtc" timestamp with time zone,
    "AcaoEtapa" smallint DEFAULT 0 NOT NULL,
    "MomentoAcao" smallint DEFAULT 0 NOT NULL,
    "AssumedByUserId" uuid,
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL,
    "LembretesEnviados" integer DEFAULT 0 NOT NULL,
    "UltimoLembreteUtc" timestamp with time zone,
    "EscaladoEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesBeneficio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesBeneficio" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "TipoBeneficio" smallint NOT NULL,
    "TipoAlteracao" smallint NOT NULL,
    "Descricao" text NOT NULL,
    "IncluirDependentes" boolean NOT NULL,
    "DependenteIdsJson" text,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesDependente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesDependente" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "TipoSolicitacao" smallint NOT NULL,
    "DependenteId" uuid,
    "NomeCompleto" text NOT NULL,
    "Parentesco" smallint NOT NULL,
    "Cpf" text,
    "DataNascimento" date NOT NULL,
    "IsPcd" boolean NOT NULL,
    "DependenteIR" boolean NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesDesligamento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesDesligamento" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "DataDesligamento" date NOT NULL,
    "TipoDesligamento" smallint NOT NULL,
    "MotivoDesligamento" text NOT NULL,
    "TipoAvisoPrevio" smallint NOT NULL,
    "DiasAvisoPrevio" integer NOT NULL,
    "ElegivelRecontratacao" boolean NOT NULL,
    "SubstituirPosicao" boolean NOT NULL,
    "SolicitacaoVagaGeradaId" uuid,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "PossuiEstabilidade" boolean DEFAULT false NOT NULL,
    "EmpresaId" uuid,
    "HistoricoMedidasDisciplinares" boolean,
    "UnitId" uuid,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone,
    "SolicitacaoVagaOrigemId" uuid
);


--
-- Name: SolicitacoesEndereco; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesEndereco" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "Cep" text NOT NULL,
    "Logradouro" text NOT NULL,
    "Numero" text,
    "Bairro" text,
    "Complemento" text,
    "Cidade" text NOT NULL,
    "Uf" text NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesFerias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesFerias" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "PeriodoAquisitivo" text,
    "DataInicio" date NOT NULL,
    "DataFim" date NOT NULL,
    "QtdDias" integer NOT NULL,
    "AbonoPecuniario" boolean NOT NULL,
    "DiasAbono" integer NOT NULL,
    "Adiantamento13" boolean NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesPagamentoExtra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesPagamentoExtra" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid,
    "FuncionarioId" uuid NOT NULL,
    "TipoPagamentoExtra" smallint NOT NULL,
    "Valor" numeric NOT NULL,
    "Descricao" character varying(500) NOT NULL,
    "DataPagamento" date NOT NULL,
    "Competencia" character varying(7),
    "Status" smallint NOT NULL,
    "ImportadoPorId" uuid,
    "ImportadaEmUtc" timestamp with time zone,
    "Observacoes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoResultado" smallint,
    "IntegracaoMensagem" character varying(2000),
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesPromocao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesPromocao" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "DataEfetiva" date NOT NULL,
    "CargoAtualId" uuid,
    "NovoCargoId" uuid NOT NULL,
    "CentroCustoAtualId" uuid,
    "NovoCentroCustoId" uuid,
    "Justificativa" text NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "MotivoMovimentacao" smallint,
    "NovaUnidadeId" uuid,
    "HorarioProposto" text,
    "NovaLocalidade" text,
    "NovaPericulosidade" text,
    "NovaRemuneracao" numeric,
    "NovoSalario" numeric,
    "UnitId" uuid,
    "EmpresaId" uuid,
    "CentroCustoId" uuid,
    "UnidadeLotacaoId" uuid,
    "ForaFaixaSalarial" boolean DEFAULT false NOT NULL,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "AprovadorId" uuid,
    "JobPositionId" uuid,
    "UnitId" uuid,
    "Titulo" character varying(160) NOT NULL,
    "Justificativa" character varying(2000),
    "QtdPosicoes" integer NOT NULL,
    "Urgencia" smallint NOT NULL,
    "Status" smallint NOT NULL,
    "VagaId" uuid,
    "ObservacaoAprovador" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IsConfidencial" boolean DEFAULT false NOT NULL,
    "SubstituidoFuncionarioId" uuid,
    "SubstituidoNome" character varying(160),
    "TipoSolicitacao" smallint DEFAULT 0 NOT NULL,
    "CnhObrigatoria" boolean DEFAULT false NOT NULL,
    "DisponibilidadeViagens" boolean DEFAULT false NOT NULL,
    "EscalaTrabalho" text,
    "MotivoRequisicao" smallint,
    "PrazoDias" integer,
    "TipoContrato" smallint DEFAULT 0 NOT NULL,
    "EmpresaId" uuid,
    "CentroCustoId" uuid,
    "UnidadeLotacaoId" uuid,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "DecisaoRH" smallint,
    "DecisaoRHEmUtc" timestamp with time zone,
    "DecisaoRHPrazoMeses" integer,
    "DecisaoRHRevisadoPorId" uuid,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone,
    "DataDesligamento" date,
    "DesligamentoVinculadoId" uuid,
    "DiasAvisoPrevioDesligamento" integer,
    "MotivoDesligamentoTexto" character varying(2000),
    "PossuiEstabilidadeDesligamento" boolean,
    "TipoAvisoPrevioDesligamento" smallint,
    "CandidatoContratadoId" uuid,
    "DecisaoRHPrazoDataAlvo" timestamp with time zone,
    "MotivoRequisicaoId" uuid
);


--
-- Name: SurveyAnswers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyAnswers" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ResponseId" uuid NOT NULL,
    "QuestionId" uuid NOT NULL,
    "OptionId" uuid,
    "TextAnswer" character varying(2000)
);


--
-- Name: SurveyOptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyOptions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "QuestionId" uuid NOT NULL,
    "Text" character varying(400) NOT NULL,
    "Order" integer NOT NULL
);


--
-- Name: SurveyQuestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyQuestions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SurveyId" uuid NOT NULL,
    "Text" character varying(2000) NOT NULL,
    "Type" character varying(40),
    "Order" integer NOT NULL
);


--
-- Name: SurveyResponses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyResponses" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SurveyId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "SubmittedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Surveys" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Title" character varying(240) NOT NULL,
    "Type" character varying(40),
    "StartAtUtc" timestamp with time zone,
    "EndAtUtc" timestamp with time zone,
    "DepartmentsJson" jsonb,
    "CreatedByUserId" uuid,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TalentoCompetencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoCompetencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Tipo" character varying(40) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Nivel" character varying(40) NOT NULL,
    "Evidencia" character varying(300),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "TempoAtuacao" character varying(80)
);


--
-- Name: TalentoCvImportJobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoCvImportJobs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "TalentoDocumentoId" uuid NOT NULL,
    "Status" integer NOT NULL,
    "EnviarParaGpt" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "FinishedAtUtc" timestamp with time zone,
    "SimilarTalentoId" uuid,
    "SuggestedDataJson" text,
    "ErrorMessage" character varying(2000)
);


--
-- Name: TalentoDocumentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoDocumentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "NomeArquivo" character varying(200) NOT NULL,
    "ContentType" character varying(120),
    "Descricao" character varying(240),
    "StorageFileName" character varying(260),
    "TamanhoBytes" bigint,
    "DataReferencia" character varying(20),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TalentoExperiencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoExperiencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Empresa" character varying(160) NOT NULL,
    "Cargo" character varying(160) NOT NULL,
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Local" character varying(160),
    "Atividades" character varying(2400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "TipoContratacao" character varying(40),
    "NivelHierarquico" character varying(80),
    "NivelSenioridade" character varying(40),
    "ResumoAtividades" character varying(800)
);


--
-- Name: TalentoFormacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoFormacoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Curso" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Tipo" character varying(40),
    "Status" character varying(40),
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Observacoes" character varying(800),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TalentoTreinamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoTreinamentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Ano" character varying(10),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Talentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Talentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PessoaId" uuid NOT NULL,
    "Origem" integer NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "CvProfileJson" text,
    "Versao" integer DEFAULT 1 NOT NULL
);


--
-- Name: TemplatesEntrevistaSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TemplatesEntrevistaSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Ativo" boolean DEFAULT false NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantAwsSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantAwsSettings" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "AccessKeyIdEncrypted" text,
    "SecretAccessKeyEncrypted" text,
    "Region" character varying(50),
    "BucketName" character varying(200),
    "PresignedUrlExpirationMinutes" integer NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantBrandings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantBrandings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NomePortal" character varying(80),
    "Subtitulo" character varying(160),
    "RodapeTexto" character varying(160),
    "CorPrimariaHex" character varying(7),
    "CorSecundariaHex" character varying(7),
    "LogoUrl" character varying(512),
    "VersaoExibida" character varying(32),
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantConfiguracoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantConfiguracoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RhDeveAprovarAposGestor" boolean NOT NULL,
    "AprovadorRhId" uuid,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DiasProvisaoSubstituicao" integer DEFAULT 30 NOT NULL,
    "DiasAlertaVagaSemFill" integer DEFAULT 60 NOT NULL,
    "SlaAprovacaoHoras" integer DEFAULT 48 NOT NULL,
    "SlaEscalacaoHoras" integer DEFAULT 96 NOT NULL,
    "BloqueiaSalarioForaFaixa" boolean DEFAULT false NOT NULL,
    "AzureAdClientId" text,
    "AzureAdClientSecret" text,
    "AzureAdTenantId" text,
    "BlipNumeroHospedeiro" text,
    "BlipApiKey" text,
    "BlipApiUrl" text,
    "LlmProvider" text,
    "LlmModel" text,
    "EmbeddingProvider" text,
    "EmbeddingModel" text
);


--
-- Name: Turnos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Turnos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "StartTime" character varying(5),
    "EndTime" character varying(5),
    "Notes" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UnidadeLotacaoId" uuid
);


--
-- Name: UnidadesLotacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UnidadesLotacao" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "Location" character varying(120),
    "Notes" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Level" integer DEFAULT 1 NOT NULL,
    "OwnerCdnEmpresa" character varying(3),
    "OwnerCdnEstab" character varying(5),
    "OwnerCdnFuncionario" character varying(12),
    "OwnerFuncionarioId" uuid,
    "ParentId" uuid,
    "SequenceNumber" integer,
    "CdnPlanoLotac" character varying(10) NOT NULL
);


--
-- Name: Units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Units" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(40) NOT NULL,
    "Name" character varying(140) NOT NULL,
    "Status" integer NOT NULL,
    "City" character varying(120),
    "Uf" character varying(2),
    "AddressLine" character varying(220),
    "Neighborhood" character varying(120),
    "ZipCode" character varying(12),
    "Email" character varying(180),
    "Phone" character varying(40),
    "ResponsibleName" character varying(140),
    "Type" character varying(120),
    "Headcount" integer NOT NULL,
    "Notes" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "EmpresaId" uuid,
    "NomAbrevPessoaFisic" text,
    "NomAbrevPessoaJurid" text,
    "NomPessoaJurid" text
);


--
-- Name: UserRoles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserRoles" (
    "UserId" uuid NOT NULL,
    "RoleId" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL
);


--
-- Name: UserUnits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserUnits" (
    "UserId" uuid NOT NULL,
    "UnitId" uuid NOT NULL
);


--
-- Name: Users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Users" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FullName" character varying(200) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UserName" character varying(256),
    "NormalizedUserName" character varying(256),
    "Email" character varying(256),
    "NormalizedEmail" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "PasswordHash" text,
    "SecurityStamp" text,
    "ConcurrencyStamp" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "TwoFactorEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp with time zone,
    "LockoutEnabled" boolean NOT NULL,
    "AccessFailedCount" integer NOT NULL,
    "FuncionarioId" uuid
);


--
-- Name: VagaBeneficios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaBeneficios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Tipo" smallint NOT NULL,
    "Valor" numeric,
    "Recorrencia" smallint NOT NULL,
    "Obrigatorio" boolean NOT NULL,
    "Observacoes" character varying(240),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: VagaEtapas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaEtapas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Responsavel" smallint NOT NULL,
    "Modo" smallint NOT NULL,
    "SlaDias" integer,
    "DescricaoInstrucoes" character varying(240),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: VagaPerguntas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaPerguntas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Texto" character varying(220) NOT NULL,
    "Tipo" smallint NOT NULL,
    "Peso" smallint NOT NULL,
    "Obrigatoria" boolean NOT NULL,
    "Knockout" boolean NOT NULL,
    "OpcoesRaw" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: VagaRequisitos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaRequisitos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Nome" character varying(180) NOT NULL,
    "Peso" smallint NOT NULL,
    "Obrigatorio" boolean NOT NULL,
    "AnosMinimos" integer,
    "Nivel" smallint,
    "Avaliacao" smallint,
    "SinonimosRaw" character varying(400),
    "Observacoes" character varying(240),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Categoria" character varying(80)
);


--
-- Name: VagaUnifiedMatchingCaches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaUnifiedMatchingCaches" (
    "VagaId" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CurrentFiltersHash" character varying(64) NOT NULL,
    "PendingFiltersHash" character varying(64),
    "Status" character varying(20) NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "ComputedAtUtc" timestamp with time zone,
    "LastAccessAtUtc" timestamp with time zone,
    "ItemsJson" jsonb,
    "LastError" character varying(2000)
);


--
-- Name: Vagas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Vagas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Codigo" character varying(40),
    "Titulo" character varying(160) NOT NULL,
    "AreaTime" smallint,
    "Modalidade" smallint,
    "Status" smallint NOT NULL,
    "Senioridade" smallint,
    "QuantidadeVagas" integer NOT NULL,
    "TipoContratacao" smallint,
    "MatchMinimoPercentual" integer NOT NULL,
    "DescricaoInterna" text,
    "CodigoInterno" character varying(40),
    "CodigoCbo" character varying(20),
    "MotivoAbertura" smallint,
    "OrcamentoAprovado" smallint,
    "GestorRequisitante" character varying(120),
    "RecrutadorResponsavel" character varying(120),
    "Prioridade" smallint,
    "ResumoPitch" text,
    "TagsResponsabilidadesRaw" text,
    "TagsKeywordsRaw" text,
    "Confidencial" boolean NOT NULL,
    "AceitaPcd" boolean NOT NULL,
    "Urgente" boolean NOT NULL,
    "GeneroPreferencia" smallint,
    "VagaAfirmativa" boolean NOT NULL,
    "LinguagemInclusiva" boolean NOT NULL,
    "PublicoAfirmativo" character varying(120),
    "ObservacoesPcd" text,
    "ProjetoNome" character varying(160),
    "ProjetoClienteAreaImpactada" character varying(160),
    "ProjetoPrazoPrevisto" character varying(80),
    "ProjetoDescricao" text,
    "Regime" smallint,
    "CargaSemanalHoras" integer,
    "Escala" smallint,
    "HoraEntrada" time without time zone,
    "HoraSaida" time without time zone,
    "Intervalo" interval,
    "Cep" character varying(12),
    "Logradouro" character varying(160),
    "Numero" character varying(20),
    "Bairro" character varying(120),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "PoliticaTrabalho" character varying(200),
    "ObservacoesDeslocamento" character varying(200),
    "Moeda" smallint,
    "SalarioMinimo" numeric(18,2),
    "SalarioMaximo" numeric(18,2),
    "Periodicidade" smallint,
    "BonusTipo" smallint,
    "BonusPercentual" numeric,
    "ObservacoesRemuneracao" character varying(240),
    "Escolaridade" smallint,
    "FormacaoArea" smallint,
    "ExperienciaMinimaAnos" integer,
    "TagsStackRaw" text,
    "TagsIdiomasRaw" text,
    "Diferenciais" text,
    "ObservacoesProcesso" text,
    "Visibilidade" smallint,
    "DataInicio" date,
    "DataEncerramento" date,
    "CanalLinkedIn" boolean NOT NULL,
    "CanalSiteCarreiras" boolean NOT NULL,
    "CanalIndicacao" boolean NOT NULL,
    "CanalPortaisEmprego" boolean NOT NULL,
    "DescricaoPublica" text,
    "LgpdSolicitarConsentimentoExplicito" boolean NOT NULL,
    "LgpdCompartilharCurriculoInternamente" boolean NOT NULL,
    "LgpdRetencaoAtiva" boolean NOT NULL,
    "LgpdRetencaoMeses" integer,
    "ExigeCnh" boolean NOT NULL,
    "DisponibilidadeParaViagens" boolean NOT NULL,
    "ChecagemAntecedentes" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "PesoCompetencia" integer DEFAULT 0 NOT NULL,
    "PesoExperiencia" integer DEFAULT 0 NOT NULL,
    "PesoFormacao" integer DEFAULT 0 NOT NULL,
    "PesoLocalidade" integer DEFAULT 0 NOT NULL,
    "DataAbertura" timestamp with time zone,
    "SlaDiasMetaFechamento" integer,
    "RecrutadorResponsavelUserId" uuid,
    "MatchingFiltrosOriginaisRaw" text,
    "MatchingFiltrosRaw" text,
    "NomeEngessado" character varying(200),
    "JobPositionId" uuid,
    "CategoriaSalarialId" uuid,
    "CentroCustoId" uuid,
    "TurnoId" uuid,
    "UnidadeLotacaoId" uuid,
    "EscalaTrabalhoRaw" text,
    "HeadcountAutorizado" integer DEFAULT 1 NOT NULL,
    "IsEstrutural" boolean DEFAULT false NOT NULL,
    "HeadcountProvisorio" integer DEFAULT 0 NOT NULL,
    "HeadcountProvisorioExpiresAtUtc" timestamp with time zone,
    "AlertaVagaSemFillSnoozeAteUtc" timestamp with time zone,
    "HeadcountPendente" integer DEFAULT 0 NOT NULL,
    "EixoVagaId" uuid,
    "TravarFaixaSalarial" boolean DEFAULT false NOT NULL,
    "AlcadaSalarialAprovadaPorUserId" uuid,
    "AlcadaSalarialAprovadaEmUtc" timestamp with time zone,
    "AlcadaSalarialJustificativa" character varying(1000),
    "AlcadaSalarialObservacaoAprovador" character varying(500),
    "PesoIdioma" integer DEFAULT 0 NOT NULL,
    "PesoConhecimentoTecnico" integer DEFAULT 0 NOT NULL,
    "PesoVivenciaEspecifica" integer DEFAULT 0 NOT NULL,
    "LocalidadeMaxDistanciaKm" integer,
    "DescricaoCargoId" uuid,
    "HierarquiaId" uuid,
    "IdReqRmOrigem" character varying(40),
    "OrigemDesligamentoId" uuid,
    "OrigemTipo" smallint DEFAULT 0 NOT NULL,
    "CodFuncaoRm" character varying(20),
    "FuncaoNomeRm" character varying(160),
    "CiclosAusenteRm" integer DEFAULT 0 NOT NULL,
    "UltimoCicloRmObservadoUtc" timestamp with time zone
);


--
-- Name: WorkflowsRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkflowsRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoWorkflow" smallint NOT NULL,
    "VagaId" uuid,
    "PreAdmissaoId" uuid,
    "Status" smallint NOT NULL,
    "ResponsavelId" uuid,
    "DataInicio" timestamp with time zone,
    "DataConclusao" timestamp with time zone,
    "SlaPrazoDias" integer,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DesligamentoId" uuid
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Data for Name: AgendaEventTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AgendaEventTypes" ("Id", "TenantId", "Code", "Label", "Color", "Icon", "SortOrder", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
1f769e4e-f2ab-4ef5-936f-5357b7356c7b	dev	followup	Seed.AgendaTypeFollowUp	#8b5cf6	bi-chat-dots	5	t	2026-04-24 22:45:13.894707-03	2026-04-24 22:45:13.894707-03
2d6211a6-a05b-4d66-b9b0-121ab406e1ab	dev	assessment	Seed.AgendaTypeAssessment	#f59e0b	bi-clipboard-check	4	t	2026-04-24 22:45:13.894707-03	2026-04-24 22:45:13.894707-03
ceaa0f3d-eeac-45cb-b865-76c13d4c8743	dev	onboarding	Seed.AgendaTypeOnboarding	#22c55e	bi-stars	3	t	2026-04-24 22:45:13.894707-03	2026-04-24 22:45:13.894707-03
f8eafc91-c3e3-4abf-bd50-289b39145199	dev	entrevista	Seed.AgendaTypeInterview	#1f6feb	bi-camera-video	1	t	2026-04-24 22:45:13.894707-03	2026-04-24 22:45:13.894707-03
f9016a78-2ded-4eaf-a278-2fc048dffa2c	dev	reuniao	Seed.AgendaTypeMeeting	#0ea5e9	bi-people	2	t	2026-04-24 22:45:13.894707-03	2026-04-24 22:45:13.894707-03
ffa45521-2bd9-4704-aa32-07d8eeee96a3	dev	outro	Seed.AgendaTypeOther	#6b7280	bi-calendar	6	t	2026-04-24 22:45:13.894707-03	2026-04-24 22:45:13.894707-03
\.


--
-- Data for Name: AgendaEvents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AgendaEvents" ("Id", "TenantId", "TypeId", "Title", "StartAtUtc", "EndAtUtc", "AllDay", "Status", "Location", "Owner", "Candidate", "VagaTitle", "VagaCode", "Notes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: ApiKeys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ApiKeys" ("Id", "TenantId", "Name", "KeyHash", "Description", "IsActive", "CreatedAtUtc", "LastUsedAtUtc") FROM stdin;
\.


--
-- Data for Name: ApprovalMagicLinks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ApprovalMagicLinks" ("Id", "TenantId", "Token", "EtapaId", "SolicitacaoId", "TipoFluxo", "AprovadorFuncionarioId", "ExpiresAtUtc", "UsedAtUtc", "AcaoRealizada", "IpAddress", "UserAgent", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: AprovacoesFaixaSalarial; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AprovacoesFaixaSalarial" ("Id", "TenantId", "FaixaSalarialId", "SolicitanteId", "ValorProposto", "Justificativa", "Status", "AprovadorId", "ObservacaoAprovador", "CreatedAtUtc", "AprovadoEmUtc") FROM stdin;
\.


--
-- Data for Name: AprovadoresAlternativos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AprovadoresAlternativos" ("Id", "TenantId", "GestorId", "AprovadorId", "DataInicio", "DataFim", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: AspNetRoleClaims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AspNetRoleClaims" ("Id", "RoleId", "ClaimType", "ClaimValue") FROM stdin;
\.


--
-- Data for Name: AspNetUserClaims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AspNetUserClaims" ("Id", "UserId", "ClaimType", "ClaimValue") FROM stdin;
\.


--
-- Data for Name: AspNetUserLogins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AspNetUserLogins" ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM stdin;
\.


--
-- Data for Name: AspNetUserTokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AspNetUserTokens" ("UserId", "LoginProvider", "Name", "Value") FROM stdin;
\.


--
-- Data for Name: AuditEntityChanges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditEntityChanges" ("Id", "TenantId", "AuditTransactionId", "AuditEventId", "Order", "EntityName", "TableName", "State", "PrimaryKeyJson", "BeforeJson", "AfterJson", "ChangedColumns", "DataJson", "OccurredAt", "CreatedAt") FROM stdin;
3b89c8fe-2b5c-47c7-86fe-d7d963652cb0	dev	12ed7009-8af3-4bcf-9ae2-f458ae00b352	b1eb95fa-bf67-4dc3-af69-ec4b43f9f340	1	GamificationDailyState	GamificationDailyStates	Added	{"Id": "1bef9ef9-7f1c-4162-90d4-5a4bc1f79cce"}	\N	{"Id": "1bef9ef9-7f1c-4162-90d4-5a4bc1f79cce", "UserId": "462756d3-8066-42bb-ad9c-6c29d8de1f99", "TenantId": "dev", "BestStreak": 1, "CreatedAtUtc": "2026-04-25T14:12:31.00693+00:00", "UpdatedAtUtc": "2026-04-25T14:12:31.00693+00:00", "CurrentStreak": 1, "LastCheckInDate": "2026-04-25", "LastActivityDate": "2026-04-25", "FeedbackSentToday": 0, "SurveyAnsweredToday": 0, "CelebrationPostsToday": 0, "OneOnOneCompletedToday": 0, "CelebrationCommentsToday": 0, "DevelopmentPlansCreatedToday": 0}	\N	\N	2026-04-25 11:12:31.033568-03	2026-04-25 11:12:31.033568-03
3f8d8352-022d-4e6c-9833-d6525bd5a2b1	dev	12ed7009-8af3-4bcf-9ae2-f458ae00b352	b1eb95fa-bf67-4dc3-af69-ec4b43f9f340	1	RenderCoinTransaction	RenderCoinTransactions	Added	{"Id": "b95c20ae-bb04-49b4-b2b3-aa8837b212d2"}	\N	{"Id": "b95c20ae-bb04-49b4-b2b3-aa8837b212d2", "Amount": 25, "Reason": "Login diário", "UserId": "462756d3-8066-42bb-ad9c-6c29d8de1f99", "SourceId": "daily_login:2026-04-25", "TenantId": "dev", "SourceType": "daily_login", "CreatedAtUtc": "2026-04-25T14:12:30.984767+00:00"}	\N	\N	2026-04-25 11:12:31.033529-03	2026-04-25 11:12:31.033538-03
55879861-3a3c-42a7-96cc-fc2776824a46	dev	12ed7009-8af3-4bcf-9ae2-f458ae00b352	b1eb95fa-bf67-4dc3-af69-ec4b43f9f340	1	RenderCoinBalance	RenderCoinBalances	Added	{"UserId": "462756d3-8066-42bb-ad9c-6c29d8de1f99", "TenantId": "dev"}	\N	{"UserId": "462756d3-8066-42bb-ad9c-6c29d8de1f99", "Balance": 25, "TenantId": "dev", "UpdatedAtUtc": "2026-04-25T14:12:30.992723+00:00"}	\N	\N	2026-04-25 11:12:31.033563-03	2026-04-25 11:12:31.033563-03
\.


--
-- Data for Name: AuditEntityPropertyChanges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditEntityPropertyChanges" ("Id", "TenantId", "AuditEntityChangeId", "PropertyName", "BeforeValue", "AfterValue", "IsSensitive", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: AuditEvents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditEvents" ("Id", "TenantId", "AuditTransactionId", "Order", "EventType", "Name", "OccurredAt", "DataJson", "CreatedAt") FROM stdin;
b1eb95fa-bf67-4dc3-af69-ec4b43f9f340	dev	12ed7009-8af3-4bcf-9ae2-f458ae00b352	1	DB	SaveChanges	2026-04-25 11:12:31.033052-03	\N	2026-04-25 11:12:31.033052-03
032d26ed-2354-4ae0-beef-d1cd5d61a3a0	dev	a84ccd4e-b745-4f1a-b7f0-a38efae5b28b	1	HTTP	HTTP Request	2026-04-25 11:12:31.147187-03	\N	2026-04-25 11:12:31.147187-03
728ae88f-d358-4801-a0b6-a473a6781e00	dev	e6337568-fa07-4ef2-9f63-07e53a81b9e4	1	HTTP	HTTP Request	2026-04-25 11:12:35.063194-03	\N	2026-04-25 11:12:35.063195-03
cd064de6-3ead-4e23-901a-b543c1669549	dev	baaed310-351e-4b70-9852-fe50f4c8974d	1	HTTP	HTTP Request	2026-04-27 09:58:47.193042-03	\N	2026-04-27 09:58:47.193042-03
eac6beb8-6500-4a7b-927d-a773393175e8	dev	8d9e6a2d-adfd-4211-a6f3-82165de5314b	1	HTTP	HTTP Request	2026-04-27 09:58:47.193035-03	\N	2026-04-27 09:58:47.193035-03
3dca4918-08d2-4f31-ac1c-5f8436614152	dev	8a68ca88-1c29-47ab-bdbc-ab3715cd6d0c	1	HTTP	HTTP Request	2026-04-27 09:58:47.19304-03	\N	2026-04-27 09:58:47.19304-03
a75c7d22-4148-4952-8a04-db5a9a9e3883	dev	3228deb4-b9d3-417d-a3ee-26d6b310c02e	1	HTTP	HTTP Request	2026-04-27 09:58:47.19304-03	\N	2026-04-27 09:58:47.193041-03
ada1e4b6-cdc2-41ea-a360-e0f4a46c6bad	dev	a95229b9-3022-4e7d-bbc8-a1b6b356c348	1	HTTP	HTTP Request	2026-04-27 09:58:47.196509-03	\N	2026-04-27 09:58:47.19651-03
2d123a3b-564d-4628-8ad5-9ac8ff82d7de	dev	752b94ab-4e94-4e26-910b-cd9ecab4c6f0	1	HTTP	HTTP Request	2026-04-27 09:58:47.196435-03	\N	2026-04-27 09:58:47.196436-03
86fc7a97-c0aa-42a5-81e6-8d3ac0487fa0	dev	08c8de51-0d87-496e-93ce-9a9b9c712e69	1	HTTP	HTTP Request	2026-04-27 09:58:47.224479-03	\N	2026-04-27 09:58:47.224479-03
10cca4c9-fe08-4e58-bab4-b8cc7b26328e	dev	df97c23d-c34e-4ee7-a3e6-404fa2fa2f48	1	HTTP	HTTP Request	2026-04-27 09:58:47.22418-03	\N	2026-04-27 09:58:47.22418-03
eebb73df-0b7c-44db-98a5-71eab55b3ffb	dev	102d9d0f-4fe0-4e79-bede-9e4f780dc4cf	1	HTTP	HTTP Request	2026-04-27 09:58:47.225288-03	\N	2026-04-27 09:58:47.225288-03
0a8b399c-b81e-43eb-b30b-bc483589ce0b	dev	3bbc552c-cc60-48a2-863d-cca364739e6d	1	HTTP	HTTP Request	2026-04-27 09:58:47.225527-03	\N	2026-04-27 09:58:47.225527-03
4ef4d26c-923f-4e27-b66a-c71da05d5016	dev	92863627-2eaa-45fa-9706-646de5b74468	1	HTTP	HTTP Request	2026-04-27 09:58:47.227584-03	\N	2026-04-27 09:58:47.227584-03
43006360-7065-4ed4-ba7c-6ab7c88bfc84	dev	0b923990-73e4-4220-9940-3e4d0bc74c31	1	HTTP	HTTP Request	2026-04-27 09:58:47.235179-03	\N	2026-04-27 09:58:47.23518-03
77c96f71-718e-4d3c-a258-ef21f1369536	dev	a6391c9c-f950-4d40-a296-ec9f4bd20afd	1	HTTP	HTTP Request	2026-04-27 09:58:47.240094-03	\N	2026-04-27 09:58:47.240094-03
d820857f-6968-4586-9766-ac1d01ea6d3e	dev	85a5bed4-1127-4f16-85f4-14c4b457db6f	1	HTTP	HTTP Request	2026-04-27 09:58:47.243499-03	\N	2026-04-27 09:58:47.2435-03
1da43e82-187c-4894-b71f-b27454f876c4	dev	98d5e273-63a8-425a-9059-19a6581f0288	1	HTTP	HTTP Request	2026-04-27 09:58:47.244123-03	\N	2026-04-27 09:58:47.244123-03
4f87dd98-4f3f-4615-80eb-dfe8b04da319	dev	f8ec8fad-f66d-482c-a3b8-642bf17aa279	1	HTTP	HTTP Request	2026-04-27 09:58:47.244461-03	\N	2026-04-27 09:58:47.244461-03
baa5cb21-3c09-4330-b67b-c836b235d517	dev	c67c9ca0-0866-4473-b252-cb59c6a867d7	1	HTTP	HTTP Request	2026-04-27 09:58:47.248944-03	\N	2026-04-27 09:58:47.248944-03
aec4305e-66d7-4988-acb1-d3265bdc23e8	dev	c1f80fbb-c47e-4dda-b4df-74825c74456c	1	HTTP	HTTP Request	2026-04-27 09:58:47.250271-03	\N	2026-04-27 09:58:47.250271-03
5520781c-a1ca-4a0a-a6e6-093759dae12b	dev	fc4818da-8c4a-4fe1-8b7b-e30bbbc09137	1	HTTP	HTTP Request	2026-04-27 09:58:47.255845-03	\N	2026-04-27 09:58:47.255845-03
b6ab096a-795e-4603-9067-01566b66c804	dev	d1b6c3d7-992a-44b1-9228-b5d24205e584	1	HTTP	HTTP Request	2026-04-27 09:58:47.259659-03	\N	2026-04-27 09:58:47.259659-03
c5638dea-5ef9-47a9-9826-2d32716999fa	dev	0f50750e-a6fa-41a0-b1da-001ce8ea7f3b	1	HTTP	HTTP Request	2026-04-27 09:58:47.260635-03	\N	2026-04-27 09:58:47.260635-03
6e482273-49b5-47d9-9830-969af7cbb1a5	dev	222593b0-1d42-4bc6-80a2-2eb01b1a9372	1	HTTP	HTTP Request	2026-04-27 09:58:49.372899-03	\N	2026-04-27 09:58:49.372899-03
2681712d-f6b3-432e-95d4-3904f38d06f4	dev	e8f74f20-eff6-4296-9975-fb3a516f4098	1	HTTP	HTTP Request	2026-04-27 09:58:53.733517-03	\N	2026-04-27 09:58:53.733517-03
29c77da1-6b7a-442b-82be-fddef97c896c	dev	1fc4323d-6871-4034-8839-5c3820a88385	1	HTTP	HTTP Request	2026-04-27 09:59:22.366083-03	\N	2026-04-27 09:59:22.366083-03
\.


--
-- Data for Name: AuditTransactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditTransactions" ("Id", "TenantId", "TransactionId", "CorrelationId", "TraceId", "SpanId", "ParentSpanId", "Environment", "AppVersion", "StartedAt", "EndedAt", "DurationMs", "UserId", "UserName", "ClientId", "Ip", "UserAgent", "Host", "Method", "Path", "QueryString", "RouteTemplate", "Controller", "Action", "StatusCode", "IsSuccess", "RequestContentType", "ResponseContentType", "RequestBody", "ResponseBody", "RequestBodyHash", "ResponseBodyHash", "RequestIsTruncated", "ResponseIsTruncated", "RequestTruncatedBytes", "ResponseTruncatedBytes", "ErrorMessage", "ErrorStackTrace", "CreatedAt") FROM stdin;
12ed7009-8af3-4bcf-9ae2-f458ae00b352	dev	48d0345b4e184c6b8276c3132357233c	\N	\N	\N	\N	system	1.0.0.0	2026-04-25 11:12:31.023433-03	\N	0	\N	\N	\N	\N	\N	\N	N/A	/	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	f	f	0	0	\N	\N	2026-04-25 11:12:31.030013-03
a84ccd4e-b745-4f1a-b7f0-a38efae5b28b	dev	0HNL2QI129U4L:00000001	00-4ec74b01445ce0a2ceb885e5fec569ce-ae5bf46139f7917b-00	4ec74b01445ce0a2ceb885e5fec569ce	ae5bf46139f7917b	0000000000000000	Development	1.0.0.0	2026-04-25 11:12:31.144766-03	2026-04-25 11:12:31.146213-03	1	462756d3-8066-42bb-ad9c-6c29d8de1f99	DEV Administrador	\N	::1	curl/8.7.1	localhost:5056	GET	/api/tenant-configuracao/ai	\N	api/tenant-configuracao/ai	TenantConfiguracao	GetAiConfig	200	t	\N	application/json; charset=utf-8	\N	{"llmProvider":null,"llmModel":null,"embeddingProvider":null,"embeddingModel":null,"knownProviders":["OpenAI","Gpt","Azure","Gemini","Google","Anthropic","Claude"],"effectiveLlmProvider":"gemini","effectiveLlmModel":"gemini-2.5-flash","effectiveEmbeddingProvider":"gemini","effectiveEmbeddingModel":"models/gemini-embedding-001"}	\N	D586BD4E42AFC7D18F2DFA130C8E0A4228D5C23C056EEE3A625FAB40E00CE838	f	f	0	0	\N	\N	2026-04-25 11:12:31.147186-03
e6337568-fa07-4ef2-9f63-07e53a81b9e4	dev	0HNL2QI129U4N:00000001	00-e4cea9d3e30c8d8bd2a9bba47a95d43d-8e6bbc1e07fd8c45-00	e4cea9d3e30c8d8bd2a9bba47a95d43d	8e6bbc1e07fd8c45	0000000000000000	Development	1.0.0.0	2026-04-25 11:12:33.165412-03	2026-04-25 11:12:35.057853-03	1892	462756d3-8066-42bb-ad9c-6c29d8de1f99	DEV Administrador	\N	::1	curl/8.7.1	localhost:5056	POST	/api/ai/invoke	\N	api/ai/invoke	Ai	Invoke	200	t	application/json	application/json; charset=utf-8	{"module":"smoke-fase3","payload":{"prompt":"Diga \\u0022oi dev\\u0022","cvText":"ping"}}	{"content":"oi dev","cost":0.0000150}	4E42B59E02F71FCD19196D5183FAAA139DDFF68931AE31E9A316509302247B7A	C8A5BF65BA42A3017FF2C8BEB0E8EC5893593A27C990D7518C04EA4B4A8D08F1	f	f	0	0	\N	\N	2026-04-25 11:12:35.063184-03
baaed310-351e-4b70-9852-fe50f4c8974d	dev	0HNL4B65QMA0L:00000001	00-f7833517a9739097f9757ed459359107-356b2a8ad58fb3e0-00	f7833517a9739097f9757ed459359107	356b2a8ad58fb3e0	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.180637-03	2026-04-27 09:58:47.189408-03	8	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/aprovacoes/pendentes/count	\N	api/aprovacoes/pendentes/count	Aprovacoes	GetPendentesCount	200	t	\N	application/json; charset=utf-8	\N	{"count":0}	\N	618DE7D9F46F3F697D827A1B6D84974760D5DEDA62E4E592ADAA3C646602A94C	f	f	0	0	\N	\N	2026-04-27 09:58:47.193033-03
3228deb4-b9d3-417d-a3ee-26d6b310c02e	dev	0HNL4B65QMA0O:00000001	00-5ffa118c245d0ceb45ad83dc91976c27-3c5320870c2c21df-00	5ffa118c245d0ceb45ad83dc91976c27	3c5320870c2c21df	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.180637-03	2026-04-27 09:58:47.187089-03	6	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-dependente	?status=1	api/colaborador/solicitacoes-dependente	SolicitacoesDependente	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.193039-03
8d9e6a2d-adfd-4211-a6f3-82165de5314b	dev	0HNL4B65QMA0N:00000001	00-76583899a3c586658118c671b24dbd2d-e6c6583974af1214-00	76583899a3c586658118c671b24dbd2d	e6c6583974af1214	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.180637-03	2026-04-27 09:58:47.186901-03	6	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-beneficio	?status=1	api/colaborador/solicitacoes-beneficio	SolicitacoesBeneficio	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.193033-03
8a68ca88-1c29-47ab-bdbc-ab3715cd6d0c	dev	0HNL4B65QMA0P:00000001	00-4a03802d4f29b130a450f96cb5c39e3e-c430e5da1f70a62c-00	4a03802d4f29b130a450f96cb5c39e3e	c430e5da1f70a62c	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.180719-03	2026-04-27 09:58:47.187273-03	6	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-endereco	?status=1	api/colaborador/solicitacoes-endereco	SolicitacoesEndereco	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.193033-03
a95229b9-3022-4e7d-bbc8-a1b6b356c348	dev	0HNL4B65QMA0Q:00000001	00-e5e173fbcc7960b0052e52ff61472a56-b1028a5d86adfcaf-00	e5e173fbcc7960b0052e52ff61472a56	b1028a5d86adfcaf	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.180637-03	2026-04-27 09:58:47.192568-03	11	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/solicitacoes-vaga	?statuses=1&statuses=5	api/solicitacoes-vaga	SolicitacoesVaga	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.196508-03
752b94ab-4e94-4e26-910b-cd9ecab4c6f0	dev	0HNL4B65QMA0M:00000001	00-8f369056a5d6b0382e38532398103301-0ab68b64e11433e6-00	8f369056a5d6b0382e38532398103301	0ab68b64e11433e6	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.191519-03	2026-04-27 09:58:47.193506-03	1	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-ferias	?status=1	api/colaborador/solicitacoes-ferias	SolicitacoesFerias	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.196433-03
df97c23d-c34e-4ee7-a3e6-404fa2fa2f48	dev	0HNL4B65QMA0U:00000001	00-c4706bc3a3eadc5e6b9bca3b6da325ee-60aeebf954e0f584-00	c4706bc3a3eadc5e6b9bca3b6da325ee	60aeebf954e0f584	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.220771-03	2026-04-27 09:58:47.221822-03	1	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-beneficio	?status=1	api/colaborador/solicitacoes-beneficio	SolicitacoesBeneficio	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.224177-03
0b923990-73e4-4220-9940-3e4d0bc74c31	dev	0HNL4B65QMA10:00000001	00-6231e51a5d787460a4f0b9983bf8a0b4-d883b383f167aeea-00	6231e51a5d787460a4f0b9983bf8a0b4	d883b383f167aeea	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.231905-03	2026-04-27 09:58:47.233469-03	1	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-endereco	?status=1	api/colaborador/solicitacoes-endereco	SolicitacoesEndereco	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.235178-03
85a5bed4-1127-4f16-85f4-14c4b457db6f	dev	0HNL4B65QMA12:00000001	00-671612297c410a8a973eb730c3262f40-88588bc9824ad59c-00	671612297c410a8a973eb730c3262f40	88588bc9824ad59c	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.236688-03	2026-04-27 09:58:47.240894-03	4	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/dashboard/funil	\N	api/dashboard/funil	Dashboard	GetFunnel	200	t	\N	application/json; charset=utf-8	\N	{"recebidos":0,"triagem":0,"entrevista":0,"aprovados":0}	\N	6A461D347CF2985FADD58F1BFF29840DFCF8EC386DAB9FDA94B3320BFAEC91AA	f	f	0	0	\N	\N	2026-04-27 09:58:47.243498-03
08c8de51-0d87-496e-93ce-9a9b9c712e69	dev	0HNL4B65QMA0S:00000001	00-4cffc3c23833f3ac7d7da44999d62982-1a65d8d99b0d7e1e-00	4cffc3c23833f3ac7d7da44999d62982	1a65d8d99b0d7e1e	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.215626-03	2026-04-27 09:58:47.222023-03	6	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/solicitacoes-desligamento	?status=1	api/solicitacoes-desligamento	SolicitacoesDesligamento	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.224448-03
c67c9ca0-0866-4473-b252-cb59c6a867d7	dev	0HNL4B65QMA11:00000001	00-50682e00430fcb1ce37cb1340089e14c-ef0aca37552173f7-00	50682e00430fcb1ce37cb1340089e14c	ef0aca37552173f7	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.235837-03	2026-04-27 09:58:47.247131-03	11	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/dashboard/kpis	\N	api/dashboard/kpis	Dashboard	GetKpis	200	t	\N	application/json; charset=utf-8	\N	{"openVagas":0,"cvsHoje":0,"pendentesMatch":0,"aprovados7Dias":0,"vagasForaSla":0}	\N	513236D50FED1F3D0A4CBA618518B633C7CAECE2FF574FA8C0DD5C4C8E4A47D6	f	f	0	0	\N	\N	2026-04-27 09:58:47.248941-03
102d9d0f-4fe0-4e79-bede-9e4f780dc4cf	dev	0HNL4B65QMA0T:00000001	00-c781bcbe548bf3cce8d565093e095be7-b5b58e2b4ee985c8-00	c781bcbe548bf3cce8d565093e095be7	b5b58e2b4ee985c8	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.220787-03	2026-04-27 09:58:47.22289-03	2	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-ferias	?status=1	api/colaborador/solicitacoes-ferias	SolicitacoesFerias	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.225286-03
3bbc552c-cc60-48a2-863d-cca364739e6d	dev	0HNL4B65QMA0V:00000001	00-47939e198efbcac3f4f30695764bac02-c4ded72944cba3de-00	47939e198efbcac3f4f30695764bac02	c4ded72944cba3de	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.22079-03	2026-04-27 09:58:47.22344-03	2	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/colaborador/solicitacoes-dependente	?status=1	api/colaborador/solicitacoes-dependente	SolicitacoesDependente	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.225525-03
a6391c9c-f950-4d40-a296-ec9f4bd20afd	dev	0HNL4B65QMA13:00000001	00-e161608a25b6d58aa79f6d4a8633581e-0e91697d07ea02cc-00	e161608a25b6d58aa79f6d4a8633581e	0e91697d07ea02cc	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.236751-03	2026-04-27 09:58:47.238381-03	1	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/dashboard/recebidos-series	?days=14	api/dashboard/recebidos-series	Dashboard	GetRecebidosSeries	200	t	\N	application/json; charset=utf-8	\N	{"labels":["14/04","15/04","16/04","17/04","18/04","19/04","20/04","21/04","22/04","23/04","24/04","25/04","26/04","27/04"],"values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0]}	\N	F87D5EB420559B3542788DE4F0EF266F1E34F30F5206D121E706FE07F8D3F45A	f	f	0	0	\N	\N	2026-04-27 09:58:47.240092-03
98d5e273-63a8-425a-9059-19a6581f0288	dev	0HNL4B65QMA15:00000001	00-98fc415c26b4aac1d04c6ea7062b7e83-b8f41514266a9345-00	98fc415c26b4aac1d04c6ea7062b7e83	b8f41514266a9345	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.238113-03	2026-04-27 09:58:47.239887-03	1	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/dashboard/areas	\N	api/dashboard/areas	Dashboard	GetAreasLookup	200	t	\N	application/json; charset=utf-8	\N	[{"id":"0687b162-6037-44c9-8efd-417dc071c148","nome":"Administrativo"},{"id":"0f274b98-8012-40c1-81d4-4bab46b8b0f3","nome":"Comercial & Marketing"},{"id":"56ecf8be-fb9e-4cea-aca6-569d1d039a9d","nome":"Engenharia & Manutencao"},{"id":"ae50636c-1ca8-438f-b5b8-0a09ba069b8c","nome":"Financeiro"},{"id":"83880d6f-c7ba-40d3-abb8-284cb1b192dd","nome":"Operacoes"},{"id":"adfb2e53-a20a-4203-abf1-9f7c96af0c7c","nome":"Pesquisa & Desenvolvimento"},{"id":"a84652e6-a8e3-45f4-9298-052638e7903e","nome":"Qualidade & Seguranca de Alimentos"},{"id":"3194b5ee-eafc-41ab-87f4-76e41e8f4c56","nome":"Recursos Humanos"},{"id":"ba8afccf-7a8c-4364-b8aa-beaef3241776","nome":"Supply Chain"},{"id":"55e01aae-6ac0-48ef-bd98-6a971e3989a1","nome":"Tecnologia da Informacao"}]	\N	DA835F0E29A5C6121699D9D38A1C39ECCDC00146DA82CFE97DF8A4395467E02A	f	f	0	0	\N	\N	2026-04-27 09:58:47.244121-03
f8ec8fad-f66d-482c-a3b8-642bf17aa279	dev	0HNL4B65QMA14:00000001	00-c922efb8440666be5a62b76cf3a70782-c003e67c3a4a1ff5-00	c922efb8440666be5a62b76cf3a70782	c003e67c3a4a1ff5	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.237897-03	2026-04-27 09:58:47.242487-03	4	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/dashboard/vagas	\N	api/dashboard/vagas	Dashboard	GetVagasLookup	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.244458-03
0f50750e-a6fa-41a0-b1da-001ce8ea7f3b	dev	0HNL4B65QMA18:00000001	00-2c453c27207a882496db9daed742a762-a3df313bdac395b2-00	2c453c27207a882496db9daed742a762	a3df313bdac395b2	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.253936-03	2026-04-27 09:58:47.258882-03	4	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/navegacao/sidebar	\N	api/navegacao/sidebar	Navegacao	GetSidebar	200	t	\N	application/json; charset=utf-8	\N	{"grupos":[{"key":"principais","label":"Principais","ordem":0,"ocultarHeader":true,"itens":[{"id":"nav-dashboard","label":"Dashboard","href":"/dashboard","icon":"layoutdashboard","ordem":10,"moduloKey":"dashboard","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-aprovacoes","label":"Minhas Pendências","href":"/gestao/aprovacoes","icon":"checkcheck","ordem":20,"moduloKey":"recrutamento","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-solicitacoes","label":"Solicitações","href":"/gestao/solicitacoes","icon":"clipboardlist","ordem":30,"moduloKey":"recrutamento","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-painel-solicitacoes","label":"Painel de Solicitações","href":"/gestao/painel-solicitacoes","icon":"gitbranch","ordem":40,"moduloKey":"gestao","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null}]},{"key":"recrutamento-selecao","label":"Recrutamento e Seleção","ordem":10,"ocultarHeader":false,"itens":[{"id":"nav-vagas","label":"Vagas","href":"/vagas","icon":"briefcase","ordem":10,"moduloKey":"recrutamento","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-painel-rh","label":"Painel RH","href":"/painel-rh","icon":"clipboardcheck","ordem":20,"moduloKey":"portal-vagas","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-candidatos","label":"Candidatos","href":"/candidatos","icon":"users","ordem":30,"moduloKey":"candidatos","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-candidaturas","label":"Kanban de Candidaturas","href":"/recrutamento/candidaturas","icon":"gitbranch","ordem":35,"moduloKey":"candidatos","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-funil","label":"Funil de Conversão","href":"/recrutamento/funil","icon":"barchart","ordem":36,"moduloKey":"candidatos","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-admissao","label":"Admissão","href":"/admissao","icon":"usercheck","ordem":40,"moduloKey":"admissao","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-matching","label":"Matching IA","href":"/matching","icon":"sparkles","ordem":50,"moduloKey":"matching","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-triagem","label":"Pipeline","href":"/triagem","icon":"filter","ordem":60,"moduloKey":"candidatos","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-processo-seletivo","label":"Processo Seletivo","href":"/gestao/processo-seletivo","icon":"listchecks","ordem":70,"moduloKey":"recrutamento","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-agendas","label":"Agenda","href":"/agendas","icon":"calendar","ordem":80,"moduloKey":"agenda","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-portalvagas","label":"Portal de Vagas","href":"/portalvagas","icon":"globe","ordem":90,"moduloKey":"portal-vagas","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-talentos","label":"Banco de Talentos","href":"/talentos","icon":"sparkles","ordem":95,"moduloKey":"candidatos","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null}]},{"key":"gestao-pessoas","label":"Gestão de Pessoas","ordem":20,"ocultarHeader":false,"itens":[{"id":"nav-gestao-dashboard","label":"Dashboard Gestão","href":"/gestao/dashboard","icon":"layoutdashboard","ordem":20,"moduloKey":"gestao","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-planos-desenvolvimento","label":"PDI","href":"/gestao/planosdesenvolvimento","icon":"target","ordem":30,"moduloKey":"feedback","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-humor","label":"Humor","href":"/gestao/humor","icon":"smile","ordem":40,"moduloKey":"gestao","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-resumo-atividades","label":"Resumo de Atividades","href":"/gestao/resumoatividades","icon":"activity","ordem":50,"moduloKey":"gestao","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-feedback-enviar","label":"Enviar Feedback","href":"/feedback/enviar","icon":"send","ordem":60,"moduloKey":"feedback","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-feedback-lista","label":"Meus Feedbacks","href":"/feedback/feedbacks","icon":"message-square","ordem":70,"moduloKey":"feedback","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-feedback-1a1","label":"Reuniões 1:1","href":"/feedback/reunioes1a1","icon":"users","ordem":80,"moduloKey":"feedback","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-feedback-celebracao","label":"Celebrações","href":"/feedback/celebracao","icon":"party-popper","ordem":90,"moduloKey":"feedback","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-desempenho-minhas","label":"Minhas Avaliações","href":"/desempenho","icon":"trending-up","ordem":100,"moduloKey":"desempenho","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-desempenho-ciclos","label":"Ciclos de Avaliação","href":"/feedback/avaliacao","icon":"target","ordem":110,"moduloKey":"desempenho","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null},{"id":"nav-desempenho-ninebox","label":"Nine Box","href":"/feedback/nine-box","icon":"grid","ordem":120,"moduloKey":"desempenho","packageKey":"gestao-pessoas","acessivel":true,"motivoBloqueio":null}]},{"key":"cadastros","label":"Cadastros","ordem":40,"ocultarHeader":false,"itens":[{"id":"nav-empresas","label":"Empresas","href":"/empresas","icon":"building2","ordem":10,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-centros-custo","label":"Centros de Custo","href":"/centros-custo","icon":"landmark","ordem":20,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-cargos","label":"Cargos","href":"/cargos","icon":"briefcase","ordem":50,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-funcoes","label":"Funções","href":"/funcoes","icon":"list-checks","ordem":55,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-descricao-cargo","label":"Descrição de Cargos","href":"/descricao-cargo","icon":"file-text","ordem":60,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-sla-vagas","label":"SLA de Vagas","href":"/sla-vagas","icon":"clock","ordem":70,"moduloKey":"recrutamento","packageKey":"recrutamento-selecao","acessivel":true,"motivoBloqueio":null},{"id":"nav-unidades","label":"Estabelecimentos","href":"/unidades","icon":"map-pin","ordem":80,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-categorias-salariais","label":"Categorias Salariais","href":"/categorias-salariais","icon":"badge-dollar-sign","ordem":100,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-turnos","label":"Turnos","href":"/turnos","icon":"clock","ordem":110,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-unidades-lotacao","label":"Unidades de Lotação","href":"/unidades-lotacao","icon":"building","ordem":120,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-pessoas","label":"Pessoas","href":"/pessoas","icon":"user","ordem":130,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-funcionarios","label":"Funcionários","href":"/funcionarios","icon":"users","ordem":140,"moduloKey":"cadastros","packageKey":null,"acessivel":true,"motivoBloqueio":null}]},{"key":"configuracoes","label":"Configurações","ordem":50,"ocultarHeader":false,"itens":[{"id":"nav-admin-email-config","label":"Config. de E-mail","href":"/admin/email-config","icon":"bi-gear","ordem":10,"moduloKey":"configuracoes","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-email-templates","label":"Templates de E-mail","href":"/admin/email-templates","icon":"bi-envelope-paper","ordem":20,"moduloKey":"configuracoes","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-emails","label":"E-mails Enviados","href":"/admin/emails","icon":"bi-envelope","ordem":30,"moduloKey":"configuracoes","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-entra-id","label":"Entra ID","href":"/admin/entra-id","icon":"bi-microsoft","ordem":40,"moduloKey":"configuracoes","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-api-keys","label":"API Keys","href":"/admin/api-keys","icon":"bi-key","ordem":50,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-localization","label":"Localização","href":"/admin/localization","icon":"bi-translate","ordem":60,"moduloKey":"configuracoes","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-tenant-config","label":"Configurações do Tenant","href":"/admin/tenant-configuracao","icon":"bi-gear","ordem":70,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-ia","label":"Configuração de IA","href":"/admin/ia","icon":"brain","ordem":75,"moduloKey":"ai","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-tenant-branding","label":"Branding / White-Label","href":"/admin/tenant-branding","icon":"palette","ordem":80,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null}]},{"key":"administracao","label":"Administração","ordem":60,"ocultarHeader":false,"itens":[{"id":"nav-admin-users","label":"Usuários","href":"/admin/users","icon":"users","ordem":10,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-roles","label":"Perfis (Roles)","href":"/admin/roles","icon":"shield","ordem":20,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-accesses","label":"Acessos","href":"/admin/accesses","icon":"bi-shield-lock","ordem":30,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-organograma","label":"Organograma","href":"/admin/organograma","icon":"bi-diagram-2","ordem":40,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-gestores","label":"Gestores","href":"/admin/gestores","icon":"usercheck","ordem":50,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-hierarquia","label":"Hierarquia","href":"/admin/hierarquia","icon":"bi-diagram-3","ordem":60,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-headcount","label":"Headcount","href":"/admin/configuracoes-headcount","icon":"users","ordem":70,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-configuracao-aprovacoes","label":"Config. de Aprovações","href":"/admin/configuracao-aprovacoes","icon":"settings2","ordem":80,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-aprovadores-alternativos","label":"Aprovadores Alternativos","href":"/admin/aprovadores-alternativos","icon":"user-check","ordem":90,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-doc-padrao","label":"Documentação Padrão","href":"/admin/documentacao-padrao","icon":"bi-journal-text","ordem":100,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-menus","label":"Menus","href":"/admin/menus","icon":"bi-list-check","ordem":110,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-logs","label":"Logs","href":"/admin/logs","icon":"bi-journal-text","ordem":120,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-operational-logs","label":"Logs Operacionais","href":"/admin/operational-logs","icon":"activity","ordem":130,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-notif-candidatura","label":"Notificações (Candidaturas)","href":"/administracao/notificacoes-candidatura","icon":"bell-ring","ordem":140,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null},{"id":"nav-admin-notif-templates","label":"Templates de Notificação","href":"/administracao/notificacoes-templates","icon":"book-template","ordem":145,"moduloKey":"administracao","packageKey":null,"acessivel":true,"motivoBloqueio":null}]},{"key":"relatorios","label":"Relatórios","ordem":70,"ocultarHeader":false,"itens":[{"id":"nav-relatorios","label":"Relatórios","href":"/relatorios","icon":"pie-chart","ordem":10,"moduloKey":"relatorios","packageKey":null,"acessivel":true,"motivoBloqueio":null}]}],"contextoEspecial":"owner-em-tenant"}	\N	DF1AD87FF38F679383F3EA0031BBB584E83870A4786B79A7B69BE4357E943F55	f	f	0	0	\N	\N	2026-04-27 09:58:47.260632-03
92863627-2eaa-45fa-9706-646de5b74468	dev	0HNL4B65QMA0R:00000001	00-2262dec069a881f7e926bf782c758f0e-f596a52331a555e5-00	2262dec069a881f7e926bf782c758f0e	f596a52331a555e5	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.216131-03	2026-04-27 09:58:47.226006-03	9	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/solicitacoes-promocao	?status=1	api/solicitacoes-promocao	SolicitacoesPromocao	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.227582-03
222593b0-1d42-4bc6-80a2-2eb01b1a9372	dev	0HNL4B65QMA1A:00000001	00-d821526f687ea2efebe599ac4993dc59-77676a77033f3cbe-00	d821526f687ea2efebe599ac4993dc59	77676a77033f3cbe	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:49.343172-03	2026-04-27 09:58:49.370516-03	27	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/vagas	\N	api/vagas	Vagas	List	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:49.372896-03
c1f80fbb-c47e-4dda-b4df-74825c74456c	dev	0HNL4B65QMA16:00000001	00-6ea8a4ac20213162de9e0ed17b38f74e-faef560c037ec750-00	6ea8a4ac20213162de9e0ed17b38f74e	faef560c037ec750	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.244703-03	2026-04-27 09:58:47.248803-03	4	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/dashboard/top-matches	?minMatch=70&take=15	api/dashboard/top-matches	Dashboard	GetTopMatches	200	t	\N	application/json; charset=utf-8	\N	[]	\N	4F53CDA18C2BAA0C0354BB5F9A3ECBE5ED12AB4D8E11BA873C2F11161202B945	f	f	0	0	\N	\N	2026-04-27 09:58:47.25027-03
e8f74f20-eff6-4296-9975-fb3a516f4098	dev	0HNL4B65QMA1B:00000001	00-82c689952f7bad8bbfa0eb1160276e0e-68abad23e2ff542f-00	82c689952f7bad8bbfa0eb1160276e0e	68abad23e2ff542f	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:53.728417-03	2026-04-27 09:58:53.729068-03	0	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/lookup/enums	\N	api/lookup/enums	Lookup	Enums	200	t	\N	application/json; charset=utf-8	\N	{"selectPlaceholder":[{"code":"","text":"Selecione..."}],"candidatoStatus":[{"code":"novo","text":"Novo"},{"code":"triagem","text":"Triagem"},{"code":"aprovado","text":"Aprovado"},{"code":"reprovado","text":"Reprovado"},{"code":"pendente","text":"Pendente"}],"candidatoStatusFilter":[{"code":"all","text":"Status: todos"},{"code":"novo","text":"Novo"},{"code":"triagem","text":"Triagem"},{"code":"aprovado","text":"Aprovado"},{"code":"reprovado","text":"Reprovado"},{"code":"pendente","text":"Pendente"}],"candidatoFonte":[{"code":"email","text":"Email"},{"code":"pasta","text":"Pasta"},{"code":"linkedin","text":"Linked In"},{"code":"indicacao","text":"Indicacao"},{"code":"site","text":"Site"}],"candidatoDocumentoTipo":[{"code":"curriculo","text":"Curriculo"},{"code":"documento","text":"Documento"},{"code":"certificado","text":"Certificado"},{"code":"portfolio","text":"Portfolio"},{"code":"diplomadeclaracao","text":"Diploma Declaracao"},{"code":"carteiraregistro","text":"Carteira Registro"},{"code":"outros","text":"Outros"}],"vagaStatus":[{"code":"rascunho","text":"Rascunho"},{"code":"aberta","text":"Aberta"},{"code":"pausada","text":"Pausada"},{"code":"emtriagem","text":"Em Triagem"},{"code":"ementrevistas","text":"Em Entrevistas"},{"code":"emoferta","text":"Em Oferta"},{"code":"encerrada","text":"Encerrada"},{"code":"cancelada","text":"Cancelada"},{"code":"preenchida","text":"Preenchida"},{"code":"naoinformado","text":"Nao Informado"}],"vagaStatusFilter":[{"code":"all","text":"Status: todos"},{"code":"rascunho","text":"Rascunho"},{"code":"aberta","text":"Aberta"},{"code":"pausada","text":"Pausada"},{"code":"emtriagem","text":"Em Triagem"},{"code":"ementrevistas","text":"Em Entrevistas"},{"code":"emoferta","text":"Em Oferta"},{"code":"encerrada","text":"Encerrada"},{"code":"cancelada","text":"Cancelada"},{"code":"preenchida","text":"Preenchida"},{"code":"naoinformado","text":"Nao Informado"}],"vagaArea":[{"code":"administrativa","text":"Administrativa"},{"code":"comercial","text":"Comercial"},{"code":"operacional","text":"Operacional"},{"code":"tecnica","text":"Tecnica"},{"code":"tecnologiainformacao","text":"Tecnologia Informacao"},{"code":"marketingcomunicacao","text":"Marketing Comunicacao"},{"code":"financeira","text":"Financeira"},{"code":"recursoshumanos","text":"Recursos Humanos"},{"code":"juridica","text":"Juridica"},{"code":"suprimentos","text":"Suprimentos"},{"code":"projetos","text":"Projetos"},{"code":"qualidade","text":"Qualidade"},{"code":"naoinformado","text":"Nao Informado"}],"vagaAreaFilter":[{"code":"all","text":"Area: todas"}],"vagaModalidade":[{"code":"presencial","text":"Presencial"},{"code":"hibrido","text":"Hibrido"},{"code":"remoto","text":"Remoto"}],"vagaSenioridade":[{"code":"estagiario","text":"Estagiario"},{"code":"trainee","text":"Trainee"},{"code":"junior","text":"Junior"},{"code":"pleno","text":"Pleno"},{"code":"senior","text":"Senior"},{"code":"especialista","text":"Especialista"},{"code":"coordenador","text":"Coordenador"},{"code":"gerente","text":"Gerente"},{"code":"diretor","text":"Diretor"},{"code":"naoinformado","text":"Nao Informado"}],"vagaDepartamento":[{"code":"operacoes","text":"Operacoes"},{"code":"logistica","text":"Logistica"},{"code":"tecnologia","text":"Tecnologia"},{"code":"produto","text":"Produto"},{"code":"marketing","text":"Marketing"},{"code":"comercial","text":"Comercial"},{"code":"financeiro","text":"Financeiro"},{"code":"recursoshumanos","text":"Recursos Humanos"},{"code":"juridico","text":"Juridico"},{"code":"compras","text":"Compras"},{"code":"atendimento","text":"Atendimento"},{"code":"qualidade","text":"Qualidade"},{"code":"manutencao","text":"Manutencao"},{"code":"administracao","text":"Administracao"},{"code":"naoinformado","text":"Nao Informado"}],"vagaAreaTime":[{"code":"backoffice","text":"Backoffice"},{"code":"field","text":"Field"},{"code":"growth","text":"Growth"},{"code":"dados","text":"Dados"},{"code":"engenharia","text":"Engenharia"},{"code":"produtoux","text":"Produto Ux"},{"code":"suporte","text":"Suporte"},{"code":"operacaochaodefabrica","text":"Operacao Chao De Fabrica"},{"code":"naoinformado","text":"Nao Informado"}],"vagaTipoContratacao":[{"code":"clt","text":"CLT"},{"code":"pj","text":"PJ"},{"code":"estagio","text":"Estagio"},{"code":"aprendiz","text":"Aprendiz"},{"code":"temporario","text":"Temporario"}],"vagaMotivoAbertura":[{"code":"substituicao","text":"Substituicao"},{"code":"aumentodequadro","text":"Aumento De Quadro"},{"code":"novoprojeto","text":"Novo Projeto"},{"code":"sazonal","text":"Sazonal"},{"code":"interno","text":"Interno"},{"code":"naoinformado","text":"Nao Informado"}],"vagaOrcamentoAprovado":[{"code":"sim","text":"Sim"},{"code":"nao","text":"Nao"},{"code":"emaprovacao","text":"Em Aprovacao"},{"code":"naoinformado","text":"Nao Informado"}],"vagaPrioridade":[{"code":"baixa","text":"Baixa"},{"code":"media","text":"Media"},{"code":"alta","text":"Alta"},{"code":"critica","text":"Critica"},{"code":"naoinformado","text":"Nao Informado"}],"vagaRegimeJornada":[{"code":"integral","text":"Integral"},{"code":"parcial","text":"Parcial"},{"code":"flexivel","text":"Flexivel"},{"code":"turnos","text":"Turnos"},{"code":"bancodehoras","text":"Banco De Horas"},{"code":"naoinformado","text":"Nao Informado"}],"vagaEscalaTrabalho":[{"code":"segundaasexta","text":"Segunda ASexta"},{"code":"seisporum","text":"Seis Por Um"},{"code":"dozeportrintaeseis","text":"Doze Por Trinta ESeis"},{"code":"quatropordois","text":"Quatro Por Dois"},{"code":"noturno","text":"Noturno"},{"code":"revezamento","text":"Revezamento"},{"code":"naoinformado","text":"Nao Informado"}],"vagaMoeda":[{"code":"brl","text":"BRL"},{"code":"usd","text":"USD"},{"code":"eur","text":"EUR"}],"vagaRemuneracaoPeriodicidade":[{"code":"mensal","text":"Mensal"},{"code":"horista","text":"Horista"},{"code":"semanal","text":"Semanal"},{"code":"quinzenal","text":"Quinzenal"},{"code":"diario","text":"Diario"},{"code":"anual","text":"Anual"}],"vagaBonusTipo":[{"code":"bonus","text":"Bonus"},{"code":"comissao","text":"Comissao"},{"code":"pprplr","text":"Ppr Plr"},{"code":"variavel","text":"Variavel"},{"code":"naoinformado","text":"Nao Informado"}],"vagaBeneficioTipo":[{"code":"valetransporte","text":"Vale Transporte"},{"code":"valerefeicao","text":"Vale Refeicao"},{"code":"valealimentacao","text":"Vale Alimentacao"},{"code":"planodesaude","text":"Plano De Saude"},{"code":"planoodontologico","text":"Plano Odontologico"},{"code":"segurodevida","text":"Seguro De Vida"},{"code":"auxiliocreche","text":"Auxilio Creche"},{"code":"auxilioeducacao","text":"Auxilio Educacao"},{"code":"gympassbemestar","text":"Gympass Bem Estar"},{"code":"homeofficeajudadecusto","text":"Home Office Ajuda De Custo"},{"code":"dayoffaniversario","text":"Day Off Aniversario"},{"code":"participacaoresultados","text":"Participacao Resultados"},{"code":"outros","text":"Outros"}],"vagaBeneficioRecorrencia":[{"code":"mensal","text":"Mensal"},{"code":"semanal","text":"Semanal"},{"code":"diario","text":"Diario"},{"code":"unico","text":"Unico"},{"code":"anual","text":"Anual"}],"vagaEscolaridade":[{"code":"fundamental","text":"Fundamental"},{"code":"medio","text":"Medio"},{"code":"tecnico","text":"Tecnico"},{"code":"superiorcursando","text":"Superior Cursando"},{"code":"superiorcompleto","text":"Superior Completo"},{"code":"posgraduacao","text":"Pos Graduacao"},{"code":"mestrado","text":"Mestrado"},{"code":"doutorado","text":"Doutorado"},{"code":"naoinformado","text":"Nao Informado"}],"vagaFormacaoArea":[{"code":"administracao","text":"Administracao"},{"code":"contabilidade","text":"Contabilidade"},{"code":"economia","text":"Economia"},{"code":"direito","text":"Direito"},{"code":"psicologia","text":"Psicologia"},{"code":"engenharias","text":"Engenharias"},{"code":"tecnologiainformacao","text":"Tecnologia Informacao"},{"code":"marketing","text":"Marketing"},{"code":"logistica","text":"Logistica"},{"code":"comunicacao","text":"Comunicacao"},{"code":"designux","text":"Design Ux"},{"code":"estatistica","text":"Estatistica"},{"code":"outros","text":"Outros"},{"code":"naoinformado","text":"Nao Informado"}],"vagaRequisitoNivel":[{"code":"naoinformado","text":"Nao Informado"},{"code":"basico","text":"Basico"},{"code":"intermediario","text":"Intermediario"},{"code":"avancado","text":"Avancado"},{"code":"especialista","text":"Especialista"}],"vagaRequisitoAvaliacao":[{"code":"naoinformado","text":"Nao Informado"},{"code":"curriculo","text":"Curriculo"},{"code":"testetecnico","text":"Teste Tecnico"},{"code":"entrevista","text":"Entrevista"},{"code":"dinamica","text":"Dinamica"},{"code":"case","text":"Case"},{"code":"certificacao","text":"Certificacao"}],"vagaEtapaResponsavel":[{"code":"rh","text":"RH"},{"code":"gestor","text":"Gestor"},{"code":"tecnico","text":"Tecnico"},{"code":"diretoria","text":"Diretoria"},{"code":"clienteinterno","text":"Cliente Interno"},{"code":"terceiro","text":"Terceiro"}],"vagaEtapaModo":[{"code":"presencial","text":"Presencial"},{"code":"online","text":"Online"},{"code":"telefonica","text":"Telefonica"},{"code":"assincrona","text":"Assincrona"}],"vagaPerguntaTipo":[{"code":"simnao","text":"Sim Nao"},{"code":"multiplaescolha","text":"Multipla Escolha"},{"code":"textocurto","text":"Texto Curto"},{"code":"textolongo","text":"Texto Longo"},{"code":"numero","text":"Numero"},{"code":"data","text":"Data"}],"vagaPeso":[{"code":"um","text":"1"},{"code":"dois","text":"2"},{"code":"tres","text":"3"},{"code":"quatro","text":"4"},{"code":"cinco","text":"5"}],"vagaPublicacaoVisibilidade":[{"code":"interna","text":"Interna"},{"code":"externa","text":"Externa"},{"code":"internaeexterna","text":"Interna EExterna"},{"code":"confidencial","text":"Confidencial"},{"code":"naoinformado","text":"Nao Informado"}],"vagaGeneroPreferencia":[{"code":"indiferente","text":"Indiferente"},{"code":"feminino","text":"Feminino"},{"code":"masculino","text":"Masculino"},{"code":"naobinario","text":"Nao Binario"},{"code":"outros","text":"Outros"},{"code":"naoinformado","text":"Nao Informado"}],"vagaFilter":[{"code":"all","text":"Vaga: todas"}],"vagaFilterSimple":[{"code":"all","text":"Todas"}],"requisitoCategoria":[{"code":"competencia","text":"Competencia"},{"code":"experiencia","text":"Experiencia"},{"code":"formacao","text":"Formacao"},{"code":"ferramenta_tecnologia","text":"Ferramenta/Tecnologia"},{"code":"idioma","text":"Idioma"},{"code":"certificacao","text":"Certificacao"},{"code":"localidade","text":"Localidade"},{"code":"outros","text":"Outros"}],"matchingSort":[{"code":"score_desc","text":"Ordenar: Match (maior -> menor)"},{"code":"score_asc","text":"Ordenar: Match (menor -> maior)"},{"code":"updated_desc","text":"Ordenar: Atualizacao (recente)"},{"code":"updated_asc","text":"Ordenar: Atualizacao (antiga)"},{"code":"name_asc","text":"Ordenar: Nome (A-Z)"}],"origemFilter":[{"code":"all","text":"Origem: todas"},{"code":"email","text":"Email"},{"code":"pasta","text":"Pasta"},{"code":"upload","text":"Upload"}],"origemFilterSimple":[{"code":"all","text":"Todas"},{"code":"email","text":"Email"},{"code":"pasta","text":"Pasta"},{"code":"upload","text":"Upload"}],"inboxStatusFilter":[{"code":"all","text":"Status: todos"},{"code":"novo","text":"Novo"},{"code":"processando","text":"Processando"},{"code":"processado","text":"Processado"},{"code":"falha","text":"Falha"},{"code":"descartado","text":"Descartado"}],"inboxStatusFilterSimple":[{"code":"all","text":"Todos"},{"code":"novo","text":"Novo"},{"code":"processando","text":"Processando"},{"code":"processado","text":"Processado"},{"code":"falha","text":"Falha"},{"code":"descartado","text":"Descartado"}],"relatorioPeriodo":[{"code":"7d","text":"Ultimos 7 dias"},{"code":"30d","text":"Ultimos 30 dias"},{"code":"90d","text":"Ultimos 90 dias"},{"code":"ytd","text":"Ano atual (YTD)"}],"relatorioFrequencia":[{"code":"daily","text":"Diario"},{"code":"weekly","text":"Semanal"},{"code":"monthly","text":"Mensal"}],"usuarioStatus":[{"code":"active","text":"Ativo"},{"code":"invited","text":"Convidado"},{"code":"disabled","text":"Desativado"}],"usuarioStatusFilter":[{"code":"all","text":"Todos"},{"code":"active","text":"Ativo"},{"code":"invited","text":"Convidado"},{"code":"disabled","text":"Desativado"}],"usuarioMfaOption":[{"code":"false","text":"Desabilitado"},{"code":"true","text":"Habilitado"}],"roleFilter":[{"code":"all","text":"Todos"}],"triagemDecisionAction":[{"code":"aprovado","text":"Aprovar"},{"code":"pendente","text":"Marcar como Pendente"},{"code":"reprovado","text":"Reprovar"},{"code":"triagem","text":"Manter em Triagem"}],"triagemDecisionReason":[{"code":"","text":"(opcional)"},{"code":"missing_mandatory","text":"Faltou requisito obrigatorio"},{"code":"below_threshold","text":"Match abaixo do minimo"},{"code":"profile_fit","text":"Perfil aderente"},{"code":"needs_validation","text":"Necessita validacao tecnica"},{"code":"low_experience","text":"Experiencia insuficiente"},{"code":"location_availability","text":"Localizacao/Disponibilidade"}],"tipoIntegracao":[{"code":"admissao","text":"Admissao"},{"code":"pagamentoextra","text":"Pagamento Extra"},{"code":"desligamento","text":"Desligamento"},{"code":"promocao","text":"Promocao"},{"code":"alteracaoendereco","text":"Alteracao Endereco"},{"code":"dependente","text":"Dependente"},{"code":"beneficio","text":"Beneficio"},{"code":"ferias","text":"Ferias"},{"code":"solicitacaovaga","text":"Solicitacao Vaga"}],"tipoPagamentoExtra":[{"code":"bonus","text":"Bonus"},{"code":"comissao","text":"Comissao"},{"code":"plr","text":"PLR"},{"code":"horaextra","text":"Hora Extra"},{"code":"premiacao","text":"Premiacao"},{"code":"reembolso","text":"Reembolso"},{"code":"outro","text":"Outro"}]}	\N	D3C374873E63EB1C1720C7A032E052127EFDA98A950ADFC292FA1E243471DBDE	f	f	0	0	\N	\N	2026-04-27 09:58:53.733509-03
1fc4323d-6871-4034-8839-5c3820a88385	dev	0HNL4B65QMA1C:00000001	00-330980c77a1baaeedc6a0b2e39912b67-157e58c3c4c849ab-00	330980c77a1baaeedc6a0b2e39912b67	157e58c3c4c849ab	0000000000000000	Development	1.0.0.0	2026-04-27 09:59:22.359328-03	2026-04-27 09:59:22.362798-03	3	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	POST	/api/me/switch-tenant	\N	api/me/switch-tenant	Me	SwitchTenant	200	t	application/json	application/json; charset=utf-8	{"tenantId":"owner"}	{"accessToken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6ImQ1ODIzZDc5LTljOTctNDMzYi04ZjYzLTFhM2JlNDMxZWFhOSIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL2VtYWlsYWRkcmVzcyI6Im93bmVyQGRldi5sb2NhbCIsInRlbmFudCI6Im93bmVyIiwiaHR0cDovL3NjaGVtYXMubWljcm9zb2Z0LmNvbS93cy8yMDA4LzA2L2lkZW50aXR5L2NsYWltcy9yb2xlIjoiT3duZXIiLCJleHAiOjE3NzczODExNjIsImlzcyI6IlJoUG9ydGFsIiwiYXVkIjoiUmhQb3J0YWwifQ.7G0LVhcuGiwNRXhRDI8Z4pzOQ4tXzerMcBOD8qJVFdA","tenantId":"owner"}	E852AEB04E325970072ADF3C73B659A203B4145C097637963AD93ED73A17AB63	2763E5B785A16C4291551C71D9352283F10BEE92D290EEA64B39CE74FF164330	f	f	0	0	\N	\N	2026-04-27 09:59:22.366076-03
fc4818da-8c4a-4fe1-8b7b-e30bbbc09137	dev	0HNL4B65QMA17:00000001	00-276d5c14f1c91257921964b037a6662d-74990b60490366ab-00	276d5c14f1c91257921964b037a6662d	74990b60490366ab	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.253213-03	2026-04-27 09:58:47.253952-03	0	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/lookup/enums	\N	api/lookup/enums	Lookup	Enums	200	t	\N	application/json; charset=utf-8	\N	{"selectPlaceholder":[{"code":"","text":"Selecione..."}],"candidatoStatus":[{"code":"novo","text":"Novo"},{"code":"triagem","text":"Triagem"},{"code":"aprovado","text":"Aprovado"},{"code":"reprovado","text":"Reprovado"},{"code":"pendente","text":"Pendente"}],"candidatoStatusFilter":[{"code":"all","text":"Status: todos"},{"code":"novo","text":"Novo"},{"code":"triagem","text":"Triagem"},{"code":"aprovado","text":"Aprovado"},{"code":"reprovado","text":"Reprovado"},{"code":"pendente","text":"Pendente"}],"candidatoFonte":[{"code":"email","text":"Email"},{"code":"pasta","text":"Pasta"},{"code":"linkedin","text":"Linked In"},{"code":"indicacao","text":"Indicacao"},{"code":"site","text":"Site"}],"candidatoDocumentoTipo":[{"code":"curriculo","text":"Curriculo"},{"code":"documento","text":"Documento"},{"code":"certificado","text":"Certificado"},{"code":"portfolio","text":"Portfolio"},{"code":"diplomadeclaracao","text":"Diploma Declaracao"},{"code":"carteiraregistro","text":"Carteira Registro"},{"code":"outros","text":"Outros"}],"vagaStatus":[{"code":"rascunho","text":"Rascunho"},{"code":"aberta","text":"Aberta"},{"code":"pausada","text":"Pausada"},{"code":"emtriagem","text":"Em Triagem"},{"code":"ementrevistas","text":"Em Entrevistas"},{"code":"emoferta","text":"Em Oferta"},{"code":"encerrada","text":"Encerrada"},{"code":"cancelada","text":"Cancelada"},{"code":"preenchida","text":"Preenchida"},{"code":"naoinformado","text":"Nao Informado"}],"vagaStatusFilter":[{"code":"all","text":"Status: todos"},{"code":"rascunho","text":"Rascunho"},{"code":"aberta","text":"Aberta"},{"code":"pausada","text":"Pausada"},{"code":"emtriagem","text":"Em Triagem"},{"code":"ementrevistas","text":"Em Entrevistas"},{"code":"emoferta","text":"Em Oferta"},{"code":"encerrada","text":"Encerrada"},{"code":"cancelada","text":"Cancelada"},{"code":"preenchida","text":"Preenchida"},{"code":"naoinformado","text":"Nao Informado"}],"vagaArea":[{"code":"administrativa","text":"Administrativa"},{"code":"comercial","text":"Comercial"},{"code":"operacional","text":"Operacional"},{"code":"tecnica","text":"Tecnica"},{"code":"tecnologiainformacao","text":"Tecnologia Informacao"},{"code":"marketingcomunicacao","text":"Marketing Comunicacao"},{"code":"financeira","text":"Financeira"},{"code":"recursoshumanos","text":"Recursos Humanos"},{"code":"juridica","text":"Juridica"},{"code":"suprimentos","text":"Suprimentos"},{"code":"projetos","text":"Projetos"},{"code":"qualidade","text":"Qualidade"},{"code":"naoinformado","text":"Nao Informado"}],"vagaAreaFilter":[{"code":"all","text":"Area: todas"}],"vagaModalidade":[{"code":"presencial","text":"Presencial"},{"code":"hibrido","text":"Hibrido"},{"code":"remoto","text":"Remoto"}],"vagaSenioridade":[{"code":"estagiario","text":"Estagiario"},{"code":"trainee","text":"Trainee"},{"code":"junior","text":"Junior"},{"code":"pleno","text":"Pleno"},{"code":"senior","text":"Senior"},{"code":"especialista","text":"Especialista"},{"code":"coordenador","text":"Coordenador"},{"code":"gerente","text":"Gerente"},{"code":"diretor","text":"Diretor"},{"code":"naoinformado","text":"Nao Informado"}],"vagaDepartamento":[{"code":"operacoes","text":"Operacoes"},{"code":"logistica","text":"Logistica"},{"code":"tecnologia","text":"Tecnologia"},{"code":"produto","text":"Produto"},{"code":"marketing","text":"Marketing"},{"code":"comercial","text":"Comercial"},{"code":"financeiro","text":"Financeiro"},{"code":"recursoshumanos","text":"Recursos Humanos"},{"code":"juridico","text":"Juridico"},{"code":"compras","text":"Compras"},{"code":"atendimento","text":"Atendimento"},{"code":"qualidade","text":"Qualidade"},{"code":"manutencao","text":"Manutencao"},{"code":"administracao","text":"Administracao"},{"code":"naoinformado","text":"Nao Informado"}],"vagaAreaTime":[{"code":"backoffice","text":"Backoffice"},{"code":"field","text":"Field"},{"code":"growth","text":"Growth"},{"code":"dados","text":"Dados"},{"code":"engenharia","text":"Engenharia"},{"code":"produtoux","text":"Produto Ux"},{"code":"suporte","text":"Suporte"},{"code":"operacaochaodefabrica","text":"Operacao Chao De Fabrica"},{"code":"naoinformado","text":"Nao Informado"}],"vagaTipoContratacao":[{"code":"clt","text":"CLT"},{"code":"pj","text":"PJ"},{"code":"estagio","text":"Estagio"},{"code":"aprendiz","text":"Aprendiz"},{"code":"temporario","text":"Temporario"}],"vagaMotivoAbertura":[{"code":"substituicao","text":"Substituicao"},{"code":"aumentodequadro","text":"Aumento De Quadro"},{"code":"novoprojeto","text":"Novo Projeto"},{"code":"sazonal","text":"Sazonal"},{"code":"interno","text":"Interno"},{"code":"naoinformado","text":"Nao Informado"}],"vagaOrcamentoAprovado":[{"code":"sim","text":"Sim"},{"code":"nao","text":"Nao"},{"code":"emaprovacao","text":"Em Aprovacao"},{"code":"naoinformado","text":"Nao Informado"}],"vagaPrioridade":[{"code":"baixa","text":"Baixa"},{"code":"media","text":"Media"},{"code":"alta","text":"Alta"},{"code":"critica","text":"Critica"},{"code":"naoinformado","text":"Nao Informado"}],"vagaRegimeJornada":[{"code":"integral","text":"Integral"},{"code":"parcial","text":"Parcial"},{"code":"flexivel","text":"Flexivel"},{"code":"turnos","text":"Turnos"},{"code":"bancodehoras","text":"Banco De Horas"},{"code":"naoinformado","text":"Nao Informado"}],"vagaEscalaTrabalho":[{"code":"segundaasexta","text":"Segunda ASexta"},{"code":"seisporum","text":"Seis Por Um"},{"code":"dozeportrintaeseis","text":"Doze Por Trinta ESeis"},{"code":"quatropordois","text":"Quatro Por Dois"},{"code":"noturno","text":"Noturno"},{"code":"revezamento","text":"Revezamento"},{"code":"naoinformado","text":"Nao Informado"}],"vagaMoeda":[{"code":"brl","text":"BRL"},{"code":"usd","text":"USD"},{"code":"eur","text":"EUR"}],"vagaRemuneracaoPeriodicidade":[{"code":"mensal","text":"Mensal"},{"code":"horista","text":"Horista"},{"code":"semanal","text":"Semanal"},{"code":"quinzenal","text":"Quinzenal"},{"code":"diario","text":"Diario"},{"code":"anual","text":"Anual"}],"vagaBonusTipo":[{"code":"bonus","text":"Bonus"},{"code":"comissao","text":"Comissao"},{"code":"pprplr","text":"Ppr Plr"},{"code":"variavel","text":"Variavel"},{"code":"naoinformado","text":"Nao Informado"}],"vagaBeneficioTipo":[{"code":"valetransporte","text":"Vale Transporte"},{"code":"valerefeicao","text":"Vale Refeicao"},{"code":"valealimentacao","text":"Vale Alimentacao"},{"code":"planodesaude","text":"Plano De Saude"},{"code":"planoodontologico","text":"Plano Odontologico"},{"code":"segurodevida","text":"Seguro De Vida"},{"code":"auxiliocreche","text":"Auxilio Creche"},{"code":"auxilioeducacao","text":"Auxilio Educacao"},{"code":"gympassbemestar","text":"Gympass Bem Estar"},{"code":"homeofficeajudadecusto","text":"Home Office Ajuda De Custo"},{"code":"dayoffaniversario","text":"Day Off Aniversario"},{"code":"participacaoresultados","text":"Participacao Resultados"},{"code":"outros","text":"Outros"}],"vagaBeneficioRecorrencia":[{"code":"mensal","text":"Mensal"},{"code":"semanal","text":"Semanal"},{"code":"diario","text":"Diario"},{"code":"unico","text":"Unico"},{"code":"anual","text":"Anual"}],"vagaEscolaridade":[{"code":"fundamental","text":"Fundamental"},{"code":"medio","text":"Medio"},{"code":"tecnico","text":"Tecnico"},{"code":"superiorcursando","text":"Superior Cursando"},{"code":"superiorcompleto","text":"Superior Completo"},{"code":"posgraduacao","text":"Pos Graduacao"},{"code":"mestrado","text":"Mestrado"},{"code":"doutorado","text":"Doutorado"},{"code":"naoinformado","text":"Nao Informado"}],"vagaFormacaoArea":[{"code":"administracao","text":"Administracao"},{"code":"contabilidade","text":"Contabilidade"},{"code":"economia","text":"Economia"},{"code":"direito","text":"Direito"},{"code":"psicologia","text":"Psicologia"},{"code":"engenharias","text":"Engenharias"},{"code":"tecnologiainformacao","text":"Tecnologia Informacao"},{"code":"marketing","text":"Marketing"},{"code":"logistica","text":"Logistica"},{"code":"comunicacao","text":"Comunicacao"},{"code":"designux","text":"Design Ux"},{"code":"estatistica","text":"Estatistica"},{"code":"outros","text":"Outros"},{"code":"naoinformado","text":"Nao Informado"}],"vagaRequisitoNivel":[{"code":"naoinformado","text":"Nao Informado"},{"code":"basico","text":"Basico"},{"code":"intermediario","text":"Intermediario"},{"code":"avancado","text":"Avancado"},{"code":"especialista","text":"Especialista"}],"vagaRequisitoAvaliacao":[{"code":"naoinformado","text":"Nao Informado"},{"code":"curriculo","text":"Curriculo"},{"code":"testetecnico","text":"Teste Tecnico"},{"code":"entrevista","text":"Entrevista"},{"code":"dinamica","text":"Dinamica"},{"code":"case","text":"Case"},{"code":"certificacao","text":"Certificacao"}],"vagaEtapaResponsavel":[{"code":"rh","text":"RH"},{"code":"gestor","text":"Gestor"},{"code":"tecnico","text":"Tecnico"},{"code":"diretoria","text":"Diretoria"},{"code":"clienteinterno","text":"Cliente Interno"},{"code":"terceiro","text":"Terceiro"}],"vagaEtapaModo":[{"code":"presencial","text":"Presencial"},{"code":"online","text":"Online"},{"code":"telefonica","text":"Telefonica"},{"code":"assincrona","text":"Assincrona"}],"vagaPerguntaTipo":[{"code":"simnao","text":"Sim Nao"},{"code":"multiplaescolha","text":"Multipla Escolha"},{"code":"textocurto","text":"Texto Curto"},{"code":"textolongo","text":"Texto Longo"},{"code":"numero","text":"Numero"},{"code":"data","text":"Data"}],"vagaPeso":[{"code":"um","text":"1"},{"code":"dois","text":"2"},{"code":"tres","text":"3"},{"code":"quatro","text":"4"},{"code":"cinco","text":"5"}],"vagaPublicacaoVisibilidade":[{"code":"interna","text":"Interna"},{"code":"externa","text":"Externa"},{"code":"internaeexterna","text":"Interna EExterna"},{"code":"confidencial","text":"Confidencial"},{"code":"naoinformado","text":"Nao Informado"}],"vagaGeneroPreferencia":[{"code":"indiferente","text":"Indiferente"},{"code":"feminino","text":"Feminino"},{"code":"masculino","text":"Masculino"},{"code":"naobinario","text":"Nao Binario"},{"code":"outros","text":"Outros"},{"code":"naoinformado","text":"Nao Informado"}],"vagaFilter":[{"code":"all","text":"Vaga: todas"}],"vagaFilterSimple":[{"code":"all","text":"Todas"}],"requisitoCategoria":[{"code":"competencia","text":"Competencia"},{"code":"experiencia","text":"Experiencia"},{"code":"formacao","text":"Formacao"},{"code":"ferramenta_tecnologia","text":"Ferramenta/Tecnologia"},{"code":"idioma","text":"Idioma"},{"code":"certificacao","text":"Certificacao"},{"code":"localidade","text":"Localidade"},{"code":"outros","text":"Outros"}],"matchingSort":[{"code":"score_desc","text":"Ordenar: Match (maior -> menor)"},{"code":"score_asc","text":"Ordenar: Match (menor -> maior)"},{"code":"updated_desc","text":"Ordenar: Atualizacao (recente)"},{"code":"updated_asc","text":"Ordenar: Atualizacao (antiga)"},{"code":"name_asc","text":"Ordenar: Nome (A-Z)"}],"origemFilter":[{"code":"all","text":"Origem: todas"},{"code":"email","text":"Email"},{"code":"pasta","text":"Pasta"},{"code":"upload","text":"Upload"}],"origemFilterSimple":[{"code":"all","text":"Todas"},{"code":"email","text":"Email"},{"code":"pasta","text":"Pasta"},{"code":"upload","text":"Upload"}],"inboxStatusFilter":[{"code":"all","text":"Status: todos"},{"code":"novo","text":"Novo"},{"code":"processando","text":"Processando"},{"code":"processado","text":"Processado"},{"code":"falha","text":"Falha"},{"code":"descartado","text":"Descartado"}],"inboxStatusFilterSimple":[{"code":"all","text":"Todos"},{"code":"novo","text":"Novo"},{"code":"processando","text":"Processando"},{"code":"processado","text":"Processado"},{"code":"falha","text":"Falha"},{"code":"descartado","text":"Descartado"}],"relatorioPeriodo":[{"code":"7d","text":"Ultimos 7 dias"},{"code":"30d","text":"Ultimos 30 dias"},{"code":"90d","text":"Ultimos 90 dias"},{"code":"ytd","text":"Ano atual (YTD)"}],"relatorioFrequencia":[{"code":"daily","text":"Diario"},{"code":"weekly","text":"Semanal"},{"code":"monthly","text":"Mensal"}],"usuarioStatus":[{"code":"active","text":"Ativo"},{"code":"invited","text":"Convidado"},{"code":"disabled","text":"Desativado"}],"usuarioStatusFilter":[{"code":"all","text":"Todos"},{"code":"active","text":"Ativo"},{"code":"invited","text":"Convidado"},{"code":"disabled","text":"Desativado"}],"usuarioMfaOption":[{"code":"false","text":"Desabilitado"},{"code":"true","text":"Habilitado"}],"roleFilter":[{"code":"all","text":"Todos"}],"triagemDecisionAction":[{"code":"aprovado","text":"Aprovar"},{"code":"pendente","text":"Marcar como Pendente"},{"code":"reprovado","text":"Reprovar"},{"code":"triagem","text":"Manter em Triagem"}],"triagemDecisionReason":[{"code":"","text":"(opcional)"},{"code":"missing_mandatory","text":"Faltou requisito obrigatorio"},{"code":"below_threshold","text":"Match abaixo do minimo"},{"code":"profile_fit","text":"Perfil aderente"},{"code":"needs_validation","text":"Necessita validacao tecnica"},{"code":"low_experience","text":"Experiencia insuficiente"},{"code":"location_availability","text":"Localizacao/Disponibilidade"}],"tipoIntegracao":[{"code":"admissao","text":"Admissao"},{"code":"pagamentoextra","text":"Pagamento Extra"},{"code":"desligamento","text":"Desligamento"},{"code":"promocao","text":"Promocao"},{"code":"alteracaoendereco","text":"Alteracao Endereco"},{"code":"dependente","text":"Dependente"},{"code":"beneficio","text":"Beneficio"},{"code":"ferias","text":"Ferias"},{"code":"solicitacaovaga","text":"Solicitacao Vaga"}],"tipoPagamentoExtra":[{"code":"bonus","text":"Bonus"},{"code":"comissao","text":"Comissao"},{"code":"plr","text":"PLR"},{"code":"horaextra","text":"Hora Extra"},{"code":"premiacao","text":"Premiacao"},{"code":"reembolso","text":"Reembolso"},{"code":"outro","text":"Outro"}]}	\N	D3C374873E63EB1C1720C7A032E052127EFDA98A950ADFC292FA1E243471DBDE	f	f	0	0	\N	\N	2026-04-27 09:58:47.255844-03
d1b6c3d7-992a-44b1-9228-b5d24205e584	dev	0HNL4B65QMA19:00000001	00-d4ea75ae7f6fdf37747ea01de3723141-a729de1ef46cf2d6-00	d4ea75ae7f6fdf37747ea01de3723141	a729de1ef46cf2d6	0000000000000000	Development	1.0.0.0	2026-04-27 09:58:47.25392-03	2026-04-27 09:58:47.257395-03	3	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	GET	/api/aprovacoes/pendentes/count	\N	api/aprovacoes/pendentes/count	Aprovacoes	GetPendentesCount	200	t	\N	application/json; charset=utf-8	\N	{"count":0}	\N	618DE7D9F46F3F697D827A1B6D84974760D5DEDA62E4E592ADAA3C646602A94C	f	f	0	0	\N	\N	2026-04-27 09:58:47.259656-03
\.


--
-- Data for Name: AvaliacaoCalibragens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AvaliacaoCalibragens" ("Id", "TenantId", "CicloId", "FuncionarioId", "ScoreGestor", "DesempenhoGestor", "PotencialGestor", "ScoreComite", "DesempenhoComite", "PotencialComite", "JustificativaComite", "Status", "Decisao", "DecididoPorUserId", "DecididoEmUtc", "ObservacaoDecisao", "NineBoxAssessmentId", "CriadoEmUtc", "AtualizadoEmUtc") FROM stdin;
\.


--
-- Data for Name: AvaliacaoCiclos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AvaliacaoCiclos" ("Id", "TenantId", "Nome", "Periodo", "Status", "CriadoPorId", "CriadoEmUtc", "AtualizadoEmUtc", "DataFim", "DataInicio", "Descricao") FROM stdin;
\.


--
-- Data for Name: AvaliacaoConvites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AvaliacaoConvites" ("Id", "TenantId", "CicloId", "AvaliadorId", "AvaliandoId", "Tipo", "Status", "CriadoEmUtc", "NotificadoEmUtc", "RespondidoEmUtc") FROM stdin;
\.


--
-- Data for Name: AvaliacaoPerguntas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AvaliacaoPerguntas" ("Id", "CicloId", "Texto", "Ordem") FROM stdin;
\.


--
-- Data for Name: AvaliacaoRespostas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AvaliacaoRespostas" ("Id", "TenantId", "CicloId", "AvaliadorId", "AvaliandoId", "Score", "RespostasJson", "CriadoEmUtc") FROM stdin;
\.


--
-- Data for Name: BatchMatchingRunVagas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BatchMatchingRunVagas" ("Id", "RunId", "VagaId", "TenantId", "Status", "ScoresGenerated", "StartedAtUtc", "CompletedAtUtc", "ErrorMessage") FROM stdin;
\.


--
-- Data for Name: BatchMatchingRuns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BatchMatchingRuns" ("Id", "TenantId", "Status", "CreatedAtUtc", "StartedAtUtc", "CompletedAtUtc", "TotalVagas", "ProcessedVagas", "FailedVagas", "TotalCandidatesScored", "LastProcessedVagaId", "LastError") FROM stdin;
\.


--
-- Data for Name: CamposPersonalizadosVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CamposPersonalizadosVaga" ("Id", "TenantId", "VagaId", "Label", "Tipo", "Obrigatorio", "Ordem", "Opcoes", "CreatedAtUtc", "UpdatedAtUtc", "IsReadOnly", "ValorPadrao") FROM stdin;
\.


--
-- Data for Name: CandidatoAcessibilidades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoAcessibilidades" ("Id", "TenantId", "CandidatoId", "Idioma", "Canal", "MelhorHorario", "ObservacoesComunicacao", "PrecisaLegendas", "PrecisaInterprete", "PrecisaLeitorTela", "PrecisaBaixaEstimulo", "PrecisaMobilidade", "PrecisaTempoExtra", "DetalhesNecessidades", "ConsentimentoPcd", "PcdIdentificacao", "PcdTipo", "PcdComprovacao", "PcdObservacoes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoAgendaBloqueios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoAgendaBloqueios" ("Id", "TenantId", "CandidatoId", "Tipo", "Titulo", "Data", "Horario", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoAgendaPreferencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoAgendaPreferencias" ("Id", "TenantId", "CandidatoId", "FormatoEntrevista", "InicioDisponivel", "AvisoPrevio", "Observacoes", "DiaSeg", "DiaTer", "DiaQua", "DiaQui", "DiaSex", "DiaSab", "DiaDom", "PeriodoManha", "PeriodoTarde", "PeriodoNoite", "HorarioPreferido", "FusoHorario", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoCertificacoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoCertificacoes" ("Id", "TenantId", "CandidatoId", "Nome", "Instituicao", "Ano", "Link", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoCompetencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoCompetencias" ("Id", "TenantId", "CandidatoId", "Tipo", "Nome", "Nivel", "Evidencia", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoDocumentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoDocumentos" ("Id", "TenantId", "CandidatoId", "Tipo", "NomeArquivo", "ContentType", "Descricao", "StorageFileName", "TamanhoBytes", "Url", "CreatedAtUtc", "UpdatedAtUtc", "ArquivoNome", "DataReferencia") FROM stdin;
\.


--
-- Data for Name: CandidatoEducacaoItens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoEducacaoItens" ("Id", "TenantId", "CandidatoId", "Curso", "Instituicao", "Tipo", "Status", "Inicio", "Fim", "Observacoes", "Link", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoEducacaoResumos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoEducacaoResumos" ("Id", "TenantId", "CandidatoId", "Nivel", "AreaPrincipal", "Situacao", "Destaques", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoEmbeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoEmbeddings" ("Id", "TenantId", "CandidatoId", "ModelVersion", "Dimensions", "Embedding", "TextoSource", "ConteudoHash", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoExperiencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoExperiencias" ("Id", "TenantId", "CandidatoId", "Empresa", "Cargo", "Inicio", "Fim", "Local", "Atividades", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoLgpdConsents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoLgpdConsents" ("Id", "TenantId", "CandidatoId", "ProcessarCandidatura", "PermitirContato", "BancoTalentos", "RetencaoMeses", "Compartilhamento", "DadosSensiveis", "Comunicacoes", "ConsentidoEmUtc", "RevogadoEmUtc", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoNotificacaoPreferencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoNotificacaoPreferencias" ("Id", "TenantId", "CandidatoId", "CanalEmail", "CanalWhatsapp", "CanalSms", "CanalPush", "Frequencia", "Idioma", "Email", "Telefone", "PermiteContato", "AlertaNovasVagas", "AlertaAtualizacoes", "AlertaEntrevistas", "AlertaMensagens", "AlertaDocumentos", "AlertaLembretes", "SilencioAtivo", "SilencioInicio", "SilencioFim", "SilencioPrioridade", "Assinatura", "CreatedAtUtc", "UpdatedAtUtc", "WhatsAppRateLimitMaxMensagens", "WhatsAppRateLimitJanelaMinutos") FROM stdin;
\.


--
-- Data for Name: CandidatoPortfolios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoPortfolios" ("Id", "TenantId", "CandidatoId", "WorkModel", "Availability", "Salary", "Shift", "Note", "Linkedin", "Github", "Portfolio", "Drive", "CreatedAtUtc", "UpdatedAtUtc", "Tags") FROM stdin;
\.


--
-- Data for Name: CandidatoPreferenciasVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoPreferenciasVaga" ("Id", "TenantId", "CandidatoId", "CargoAlvo", "Senioridade", "InicioDisponivel", "Resumo", "AreasInteresse", "ModeloTrabalho", "Jornada", "TipoContrato", "Viagens", "Mudanca", "CidadePreferida", "DistanciaMaxKm", "ObsDeslocamento", "PretensaoSalarial", "PretensaoNegociavel", "BeneficiosDesejados", "NaoAbreMaoDe", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoProjetos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoProjetos" ("Id", "TenantId", "CandidatoId", "Nome", "Periodo", "Descricao", "Link", "Stack", "Destaques", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoReferencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoReferencias" ("Id", "TenantId", "CandidatoId", "Nome", "Relacao", "Empresa", "Cargo", "Contato", "Periodo", "Linkedin", "Observacoes", "PodeContatar", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoStatusHistories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoStatusHistories" ("Id", "TenantId", "CandidatoId", "FromStatus", "ToStatus", "Reason", "Note", "Source", "UserId", "UserName", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoVagaLlmScores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoVagaLlmScores" ("Id", "TenantId", "CandidatoId", "VagaId", "ScoreFinal", "PassouMatchMinimo", "JustificativaTexto", "CriteriosJson", "PontosFortes", "Gaps", "InputHash", "ModelVersion", "DurationMs", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CandidatoVagaMatchingScores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidatoVagaMatchingScores" ("CandidatoId", "VagaId", "Score", "CalculatedAtUtc", "TenantId", "Justificativa", "RuleVersion", "ScoreCompetencia", "ScoreExperiencia", "ScoreFormacao", "ScoreLocalidade", "Source") FROM stdin;
\.


--
-- Data for Name: Candidatos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Candidatos" ("Id", "TenantId", "Nome", "Email", "Fone", "Cidade", "Uf", "Fonte", "Status", "VagaId", "Obs", "CvText", "LastMatchScore", "LastMatchPass", "LastMatchAtUtc", "LastMatchVagaId", "CreatedAtUtc", "UpdatedAtUtc", "PortalAccessKey", "PortalPasswordHash", "AvatarContentType", "AvatarFileName", "LinkedinUrl", "ResumoProfissional", "ApplicationRecruiterUserId", "ApplicationRecruiterUserName", "TalentoId", "TrabalhandoAtualmente", "Celular", "PretensaoSalarial") FROM stdin;
\.


--
-- Data for Name: CandidaturaEtapaHistoricos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CandidaturaEtapaHistoricos" ("Id", "TenantId", "CandidaturaId", "EtapaAnterior", "EtapaNova", "Observacao", "UserId", "EmUtc") FROM stdin;
\.


--
-- Data for Name: Candidaturas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Candidaturas" ("Id", "TenantId", "CandidatoId", "VagaId", "Status", "EtapaMacro", "Fonte", "Observacoes", "AplicadaEmUtc", "EtapaAtualDesdeUtc", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Cargos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Cargos" ("Id", "TenantId", "Code", "Description", "OccupationalClassification", "CargoType", "SimilarityIndicator", "FullDescription", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CategoriaSalarialSteps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CategoriaSalarialSteps" ("Id", "TenantId", "CategoriaSalarialId", "Percentual", "ValorOverride", "Ordem", "Observacao", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CategoriasSalariais; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CategoriasSalariais" ("Id", "TenantId", "Code", "Description", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "EmpresaId", "EstabelecimentoId", "ValorBase") FROM stdin;
\.


--
-- Data for Name: CelebrationCommentMentions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CelebrationCommentMentions" ("Id", "CommentId", "UserId") FROM stdin;
\.


--
-- Data for Name: CelebrationCommentReactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CelebrationCommentReactions" ("Id", "CommentId", "UserId", "Type", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CelebrationComments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CelebrationComments" ("Id", "TenantId", "PostId", "AuthorId", "Content", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CelebrationMentions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CelebrationMentions" ("Id", "PostId", "UserId") FROM stdin;
\.


--
-- Data for Name: CelebrationPosts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CelebrationPosts" ("Id", "TenantId", "AuthorId", "Content", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: CentrosCusto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CentrosCusto" ("Id", "TenantId", "Code", "Description", "Manager", "Notes", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "EmpresaId", "ValidFrom", "ValidUntil", "ParentId", "BranchOrLocation", "Description2", "Headcount", "OwnerFuncionarioId", "Phone") FROM stdin;
0687b162-6037-44c9-8efd-417dc071c148	dev	ADM	Administrativo	\N	\N	t	2026-04-24 22:45:13.892071-03	2026-04-24 22:45:13.892071-03	\N	\N	\N	\N	Embu das Artes - SP	\N	12	\N	\N
0f274b98-8012-40c1-81d4-4bab46b8b0f3	dev	COM	Comercial & Marketing	\N	\N	t	2026-04-24 22:45:13.892051-03	2026-04-24 22:45:13.892052-03	\N	\N	\N	\N	Sao Paulo - SP	\N	40	\N	\N
3194b5ee-eafc-41ab-87f4-76e41e8f4c56	dev	RH	Recursos Humanos	\N	\N	t	2026-04-24 22:45:13.892067-03	2026-04-24 22:45:13.892067-03	\N	\N	\N	\N	Sao Paulo - SP	\N	15	\N	\N
55e01aae-6ac0-48ef-bd98-6a971e3989a1	dev	TEC	Tecnologia da Informacao	\N	\N	t	2026-04-24 22:45:13.892057-03	2026-04-24 22:45:13.892057-03	\N	\N	\N	\N	Sao Paulo - SP	\N	18	\N	\N
56ecf8be-fb9e-4cea-aca6-569d1d039a9d	dev	ENG	Engenharia & Manutencao	\N	\N	t	2026-04-24 22:45:13.892035-03	2026-04-24 22:45:13.892035-03	\N	\N	\N	\N	Embu das Artes - SP	\N	80	\N	\N
83880d6f-c7ba-40d3-abb8-284cb1b192dd	dev	OPS	Operacoes	\N	\N	t	2026-04-24 22:45:13.891995-03	2026-04-24 22:45:13.891995-03	\N	\N	\N	\N	Embu das Artes - SP	\N	420	\N	\N
a84652e6-a8e3-45f4-9298-052638e7903e	dev	QUA	Qualidade & Seguranca de Alimentos	\N	\N	t	2026-04-24 22:45:13.892028-03	2026-04-24 22:45:13.892028-03	\N	\N	\N	\N	Embu das Artes - SP	\N	65	\N	\N
adfb2e53-a20a-4203-abf1-9f7c96af0c7c	dev	PDI	Pesquisa & Desenvolvimento	\N	\N	t	2026-04-24 22:45:13.892046-03	2026-04-24 22:45:13.892046-03	\N	\N	\N	\N	Sao Paulo - SP	\N	25	\N	\N
ae50636c-1ca8-438f-b5b8-0a09ba069b8c	dev	FIN	Financeiro	\N	\N	t	2026-04-24 22:45:13.892061-03	2026-04-24 22:45:13.892061-03	\N	\N	\N	\N	Sao Paulo - SP	\N	22	\N	\N
ba8afccf-7a8c-4364-b8aa-beaef3241776	dev	SCM	Supply Chain	\N	\N	t	2026-04-24 22:45:13.892041-03	2026-04-24 22:45:13.892041-03	\N	\N	\N	\N	Embu das Artes - SP	\N	55	\N	\N
\.


--
-- Data for Name: DadosBancarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DadosBancarios" ("Id", "TenantId", "FuncionarioId", "Banco", "Agencia", "Conta", "TipoConta", "Pix", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Dependentes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Dependentes" ("Id", "TenantId", "FuncionarioId", "NomeCompleto", "Parentesco", "Cpf", "DataNascimento", "IsPcd", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DescricaoCargoItemEmbeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DescricaoCargoItemEmbeddings" ("Id", "TenantId", "DescricaoCargoItemId", "ModelVersion", "Dimensions", "Embedding", "TextoSource", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DescricaoCargoItens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DescricaoCargoItens" ("Id", "TenantId", "DescricaoCargoId", "Categoria", "Texto", "IsObrigatoria", "NivelMinimo", "Subcategoria", "Ordem", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DescricoesCargo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DescricoesCargo" ("Id", "TenantId", "Code", "Title", "Summary", "Responsibilities", "Requirements", "NiceToHave", "Benefits", "IsTemplate", "NivelCargoId", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "AreaTemplate", "CboCodigo", "FormacaoMinima", "FormacaoDesejavel", "FormacaoAreaEstudo", "ExperienciaTempoMinimo", "ExperienciaTempoDesejavel", "ExperienciaEspecificacao", "RevisaoNumero", "RevisaoData", "RevisaoNatureza", "GestorNome", "GestorEmail") FROM stdin;
\.


--
-- Data for Name: Desligamentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Desligamentos" ("Id", "TenantId", "IdReqRm", "ChapaRm", "FuncionarioId", "CodMotivoRescisao", "MotivoRescisaoDescricao", "CodTipoRescisao", "TipoRescisaoDescricao", "GerouSubstituicao", "DataAbertura", "DataPrevista", "DataConclusao", "DataCancelamento", "CodStatus", "Justificativa", "NumDiasAviso", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DevelopmentPlanGoals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DevelopmentPlanGoals" ("Id", "PlanId", "Description", "DueDate", "ConcludedAt", "Order") FROM stdin;
\.


--
-- Data for Name: DevelopmentPlans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DevelopmentPlans" ("Id", "TenantId", "OwnerUserId", "TargetUserId", "Title", "Description", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DocumentacaoPadraoConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DocumentacaoPadraoConfigs" ("Id", "TenantId", "TipoDocumento", "Configuracao", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DocumentacaoPadraoHistoricos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DocumentacaoPadraoHistoricos" ("Id", "TenantId", "Escopo", "NivelCargoId", "TipoDocumento", "ConfiguracaoAnterior", "ConfiguracaoNova", "Acao", "UserId", "UserNome", "CriadoEmUtc", "CargoId") FROM stdin;
\.


--
-- Data for Name: DocumentacaoPadraoPorCargoConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DocumentacaoPadraoPorCargoConfigs" ("Id", "TenantId", "JobPositionId", "TipoDocumento", "Configuracao", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DocumentacaoPadraoPorNivelCargoConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DocumentacaoPadraoPorNivelCargoConfigs" ("Id", "TenantId", "NivelCargoId", "TipoDocumento", "Configuracao", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: DocumentosColaborador; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DocumentosColaborador" ("Id", "TenantId", "FuncionarioId", "Tipo", "NomeArquivo", "ContentType", "TamanhoBytes", "StoragePath", "Status", "ObservacaoRh", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: EixosVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EixosVaga" ("Id", "TenantId", "Code", "Name", "Description", "SlaDiasMetaFechamento", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: EmailAttempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EmailAttempts" ("Id", "TenantId", "EmailMessageId", "AttemptNumber", "Provider", "StartedAtUtc", "CompletedAtUtc", "IsSuccess", "ErrorMessage", "ErrorStackTrace") FROM stdin;
\.


--
-- Data for Name: EmailConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EmailConfigs" ("Id", "TenantId", "Provider", "SmtpHost", "SmtpPort", "SmtpEnableSsl", "SmtpUserName", "SmtpPasswordEncrypted", "SmtpFromName", "SmtpFromAddress", "ImapHost", "ImapPort", "ImapEnableSsl", "ImapUserName", "ImapPasswordEncrypted", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
9fc5ddb9-148c-4d30-ac41-f426cdfe030f	dev	smtp	smtp.gmail.com	587	t	leonardomendes201704@gmail.com	\N	Portal RH	leonardomendes201704@gmail.com	imap.gmail.com	993	t	leonardomendes201704@gmail.com	\N	2026-04-24 22:45:13.886484-03	2026-04-24 22:45:13.886484-03
\.


--
-- Data for Name: EmailMessages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EmailMessages" ("Id", "TenantId", "OwnerUserId", "OwnerUserName", "IsSystem", "Source", "To", "Cc", "Bcc", "Subject", "BodyHtml", "BodyText", "TemplateId", "TemplateName", "TemplateVersion", "PayloadJson", "Status", "AttemptCount", "MaxAttempts", "NextAttemptAtUtc", "LastError", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: EmailTemplates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EmailTemplates" ("Id", "TenantId", "Name", "SubjectTemplate", "BodyHtml", "Version", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
43796709-5f77-432f-b1d9-2e1938840137	dev	CandidaturaConfirmacao	Seed.EmailTemplateCandidaturaSubject	Seed.EmailTemplateCandidaturaBody	1	t	2026-04-24 22:45:13.883073-03	2026-04-24 22:45:13.883073-03
1037d687-0d2e-4897-ac26-e9af9814905d	dev	PreAdmissaoLink	Preencha seus dados para admissao - {{empresa}}	<div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;margin:0 auto;padding:24px;">\n    <div style="text-align:center;margin-bottom:24px;">\n        <div style="display:inline-block;background:#2563eb;color:#fff;width:56px;height:56px;border-radius:50%;line-height:56px;font-size:24px;font-weight:bold;">RH</div>\n    </div>\n    <h2 style="color:#1a1a1a;text-align:center;margin-bottom:8px;">Bem-vindo(a), {{nome}}!</h2>\n    <p style="color:#555;text-align:center;font-size:15px;margin-bottom:24px;">\n        Voce foi aprovado(a) e precisa preencher seus dados para admissao. E rapido e simples.\n    </p>\n    <div style="text-align:center;margin-bottom:24px;">\n        <a href="{{url}}" style="background:#2563eb;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;display:inline-block;font-size:16px;font-weight:600;">\n            Comecar agora\n        </a>\n    </div>\n    <div style="background:#f8f9fa;border-radius:8px;padding:16px;margin-bottom:24px;">\n        <p style="color:#555;font-size:13px;margin:0 0 8px 0;font-weight:600;">O que voce vai precisar:</p>\n        <ul style="color:#555;font-size:13px;margin:0;padding-left:20px;">\n            <li>RG e CPF</li>\n            <li>Comprovante de Residencia</li>\n            <li>Comprovante Bancario</li>\n            <li>Carteira de Trabalho (CTPS)</li>\n        </ul>\n    </div>\n    <p style="color:#999;font-size:12px;text-align:center;">\n        Ou copie e cole este link no navegador:<br/>\n        <a href="{{url}}" style="color:#2563eb;font-size:11px;word-break:break-all;">{{url}}</a>\n    </p>\n    <p style="color:#999;font-size:11px;text-align:center;margin-top:24px;">\n        Atenciosamente, Equipe RH\n    </p>\n</div>	1	t	2026-04-24 22:45:13.884937-03	2026-04-24 22:45:13.884937-03
\.


--
-- Data for Name: Empresas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Empresas" ("Id", "TenantId", "Code", "Description", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "Cep", "Logradouro", "Numero", "Bairro", "Cidade", "Uf", "Latitude", "Longitude", "GeocodificadoEmUtc") FROM stdin;
\.


--
-- Data for Name: EntraIdConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EntraIdConfigs" ("Id", "TenantId", "EntraTenantId", "ClientId", "ClientSecretEncrypted", "IsEnabled", "CallbackPath", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: EntrevistasSaida; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EntrevistasSaida" ("Id", "TenantId", "DesligamentoId", "FuncionarioId", "TemplateId", "Token", "ExpiresAtUtc", "SubmittedAtUtc", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: EtapasConfigAprovacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EtapasConfigAprovacao" ("Id", "TenantId", "TipoFluxo", "Ordem", "Label", "TipoAprovador", "FuncionarioFixoId", "RoleFilaId", "Ativo", "UpdatedAtUtc", "AcaoEtapa", "MomentoAcao", "SlaHoras") FROM stdin;
\.


--
-- Data for Name: EtapasConfigWorkflowRH; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EtapasConfigWorkflowRH" ("Id", "TenantId", "TipoWorkflow", "Ordem", "Codigo", "Label", "Descricao", "SlaPrazoDias", "Obrigatoria", "RoleFilaId", "Ativo", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: EtapasWorkflowRH; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EtapasWorkflowRH" ("Id", "TenantId", "WorkflowId", "Ordem", "Codigo", "Label", "Descricao", "Status", "Obrigatoria", "ResponsavelId", "RoleFilaId", "SlaPrazoDias", "DataInicio", "DataConclusao", "DadosJson", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: ExceptionLogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ExceptionLogs" ("Id", "TenantId", "RequestLogId", "TransactionId", "EnvironmentName", "EnvironmentNormalized", "DeviceId", "DeviceType", "Platform", "Browser", "DeviceAppVersion", "Locale", "Order", "OccurredAt", "IsHandled", "StatusCode", "ExceptionType", "Message", "StackTrace", "InnerExceptionType", "InnerMessage", "ProblemTitle", "ProblemDetail", "ProblemType", "ValidationErrorsJson", "Tags", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: FaixasSalariais; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FaixasSalariais" ("Id", "TenantId", "EstabelecimentoCodigo", "JobPositionId", "SalarioMinimo", "SalarioMaximo", "Descricao", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: FasesProcesso; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FasesProcesso" ("Id", "TenantId", "ProjetoId", "Nome", "Ordem", "ResponsavelTipo", "CreatedAtUtc", "UpdatedAtUtc", "Descricao", "Observacoes", "SlaDias") FROM stdin;
\.


--
-- Data for Name: FeedbackItemRatings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FeedbackItemRatings" ("Id", "FeedbackItemId", "ItemName", "Stars") FROM stdin;
\.


--
-- Data for Name: FeedbackItems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FeedbackItems" ("Id", "TenantId", "FromUserId", "ToUserId", "Content", "Tipo", "CreatedAtUtc", "InternalNotes", "IsPresencial") FROM stdin;
\.


--
-- Data for Name: FluxosAprovacaoConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FluxosAprovacaoConfig" ("Id", "TenantId", "TipoFluxo", "ReferenciaUnidade", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: FuncionarioMovimentacoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FuncionarioMovimentacoes" ("Id", "TenantId", "FuncionarioId", "ChapaRm", "IdReqRm", "TipoMovimentacao", "TipoDescricao", "DataAbertura", "DataConclusao", "DataCancelamento", "CodStatus", "StatusDescricao", "CodFuncaoOrigem", "FuncaoOrigemNome", "CodSecaoOrigem", "CodSecaoDestino", "CodFuncaoDestino", "FuncaoDestinoNome", "HierarquiaOrigemId", "HierarquiaDestinoId", "IdHierarquiaOrigemRm", "IdHierarquiaDestinoRm", "SalarioOrigem", "SalarioDestino", "Justificativa", "GerouSubstituicao", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Funcionarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Funcionarios" ("Id", "TenantId", "Name", "Email", "Phone", "Status", "UserId", "UnitId", "Headcount", "JobPositionId", "Notes", "CreatedAtUtc", "UpdatedAtUtc", "PessoaId", "AvatarFileName", "GestorDiretoId", "NivelHierarquicoId", "CdnEmpresa", "CdnEstab", "CdnFuncionario", "UnidadeLotacaoId", "NivelCargoId", "CdnNivCargo", "CentroCustoId", "HasIncompleteData", "DataAdmissao", "DataNascimento", "PeriodoExperienciaDias", "Sexo", "MatriculaRm", "HierarquiaId", "CodSituacaoRm", "SituacaoRmDescricao", "CodFuncaoRm", "FuncaoNomeRm", "CiclosAusenteRm", "UltimoCicloRmObservadoUtc") FROM stdin;
\.


--
-- Data for Name: GamificationDailyStates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GamificationDailyStates" ("Id", "TenantId", "UserId", "CurrentStreak", "BestStreak", "LastCheckInDate", "LastActivityDate", "FeedbackSentToday", "CelebrationPostsToday", "CelebrationCommentsToday", "OneOnOneCompletedToday", "DevelopmentPlansCreatedToday", "SurveyAnsweredToday", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
1bef9ef9-7f1c-4162-90d4-5a4bc1f79cce	dev	462756d3-8066-42bb-ad9c-6c29d8de1f99	1	1	2026-04-25	2026-04-25	0	0	0	0	0	0	2026-04-25 11:12:31.00693-03	2026-04-25 11:12:31.00693-03
\.


--
-- Data for Name: Hierarquias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Hierarquias" ("Id", "TenantId", "IdHierarquiaRm", "Descricao", "IdHierarquiaSuperiorRm", "HierarquiaSuperiorId", "Estrutura", "IdNivelHierarquiaRm", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: HistoricosAlteracaoWorkflowRH; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HistoricosAlteracaoWorkflowRH" ("Id", "TenantId", "WorkflowId", "EtapaWorkflowId", "Campo", "ValorAnterior", "ValorNovo", "OrigemPreenchimento", "AlteradoPorId", "AlteradoPorNome", "DataAlteracaoUtc", "Observacao") FROM stdin;
\.


--
-- Data for Name: HistoricosStatus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."HistoricosStatus" ("Id", "TenantId", "TipoEntidade", "EntidadeId", "StatusAnterior", "StatusNovo", "AlteradoPorFuncionarioId", "AlteradoPorUserId", "AlteradoPorNome", "AlteradoEmUtc", "SlaEsperadoHoras", "TempoNoStatusAnteriorHoras", "DentroDoSla", "Observacao") FROM stdin;
\.


--
-- Data for Name: Holerites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Holerites" ("Id", "TenantId", "FuncionarioId", "MesReferencia", "AnoReferencia", "ArquivoPath", "ArquivoNome", "TamanhoBytes", "EnviadoPorId", "EnviadoEmUtc", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: InboxAttachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InboxAttachments" ("Id", "TenantId", "InboxItemId", "Nome", "Tipo", "TamanhoKB", "Hash", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: InboxItems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InboxItems" ("Id", "TenantId", "Origem", "Status", "RecebidoEm", "Remetente", "Assunto", "Destinatario", "VagaId", "PreviewText", "ProcessamentoPct", "ProcessamentoEtapa", "ProcessamentoTentativas", "ProcessamentoUltimoErro", "ProcessamentoLogRaw", "CreatedAtUtc", "UpdatedAtUtc", "SuggestedVagasJson", "CandidatoId") FROM stdin;
\.


--
-- Data for Name: JobPositions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobPositions" ("Id", "TenantId", "Code", "Name", "Status", "CentroCustoId", "Seniority", "Type", "Description", "CreatedAtUtc", "UpdatedAtUtc", "DescricaoPublicacao", "NivelHierarquicoId", "OccupationalClassification", "FullDescription", "SimilarityIndicator", "DesEnvelPagto", "NivelCargoId", "TotvsCargoBasicId", "TotvsNivCargoId") FROM stdin;
\.


--
-- Data for Name: LocalizationConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."LocalizationConfigs" ("Id", "TenantId", "Culture", "UiCulture", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: LogEntries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."LogEntries" ("Id", "TenantId", "RequestLogId", "TransactionId", "EnvironmentName", "EnvironmentNormalized", "DeviceId", "DeviceType", "Platform", "Browser", "DeviceAppVersion", "Locale", "Order", "Level", "Category", "EventId", "EventName", "Message", "ExceptionType", "ExceptionMessage", "ExceptionStackTrace", "PropertiesJson", "OccurredAt", "CreatedAt") FROM stdin;
9151976c-cd95-4f82-9fa5-844838b7677e	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (3ms) [Parameters=[@__ef_filter__TenantId_0='?', @__email_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT u."Id", u."AccessFailedCount", u."ConcurrencyStamp", u."CreatedAtUtc", u."Email", u."EmailConfirmed", u."FullName", u."FuncionarioId", u."IsActive", u."LockoutEnabled", u."LockoutEnd", u."NormalizedEmail", u."NormalizedUserName", u."PasswordHash", u."PhoneNumber", u."PhoneNumberConfirmed", u."SecurityStamp", u."TenantId", u."TwoFactorEnabled", u."UpdatedAtUtc", u."UserName", t."Id", t."AvatarFileName", t."CdnEmpresa", t."CdnEstab", t."CdnFuncionario", t."CdnNivCargo", t."CentroCustoId", t."CreatedAtUtc", t."DataAdmissao", t."DataNascimento", t."Email", t."GestorDiretoId", t."HasIncompleteData", t."Headcount", t."JobPositionId", t."Name", t."NivelCargoId", t."NivelHierarquicoId", t."Notes", t."PeriodoExperienciaDias", t."PessoaId", t."Phone", t."Sexo", t."Status", t."TenantId", t."UnidadeLotacaoId", t."UnitId", t."UpdatedAtUtc", t."UserId"\nFROM "Users" AS u\nLEFT JOIN (\n    SELECT f."Id", f."AvatarFileName", f."CdnEmpresa", f."CdnEstab", f."CdnFuncionario", f."CdnNivCargo", f."CentroCustoId", f."CreatedAtUtc", f."DataAdmissao", f."DataNascimento", f."Email", f."GestorDiretoId", f."HasIncompleteData", f."Headcount", f."JobPositionId", f."Name", f."NivelCargoId", f."NivelHierarquicoId", f."Notes", f."PeriodoExperienciaDias", f."PessoaId", f."Phone", f."Sexo", f."Status", f."TenantId", f."UnidadeLotacaoId", f."UnitId", f."UpdatedAtUtc", f."UserId"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t ON u."FuncionarioId" = t."Id"\nWHERE u."TenantId" = @__ef_filter__TenantId_0 AND u."Email" = @__email_0\nLIMIT 1	\N	\N	\N	{"elapsed": "3", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__email_0='?'", "commandText": "SELECT u.\\"Id\\", u.\\"AccessFailedCount\\", u.\\"ConcurrencyStamp\\", u.\\"CreatedAtUtc\\", u.\\"Email\\", u.\\"EmailConfirmed\\", u.\\"FullName\\", u.\\"FuncionarioId\\", u.\\"IsActive\\", u.\\"LockoutEnabled\\", u.\\"LockoutEnd\\", u.\\"NormalizedEmail\\", u.\\"NormalizedUserName\\", u.\\"PasswordHash\\", u.\\"PhoneNumber\\", u.\\"PhoneNumberConfirmed\\", u.\\"SecurityStamp\\", u.\\"TenantId\\", u.\\"TwoFactorEnabled\\", u.\\"UpdatedAtUtc\\", u.\\"UserName\\", t.\\"Id\\", t.\\"AvatarFileName\\", t.\\"CdnEmpresa\\", t.\\"CdnEstab\\", t.\\"CdnFuncionario\\", t.\\"CdnNivCargo\\", t.\\"CentroCustoId\\", t.\\"CreatedAtUtc\\", t.\\"DataAdmissao\\", t.\\"DataNascimento\\", t.\\"Email\\", t.\\"GestorDiretoId\\", t.\\"HasIncompleteData\\", t.\\"Headcount\\", t.\\"JobPositionId\\", t.\\"Name\\", t.\\"NivelCargoId\\", t.\\"NivelHierarquicoId\\", t.\\"Notes\\", t.\\"PeriodoExperienciaDias\\", t.\\"PessoaId\\", t.\\"Phone\\", t.\\"Sexo\\", t.\\"Status\\", t.\\"TenantId\\", t.\\"UnidadeLotacaoId\\", t.\\"UnitId\\", t.\\"UpdatedAtUtc\\", t.\\"UserId\\"\\nFROM \\"Users\\" AS u\\nLEFT JOIN (\\n    SELECT f.\\"Id\\", f.\\"AvatarFileName\\", f.\\"CdnEmpresa\\", f.\\"CdnEstab\\", f.\\"CdnFuncionario\\", f.\\"CdnNivCargo\\", f.\\"CentroCustoId\\", f.\\"CreatedAtUtc\\", f.\\"DataAdmissao\\", f.\\"DataNascimento\\", f.\\"Email\\", f.\\"GestorDiretoId\\", f.\\"HasIncompleteData\\", f.\\"Headcount\\", f.\\"JobPositionId\\", f.\\"Name\\", f.\\"NivelCargoId\\", f.\\"NivelHierarquicoId\\", f.\\"Notes\\", f.\\"PeriodoExperienciaDias\\", f.\\"PessoaId\\", f.\\"Phone\\", f.\\"Sexo\\", f.\\"Status\\", f.\\"TenantId\\", f.\\"UnidadeLotacaoId\\", f.\\"UnitId\\", f.\\"UpdatedAtUtc\\", f.\\"UserId\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t ON u.\\"FuncionarioId\\" = t.\\"Id\\"\\nWHERE u.\\"TenantId\\" = @__ef_filter__TenantId_0 AND u.\\"Email\\" = @__email_0\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:30.943262-03	2026-04-25 11:12:30.943262-03
604c5d7f-e9e5-4c4c-af85-c65d343e3de9	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT t."Name"\nFROM "UserRoles" AS u\nINNER JOIN (\n    SELECT r."Id", r."Name"\n    FROM "Roles" AS r\n    WHERE r."TenantId" = @__ef_filter__TenantId_0\n) AS t ON u."RoleId" = t."Id"\nWHERE u."TenantId" = @__ef_filter__TenantId_0 AND u."UserId" = @__userId_0	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid)", "commandText": "SELECT t.\\"Name\\"\\nFROM \\"UserRoles\\" AS u\\nINNER JOIN (\\n    SELECT r.\\"Id\\", r.\\"Name\\"\\n    FROM \\"Roles\\" AS r\\n    WHERE r.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t ON u.\\"RoleId\\" = t.\\"Id\\"\\nWHERE u.\\"TenantId\\" = @__ef_filter__TenantId_0 AND u.\\"UserId\\" = @__userId_0", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:30.978938-03	2026-04-25 11:12:30.978938-03
251696af-32d9-4189-8676-12500944d7b3	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	4	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (3ms) [Parameters=[@__ef_filter__TenantId_0='?', @__tenantId_0='?', @__userId_1='?' (DbType = Guid), @__eventType_2='?', @__safeSourceId_3='?'], CommandType='Text', CommandTimeout='30']\nSELECT EXISTS (\n    SELECT 1\n    FROM "RenderCoinTransactions" AS r\n    WHERE r."TenantId" = @__ef_filter__TenantId_0 AND r."TenantId" = @__tenantId_0 AND r."UserId" = @__userId_1 AND r."SourceType" = @__eventType_2 AND r."SourceId" = @__safeSourceId_3)	\N	\N	\N	{"elapsed": "3", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__tenantId_0='?', @__userId_1='?' (DbType = Guid), @__eventType_2='?', @__safeSourceId_3='?'", "commandText": "SELECT EXISTS (\\n    SELECT 1\\n    FROM \\"RenderCoinTransactions\\" AS r\\n    WHERE r.\\"TenantId\\" = @__ef_filter__TenantId_0 AND r.\\"TenantId\\" = @__tenantId_0 AND r.\\"UserId\\" = @__userId_1 AND r.\\"SourceType\\" = @__eventType_2 AND r.\\"SourceId\\" = @__safeSourceId_3)", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:30.98267-03	2026-04-25 11:12:30.98267-03
43dafe7b-9ace-45c3-8619-76b8dd77224c	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	5	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid), @__eventType_1='?', @__businessDate_Item2_2='?' (DbType = DateTime), @__businessDate_Item3_3='?' (DbType = DateTime)], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "RenderCoinTransactions" AS r\nWHERE r."TenantId" = @__ef_filter__TenantId_0 AND r."UserId" = @__userId_0 AND r."SourceType" = @__eventType_1 AND r."CreatedAtUtc" >= @__businessDate_Item2_2 AND r."CreatedAtUtc" < @__businessDate_Item3_3	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid), @__eventType_1='?', @__businessDate_Item2_2='?' (DbType = DateTime), @__businessDate_Item3_3='?' (DbType = DateTime)", "commandText": "SELECT count(*)::int\\nFROM \\"RenderCoinTransactions\\" AS r\\nWHERE r.\\"TenantId\\" = @__ef_filter__TenantId_0 AND r.\\"UserId\\" = @__userId_0 AND r.\\"SourceType\\" = @__eventType_1 AND r.\\"CreatedAtUtc\\" >= @__businessDate_Item2_2 AND r.\\"CreatedAtUtc\\" < @__businessDate_Item3_3", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:30.984544-03	2026-04-25 11:12:30.984544-03
ab07ed9e-b9a2-4539-9af3-7f3445e39b2a	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	3	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (0ms) [Parameters=[@__ef_filter__TenantId_0='?', @__roleNames_0='?' (DbType = Object)], CommandType='Text', CommandTimeout='30']\nSELECT r."Id", r."AccessMode", r."ConcurrencyStamp", r."CreatedAtUtc", r."Description", r."IsActive", r."Name", r."NormalizedName", r."TenantId", r."Tipo", r."UpdatedAtUtc", r."VagasDataScope", r."VisibilityScope"\nFROM "Roles" AS r\nWHERE r."TenantId" = @__ef_filter__TenantId_0 AND r."Name" IS NOT NULL AND r."Name" = ANY (@__roleNames_0)	\N	\N	\N	{"elapsed": "0", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__roleNames_0='?' (DbType = Object)", "commandText": "SELECT r.\\"Id\\", r.\\"AccessMode\\", r.\\"ConcurrencyStamp\\", r.\\"CreatedAtUtc\\", r.\\"Description\\", r.\\"IsActive\\", r.\\"Name\\", r.\\"NormalizedName\\", r.\\"TenantId\\", r.\\"Tipo\\", r.\\"UpdatedAtUtc\\", r.\\"VagasDataScope\\", r.\\"VisibilityScope\\"\\nFROM \\"Roles\\" AS r\\nWHERE r.\\"TenantId\\" = @__ef_filter__TenantId_0 AND r.\\"Name\\" IS NOT NULL AND r.\\"Name\\" = ANY (@__roleNames_0)", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:30.979385-03	2026-04-25 11:12:30.979385-03
926625cf-7410-4222-929f-c18553b3a522	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	6	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT r."TenantId", r."UserId", r."Balance", r."UpdatedAtUtc"\nFROM "RenderCoinBalances" AS r\nWHERE r."TenantId" = @__ef_filter__TenantId_0 AND r."UserId" = @__userId_0\nLIMIT 1	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid)", "commandText": "SELECT r.\\"TenantId\\", r.\\"UserId\\", r.\\"Balance\\", r.\\"UpdatedAtUtc\\"\\nFROM \\"RenderCoinBalances\\" AS r\\nWHERE r.\\"TenantId\\" = @__ef_filter__TenantId_0 AND r.\\"UserId\\" = @__userId_0\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:30.992384-03	2026-04-25 11:12:30.992384-03
ff162754-acb4-45fa-9879-fb7a8325b903	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	9	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-25 11:12:31.023474-03	2026-04-25 11:12:31.023474-03
68454da3-155a-476a-a4fb-b5d0768a81d3	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	7	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT g."Id", g."BestStreak", g."CelebrationCommentsToday", g."CelebrationPostsToday", g."CreatedAtUtc", g."CurrentStreak", g."DevelopmentPlansCreatedToday", g."FeedbackSentToday", g."LastActivityDate", g."LastCheckInDate", g."OneOnOneCompletedToday", g."SurveyAnsweredToday", g."TenantId", g."UpdatedAtUtc", g."UserId"\nFROM "GamificationDailyStates" AS g\nWHERE g."TenantId" = @__ef_filter__TenantId_0 AND g."UserId" = @__userId_0\nLIMIT 1	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userId_0='?' (DbType = Guid)", "commandText": "SELECT g.\\"Id\\", g.\\"BestStreak\\", g.\\"CelebrationCommentsToday\\", g.\\"CelebrationPostsToday\\", g.\\"CreatedAtUtc\\", g.\\"CurrentStreak\\", g.\\"DevelopmentPlansCreatedToday\\", g.\\"FeedbackSentToday\\", g.\\"LastActivityDate\\", g.\\"LastCheckInDate\\", g.\\"OneOnOneCompletedToday\\", g.\\"SurveyAnsweredToday\\", g.\\"TenantId\\", g.\\"UpdatedAtUtc\\", g.\\"UserId\\"\\nFROM \\"GamificationDailyStates\\" AS g\\nWHERE g.\\"TenantId\\" = @__ef_filter__TenantId_0 AND g.\\"UserId\\" = @__userId_0\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:31.001625-03	2026-04-25 11:12:31.001625-03
1c2f6917-39e3-4541-ae57-26538d288080	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	8	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (6ms) [Parameters=[@p0='?' (DbType = Guid), @p1='?' (DbType = Int32), @p2='?' (DbType = Int32), @p3='?' (DbType = Int32), @p4='?' (DbType = DateTime), @p5='?' (DbType = Int32), @p6='?' (DbType = Int32), @p7='?' (DbType = Int32), @p8='?' (DbType = Date), @p9='?' (DbType = Date), @p10='?' (DbType = Int32), @p11='?' (DbType = Int32), @p12='?', @p13='?' (DbType = DateTime), @p14='?' (DbType = Guid), @p15='?', @p16='?' (DbType = Guid), @p17='?' (DbType = Decimal), @p18='?' (DbType = DateTime), @p19='?' (DbType = Guid), @p20='?' (DbType = Decimal), @p21='?' (DbType = DateTime), @p22='?', @p23='?', @p24='?', @p25='?', @p26='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nINSERT INTO "GamificationDailyStates" ("Id", "BestStreak", "CelebrationCommentsToday", "CelebrationPostsToday", "CreatedAtUtc", "CurrentStreak", "DevelopmentPlansCreatedToday", "FeedbackSentToday", "LastActivityDate", "LastCheckInDate", "OneOnOneCompletedToday", "SurveyAnsweredToday", "TenantId", "UpdatedAtUtc", "UserId")\nVALUES (@p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11, @p12, @p13, @p14);\nINSERT INTO "RenderCoinBalances" ("TenantId", "UserId", "Balance", "UpdatedAtUtc")\nVALUES (@p15, @p16, @p17, @p18);\nINSERT INTO "RenderCoinTransactions" ("Id", "Amount", "CreatedAtUtc", "Reason", "SourceId", "SourceType", "TenantId", "UserId")\nVALUES (@p19, @p20, @p21, @p22, @p23, @p24, @p25, @p26);	\N	\N	\N	{"elapsed": "6", "newLine": "\\n", "parameters": "@p0='?' (DbType = Guid), @p1='?' (DbType = Int32), @p2='?' (DbType = Int32), @p3='?' (DbType = Int32), @p4='?' (DbType = DateTime), @p5='?' (DbType = Int32), @p6='?' (DbType = Int32), @p7='?' (DbType = Int32), @p8='?' (DbType = Date), @p9='?' (DbType = Date), @p10='?' (DbType = Int32), @p11='?' (DbType = Int32), @p12='?', @p13='?' (DbType = DateTime), @p14='?' (DbType = Guid), @p15='?', @p16='?' (DbType = Guid), @p17='?' (DbType = Decimal), @p18='?' (DbType = DateTime), @p19='?' (DbType = Guid), @p20='?' (DbType = Decimal), @p21='?' (DbType = DateTime), @p22='?', @p23='?', @p24='?', @p25='?', @p26='?' (DbType = Guid)", "commandText": "INSERT INTO \\"GamificationDailyStates\\" (\\"Id\\", \\"BestStreak\\", \\"CelebrationCommentsToday\\", \\"CelebrationPostsToday\\", \\"CreatedAtUtc\\", \\"CurrentStreak\\", \\"DevelopmentPlansCreatedToday\\", \\"FeedbackSentToday\\", \\"LastActivityDate\\", \\"LastCheckInDate\\", \\"OneOnOneCompletedToday\\", \\"SurveyAnsweredToday\\", \\"TenantId\\", \\"UpdatedAtUtc\\", \\"UserId\\")\\nVALUES (@p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9, @p10, @p11, @p12, @p13, @p14);\\nINSERT INTO \\"RenderCoinBalances\\" (\\"TenantId\\", \\"UserId\\", \\"Balance\\", \\"UpdatedAtUtc\\")\\nVALUES (@p15, @p16, @p17, @p18);\\nINSERT INTO \\"RenderCoinTransactions\\" (\\"Id\\", \\"Amount\\", \\"CreatedAtUtc\\", \\"Reason\\", \\"SourceId\\", \\"SourceType\\", \\"TenantId\\", \\"UserId\\")\\nVALUES (@p19, @p20, @p21, @p22, @p23, @p24, @p25, @p26);", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:31.022698-03	2026-04-25 11:12:31.022698-03
36a9c152-711d-438e-add5-0680c479ef64	dev	59b0927a-9291-4683-b6e4-5c44919c802b	0HNL2QI129U4I:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	10	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-25 11:12:31.03389-03	2026-04-25 11:12:31.03389-03
4d0eeae9-0208-44fc-9d67-560209f4bf4b	dev	eeb59d5b-8f7b-45b5-a5c3-91db97f9d086	0HNL2QI129U4L:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."AprovadorRhId", t."AzureAdClientId", t."AzureAdClientSecret", t."AzureAdTenantId", t."BlipApiKey", t."BlipApiUrl", t."BlipNumeroHospedeiro", t."BloqueiaSalarioForaFaixa", t."DiasAlertaVagaSemFill", t."DiasProvisaoSubstituicao", t."EmbeddingModel", t."EmbeddingProvider", t."LlmModel", t."LlmProvider", t."RhDeveAprovarAposGestor", t."SlaAprovacaoHoras", t."SlaEscalacaoHoras", t."TenantId", t."UpdatedAtUtc"\nFROM "TenantConfiguracoes" AS t\nWHERE t."TenantId" = @__ef_filter__TenantId_0\nLIMIT 1	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"AprovadorRhId\\", t.\\"AzureAdClientId\\", t.\\"AzureAdClientSecret\\", t.\\"AzureAdTenantId\\", t.\\"BlipApiKey\\", t.\\"BlipApiUrl\\", t.\\"BlipNumeroHospedeiro\\", t.\\"BloqueiaSalarioForaFaixa\\", t.\\"DiasAlertaVagaSemFill\\", t.\\"DiasProvisaoSubstituicao\\", t.\\"EmbeddingModel\\", t.\\"EmbeddingProvider\\", t.\\"LlmModel\\", t.\\"LlmProvider\\", t.\\"RhDeveAprovarAposGestor\\", t.\\"SlaAprovacaoHoras\\", t.\\"SlaEscalacaoHoras\\", t.\\"TenantId\\", t.\\"UpdatedAtUtc\\"\\nFROM \\"TenantConfiguracoes\\" AS t\\nWHERE t.\\"TenantId\\" = @__ef_filter__TenantId_0\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:31.146105-03	2026-04-25 11:12:31.146105-03
595db55c-c9e8-42c5-98da-5307f7111425	dev	eeb59d5b-8f7b-45b5-a5c3-91db97f9d086	0HNL2QI129U4L:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-25 11:12:31.146307-03	2026-04-25 11:12:31.146307-03
71b2a67b-421f-468c-9b77-551d8d276c34	dev	eeb59d5b-8f7b-45b5-a5c3-91db97f9d086	0HNL2QI129U4L:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/tenant-configuracao/ai	\N	\N	\N	{"Path": {"value": "/api/tenant-configuracao/ai", "hasValue": true}, "TenantId": "dev"}	2026-04-25 11:12:31.146297-03	2026-04-25 11:12:31.146297-03
f4596e07-6afc-4b4e-92a6-48fbf66010c2	dev	eeb59d5b-8f7b-45b5-a5c3-91db97f9d086	0HNL2QI129U4L:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-25 11:12:31.147209-03	2026-04-25 11:12:31.147209-03
9e4d06d9-da4b-45f9-b83f-e1b442a58767	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (0ms) [Parameters=[], CommandType='Text', CommandTimeout='30']\nSELECT a."Id", a."CreatedAtUtc", a."EncryptedKey", a."IsActive", a."IsDefault", a."Name", a."Provider", a."UpdatedAtUtc"\nFROM "AiProviderKeys" AS a\nWHERE a."IsActive"\nORDER BY a."IsDefault" DESC, a."CreatedAtUtc"\nLIMIT 1	\N	\N	\N	{"elapsed": "0", "newLine": "\\n", "parameters": "", "commandText": "SELECT a.\\"Id\\", a.\\"CreatedAtUtc\\", a.\\"EncryptedKey\\", a.\\"IsActive\\", a.\\"IsDefault\\", a.\\"Name\\", a.\\"Provider\\", a.\\"UpdatedAtUtc\\"\\nFROM \\"AiProviderKeys\\" AS a\\nWHERE a.\\"IsActive\\"\\nORDER BY a.\\"IsDefault\\" DESC, a.\\"CreatedAtUtc\\"\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:33.168513-03	2026-04-25 11:12:33.168513-03
58a38370-55f8-4c91-bf65-a497070970f2	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (0ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."LlmProvider", t."LlmModel", t."EmbeddingProvider", t."EmbeddingModel"\nFROM "TenantConfiguracoes" AS t\nWHERE t."TenantId" = @__ef_filter__TenantId_0\nLIMIT 1	\N	\N	\N	{"elapsed": "0", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"LlmProvider\\", t.\\"LlmModel\\", t.\\"EmbeddingProvider\\", t.\\"EmbeddingModel\\"\\nFROM \\"TenantConfiguracoes\\" AS t\\nWHERE t.\\"TenantId\\" = @__ef_filter__TenantId_0\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-25 11:12:33.166388-03	2026-04-25 11:12:33.166388-03
441a6d99-1a0a-4b5e-b2b4-e5ea3a0e3e91	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	3	Information	System.Net.Http.HttpClient.Default.LogicalHandler	100	RequestPipelineStart	Start processing HTTP request POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyBITEy4tCS_01TygEzz8CORwVBpgF3cl8s	\N	\N	\N	{"Uri": "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyBITEy4tCS_01TygEzz8CORwVBpgF3cl8s", "HttpMethod": {"method": "POST"}}	2026-04-25 11:12:33.168732-03	2026-04-25 11:12:33.168732-03
56fd9e94-7924-4fdd-9df1-dfcd6dfb2b6a	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	4	Information	System.Net.Http.HttpClient.Default.ClientHandler	100	RequestStart	Sending HTTP request POST https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyBITEy4tCS_01TygEzz8CORwVBpgF3cl8s	\N	\N	\N	{"Uri": "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyBITEy4tCS_01TygEzz8CORwVBpgF3cl8s", "HttpMethod": {"method": "POST"}}	2026-04-25 11:12:33.168742-03	2026-04-25 11:12:33.168742-03
0f94d9fc-a1ba-4111-9b0e-eee469b7aee1	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	7	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/ai/invoke	\N	\N	\N	{"Path": {"value": "/api/ai/invoke", "hasValue": true}, "TenantId": "dev"}	2026-04-25 11:12:35.058097-03	2026-04-25 11:12:35.058097-03
435f7974-4949-4b21-9a0d-ee76e240bbbf	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	8	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-25 11:12:35.058139-03	2026-04-25 11:12:35.058139-03
594f9719-7dbe-44d3-b624-0523030da016	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	6	Information	System.Net.Http.HttpClient.Default.LogicalHandler	101	RequestPipelineEnd	End processing HTTP request after 1888.5391ms - 200	\N	\N	\N	{"StatusCode": 200, "ElapsedMilliseconds": 1888.5391}	2026-04-25 11:12:35.057262-03	2026-04-25 11:12:35.057262-03
507bde8b-3bd9-4018-a9dd-2956af3eacb0	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	9	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-25 11:12:35.06329-03	2026-04-25 11:12:35.06329-03
ea2d2268-64a7-4979-b301-aefd912a6a9f	dev	ec4894f7-24ee-45a8-81c0-973c2df27906	0HNL2QI129U4N:00000001	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	5	Information	System.Net.Http.HttpClient.Default.ClientHandler	101	RequestEnd	Received HTTP response headers after 1888.3147ms - 200	\N	\N	\N	{"StatusCode": 200, "ElapsedMilliseconds": 1888.3147}	2026-04-25 11:12:35.057216-03	2026-04-25 11:12:35.057216-03
b125df73-46e7-40a5-9ede-468ab85823cc	dev	196c7421-a277-436f-8cf2-ca6ff97bdf37	0HNL4B65QMA0L:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (3ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userId_Value_0='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT u."RoleId"\nFROM "UserRoles" AS u\nWHERE u."TenantId" = @__ef_filter__TenantId_0 AND u."UserId" = @__userId_Value_0	\N	\N	\N	{"elapsed": "3", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userId_Value_0='?' (DbType = Guid)", "commandText": "SELECT u.\\"RoleId\\"\\nFROM \\"UserRoles\\" AS u\\nWHERE u.\\"TenantId\\" = @__ef_filter__TenantId_0 AND u.\\"UserId\\" = @__userId_Value_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.184094-03	2026-04-27 09:58:47.184094-03
06ccfd6d-6cc1-4c7d-9ca1-fa735a94c42e	dev	dced2881-572c-45ac-a4fa-78a7e88f7a79	0HNL4B65QMA0Q:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.192715-03	2026-04-27 09:58:47.192715-03
1ab84a83-f0ba-4677-a663-10087a0ca268	dev	1e740ef3-5e48-44ec-ac5a-b19ade616a28	0HNL4B65QMA0P:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (6ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name", t."Cep", t."Cidade", t."Uf", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."Cep", s."Cidade", s."CreatedAtUtc", s."SolicitanteId", s."Status", s."Uf"\n    FROM "SolicitacoesEndereco" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "6", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\", t.\\"Cep\\", t.\\"Cidade\\", t.\\"Uf\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"Cep\\", s.\\"Cidade\\", s.\\"CreatedAtUtc\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"Uf\\"\\n    FROM \\"SolicitacoesEndereco\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.187171-03	2026-04-27 09:58:47.187171-03
217857b8-59cf-4c66-82b0-b98e9ebf8755	dev	196c7421-a277-436f-8cf2-ca6ff97bdf37	0HNL4B65QMA0L:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.189558-03	2026-04-27 09:58:47.189558-03
256939bb-6c99-41d7-9b9c-b916d624ef39	dev	dced2881-572c-45ac-a4fa-78a7e88f7a79	0HNL4B65QMA0Q:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (11ms) [Parameters=[@__ef_filter__TenantId_0='?', @__query_Statuses_0='?' (DbType = Object), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32)], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Titulo", t."Urgencia", t."Status", t."SolicitanteId", t0."Name" AS "SolicitanteNome", t."AprovadorId", t1."Name" AS "AprovadorNome", t2."Description" AS "CentroCustoNome", t."QtdPosicoes", t."TipoSolicitacao", t."IsConfidencial", t."SubstituidoNome", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."AprovadorId", s."CentroCustoId", s."CreatedAtUtc", s."IsConfidencial", s."QtdPosicoes", s."SolicitanteId", s."Status", s."SubstituidoNome", s."TipoSolicitacao", s."Titulo", s."Urgencia"\n    FROM "SolicitacoesVaga" AS s\n    WHERE s."TenantId" = @__ef_filter__TenantId_0 AND s."Status" = ANY (@__query_Statuses_0)\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nLEFT JOIN (\n    SELECT f0."Id", f0."Name"\n    FROM "Funcionarios" AS f0\n    WHERE f0."TenantId" = @__ef_filter__TenantId_0\n) AS t1 ON t."AprovadorId" = t1."Id"\nLEFT JOIN (\n    SELECT c."Id", c."Description"\n    FROM "CentrosCusto" AS c\n    WHERE c."TenantId" = @__ef_filter__TenantId_0\n) AS t2 ON t."CentroCustoId" = t2."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "11", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__query_Statuses_0='?' (DbType = Object), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32)", "commandText": "SELECT t.\\"Id\\", t.\\"Titulo\\", t.\\"Urgencia\\", t.\\"Status\\", t.\\"SolicitanteId\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t.\\"AprovadorId\\", t1.\\"Name\\" AS \\"AprovadorNome\\", t2.\\"Description\\" AS \\"CentroCustoNome\\", t.\\"QtdPosicoes\\", t.\\"TipoSolicitacao\\", t.\\"IsConfidencial\\", t.\\"SubstituidoNome\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"AprovadorId\\", s.\\"CentroCustoId\\", s.\\"CreatedAtUtc\\", s.\\"IsConfidencial\\", s.\\"QtdPosicoes\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"SubstituidoNome\\", s.\\"TipoSolicitacao\\", s.\\"Titulo\\", s.\\"Urgencia\\"\\n    FROM \\"SolicitacoesVaga\\" AS s\\n    WHERE s.\\"TenantId\\" = @__ef_filter__TenantId_0 AND s.\\"Status\\" = ANY (@__query_Statuses_0)\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nLEFT JOIN (\\n    SELECT f0.\\"Id\\", f0.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f0\\n    WHERE f0.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t1 ON t.\\"AprovadorId\\" = t1.\\"Id\\"\\nLEFT JOIN (\\n    SELECT c.\\"Id\\", c.\\"Description\\"\\n    FROM \\"CentrosCusto\\" AS c\\n    WHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t2 ON t.\\"CentroCustoId\\" = t2.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.19244-03	2026-04-27 09:58:47.19244-03
337c4650-ddd7-4555-bb38-22528d8ed408	dev	1e740ef3-5e48-44ec-ac5a-b19ade616a28	0HNL4B65QMA0P:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.193072-03	2026-04-27 09:58:47.193072-03
386ec047-657d-4ebc-9ef3-feac6f6ad44e	dev	dced2881-572c-45ac-a4fa-78a7e88f7a79	0HNL4B65QMA0Q:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.196557-03	2026-04-27 09:58:47.196557-03
38e0fe46-19fc-4785-b652-e5ea02d30a21	dev	fb36d099-3748-4c21-867d-a3f6f5414348	0HNL4B65QMA0M:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-ferias	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-ferias", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.193662-03	2026-04-27 09:58:47.193662-03
3bc82138-910f-4c6e-9336-d18e19523d46	dev	1e740ef3-5e48-44ec-ac5a-b19ade616a28	0HNL4B65QMA0P:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-endereco	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-endereco", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.187437-03	2026-04-27 09:58:47.187437-03
3dd5cc93-2e8d-4e4e-803f-7241cce422c0	dev	fb36d099-3748-4c21-867d-a3f6f5414348	0HNL4B65QMA0M:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.196498-03	2026-04-27 09:58:47.196498-03
3ed269d1-4e1a-442d-87a0-fc825ca190e1	dev	ea85ad8d-641c-4906-9239-3c5831867331	0HNL4B65QMA0O:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-dependente	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-dependente", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.187146-03	2026-04-27 09:58:47.187146-03
4db6a6cd-a8fd-465e-9b14-6c6e64fd41ac	dev	ea85ad8d-641c-4906-9239-3c5831867331	0HNL4B65QMA0O:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.193071-03	2026-04-27 09:58:47.193072-03
59ceb2b2-0a5d-4bb6-bfb5-8369be480493	dev	ea85ad8d-641c-4906-9239-3c5831867331	0HNL4B65QMA0O:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (6ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name" AS "SolicitanteNome", t."TipoSolicitacao", t."NomeCompleto", t."Parentesco", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."CreatedAtUtc", s."NomeCompleto", s."Parentesco", s."SolicitanteId", s."Status", s."TipoSolicitacao"\n    FROM "SolicitacoesDependente" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "6", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t.\\"TipoSolicitacao\\", t.\\"NomeCompleto\\", t.\\"Parentesco\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"CreatedAtUtc\\", s.\\"NomeCompleto\\", s.\\"Parentesco\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"TipoSolicitacao\\"\\n    FROM \\"SolicitacoesDependente\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.186988-03	2026-04-27 09:58:47.186988-03
5b7025f0-d757-4ddd-9fb5-ca6b641ddd28	dev	196c7421-a277-436f-8cf2-ca6ff97bdf37	0HNL4B65QMA0L:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (5ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userRoleIds_0='?' (DbType = Object), @__userId_Value_1='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM (\n    SELECT DISTINCT s."SolicitacaoId"\n    FROM "SolicitacoesAprovacaoEtapas" AS s\n    WHERE s."TenantId" = @__ef_filter__TenantId_0 AND s."Status" = 0 AND ((s."RoleFilaId" IS NOT NULL AND s."RoleFilaId" = ANY (@__userRoleIds_0) AND s."AprovadorId" IS NULL AND s."AssumedByUserId" IS NULL) OR s."AssumedByUserId" = @__userId_Value_1)\n) AS t	\N	\N	\N	{"elapsed": "5", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userRoleIds_0='?' (DbType = Object), @__userId_Value_1='?' (DbType = Guid)", "commandText": "SELECT count(*)::int\\nFROM (\\n    SELECT DISTINCT s.\\"SolicitacaoId\\"\\n    FROM \\"SolicitacoesAprovacaoEtapas\\" AS s\\n    WHERE s.\\"TenantId\\" = @__ef_filter__TenantId_0 AND s.\\"Status\\" = 0 AND ((s.\\"RoleFilaId\\" IS NOT NULL AND s.\\"RoleFilaId\\" = ANY (@__userRoleIds_0) AND s.\\"AprovadorId\\" IS NULL AND s.\\"AssumedByUserId\\" IS NULL) OR s.\\"AssumedByUserId\\" = @__userId_Value_1)\\n) AS t", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.189284-03	2026-04-27 09:58:47.189284-03
72b74d19-6625-440f-8600-0c5b9e8c45c4	dev	fb36d099-3748-4c21-867d-a3f6f5414348	0HNL4B65QMA0M:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name" AS "SolicitanteNome", t."DataInicio", t."DataFim", t."QtdDias", t."AbonoPecuniario", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."AbonoPecuniario", s."CreatedAtUtc", s."DataFim", s."DataInicio", s."QtdDias", s."SolicitanteId", s."Status"\n    FROM "SolicitacoesFerias" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t.\\"DataInicio\\", t.\\"DataFim\\", t.\\"QtdDias\\", t.\\"AbonoPecuniario\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"AbonoPecuniario\\", s.\\"CreatedAtUtc\\", s.\\"DataFim\\", s.\\"DataInicio\\", s.\\"QtdDias\\", s.\\"SolicitanteId\\", s.\\"Status\\"\\n    FROM \\"SolicitacoesFerias\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.193381-03	2026-04-27 09:58:47.193381-03
7fed6b5d-061a-44a3-9cdd-d60459769665	dev	74a92961-f605-496c-876e-6df46f87833c	0HNL4B65QMA0N:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.193062-03	2026-04-27 09:58:47.193062-03
84fbec19-dc95-4def-8669-d121fdf931cc	dev	dced2881-572c-45ac-a4fa-78a7e88f7a79	0HNL4B65QMA0Q:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/solicitacoes-vaga	\N	\N	\N	{"Path": {"value": "/api/solicitacoes-vaga", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.19269-03	2026-04-27 09:58:47.19269-03
91d160da-4fc8-4274-9af1-31f3ca042c45	dev	fb36d099-3748-4c21-867d-a3f6f5414348	0HNL4B65QMA0M:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.193686-03	2026-04-27 09:58:47.193686-03
94796e0b-b910-4418-8915-ae1d18a2ef56	dev	ea85ad8d-641c-4906-9239-3c5831867331	0HNL4B65QMA0O:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.18715-03	2026-04-27 09:58:47.18715-03
9570ff3d-a234-43e6-96c6-da3f0ddd9771	dev	74a92961-f605-496c-876e-6df46f87833c	0HNL4B65QMA0N:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.187017-03	2026-04-27 09:58:47.187017-03
afbabf95-caa4-48a4-888f-b3bf4c8eb19c	dev	196c7421-a277-436f-8cf2-ca6ff97bdf37	0HNL4B65QMA0L:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/aprovacoes/pendentes/count	\N	\N	\N	{"Path": {"value": "/api/aprovacoes/pendentes/count", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.189538-03	2026-04-27 09:58:47.189538-03
b0a5310f-d1ba-454e-bd69-c0ba3ef6037e	dev	74a92961-f605-496c-876e-6df46f87833c	0HNL4B65QMA0N:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (6ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name", t."TipoBeneficio", t."TipoAlteracao", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."CreatedAtUtc", s."SolicitanteId", s."Status", s."TipoAlteracao", s."TipoBeneficio"\n    FROM "SolicitacoesBeneficio" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "6", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\", t.\\"TipoBeneficio\\", t.\\"TipoAlteracao\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"CreatedAtUtc\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"TipoAlteracao\\", s.\\"TipoBeneficio\\"\\n    FROM \\"SolicitacoesBeneficio\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.186715-03	2026-04-27 09:58:47.186715-03
c842a945-8c25-4d5f-9dae-47eeff043d0d	dev	1e740ef3-5e48-44ec-ac5a-b19ade616a28	0HNL4B65QMA0P:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.187443-03	2026-04-27 09:58:47.187443-03
c99ae7d1-c6a7-44fe-b19f-a20826909cc7	dev	196c7421-a277-436f-8cf2-ca6ff97bdf37	0HNL4B65QMA0L:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.193062-03	2026-04-27 09:58:47.193062-03
f867a5c2-3ea1-4b4a-b7ce-d0cd45e69b0b	dev	74a92961-f605-496c-876e-6df46f87833c	0HNL4B65QMA0N:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-beneficio	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-beneficio", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.187002-03	2026-04-27 09:58:47.187002-03
62d3ce8f-b38e-4c07-a067-64e107943d4d	dev	8c5fd93f-6f0f-403f-a07c-f40d03e69173	0HNL4B65QMA0U:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name", t."TipoBeneficio", t."TipoAlteracao", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."CreatedAtUtc", s."SolicitanteId", s."Status", s."TipoAlteracao", s."TipoBeneficio"\n    FROM "SolicitacoesBeneficio" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\", t.\\"TipoBeneficio\\", t.\\"TipoAlteracao\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"CreatedAtUtc\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"TipoAlteracao\\", s.\\"TipoBeneficio\\"\\n    FROM \\"SolicitacoesBeneficio\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.221779-03	2026-04-27 09:58:47.221779-03
14409f8d-c46f-49c6-9a5e-7b281959a4e6	dev	9df5b546-b286-48f2-8d69-6cc966139a02	0HNL4B65QMA0S:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.222099-03	2026-04-27 09:58:47.222099-03
42882e7d-3b92-4cc4-aa2e-2458df291cf3	dev	8c5fd93f-6f0f-403f-a07c-f40d03e69173	0HNL4B65QMA0U:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.224243-03	2026-04-27 09:58:47.224243-03
51f23d95-0cb9-49a1-bffa-a8b7768d15a0	dev	d4c07167-d11c-4c8d-88f4-69f208203948	0HNL4B65QMA10:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.235208-03	2026-04-27 09:58:47.235208-03
b26d1209-84ce-4cbd-b7d9-1e39cd7995af	dev	e705432a-27ee-4d34-948f-468a141f2d5a	0HNL4B65QMA17:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/lookup/enums	\N	\N	\N	{"Path": {"value": "/api/lookup/enums", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.254387-03	2026-04-27 09:58:47.254387-03
18b86b82-c937-4b88-b688-5e6ba8c9b706	dev	cdf34249-73e6-4406-a58e-4671d5cccdaf	0HNL4B65QMA0V:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name" AS "SolicitanteNome", t."TipoSolicitacao", t."NomeCompleto", t."Parentesco", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."CreatedAtUtc", s."NomeCompleto", s."Parentesco", s."SolicitanteId", s."Status", s."TipoSolicitacao"\n    FROM "SolicitacoesDependente" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t.\\"TipoSolicitacao\\", t.\\"NomeCompleto\\", t.\\"Parentesco\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"CreatedAtUtc\\", s.\\"NomeCompleto\\", s.\\"Parentesco\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"TipoSolicitacao\\"\\n    FROM \\"SolicitacoesDependente\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.223371-03	2026-04-27 09:58:47.223371-03
2eae09bf-3dcb-49a6-92a1-11e8ba3b096d	dev	152888f1-c3c9-468d-acc2-8d144078bb54	0HNL4B65QMA0T:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.223038-03	2026-04-27 09:58:47.223038-03
442fc74c-68a0-48d0-a611-f6383f837951	dev	9df5b546-b286-48f2-8d69-6cc966139a02	0HNL4B65QMA0S:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/solicitacoes-desligamento	\N	\N	\N	{"Path": {"value": "/api/solicitacoes-desligamento", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.222096-03	2026-04-27 09:58:47.222096-03
65cda190-faf0-4001-a738-ae6bfb965532	dev	152888f1-c3c9-468d-acc2-8d144078bb54	0HNL4B65QMA0T:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name" AS "SolicitanteNome", t."DataInicio", t."DataFim", t."QtdDias", t."AbonoPecuniario", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."AbonoPecuniario", s."CreatedAtUtc", s."DataFim", s."DataInicio", s."QtdDias", s."SolicitanteId", s."Status"\n    FROM "SolicitacoesFerias" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t.\\"DataInicio\\", t.\\"DataFim\\", t.\\"QtdDias\\", t.\\"AbonoPecuniario\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"AbonoPecuniario\\", s.\\"CreatedAtUtc\\", s.\\"DataFim\\", s.\\"DataInicio\\", s.\\"QtdDias\\", s.\\"SolicitanteId\\", s.\\"Status\\"\\n    FROM \\"SolicitacoesFerias\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.222775-03	2026-04-27 09:58:47.222775-03
a419ba77-df47-465f-9f14-122a3de967ac	dev	8c5fd93f-6f0f-403f-a07c-f40d03e69173	0HNL4B65QMA0U:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.221921-03	2026-04-27 09:58:47.221921-03
c71f72bb-33e0-4ecc-a1b1-3f730b9ad043	dev	9df5b546-b286-48f2-8d69-6cc966139a02	0HNL4B65QMA0S:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (5ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name" AS "SolicitanteNome", t1."Name" AS "FuncionarioNome", t."TipoDesligamento", t."DataDesligamento", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."CreatedAtUtc", s."DataDesligamento", s."FuncionarioId", s."SolicitanteId", s."Status", s."TipoDesligamento"\n    FROM "SolicitacoesDesligamento" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nINNER JOIN (\n    SELECT f0."Id", f0."Name"\n    FROM "Funcionarios" AS f0\n    WHERE f0."TenantId" = @__ef_filter__TenantId_0\n) AS t1 ON t."FuncionarioId" = t1."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "5", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t1.\\"Name\\" AS \\"FuncionarioNome\\", t.\\"TipoDesligamento\\", t.\\"DataDesligamento\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"CreatedAtUtc\\", s.\\"DataDesligamento\\", s.\\"FuncionarioId\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"TipoDesligamento\\"\\n    FROM \\"SolicitacoesDesligamento\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nINNER JOIN (\\n    SELECT f0.\\"Id\\", f0.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f0\\n    WHERE f0.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t1 ON t.\\"FuncionarioId\\" = t1.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.221941-03	2026-04-27 09:58:47.221941-03
e7c9e31b-fe0a-4562-b269-9cdca6ff24ee	dev	8c5fd93f-6f0f-403f-a07c-f40d03e69173	0HNL4B65QMA0U:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-beneficio	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-beneficio", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.221912-03	2026-04-27 09:58:47.221912-03
ff4a98ce-2ea2-454a-8a58-ae49051b90f2	dev	152888f1-c3c9-468d-acc2-8d144078bb54	0HNL4B65QMA0T:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-ferias	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-ferias", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.223026-03	2026-04-27 09:58:47.223026-03
2bede23e-4354-4a38-a5dc-688f32f0a699	dev	cdf34249-73e6-4406-a58e-4671d5cccdaf	0HNL4B65QMA0V:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.225621-03	2026-04-27 09:58:47.225621-03
484448e4-639d-436d-adae-2202b64ee8f4	dev	52528b33-54cb-4e97-8e46-1fb777ec5aac	0HNL4B65QMA0R:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (9ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name" AS "SolicitanteNome", t1."Name" AS "FuncionarioNome", t2."Name" AS "NovoCargoNome", t."DataEfetiva", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."CreatedAtUtc", s."DataEfetiva", s."FuncionarioId", s."NovoCargoId", s."SolicitanteId", s."Status"\n    FROM "SolicitacoesPromocao" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nINNER JOIN (\n    SELECT f0."Id", f0."Name"\n    FROM "Funcionarios" AS f0\n    WHERE f0."TenantId" = @__ef_filter__TenantId_0\n) AS t1 ON t."FuncionarioId" = t1."Id"\nINNER JOIN (\n    SELECT j."Id", j."Name"\n    FROM "JobPositions" AS j\n    WHERE j."TenantId" = @__ef_filter__TenantId_0\n) AS t2 ON t."NovoCargoId" = t2."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "9", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\" AS \\"SolicitanteNome\\", t1.\\"Name\\" AS \\"FuncionarioNome\\", t2.\\"Name\\" AS \\"NovoCargoNome\\", t.\\"DataEfetiva\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"CreatedAtUtc\\", s.\\"DataEfetiva\\", s.\\"FuncionarioId\\", s.\\"NovoCargoId\\", s.\\"SolicitanteId\\", s.\\"Status\\"\\n    FROM \\"SolicitacoesPromocao\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nINNER JOIN (\\n    SELECT f0.\\"Id\\", f0.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f0\\n    WHERE f0.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t1 ON t.\\"FuncionarioId\\" = t1.\\"Id\\"\\nINNER JOIN (\\n    SELECT j.\\"Id\\", j.\\"Name\\"\\n    FROM \\"JobPositions\\" AS j\\n    WHERE j.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t2 ON t.\\"NovoCargoId\\" = t2.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.225929-03	2026-04-27 09:58:47.225929-03
5e88dfc5-d256-4630-8816-895fbb74fcf2	dev	cdf34249-73e6-4406-a58e-4671d5cccdaf	0HNL4B65QMA0V:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-dependente	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-dependente", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.223531-03	2026-04-27 09:58:47.223531-03
8e4e4209-4d24-44e1-9a4c-5772bb8d00de	dev	152888f1-c3c9-468d-acc2-8d144078bb54	0HNL4B65QMA0T:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.225338-03	2026-04-27 09:58:47.225338-03
b06b67a3-f392-42c8-b7d5-f6ef63f755aa	dev	cdf34249-73e6-4406-a58e-4671d5cccdaf	0HNL4B65QMA0V:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.223544-03	2026-04-27 09:58:47.223544-03
bb1f62cf-3c47-49f5-91e9-b43a1f726063	dev	52528b33-54cb-4e97-8e46-1fb777ec5aac	0HNL4B65QMA0R:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.226108-03	2026-04-27 09:58:47.226108-03
c6592219-9d41-4415-9cad-318bcce9dec7	dev	9df5b546-b286-48f2-8d69-6cc966139a02	0HNL4B65QMA0S:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.224512-03	2026-04-27 09:58:47.224512-03
d686c13d-c111-4e31-80dd-01f2f409367a	dev	52528b33-54cb-4e97-8e46-1fb777ec5aac	0HNL4B65QMA0R:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/solicitacoes-promocao	\N	\N	\N	{"Path": {"value": "/api/solicitacoes-promocao", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.226097-03	2026-04-27 09:58:47.226097-03
9c48ff0b-3f4e-4ecd-aa96-9786fa8923a4	dev	52528b33-54cb-4e97-8e46-1fb777ec5aac	0HNL4B65QMA0R:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.227639-03	2026-04-27 09:58:47.227639-03
28eee387-adfc-488d-bba2-fcd090516c3f	dev	d4c07167-d11c-4c8d-88f4-69f208203948	0HNL4B65QMA10:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/colaborador/solicitacoes-endereco	\N	\N	\N	{"Path": {"value": "/api/colaborador/solicitacoes-endereco", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.233576-03	2026-04-27 09:58:47.233576-03
817d4797-516a-4a95-ad37-af89ba27e1b6	dev	d4c07167-d11c-4c8d-88f4-69f208203948	0HNL4B65QMA10:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.233593-03	2026-04-27 09:58:47.233593-03
d67e7501-c462-48f5-9bb5-6a870257addf	dev	d4c07167-d11c-4c8d-88f4-69f208203948	0HNL4B65QMA10:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Status", t0."Name", t."Cep", t."Cidade", t."Uf", t."CreatedAtUtc"\nFROM (\n    SELECT s."Id", s."Cep", s."Cidade", s."CreatedAtUtc", s."SolicitanteId", s."Status", s."Uf"\n    FROM "SolicitacoesEndereco" AS s\n    WHERE s."Status" = @__query_Status_Value_0\n    ORDER BY s."CreatedAtUtc" DESC\n    LIMIT @__p_2 OFFSET @__p_1\n) AS t\nINNER JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."SolicitanteId" = t0."Id"\nORDER BY t."CreatedAtUtc" DESC	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__query_Status_Value_0='?' (DbType = Int16), @__p_2='?' (DbType = Int32), @__p_1='?' (DbType = Int32), @__ef_filter__TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Status\\", t0.\\"Name\\", t.\\"Cep\\", t.\\"Cidade\\", t.\\"Uf\\", t.\\"CreatedAtUtc\\"\\nFROM (\\n    SELECT s.\\"Id\\", s.\\"Cep\\", s.\\"Cidade\\", s.\\"CreatedAtUtc\\", s.\\"SolicitanteId\\", s.\\"Status\\", s.\\"Uf\\"\\n    FROM \\"SolicitacoesEndereco\\" AS s\\n    WHERE s.\\"Status\\" = @__query_Status_Value_0\\n    ORDER BY s.\\"CreatedAtUtc\\" DESC\\n    LIMIT @__p_2 OFFSET @__p_1\\n) AS t\\nINNER JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"SolicitanteId\\" = t0.\\"Id\\"\\nORDER BY t.\\"CreatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.233382-03	2026-04-27 09:58:47.233382-03
025a8ef6-aff9-4dc0-b96d-2354c0735d03	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	8	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.248972-03	2026-04-27 09:58:47.248973-03
ce7668a8-205a-4fe9-a934-8731b2c68643	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.238156-03	2026-04-27 09:58:47.238156-03
27907a8e-6ba9-4f8c-9a2a-c11a77a19e6e	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	6	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/dashboard/kpis	\N	\N	\N	{"Path": {"value": "/api/dashboard/kpis", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.247287-03	2026-04-27 09:58:47.247287-03
813289ff-871b-47eb-9943-e1128f8941b6	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__ef_filter__TenantId_0='?', @__todayStart_0='?' (DbType = DateTime)], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."CreatedAtUtc" >= @__todayStart_0	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__todayStart_0='?' (DbType = DateTime)", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"CreatedAtUtc\\" >= @__todayStart_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.24571-03	2026-04-27 09:58:47.24571-03
acb54c2c-c982-4c6d-93cf-3556b7548176	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	7	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.247309-03	2026-04-27 09:58:47.247309-03
d84f36a3-bc14-4d29-a109-dbd94c89bca5	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (0ms) [Parameters=[@__ef_filter__TenantId_0='?', @__weekStart_0='?' (DbType = DateTime)], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."Status" = 2 AND c."UpdatedAtUtc" >= @__weekStart_0	\N	\N	\N	{"elapsed": "0", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__weekStart_0='?' (DbType = DateTime)", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"Status\\" = 2 AND c.\\"UpdatedAtUtc\\" >= @__weekStart_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.246944-03	2026-04-27 09:58:47.246945-03
e49c5238-314e-4306-8659-a809d9304767	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."LastMatchAtUtc" IS NULL AND c."LastMatchScore" IS NULL	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"LastMatchAtUtc\\" IS NULL AND c.\\"LastMatchScore\\" IS NULL", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.246483-03	2026-04-27 09:58:47.246483-03
1d188979-cfd4-4589-936b-72f981e370f5	dev	80be0670-6e47-46f7-87e5-8e242921a8de	0HNL4B65QMA16:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.250321-03	2026-04-27 09:58:47.250321-03
f72eea3e-4d8c-48e6-8b99-aa94dd415957	dev	0ee0a6d6-7445-4761-a42b-7551449cf054	0HNL4B65QMA1A:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (5ms) [Parameters=[@__ef_filter__TenantId_0='?', @__vagaIds_0='?' (DbType = Object)], CommandType='Text', CommandTimeout='30']\nSELECT p."VagaId", p."Numero", (\n    SELECT count(*)::int\n    FROM "ProjetoCandidatos" AS p0\n    WHERE p0."TenantId" = @__ef_filter__TenantId_0 AND p0."ProjetoId" = p."Id") AS "TotalCandidatos"\nFROM "ProjetosVaga" AS p\nWHERE p."TenantId" = @__ef_filter__TenantId_0 AND p."VagaId" = ANY (@__vagaIds_0) AND p."Status" = 0	\N	\N	\N	{"elapsed": "5", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__vagaIds_0='?' (DbType = Object)", "commandText": "SELECT p.\\"VagaId\\", p.\\"Numero\\", (\\n    SELECT count(*)::int\\n    FROM \\"ProjetoCandidatos\\" AS p0\\n    WHERE p0.\\"TenantId\\" = @__ef_filter__TenantId_0 AND p0.\\"ProjetoId\\" = p.\\"Id\\") AS \\"TotalCandidatos\\"\\nFROM \\"ProjetosVaga\\" AS p\\nWHERE p.\\"TenantId\\" = @__ef_filter__TenantId_0 AND p.\\"VagaId\\" = ANY (@__vagaIds_0) AND p.\\"Status\\" = 0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:49.370272-03	2026-04-27 09:58:49.370272-03
7c2f22df-f63f-4898-aeb8-e8329345304e	dev	3540eda5-99df-4a90-9ecd-a59f6a1806e2	0HNL4B65QMA1B:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:53.73364-03	2026-04-27 09:58:53.73364-03
0f6b9943-c9f5-4e4b-9db9-680d08a2230e	dev	39c508d0-d961-4ee5-9687-0948c9e64a3e	0HNL4B65QMA13:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?', @__startDate_0='?' (DbType = DateTime)], CommandType='Text', CommandTimeout='30']\nSELECT date_trunc('day', c."CreatedAtUtc" AT TIME ZONE 'UTC')\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."CreatedAtUtc" >= @__startDate_0	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__startDate_0='?' (DbType = DateTime)", "commandText": "SELECT date_trunc('day', c.\\"CreatedAtUtc\\" AT TIME ZONE 'UTC')\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"CreatedAtUtc\\" >= @__startDate_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.238198-03	2026-04-27 09:58:47.238198-03
112e574c-f044-4a75-92ac-6e3055cd2884	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."Status" = 1	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"Status\\" = 1", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.239203-03	2026-04-27 09:58:47.239203-03
b2af58d3-b121-45f6-8505-433752df1c98	dev	39c508d0-d961-4ee5-9687-0948c9e64a3e	0HNL4B65QMA13:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.23851-03	2026-04-27 09:58:47.23851-03
ff8e92b0-4064-403a-911f-a9e2268c2b9b	dev	39c508d0-d961-4ee5-9687-0948c9e64a3e	0HNL4B65QMA13:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/dashboard/recebidos-series	\N	\N	\N	{"Path": {"value": "/api/dashboard/recebidos-series", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.238488-03	2026-04-27 09:58:47.238488-03
34de12dd-72b0-40da-8e2a-c3d61575d4a1	dev	66e2cba6-6e09-4c90-9993-3861b0daeb79	0HNL4B65QMA15:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.244155-03	2026-04-27 09:58:47.244155-03
41139e73-9d14-4739-b8cd-7f741a0e36dc	dev	ee801d85-141a-4a41-97a1-8792521c2e83	0HNL4B65QMA14:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/dashboard/vagas	\N	\N	\N	{"Path": {"value": "/api/dashboard/vagas", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.242612-03	2026-04-27 09:58:47.242612-03
4883673e-5485-4103-8371-302998f4b45e	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	7	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.243542-03	2026-04-27 09:58:47.243542-03
51363330-1f15-4cc7-8bf6-0d625349974d	dev	ee801d85-141a-4a41-97a1-8792521c2e83	0HNL4B65QMA14:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.244501-03	2026-04-27 09:58:47.244501-03
6500eea7-9f0d-4a5f-a32e-67ab32edd3b3	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (7ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Vagas" AS v\nWHERE v."TenantId" = @__ef_filter__TenantId_0 AND v."Status" = 2	\N	\N	\N	{"elapsed": "7", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT count(*)::int\\nFROM \\"Vagas\\" AS v\\nWHERE v.\\"TenantId\\" = @__ef_filter__TenantId_0 AND v.\\"Status\\" = 2", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.242594-03	2026-04-27 09:58:47.242594-03
6f5d6540-7325-4a6f-9e8c-768830a4f28b	dev	ee801d85-141a-4a41-97a1-8792521c2e83	0HNL4B65QMA14:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (4ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT v."Id", v."Codigo", v."Titulo"\nFROM "Vagas" AS v\nWHERE v."TenantId" = @__ef_filter__TenantId_0\nORDER BY v."Titulo"	\N	\N	\N	{"elapsed": "4", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT v.\\"Id\\", v.\\"Codigo\\", v.\\"Titulo\\"\\nFROM \\"Vagas\\" AS v\\nWHERE v.\\"TenantId\\" = @__ef_filter__TenantId_0\\nORDER BY v.\\"Titulo\\"", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.242396-03	2026-04-27 09:58:47.242396-03
b487dd4c-21dc-457e-9642-7e32d0432ee2	dev	a15211e8-2b14-41ea-bbf2-d7795cbfa13c	0HNL4B65QMA11:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (0ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT v."DataAbertura", v."SlaDiasMetaFechamento", v."Urgente", v."Prioridade"\nFROM "Vagas" AS v\nWHERE v."TenantId" = @__ef_filter__TenantId_0 AND v."Status" = 2 AND v."DataAbertura" IS NOT NULL	\N	\N	\N	{"elapsed": "0", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT v.\\"DataAbertura\\", v.\\"SlaDiasMetaFechamento\\", v.\\"Urgente\\", v.\\"Prioridade\\"\\nFROM \\"Vagas\\" AS v\\nWHERE v.\\"TenantId\\" = @__ef_filter__TenantId_0 AND v.\\"Status\\" = 2 AND v.\\"DataAbertura\\" IS NOT NULL", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.243277-03	2026-04-27 09:58:47.243277-03
d3d95c5c-80ef-4045-8e78-320e953fbcdc	dev	ee801d85-141a-4a41-97a1-8792521c2e83	0HNL4B65QMA14:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.242632-03	2026-04-27 09:58:47.242632-03
0aae71f9-31e1-4248-a11d-17b29cb96593	dev	66e2cba6-6e09-4c90-9993-3861b0daeb79	0HNL4B65QMA15:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT c."Id", c."Description"\nFROM "CentrosCusto" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."IsActive"\nORDER BY c."Description"	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT c.\\"Id\\", c.\\"Description\\"\\nFROM \\"CentrosCusto\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"IsActive\\"\\nORDER BY c.\\"Description\\"", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.239789-03	2026-04-27 09:58:47.239789-03
1da38eac-93b9-4830-bfcd-c2aabd6149b8	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."Status" = 2	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"Status\\" = 2", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.240779-03	2026-04-27 09:58:47.240779-03
6c11d55e-da4b-401a-bebc-72790dd1500f	dev	39c508d0-d961-4ee5-9687-0948c9e64a3e	0HNL4B65QMA13:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.240117-03	2026-04-27 09:58:47.240117-03
6d69015f-2ba6-40f2-83d9-9789ecef6b66	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (0ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM "Candidatos" AS c\nWHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."Status" = 4	\N	\N	\N	{"elapsed": "0", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT count(*)::int\\nFROM \\"Candidatos\\" AS c\\nWHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"Status\\" = 4", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.239789-03	2026-04-27 09:58:47.239789-03
6da001b6-4c28-4f05-bb81-e7410c859a7f	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	6	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.24101-03	2026-04-27 09:58:47.24101-03
98d08f06-e4a4-4fca-adbd-844dc3c5bc93	dev	66e2cba6-6e09-4c90-9993-3861b0daeb79	0HNL4B65QMA15:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/dashboard/areas	\N	\N	\N	{"Path": {"value": "/api/dashboard/areas", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.240025-03	2026-04-27 09:58:47.240025-03
cae4d66a-7c0d-4ebd-898c-e9c4153085df	dev	66e2cba6-6e09-4c90-9993-3861b0daeb79	0HNL4B65QMA15:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.240046-03	2026-04-27 09:58:47.240046-03
f7447ad0-7176-44d2-9453-6db76af0e4e4	dev	1fd4de7b-4954-4396-8476-c16c11d9620a	0HNL4B65QMA12:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/dashboard/funil	\N	\N	\N	{"Path": {"value": "/api/dashboard/funil", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.240988-03	2026-04-27 09:58:47.240988-03
0ef508bc-b7d2-4314-8d32-b255f6347fb1	dev	2aa7d29b-b6d9-4df6-a087-9864ec478d45	0HNL4B65QMA18:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__tenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."Estado", t."NavItemId", t."TenantId", t."UpdatedAtUtc", t."UpdatedByOwnerId"\nFROM "TenantScreens" AS t\nWHERE t."TenantId" = @__tenantId_0	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__tenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"Estado\\", t.\\"NavItemId\\", t.\\"TenantId\\", t.\\"UpdatedAtUtc\\", t.\\"UpdatedByOwnerId\\"\\nFROM \\"TenantScreens\\" AS t\\nWHERE t.\\"TenantId\\" = @__tenantId_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.258064-03	2026-04-27 09:58:47.258064-03
6800edb9-512f-483e-bf62-7fbd06dd38a4	dev	2aa7d29b-b6d9-4df6-a087-9864ec478d45	0HNL4B65QMA18:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.259285-03	2026-04-27 09:58:47.259285-03
c8ec75ab-9b48-41e5-a5d4-a790c44d7e2a	dev	ef933d0e-5d42-414c-ab7c-3635b7e5043e	0HNL4B65QMA19:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.259689-03	2026-04-27 09:58:47.259689-03
ef515546-d603-4487-96d6-07fcf064fe74	dev	2aa7d29b-b6d9-4df6-a087-9864ec478d45	0HNL4B65QMA18:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/navegacao/sidebar	\N	\N	\N	{"Path": {"value": "/api/navegacao/sidebar", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.259264-03	2026-04-27 09:58:47.259264-03
42b8c661-5c49-4dba-8688-ac8c7452315e	dev	80be0670-6e47-46f7-87e5-8e242921a8de	0HNL4B65QMA16:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (3ms) [Parameters=[@__ef_filter__TenantId_0='?', @__safeMin_0='?' (DbType = Int32), @__p_1='?' (DbType = Int32)], CommandType='Text', CommandTimeout='30']\nSELECT t."VagaId", t0."Titulo", t0."Codigo", t."Id", t."Nome", t."Fonte", COALESCE(t."LastMatchScore", 0), t."Status"\nFROM (\n    SELECT c."Id", c."Fonte", c."LastMatchScore", c."Nome", c."Status", c."UpdatedAtUtc", c."VagaId"\n    FROM "Candidatos" AS c\n    WHERE c."TenantId" = @__ef_filter__TenantId_0 AND c."LastMatchScore" IS NOT NULL AND c."VagaId" IS NOT NULL AND c."LastMatchScore" >= @__safeMin_0\n    ORDER BY c."LastMatchScore" DESC, c."UpdatedAtUtc" DESC\n    LIMIT @__p_1\n) AS t\nLEFT JOIN (\n    SELECT v."Id", v."Codigo", v."Titulo"\n    FROM "Vagas" AS v\n    WHERE v."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON t."VagaId" = t0."Id"\nORDER BY t."LastMatchScore" DESC, t."UpdatedAtUtc" DESC	\N	\N	\N	{"elapsed": "3", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__safeMin_0='?' (DbType = Int32), @__p_1='?' (DbType = Int32)", "commandText": "SELECT t.\\"VagaId\\", t0.\\"Titulo\\", t0.\\"Codigo\\", t.\\"Id\\", t.\\"Nome\\", t.\\"Fonte\\", COALESCE(t.\\"LastMatchScore\\", 0), t.\\"Status\\"\\nFROM (\\n    SELECT c.\\"Id\\", c.\\"Fonte\\", c.\\"LastMatchScore\\", c.\\"Nome\\", c.\\"Status\\", c.\\"UpdatedAtUtc\\", c.\\"VagaId\\"\\n    FROM \\"Candidatos\\" AS c\\n    WHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0 AND c.\\"LastMatchScore\\" IS NOT NULL AND c.\\"VagaId\\" IS NOT NULL AND c.\\"LastMatchScore\\" >= @__safeMin_0\\n    ORDER BY c.\\"LastMatchScore\\" DESC, c.\\"UpdatedAtUtc\\" DESC\\n    LIMIT @__p_1\\n) AS t\\nLEFT JOIN (\\n    SELECT v.\\"Id\\", v.\\"Codigo\\", v.\\"Titulo\\"\\n    FROM \\"Vagas\\" AS v\\n    WHERE v.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON t.\\"VagaId\\" = t0.\\"Id\\"\\nORDER BY t.\\"LastMatchScore\\" DESC, t.\\"UpdatedAtUtc\\" DESC", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.24866-03	2026-04-27 09:58:47.24866-03
491dfbc4-2607-4ce7-a95e-940665f10022	dev	80be0670-6e47-46f7-87e5-8e242921a8de	0HNL4B65QMA16:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.248971-03	2026-04-27 09:58:47.248971-03
8c8eac1f-3aa7-42f1-b854-e8d08af668c2	dev	80be0670-6e47-46f7-87e5-8e242921a8de	0HNL4B65QMA16:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/dashboard/top-matches	\N	\N	\N	{"Path": {"value": "/api/dashboard/top-matches", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.248954-03	2026-04-27 09:58:47.248954-03
692b0a22-6cb0-49f8-8501-6be21a93913e	dev	0ee0a6d6-7445-4761-a42b-7551449cf054	0HNL4B65QMA1A:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (17ms) [Parameters=[@__ef_filter__TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT v."Id", v."Codigo", v."Titulo", v."Status", v."CentroCustoId", t."Code" AS "CentroCustoCode", t."Description" AS "CentroCustoNome", v."Modalidade", v."Senioridade", v."QuantidadeVagas", v."MatchMinimoPercentual", v."Confidencial", v."Urgente", v."AceitaPcd", v."DataInicio", v."DataEncerramento", v."DataAbertura", v."SlaDiasMetaFechamento", v."Cidade", v."Uf", (\n    SELECT count(*)::int\n    FROM "VagaRequisitos" AS v0\n    WHERE v0."TenantId" = @__ef_filter__TenantId_0 AND v."Id" = v0."VagaId") AS "RequisitosTotal", (\n    SELECT count(*)::int\n    FROM "VagaRequisitos" AS v1\n    WHERE v1."TenantId" = @__ef_filter__TenantId_0 AND v."Id" = v1."VagaId" AND v1."Obrigatorio") AS "RequisitosObrigatorios", v."CreatedAtUtc", v."UpdatedAtUtc", v."HeadcountAutorizado", (\n    SELECT count(*)::int\n    FROM "OcupacoesHistorico" AS o\n    WHERE o."TenantId" = @__ef_filter__TenantId_0 AND v."Id" = o."VagaId" AND o."DataSaida" IS NULL) AS "HeadcountOcupado", v."IsEstrutural", v."HeadcountProvisorio", v."HeadcountProvisorioExpiresAtUtc", v."AlertaVagaSemFillSnoozeAteUtc", v."HeadcountPendente", v."UnidadeLotacaoId", t0."Code" AS "UnidadeLotacaoCode", t0."Description" AS "UnidadeLotacaoName", v."OrigemTipo", CASE\n    WHEN t1."Id" IS NOT NULL AND t2."Id" IS NOT NULL THEN t2."Name"\n    ELSE NULL\nEND AS "SubstituindoNome", v."HierarquiaId", t3."Descricao" AS "HierarquiaDescricao", v."IdReqRmOrigem", v."CodFuncaoRm", v."FuncaoNomeRm"\nFROM "Vagas" AS v\nLEFT JOIN (\n    SELECT c."Id", c."Code", c."Description"\n    FROM "CentrosCusto" AS c\n    WHERE c."TenantId" = @__ef_filter__TenantId_0\n) AS t ON v."CentroCustoId" = t."Id"\nLEFT JOIN (\n    SELECT u."Id", u."Code", u."Description"\n    FROM "UnidadesLotacao" AS u\n    WHERE u."TenantId" = @__ef_filter__TenantId_0\n) AS t0 ON v."UnidadeLotacaoId" = t0."Id"\nLEFT JOIN (\n    SELECT d."Id", d."FuncionarioId"\n    FROM "Desligamentos" AS d\n    WHERE d."TenantId" = @__ef_filter__TenantId_0\n) AS t1 ON v."OrigemDesligamentoId" = t1."Id"\nLEFT JOIN (\n    SELECT f."Id", f."Name"\n    FROM "Funcionarios" AS f\n    WHERE f."TenantId" = @__ef_filter__TenantId_0\n) AS t2 ON t1."FuncionarioId" = t2."Id"\nLEFT JOIN (\n    SELECT h."Id", h."Descricao"\n    FROM "Hierarquias" AS h\n    WHERE h."TenantId" = @__ef_filter__TenantId_0\n) AS t3 ON v."HierarquiaId" = t3."Id"\nWHERE v."TenantId" = @__ef_filter__TenantId_0	\N	\N	\N	{"elapsed": "17", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?'", "commandText": "SELECT v.\\"Id\\", v.\\"Codigo\\", v.\\"Titulo\\", v.\\"Status\\", v.\\"CentroCustoId\\", t.\\"Code\\" AS \\"CentroCustoCode\\", t.\\"Description\\" AS \\"CentroCustoNome\\", v.\\"Modalidade\\", v.\\"Senioridade\\", v.\\"QuantidadeVagas\\", v.\\"MatchMinimoPercentual\\", v.\\"Confidencial\\", v.\\"Urgente\\", v.\\"AceitaPcd\\", v.\\"DataInicio\\", v.\\"DataEncerramento\\", v.\\"DataAbertura\\", v.\\"SlaDiasMetaFechamento\\", v.\\"Cidade\\", v.\\"Uf\\", (\\n    SELECT count(*)::int\\n    FROM \\"VagaRequisitos\\" AS v0\\n    WHERE v0.\\"TenantId\\" = @__ef_filter__TenantId_0 AND v.\\"Id\\" = v0.\\"VagaId\\") AS \\"RequisitosTotal\\", (\\n    SELECT count(*)::int\\n    FROM \\"VagaRequisitos\\" AS v1\\n    WHERE v1.\\"TenantId\\" = @__ef_filter__TenantId_0 AND v.\\"Id\\" = v1.\\"VagaId\\" AND v1.\\"Obrigatorio\\") AS \\"RequisitosObrigatorios\\", v.\\"CreatedAtUtc\\", v.\\"UpdatedAtUtc\\", v.\\"HeadcountAutorizado\\", (\\n    SELECT count(*)::int\\n    FROM \\"OcupacoesHistorico\\" AS o\\n    WHERE o.\\"TenantId\\" = @__ef_filter__TenantId_0 AND v.\\"Id\\" = o.\\"VagaId\\" AND o.\\"DataSaida\\" IS NULL) AS \\"HeadcountOcupado\\", v.\\"IsEstrutural\\", v.\\"HeadcountProvisorio\\", v.\\"HeadcountProvisorioExpiresAtUtc\\", v.\\"AlertaVagaSemFillSnoozeAteUtc\\", v.\\"HeadcountPendente\\", v.\\"UnidadeLotacaoId\\", t0.\\"Code\\" AS \\"UnidadeLotacaoCode\\", t0.\\"Description\\" AS \\"UnidadeLotacaoName\\", v.\\"OrigemTipo\\", CASE\\n    WHEN t1.\\"Id\\" IS NOT NULL AND t2.\\"Id\\" IS NOT NULL THEN t2.\\"Name\\"\\n    ELSE NULL\\nEND AS \\"SubstituindoNome\\", v.\\"HierarquiaId\\", t3.\\"Descricao\\" AS \\"HierarquiaDescricao\\", v.\\"IdReqRmOrigem\\", v.\\"CodFuncaoRm\\", v.\\"FuncaoNomeRm\\"\\nFROM \\"Vagas\\" AS v\\nLEFT JOIN (\\n    SELECT c.\\"Id\\", c.\\"Code\\", c.\\"Description\\"\\n    FROM \\"CentrosCusto\\" AS c\\n    WHERE c.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t ON v.\\"CentroCustoId\\" = t.\\"Id\\"\\nLEFT JOIN (\\n    SELECT u.\\"Id\\", u.\\"Code\\", u.\\"Description\\"\\n    FROM \\"UnidadesLotacao\\" AS u\\n    WHERE u.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t0 ON v.\\"UnidadeLotacaoId\\" = t0.\\"Id\\"\\nLEFT JOIN (\\n    SELECT d.\\"Id\\", d.\\"FuncionarioId\\"\\n    FROM \\"Desligamentos\\" AS d\\n    WHERE d.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t1 ON v.\\"OrigemDesligamentoId\\" = t1.\\"Id\\"\\nLEFT JOIN (\\n    SELECT f.\\"Id\\", f.\\"Name\\"\\n    FROM \\"Funcionarios\\" AS f\\n    WHERE f.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t2 ON t1.\\"FuncionarioId\\" = t2.\\"Id\\"\\nLEFT JOIN (\\n    SELECT h.\\"Id\\", h.\\"Descricao\\"\\n    FROM \\"Hierarquias\\" AS h\\n    WHERE h.\\"TenantId\\" = @__ef_filter__TenantId_0\\n) AS t3 ON v.\\"HierarquiaId\\" = t3.\\"Id\\"\\nWHERE v.\\"TenantId\\" = @__ef_filter__TenantId_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:49.364193-03	2026-04-27 09:58:49.364193-03
61bc1854-012e-4768-bad4-491f237927f7	dev	0ee0a6d6-7445-4761-a42b-7551449cf054	0HNL4B65QMA1A:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	6	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:49.372932-03	2026-04-27 09:58:49.372932-03
013f694e-4ef1-479a-89bf-d9de7787e189	dev	3540eda5-99df-4a90-9ecd-a59f6a1806e2	0HNL4B65QMA1B:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/lookup/enums	\N	\N	\N	{"Path": {"value": "/api/lookup/enums", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:53.729609-03	2026-04-27 09:58:53.729609-03
22550699-743e-4ccc-883a-d808befae436	dev	ef933d0e-5d42-414c-ab7c-3635b7e5043e	0HNL4B65QMA19:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userId_Value_0='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT u."RoleId"\nFROM "UserRoles" AS u\nWHERE u."TenantId" = @__ef_filter__TenantId_0 AND u."UserId" = @__userId_Value_0	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userId_Value_0='?' (DbType = Guid)", "commandText": "SELECT u.\\"RoleId\\"\\nFROM \\"UserRoles\\" AS u\\nWHERE u.\\"TenantId\\" = @__ef_filter__TenantId_0 AND u.\\"UserId\\" = @__userId_Value_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.254774-03	2026-04-27 09:58:47.254774-03
4c312e6d-9f60-48f9-9dab-b5048535e0ae	dev	2aa7d29b-b6d9-4df6-a087-9864ec478d45	0HNL4B65QMA18:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__tenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."IsEnabled", t."ModuleKey", t."TenantId", t."UpdatedAtUtc", t."UpdatedByOwnerId"\nFROM "TenantModules" AS t\nWHERE t."TenantId" = @__tenantId_0	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__tenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"IsEnabled\\", t.\\"ModuleKey\\", t.\\"TenantId\\", t.\\"UpdatedAtUtc\\", t.\\"UpdatedByOwnerId\\"\\nFROM \\"TenantModules\\" AS t\\nWHERE t.\\"TenantId\\" = @__tenantId_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.255189-03	2026-04-27 09:58:47.255189-03
a9b6a1cd-d9c7-4b1f-aa20-e834e1215a41	dev	e705432a-27ee-4d34-948f-468a141f2d5a	0HNL4B65QMA17:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.254412-03	2026-04-27 09:58:47.254412-03
5d31b494-b674-4510-8595-9bbea88113bc	dev	3540eda5-99df-4a90-9ecd-a59f6a1806e2	0HNL4B65QMA1B:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:53.729659-03	2026-04-27 09:58:53.729659-03
2e335190-6059-46c1-bc75-fa63f3f58917	dev	e705432a-27ee-4d34-948f-468a141f2d5a	0HNL4B65QMA17:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.255865-03	2026-04-27 09:58:47.255865-03
6ef7fae5-e3ce-427e-bc07-52fb7c9a0972	dev	2aa7d29b-b6d9-4df6-a087-9864ec478d45	0HNL4B65QMA18:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__tenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."IsEnabled", t."PackageKey", t."TenantId", t."UpdatedAtUtc", t."UpdatedByOwnerId"\nFROM "TenantPackages" AS t\nWHERE t."TenantId" = @__tenantId_0	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__tenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"IsEnabled\\", t.\\"PackageKey\\", t.\\"TenantId\\", t.\\"UpdatedAtUtc\\", t.\\"UpdatedByOwnerId\\"\\nFROM \\"TenantPackages\\" AS t\\nWHERE t.\\"TenantId\\" = @__tenantId_0", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.255986-03	2026-04-27 09:58:47.255986-03
7c9b1dc8-a855-4b0f-9f70-99b30f975b4e	dev	ef933d0e-5d42-414c-ab7c-3635b7e5043e	0HNL4B65QMA19:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (2ms) [Parameters=[@__ef_filter__TenantId_0='?', @__userRoleIds_0='?' (DbType = Object), @__userId_Value_1='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT count(*)::int\nFROM (\n    SELECT DISTINCT s."SolicitacaoId"\n    FROM "SolicitacoesAprovacaoEtapas" AS s\n    WHERE s."TenantId" = @__ef_filter__TenantId_0 AND s."Status" = 0 AND ((s."RoleFilaId" IS NOT NULL AND s."RoleFilaId" = ANY (@__userRoleIds_0) AND s."AprovadorId" IS NULL AND s."AssumedByUserId" IS NULL) OR s."AssumedByUserId" = @__userId_Value_1)\n) AS t	\N	\N	\N	{"elapsed": "2", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @__userRoleIds_0='?' (DbType = Object), @__userId_Value_1='?' (DbType = Guid)", "commandText": "SELECT count(*)::int\\nFROM (\\n    SELECT DISTINCT s.\\"SolicitacaoId\\"\\n    FROM \\"SolicitacoesAprovacaoEtapas\\" AS s\\n    WHERE s.\\"TenantId\\" = @__ef_filter__TenantId_0 AND s.\\"Status\\" = 0 AND ((s.\\"RoleFilaId\\" IS NOT NULL AND s.\\"RoleFilaId\\" = ANY (@__userRoleIds_0) AND s.\\"AprovadorId\\" IS NULL AND s.\\"AssumedByUserId\\" IS NULL) OR s.\\"AssumedByUserId\\" = @__userId_Value_1)\\n) AS t", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:47.257274-03	2026-04-27 09:58:47.257274-03
bd226a7f-5211-4c2b-9d00-cc2643db12bd	dev	ef933d0e-5d42-414c-ab7c-3635b7e5043e	0HNL4B65QMA19:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/aprovacoes/pendentes/count	\N	\N	\N	{"Path": {"value": "/api/aprovacoes/pendentes/count", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:47.257551-03	2026-04-27 09:58:47.257551-03
cd2a2b2b-acec-4d68-b7fb-7728ac1c546c	dev	ef933d0e-5d42-414c-ab7c-3635b7e5043e	0HNL4B65QMA19:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.257579-03	2026-04-27 09:58:47.257579-03
d4683733-61d0-4e9a-b5d3-d3f225e54434	dev	2aa7d29b-b6d9-4df6-a087-9864ec478d45	0HNL4B65QMA18:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	6	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:47.260681-03	2026-04-27 09:58:47.260681-03
0477c94c-a5c0-4ff4-a8dd-663a645b6404	dev	0ee0a6d6-7445-4761-a42b-7551449cf054	0HNL4B65QMA1A:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ef_filter__TenantId_0='?', @___tenantContext_TenantId_0='?'], CommandType='Text', CommandTimeout='30']\nSELECT t."Id", t."AprovadorRhId", t."AzureAdClientId", t."AzureAdClientSecret", t."AzureAdTenantId", t."BlipApiKey", t."BlipApiUrl", t."BlipNumeroHospedeiro", t."BloqueiaSalarioForaFaixa", t."DiasAlertaVagaSemFill", t."DiasProvisaoSubstituicao", t."EmbeddingModel", t."EmbeddingProvider", t."LlmModel", t."LlmProvider", t."RhDeveAprovarAposGestor", t."SlaAprovacaoHoras", t."SlaEscalacaoHoras", t."TenantId", t."UpdatedAtUtc"\nFROM "TenantConfiguracoes" AS t\nWHERE t."TenantId" = @__ef_filter__TenantId_0 AND t."TenantId" = @___tenantContext_TenantId_0\nLIMIT 1	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ef_filter__TenantId_0='?', @___tenantContext_TenantId_0='?'", "commandText": "SELECT t.\\"Id\\", t.\\"AprovadorRhId\\", t.\\"AzureAdClientId\\", t.\\"AzureAdClientSecret\\", t.\\"AzureAdTenantId\\", t.\\"BlipApiKey\\", t.\\"BlipApiUrl\\", t.\\"BlipNumeroHospedeiro\\", t.\\"BloqueiaSalarioForaFaixa\\", t.\\"DiasAlertaVagaSemFill\\", t.\\"DiasProvisaoSubstituicao\\", t.\\"EmbeddingModel\\", t.\\"EmbeddingProvider\\", t.\\"LlmModel\\", t.\\"LlmProvider\\", t.\\"RhDeveAprovarAposGestor\\", t.\\"SlaAprovacaoHoras\\", t.\\"SlaEscalacaoHoras\\", t.\\"TenantId\\", t.\\"UpdatedAtUtc\\"\\nFROM \\"TenantConfiguracoes\\" AS t\\nWHERE t.\\"TenantId\\" = @__ef_filter__TenantId_0 AND t.\\"TenantId\\" = @___tenantContext_TenantId_0\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:58:49.345614-03	2026-04-27 09:58:49.345614-03
715bcf9c-872a-4756-a2fd-99d3a97b0c1b	dev	0ee0a6d6-7445-4761-a42b-7551449cf054	0HNL4B65QMA1A:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:58:49.370755-03	2026-04-27 09:58:49.370755-03
f246e794-f5e4-4566-a567-fcf9368661df	dev	0ee0a6d6-7445-4761-a42b-7551449cf054	0HNL4B65QMA1A:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/vagas	\N	\N	\N	{"Path": {"value": "/api/vagas", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:58:49.370725-03	2026-04-27 09:58:49.370725-03
bdd76f4a-ddae-4228-a881-35056856c570	dev	3affba32-c095-403f-87b9-b6b538eba0d2	0HNL4B65QMA1C:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	1	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[], CommandType='Text', CommandTimeout='30']\nSELECT t."TenantId", t."Name"\nFROM "Tenants" AS t\nWHERE t."IsActive"\nORDER BY t."TenantId"	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "", "commandText": "SELECT t.\\"TenantId\\", t.\\"Name\\"\\nFROM \\"Tenants\\" AS t\\nWHERE t.\\"IsActive\\"\\nORDER BY t.\\"TenantId\\"", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:59:22.361266-03	2026-04-27 09:59:22.361266-03
4af68527-dc62-4908-93a1-d5838d18d1ae	dev	3affba32-c095-403f-87b9-b6b538eba0d2	0HNL4B65QMA1C:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	3	Debug	RhPortal.Api.Auditing.Middleware.AuditMiddleware	\N	\N	AuditMiddleware.PersistAuditAsync: TenantId=dev, Path=/api/me/switch-tenant	\N	\N	\N	{"Path": {"value": "/api/me/switch-tenant", "hasValue": true}, "TenantId": "dev"}	2026-04-27 09:59:22.36321-03	2026-04-27 09:59:22.36321-03
60ce4bcb-d33f-447e-a2bb-e7d2f990785e	dev	3affba32-c095-403f-87b9-b6b538eba0d2	0HNL4B65QMA1C:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2	Information	Microsoft.EntityFrameworkCore.Database.Command	20101	Microsoft.EntityFrameworkCore.Database.Command.CommandExecuted	Executed DbCommand (1ms) [Parameters=[@__ownerId_0='?' (DbType = Guid)], CommandType='Text', CommandTimeout='30']\nSELECT o."Id", o."CreatedAtUtc", o."Email", o."IsActive", o."PasswordHash", o."UpdatedAtUtc"\nFROM "Owners" AS o\nWHERE o."Id" = @__ownerId_0 AND o."IsActive"\nLIMIT 1	\N	\N	\N	{"elapsed": "1", "newLine": "\\n", "parameters": "@__ownerId_0='?' (DbType = Guid)", "commandText": "SELECT o.\\"Id\\", o.\\"CreatedAtUtc\\", o.\\"Email\\", o.\\"IsActive\\", o.\\"PasswordHash\\", o.\\"UpdatedAtUtc\\"\\nFROM \\"Owners\\" AS o\\nWHERE o.\\"Id\\" = @__ownerId_0 AND o.\\"IsActive\\"\\nLIMIT 1", "commandType": 1, "commandTimeout": 30}	2026-04-27 09:59:22.362351-03	2026-04-27 09:59:22.362351-03
f36b0f9c-2a92-4b33-93bf-a0fd218312f5	dev	3affba32-c095-403f-87b9-b6b538eba0d2	0HNL4B65QMA1C:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	4	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:59:22.363271-03	2026-04-27 09:59:22.363271-03
a5b162dd-90ae-46cb-8f5c-1a7be925e121	dev	3affba32-c095-403f-87b9-b6b538eba0d2	0HNL4B65QMA1C:00000001	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	5	Debug	RhPortal.Api.Auditing.Services.AuditWriter	\N	\N	AuditWriter.CreateDbContext: TenantId=dev, useDefault=False, Database=dev_render_dev	\N	\N	\N	{"Database": "dev_render_dev", "TenantId": "dev", "UseDefault": false}	2026-04-27 09:59:22.366192-03	2026-04-27 09:59:22.366192-03
\.


--
-- Data for Name: LogsComunicacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."LogsComunicacao" ("Id", "TenantId", "CandidatoId", "ProjetoId", "Tipo", "Assunto", "Mensagem", "Destinatario", "UsuarioNome", "DataUtc") FROM stdin;
\.


--
-- Data for Name: Menus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Menus" ("Id", "TenantId", "DisplayName", "Route", "Icon", "Order", "ParentId", "PermissionKey", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "OpenInNewTab", "DisplayNameKey") FROM stdin;
01de57dd-e162-4992-ab2a-915c7daacbf9	dev	Seed.Menu.NiveisHierarquicos	/Admin/Hierarquia	bi-diagram-2	104	\N	admin.hierarquia.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.NiveisHierarquicos
078e93ac-b9c7-4ef1-801e-02b081390e3e	dev	Seed.Menu.Reunioes1a1	/Feedback/Reunioes1a1	bi-people	14	7581c6bd-bbc5-4e78-9828-b058d2ef4183	feedback.oneonone.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Reunioes1a1
085ce56b-bfff-45ac-9af6-9acdfb30214f	dev	Seed.Menu.Feedbacks	/Feedback/Feedbacks	bi-chat-quote	12	7581c6bd-bbc5-4e78-9828-b058d2ef4183	feedback.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Feedbacks
0a4a3a0b-ad0c-4b8c-a05d-1b2c8b9c59bc	dev	Seed.Menu.CategoriasSalariais	/Categorias-Salariais	bi-cash-coin	87	\N	categorias-salariais.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.CategoriasSalariais
0e569084-7a83-4337-85a5-686d38c1d1eb	dev	Seed.Menu.Cargos	/Cadastro/Cargos	bi-briefcase	83	\N	jobpositions.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Cargos
0ea02fad-74da-424f-9858-97226ca19699	dev	Seed.Menu.Gestao	#	bi-person-badge	40	\N	feedback.gestao.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Gestao
1456473f-dcb0-4131-a72a-231d51ce1232	dev	Seed.Menu.Rodadas	/Gestao/Projetos	clipboardlist	53	\N	projetos.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Rodadas
146cd954-b520-45e0-a1d3-57381b141e4c	dev	Seed.Menu.Departamentos	/Departamentos	bi-diagram-2	80	\N	departments.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Departamentos
14fec29f-be6e-475f-9adf-17148a998029	dev	Seed.Menu.Pesquisas	#	bi-search	30	\N	feedback.pesquisas.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Pesquisas
15a9a677-a659-4d22-8704-b169d9f23995	dev	Seed.Menu.GestaoDashboard	/Gestao/Dashboard	bi-speedometer2	41	0ea02fad-74da-424f-9858-97226ca19699	gestao.dashboard	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GestaoDashboard
17979c99-66fc-4876-b465-eba91320fe3a	dev	Seed.Menu.LogsTransacionais	/Admin/Logs	bi-activity	94	\N	audit.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.LogsTransacionais
1c7e40d3-9a59-4f16-8030-c051b9079431	dev	Seed.Menu.GestaoResumo	/Gestao/ResumoAtividades	bi-activity	44	0ea02fad-74da-424f-9858-97226ca19699	gestao.resumo	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GestaoResumo
20a5e05e-5dca-4a6a-b350-04141c18cd2d	dev	Seed.Menu.PesquisaRapida	/Feedback/PesquisaRapida	bi-search-heart	31	14fec29f-be6e-475f-9adf-17148a998029	feedback.pesquisa.rapida	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.PesquisaRapida
294f9c02-6028-4b3d-89a5-cb9c11efe57e	dev	Seed.Menu.ConfigAws	/Owner/AwsSettings	cloud-upload	105	\N	aws-settings.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.ConfigAws
2bb39e80-9ea8-4d99-9d33-bb65bc6555a2	dev	Seed.Menu.Agenda	/Agendas	bi-calendar-event	9	\N	agenda.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Agenda
2d6bd249-7193-4a2b-bd78-e4dcd5cbd24f	dev	Seed.Menu.Desempenho	#	bi-bar-chart	50	\N	desempenho	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Desempenho
3bc20dc3-b272-47ec-9b49-73c7b915865c	dev	Seed.Menu.SuperPesquisa	/Feedback/SuperPesquisa	bi-search	32	14fec29f-be6e-475f-9adf-17148a998029	feedback.pesquisa.super	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.SuperPesquisa
43063961-6a43-49ac-9cc7-9c236195457f	dev	Seed.Menu.PortalVagas	/PortalVagas	globe	51	\N	portalvagas.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.PortalVagas
437ec62f-1c5a-4bb9-83d5-70cecbe13778	dev	Seed.Menu.Acessos	/Admin/Accesses	bi-key	93	\N	access.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Acessos
492fc7c9-f8df-456c-b5e8-7f5737669316	dev	Seed.Menu.Candidatos	/Candidatos	bi-people	4	\N	candidatos.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Candidatos
4b17f24e-122e-4fc9-ae80-277895867143	dev	Seed.Menu.GamificacaoHistorico	/Feedback/GamificacaoHistorico	bi-clock-history	22	6ae869d6-c5a7-4e28-b1d2-6ec5727896d6	feedback.gamificacao.history	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GamificacaoHistorico
4ca803c6-e3b9-4bc6-a9b7-55ce692c0511	dev	Seed.Menu.Unidades	/Unidades	bi-building	84	\N	units.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Unidades
4d44e317-9c0c-4726-bd92-0ac12d3114ee	dev	Seed.Menu.Dashboard	/Dashboard	bi-speedometer2	1	\N	dashboard.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Dashboard
4e1652a2-6efd-4779-afcb-a03417d6b229	dev	Seed.Menu.GestaoHumor	/Gestao/Humor	bi-emoji-smile	43	0ea02fad-74da-424f-9858-97226ca19699	gestao.humor	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GestaoHumor
56a4cccc-e494-40aa-8152-45c50c080ab9	dev	Seed.Menu.Admissao	/Admissao	usercheck	8	\N	admissao.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Admissao
5a736900-ef73-498d-8e81-7520b53b0d70	dev	Seed.Menu.Usuarios	/Admin/Users	bi-people	90	\N	users.read	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Usuarios
5db8597d-3bb2-4f45-9667-d33debf43308	dev	Seed.Menu.Menus	/Admin/Menus	bi-list-check	92	\N	menus.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Menus
60096ca4-3a91-4546-bc8a-fe636cc50951	dev	Seed.Menu.Funcoes	/Cadastro/Funcoes	bi-tags	82	\N	categories.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Funcoes
6306aa9d-8846-46d0-ad73-05296ae3dc39	dev	Seed.Menu.GestaoPlanos	/Gestao/PlanosDesenvolvimento	bi-journal-check	42	0ea02fad-74da-424f-9858-97226ca19699	gestao.planos	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GestaoPlanos
67aeead1-40b6-4383-a0b9-2cb7691822f1	dev	Seed.Menu.ConfigEntraId	/Admin/EntraIdConfig	bi-microsoft	99	\N	entra-config.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.ConfigEntraId
686fd9d5-a577-4f41-b249-4f35009dec95	dev	Seed.Menu.Talentos	/Talentos	bi-person-plus	52	\N	talentos.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Talentos
6ae869d6-c5a7-4e28-b1d2-6ec5727896d6	dev	Seed.Menu.Gamificacao	#	bi-trophy	20	\N	feedback.gamificacao.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Gamificacao
70fc7b25-8329-40ad-acda-bd220db58f04	dev	Seed.Menu.ApiKeys	/Admin/ApiKeys	bi-key-fill	100	\N	api-keys.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.ApiKeys
7581c6bd-bbc5-4e78-9828-b058d2ef4183	dev	Seed.Menu.Desenvolvimento	#	bi-journal-plus	10	\N	feedback.desenvolvimento	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Desenvolvimento
87f29636-7457-472a-9b19-fb2791545b8c	dev	Seed.Menu.Entrada	/EntradaEmailPasta	bi-inbox	60	\N	entrada.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Entrada
89aaf5ee-e87e-4417-aee1-c2e5d74a30bb	dev	Seed.Menu.Turnos	/Turnos	bi-clock	88	\N	turnos.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Turnos
8c0e5b65-bfa3-4031-92ee-ca5ef912a580	dev	Seed.Menu.EnviarFeedback	/Feedback/Enviar	bi-send	11	7581c6bd-bbc5-4e78-9828-b058d2ef4183	feedback.send	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.EnviarFeedback
8f53269d-786f-4d4c-939b-bae850eaf71e	dev	Seed.Menu.GestoresHierarquia	/Admin/Gestores	bi-people	102	\N	admin.gestores.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GestoresHierarquia
92c4bedc-8a67-4505-8f3e-2aa3ad88ab53	dev	Seed.Menu.Matching	/Matching	bi-stars	5	\N	matching.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Matching
934741e9-70de-4e7a-b4dd-5ac382eba7c0	dev	Seed.Menu.ConfigEmail	/Admin/EmailConfig	bi-gear	98	\N	email-config.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.ConfigEmail
95b7d622-c9ff-40b3-93af-f80f4c817e36	dev	Seed.Menu.MinhasAvaliacoes	/Desempenho/MinhasAvaliacoes	bi-journal-check	51	2d6bd249-7193-4a2b-bd78-e4dcd5cbd24f	desempenho.minhasavaliacoes	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.MinhasAvaliacoes
9b4e2de8-9e66-45ae-98c2-3fca9e4369a7	dev	Seed.Menu.Areas	/Areas	bi-diagram-3	81	\N	areas.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Areas
9d5920b2-0ce3-4ce9-90bc-3b4a6d6335e2	dev	Seed.Menu.CentrosCusto	/Centros-Custo	bi-receipt	89	\N	centros-custo.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.CentrosCusto
9eb45db7-4f14-428c-b5e5-5c4751022099	dev	Seed.Menu.Idioma	/Admin/LocalizationConfig	bi-translate	101	\N	localization-config.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Idioma
a1c4ef54-57ee-4ef8-ba62-048587bdee4f	dev	Seed.Menu.SolicitacoesVaga	/Gestao/Solicitacoes	clipboardlist	2	\N	solicitacoes-vaga.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.SolicitacoesVaga
af4654cc-07e7-4790-be8e-06ae07454d67	dev	Seed.Menu.Relatorios	/Relatorios	bi-graph-up	70	\N	relatorios.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Relatorios
b984e834-c9f2-450f-a9f5-f18695b18cf8	dev	Seed.Menu.Emails	/Admin/Emails	bi-envelope	97	\N	emails.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Emails
bcabc0f8-28ea-4842-8ddd-b1e9b035d36a	dev	Seed.Menu.TemplatesEmail	/Admin/EmailTemplates	bi-envelope-paper	96	\N	email-templates.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.TemplatesEmail
c0716663-08a4-435f-a39e-9c2b18a42601	dev	Seed.Menu.UnidadesLotacao	/Unidades-Lotacao	bi-geo-alt	90	\N	unidades-lotacao.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.UnidadesLotacao
c9fa5d48-128d-4994-aa56-1ffecfdf08ed	dev	Seed.Menu.Funcionarios	/Funcionarios	bi-person-badge	85	\N	funcionarios.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Funcionarios
cdbb2797-3e1d-44f7-8c54-45a49674edb3	dev	Seed.Menu.Perfis	/Admin/Roles	bi-shield-lock	91	\N	roles.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Perfis
ce599507-5233-4f6e-ba47-8b35805665d9	dev	Seed.Menu.LogsOperacionais	/Admin/OperationalLogs	bi-journal-text	95	\N	logs.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.LogsOperacionais
d65af1a2-ed15-4f22-ac9a-f6387514ac9a	dev	Seed.Menu.Vagas	/Vagas	bi-briefcase	3	\N	vagas.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Vagas
d69072a1-cd1e-45f5-ab0e-a058d9a53482	dev	Seed.Menu.Celebracao	/Feedback/Celebracao	bi-balloon-heart	5	\N	feedback.celebracao.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Celebracao
dcb4b451-c9aa-45e2-9371-55e086863640	dev	Seed.Menu.BloqueioPessoa	/Pessoas	bi-person-x	86	\N	bloqueio-pessoa.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.BloqueioPessoa
de17ef96-7f13-4724-8462-c9105f9d2704	dev	Seed.Menu.RegrasAprovacao	/Admin/RegrasAprovacaoVaga	bi-check2-square	103	\N	admin.regras-aprovacao.manage	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.RegrasAprovacao
de59b0a4-aedf-48aa-903a-3b306148fb2a	dev	Seed.Menu.GamificacaoRanking	/Feedback/Gamificacao	bi-trophy	21	6ae869d6-c5a7-4e28-b1d2-6ec5727896d6	feedback.gamificacao.ranking	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.GamificacaoRanking
e8dfd418-1178-4cfc-86fd-e48437bff05e	dev	Seed.Menu.Aprovacoes	/Gestao/Aprovacoes	listchecks	50	\N	aprovacoes-vaga.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Aprovacoes
f2ae5a71-e2a4-431d-8000-ba2b441c5575	dev	Seed.Menu.ProcessoSeletivo	/Gestao/Processo-Seletivo	listchecks	7	\N	processo-seletivo.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.ProcessoSeletivo
f4556c0d-098b-4f3d-91cc-e67584013e48	dev	Seed.Menu.FeedbackInicio	/Feedback	bi-house	4	\N	feedback.inicio.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.FeedbackInicio
f5332a84-4398-4dd5-9c5f-edd6d3c67113	dev	Seed.Menu.Triagem	/Triagem	bi-funnel	6	\N	triagem.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.Triagem
f9464df1-d2ba-4fc6-8e48-0ed391c16002	dev	Seed.Menu.NivelCargo	/Nivel-Cargo	bi-layers	84	\N	nivel-cargo.view	t	2026-04-24 22:45:13.849105-03	2026-04-24 22:45:13.849105-03	f	Seed.Menu.NivelCargo
\.


--
-- Data for Name: Metas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Metas" ("Id", "TenantId", "FuncionarioId", "CriadaPorId", "Titulo", "Descricao", "ValorMeta", "ValorAtual", "Unidade", "Prazo", "Status", "CriadoEmUtc", "AtualizadoEmUtc") FROM stdin;
\.


--
-- Data for Name: MoodEntries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MoodEntries" ("Id", "TenantId", "UserId", "Mood", "Note", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: MotivosRequisicaoVagaConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."MotivosRequisicaoVagaConfig" ("Id", "TenantId", "Codigo", "Nome", "Descricao", "EfeitoHeadcount", "IsActive", "Ordem", "IsSystem", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
05710503-1abb-462a-aa08-4c7edbbdc882	dev	AtenderDemanda	Atender demanda	Nova vaga para atender demanda da operação.	0	t	10	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
2754c8ed-d815-4e08-8f68-74633279242f	dev	DesligamentoSemJustaCausa	Desligamento sem justa causa	Reposição por desligamento iniciado pela empresa.	2	t	60	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
5043a6c1-d694-4a3a-b20e-0fbce3b0470b	dev	CotaAprendiz	Cota de aprendiz	Preenchimento da cota legal de aprendizes.	0	t	40	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
7881d14b-512c-4e6f-abdf-6182d9bb7f6b	dev	PedidoDemissao	Pedido de demissão	Reposição por pedido de demissão do ocupante.	2	t	50	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
88b9a162-17a0-43a1-8b83-c9144d67c6a0	dev	TerminoContrato	Término de contrato	Substituição ao fim de contrato temporário / experiência.	2	t	70	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
cbcbcbe3-724a-41e7-ab65-5cc5ef25afc8	dev	ExpansaoBase	Expansão de base	Crescimento planejado do quadro em uma área existente.	0	t	20	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
ce219230-744d-48de-8014-1188d72f4d15	dev	Movimentacao	Movimentação interna	Vaga aberta por promoção ou transferência interna do ocupante.	2	t	80	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
e048d7f0-464f-4dd2-998d-a4dae44baef5	dev	NovaUnidade	Nova unidade	Abertura de filial / nova estrutura.	0	t	30	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
fa8750bf-48e0-46b4-9453-a611ec98499d	dev	Afastamento	Afastamento	Cobertura temporária por afastamento prolongado do ocupante.	2	t	90	t	2026-04-24 22:45:13.899029-03	2026-04-24 22:45:13.899029-03
\.


--
-- Data for Name: NineBoxAssessments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NineBoxAssessments" ("Id", "TenantId", "FuncionarioId", "AvaliadorId", "Desempenho", "Potencial", "Observacoes", "CriadoEmUtc", "AtualizadoEmUtc", "CicloAvaliacaoId") FROM stdin;
\.


--
-- Data for Name: NiveisCargo; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NiveisCargo" ("Id", "TenantId", "CdnNivCargo", "NomReduz", "NomComplet", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: NiveisHierarquicos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NiveisHierarquicos" ("Id", "TenantId", "Nome", "Ordem", "Ativo", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: NotificacoesCandidaturaLogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NotificacoesCandidaturaLogs" ("Id", "TenantId", "CandidaturaId", "CandidatoId", "EtapaMacro", "Canal", "Status", "Destino", "Mensagem", "ErroMensagem", "CriadoEmUtc") FROM stdin;
\.


--
-- Data for Name: NotificacoesTemplates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NotificacoesTemplates" ("Id", "TenantId", "Etapa", "Canal", "Assunto", "Corpo", "CreatedAtUtc", "UpdatedAtUtc", "Idioma") FROM stdin;
\.


--
-- Data for Name: NotificationReceipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NotificationReceipts" ("Id", "TenantId", "NotificationId", "UserId", "SeenAtUtc", "ReadAtUtc", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Notifications" ("Id", "TenantId", "Title", "Message", "Level", "Url", "IsRead", "CreatedAtUtc", "UpdatedAtUtc", "UserId") FROM stdin;
\.


--
-- Data for Name: OcupacoesHistorico; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OcupacoesHistorico" ("Id", "TenantId", "VagaId", "FuncionarioId", "DataEntrada", "DataSaida", "MotivoSaida", "SolicitacaoOrigemId", "IsProvisorio", "ProvisorioExpiresAtUtc") FROM stdin;
\.


--
-- Data for Name: OneOnOneMeetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OneOnOneMeetings" ("Id", "TenantId", "ManagerId", "CollaboratorId", "MeetingDate", "Subject", "Notes", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: PerguntasEntrevistaSaida; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PerguntasEntrevistaSaida" ("Id", "TenantId", "TemplateId", "Ordem", "Texto", "TipoResposta", "Opcoes", "Obrigatoria") FROM stdin;
\.


--
-- Data for Name: PermissoesNivelVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PermissoesNivelVaga" ("Id", "TenantId", "NivelHierarquicoId", "RoleId", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: PessoaBloqueios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PessoaBloqueios" ("Id", "TenantId", "PessoaId", "Motivo", "OrigemBloqueio", "CreatedAtUtc", "CreatedByUserId") FROM stdin;
\.


--
-- Data for Name: Pessoas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Pessoas" ("Id", "TenantId", "Nome", "Email", "Fone", "Cidade", "Uf", "LinkedinUrl", "ResumoProfissional", "Obs", "CreatedAtUtc", "UpdatedAtUtc", "Origem", "Bairro", "Cep", "Complemento", "Cpf", "FoneContato", "Logradouro", "Numero", "Rg", "DataNascimento", "Latitude", "Longitude", "GeocodificadoEmUtc", "Sexo", "EstadoCivil", "Naturalidade", "EstadoNatal", "GrauInstrucao", "RgOrgEmissor", "RgUf", "RgDataEmissao", "CarteiraTrabalho", "CarteiraTrabalhoSerie", "CarteiraTrabalhoUf", "CarteiraTrabalhoData", "NumeroPis", "TituloEleitor", "TituloEleitorZona", "TituloEleitorSecao", "CertificadoReservista", "CategoriaMilitar", "NomePai", "NomeMae", "Nacionalidade") FROM stdin;
\.


--
-- Data for Name: PreAdmissaoDependentes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PreAdmissaoDependentes" ("Id", "TenantId", "PreAdmissaoId", "NomeCompleto", "Parentesco", "Cpf", "DataNascimento", "IsPcd", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: PreAdmissaoDocumentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PreAdmissaoDocumentos" ("Id", "TenantId", "PreAdmissaoId", "Tipo", "NomeArquivo", "ContentType", "TamanhoBytes", "StoragePath", "Status", "ObservacaoRh", "CreatedAtUtc", "UpdatedAtUtc", "Lado") FROM stdin;
\.


--
-- Data for Name: PreAdmissaoDocumentosSolicitados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PreAdmissaoDocumentosSolicitados" ("Id", "TenantId", "PreAdmissaoId", "TipoDocumento", "Obrigatorio", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: PreAdmissoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PreAdmissoes" ("Id", "TenantId", "Status", "PreenchidoPor", "CandidatoId", "RevisadoPorId", "AprovadoPorId", "ObservacaoRh", "MotivoRejeicao", "Nome", "Cpf", "Rg", "RgOrgaoExpedidor", "RgDataExpedicao", "DataNascimento", "Sexo", "EstadoCivil", "Nacionalidade", "NomeMae", "NomePai", "NaturalCidade", "NaturalUf", "Passaporte", "RnmRne", "ValidadeVisto", "TipoVisto", "Cep", "Logradouro", "Numero", "Complemento", "Bairro", "Cidade", "Uf", "Email", "Telefone", "Celular", "ContatoEmergenciaNome", "ContatoEmergenciaFone", "BancoCodigo", "BancoNome", "Agencia", "AgenciaDigito", "Conta", "ContaDigito", "TipoConta", "EstabelecimentoCodigo", "MatriculaRM", "UnitId", "CentroCustoId", "JobPositionId", "DataAdmissao", "Salario", "TipoContratacao", "CargaHorariaSemanal", "PisPasep", "TituloEleitorNumero", "TituloEleitorZona", "TituloEleitorSecao", "ReservistaNumero", "CategoriaCnh", "ValidadeCnh", "Ctps", "CtpsSerie", "CtpsUf", "ValidacaoCpfOk", "ValidacaoCepOk", "ValidacaoBancoOk", "ValidacaoSalarioOk", "ValidacaoSalarioJustificativa", "CreatedAtUtc", "UpdatedAtUtc", "SubmittedAtUtc", "ApprovedAtUtc", "AccessToken", "Altura", "CartaoSus", "CategoriaSalarial", "CentroCustoTotvs", "CodCargoTotvs", "CodTurno", "CodVinculoEmpregaticio", "CtpsModelo", "DocMilitarNumero", "DocMilitarRegiao", "DocMilitarSerie", "DocMilitarTipo", "FatorRh", "GrauInstrucao", "GrupoSanguineo", "Peso", "PossuiDeficiencia", "TipoFuncionario", "TituloEleitorCidade", "TituloEleitorUf", "UnidadeLotacao", "Avos13SalCalc", "Avos13SalCalcAnterior", "Cabelo", "Calcula13", "CargaAutomTurno", "CategoriaTrabalhoESocial", "CnhDataExpedicao", "CnhNumero", "CnhOrgaoEmissor", "CnhPrimeiraHabilitacao", "CnhUf", "CodClassFuncPontoEletronico", "CodEmpresa", "CodFpas", "CodLocalMarcacao", "CodLocalidade", "CodNivel", "CodPlanoLotacao", "CodSindicato", "CodTurma", "ConsidEmissRAIS", "ContribSindicDia", "CtpsSerieESocial", "Cutis", "DataTerminoContrato", "DddTelContato", "DddTelefone", "DescContribSindical", "DiasProvFeriasMesAnterior", "DiasProvFeriasMesAtual", "EmailAlternativo", "EmitCartPonto", "FormaPagamento", "FuncDoador", "FuncQualificado", "IndAdmissao", "IndFuncVinculado", "Manequim", "MatriculaESocial", "MunicipioEnderecoIbge", "MunicipioNascimentoIbge", "NaturezaAtividade", "NomeAbreviado", "NumCartaoPonto", "OcorrenciaCAGED", "Olhos", "OptanteFgts", "OrigemFuncionario", "PaisLocalidade", "PaisNascimento", "PontoReferencia", "ProvAcum13Sal", "ProvAcumFerias", "ProvAcumFerias13", "ProvAcumFgts13Sal", "ProvAcumFgtsFerias", "ProvAcumInss13Sal", "ProvAcumInssFerias", "RecebeAdiantamento", "RecebeFerias", "RecebeInsalub", "RecebePericul", "RecolheFgts", "RecolheInss", "RegimeJornada", "RegimePrevidenciario", "RegimeTrabalhista", "RgUfExpedidor", "SalarioSimulado", "Sapato", "Sindicalizado", "TipoAdmissaoESocial", "TipoAdmissaoFgts", "TipoLogradouroESocial", "TipoMaoDeObra", "TipoVistoEstrangeiro", "CodRegistroExterior", "DataOpcaoFgts", "DocMilitarCircunscricao", "LastActivityUtc", "NomeSocial", "PaisNacionalidade", "ResideExterior", "WizardCompletionPercent", "WizardCurrentStep", "AnoChegada", "CidadeExterior", "CodEnderecoPostalExterior", "DataObitoCivil", "OrgaoEmisPassaporte", "PaisEmisPassaporte", "PortariaNaturalizacao", "Naturalizacao", "TipoCertidaoCivil", "TipoEstatistica", "ValidadeIdentEstrangeiro", "FuncionarioIdMaterializado", "TentativasIntegracao", "UltimaTentativaUtc", "RegIdentidCivilNumero", "RegIdentidCivilUf", "RegIdentidCivilCidade", "RegIdentidCivilOrgEmiss", "RegIdentidCivilDataExped", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc", "VagaId", "IntegracaoResultado", "IntegracaoMensagem", "IntegradaEmUtc", "RequisitoCategoriaId") FROM stdin;
\.


--
-- Data for Name: ProjetoCandidatos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProjetoCandidatos" ("Id", "TenantId", "ProjetoId", "CandidatoId", "Status", "FaseAtualId", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: ProjetosVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProjetosVaga" ("Id", "TenantId", "VagaId", "Numero", "Descricao", "Status", "CreatedAtUtc", "UpdatedAtUtc", "DataInicio", "DataEncerramento") FROM stdin;
\.


--
-- Data for Name: PropostasVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PropostasVaga" ("Id", "TenantId", "VagaId", "CandidatoId", "Status", "Moeda", "SalarioOferecido", "DescricaoBeneficios", "DataPrevistaInicio", "MensagemPersonalizada", "AccessToken", "EnviadaEmUtc", "ExpiraEmUtc", "VisualizadaEmUtc", "RespondidaEmUtc", "NomeConfirmadoCandidato", "IpOrigemResposta", "UserAgentResposta", "MotivoRecusa", "CriadaPorUserId", "EnviadaPorUserId", "ObservacaoInternaRh", "CreatedAtUtc", "UpdatedAtUtc", "CandidaturaId") FROM stdin;
\.


--
-- Data for Name: RecruiterMatchingFeedbacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RecruiterMatchingFeedbacks" ("Id", "TenantId", "VagaId", "CandidatoId", "RecruiterUserId", "Action", "MatchScoreAtAction", "RankPositionAtAction", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: RenderCoinBalances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RenderCoinBalances" ("TenantId", "UserId", "Balance", "UpdatedAtUtc") FROM stdin;
dev	462756d3-8066-42bb-ad9c-6c29d8de1f99	25.0000	2026-04-25 11:12:30.992723-03
\.


--
-- Data for Name: RenderCoinTransactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RenderCoinTransactions" ("Id", "TenantId", "UserId", "Amount", "Reason", "SourceType", "SourceId", "CreatedAtUtc") FROM stdin;
b95c20ae-bb04-49b4-b2b3-aa8837b212d2	dev	462756d3-8066-42bb-ad9c-6c29d8de1f99	25.0000	Login diário	daily_login	daily_login:2026-04-25	2026-04-25 11:12:30.984767-03
\.


--
-- Data for Name: RequestLogs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RequestLogs" ("Id", "TenantId", "TransactionId", "CorrelationId", "TraceId", "EnvironmentName", "EnvironmentNormalized", "DeviceId", "DeviceType", "Platform", "Browser", "DeviceAppVersion", "Locale", "StartedAt", "EndedAt", "DurationMs", "Method", "Path", "QueryString", "StatusCode", "IsSuccess", "UserId", "UserName", "ClientId", "Ip", "UserAgent", "Host", "Controller", "Action", "RouteTemplate", "RequestBodySnippet", "ResponseBodySnippet", "ErrorCount", "WarningCount", "CreatedAt") FROM stdin;
59b0927a-9291-4683-b6e4-5c44919c802b	dev	0HNL2QI129U4I:00000001	00-8152ab6e7951ab59511299a2a1d1b591-75eb6155c64cb5a2-00	8152ab6e7951ab59511299a2a1d1b591	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	2026-04-25 11:12:30.935204-03	2026-04-25 11:12:31.053516-03	118	POST	/api/auth/login	\N	200	t	\N	\N	\N	::1	curl/8.7.1	localhost:5056	Auth	Login	api/auth/login	\N	\N	0	0	2026-04-25 11:12:30.935212-03
eeb59d5b-8f7b-45b5-a5c3-91db97f9d086	dev	0HNL2QI129U4L:00000001	00-4ec74b01445ce0a2ceb885e5fec569ce-ae5bf46139f7917b-00	4ec74b01445ce0a2ceb885e5fec569ce	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	2026-04-25 11:12:31.144012-03	2026-04-25 11:12:31.148091-03	4	GET	/api/tenant-configuracao/ai	\N	200	t	462756d3-8066-42bb-ad9c-6c29d8de1f99	DEV Administrador	\N	::1	curl/8.7.1	localhost:5056	TenantConfiguracao	GetAiConfig	api/tenant-configuracao/ai	\N	\N	0	0	2026-04-25 11:12:31.14402-03
ec4894f7-24ee-45a8-81c0-973c2df27906	dev	0HNL2QI129U4N:00000001	00-e4cea9d3e30c8d8bd2a9bba47a95d43d-8e6bbc1e07fd8c45-00	e4cea9d3e30c8d8bd2a9bba47a95d43d	Development	dev	9FB529E7FBD3904A850CDFBA3A8BBE2C6F50042D6B479E2B0B93A21BA2F32A81	unknown	unknown	unknown	1.0.0.0	\N	2026-04-25 11:12:33.162947-03	2026-04-25 11:12:35.066027-03	1903	POST	/api/ai/invoke	\N	200	t	462756d3-8066-42bb-ad9c-6c29d8de1f99	DEV Administrador	\N	::1	curl/8.7.1	localhost:5056	Ai	Invoke	api/ai/invoke	{"module":"smoke-fase3","payload":{"prompt":"Diga \\u0022oi dev\\u0022","cvText":"ping"}}	\N	0	0	2026-04-25 11:12:33.162959-03
74a92961-f605-496c-876e-6df46f87833c	dev	0HNL4B65QMA0N:00000001	00-76583899a3c586658118c671b24dbd2d-e6c6583974af1214-00	76583899a3c586658118c671b24dbd2d	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.175536-03	2026-04-27 09:58:47.196909-03	21	GET	/api/colaborador/solicitacoes-beneficio	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesBeneficio	List	api/colaborador/solicitacoes-beneficio	\N	\N	0	0	2026-04-27 09:58:47.175547-03
ea85ad8d-641c-4906-9239-3c5831867331	dev	0HNL4B65QMA0O:00000001	00-5ffa118c245d0ceb45ad83dc91976c27-3c5320870c2c21df-00	5ffa118c245d0ceb45ad83dc91976c27	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.176863-03	2026-04-27 09:58:47.196909-03	20	GET	/api/colaborador/solicitacoes-dependente	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesDependente	List	api/colaborador/solicitacoes-dependente	\N	\N	0	0	2026-04-27 09:58:47.176869-03
dced2881-572c-45ac-a4fa-78a7e88f7a79	dev	0HNL4B65QMA0Q:00000001	00-e5e173fbcc7960b0052e52ff61472a56-b1028a5d86adfcaf-00	e5e173fbcc7960b0052e52ff61472a56	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.177347-03	2026-04-27 09:58:47.197978-03	20	GET	/api/solicitacoes-vaga	?statuses=1&statuses=5	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesVaga	List	api/solicitacoes-vaga	\N	\N	0	0	2026-04-27 09:58:47.177359-03
9df5b546-b286-48f2-8d69-6cc966139a02	dev	0HNL4B65QMA0S:00000001	00-4cffc3c23833f3ac7d7da44999d62982-1a65d8d99b0d7e1e-00	4cffc3c23833f3ac7d7da44999d62982	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.211859-03	2026-04-27 09:58:47.225653-03	13	GET	/api/solicitacoes-desligamento	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesDesligamento	List	api/solicitacoes-desligamento	\N	\N	0	0	2026-04-27 09:58:47.211866-03
152888f1-c3c9-468d-acc2-8d144078bb54	dev	0HNL4B65QMA0T:00000001	00-c781bcbe548bf3cce8d565093e095be7-b5b58e2b4ee985c8-00	c781bcbe548bf3cce8d565093e095be7	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.220059-03	2026-04-27 09:58:47.226557-03	6	GET	/api/colaborador/solicitacoes-ferias	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesFerias	List	api/colaborador/solicitacoes-ferias	\N	\N	0	0	2026-04-27 09:58:47.220068-03
66e2cba6-6e09-4c90-9993-3861b0daeb79	dev	0HNL4B65QMA15:00000001	00-98fc415c26b4aac1d04c6ea7062b7e83-b8f41514266a9345-00	98fc415c26b4aac1d04c6ea7062b7e83	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.237627-03	2026-04-27 09:58:47.245124-03	7	GET	/api/dashboard/areas	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Dashboard	GetAreasLookup	api/dashboard/areas	\N	\N	0	0	2026-04-27 09:58:47.237632-03
2aa7d29b-b6d9-4df6-a087-9864ec478d45	dev	0HNL4B65QMA18:00000001	00-2c453c27207a882496db9daed742a762-a3df313bdac395b2-00	2c453c27207a882496db9daed742a762	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.253227-03	2026-04-27 09:58:47.263091-03	9	GET	/api/navegacao/sidebar	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Navegacao	GetSidebar	api/navegacao/sidebar	\N	\N	0	0	2026-04-27 09:58:47.25323-03
8c5fd93f-6f0f-403f-a07c-f40d03e69173	dev	0HNL4B65QMA0U:00000001	00-c4706bc3a3eadc5e6b9bca3b6da325ee-60aeebf954e0f584-00	c4706bc3a3eadc5e6b9bca3b6da325ee	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.220284-03	2026-04-27 09:58:47.225995-03	5	GET	/api/colaborador/solicitacoes-beneficio	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesBeneficio	List	api/colaborador/solicitacoes-beneficio	\N	\N	0	0	2026-04-27 09:58:47.220287-03
ef933d0e-5d42-414c-ab7c-3635b7e5043e	dev	0HNL4B65QMA19:00000001	00-d4ea75ae7f6fdf37747ea01de3723141-a729de1ef46cf2d6-00	d4ea75ae7f6fdf37747ea01de3723141	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.253035-03	2026-04-27 09:58:47.260973-03	7	GET	/api/aprovacoes/pendentes/count	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Aprovacoes	GetPendentesCount	api/aprovacoes/pendentes/count	\N	\N	0	0	2026-04-27 09:58:47.253041-03
0ee0a6d6-7445-4761-a42b-7551449cf054	dev	0HNL4B65QMA1A:00000001	00-d821526f687ea2efebe599ac4993dc59-77676a77033f3cbe-00	d821526f687ea2efebe599ac4993dc59	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:49.340818-03	2026-04-27 09:58:49.374265-03	33	GET	/api/vagas	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Vagas	List	api/vagas	\N	\N	0	0	2026-04-27 09:58:49.340832-03
196c7421-a277-436f-8cf2-ca6ff97bdf37	dev	0HNL4B65QMA0L:00000001	00-f7833517a9739097f9757ed459359107-356b2a8ad58fb3e0-00	f7833517a9739097f9757ed459359107	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.172344-03	2026-04-27 09:58:47.19678-03	24	GET	/api/aprovacoes/pendentes/count	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Aprovacoes	GetPendentesCount	api/aprovacoes/pendentes/count	\N	\N	0	0	2026-04-27 09:58:47.172352-03
1fd4de7b-4954-4396-8476-c16c11d9620a	dev	0HNL4B65QMA12:00000001	00-671612297c410a8a973eb730c3262f40-88588bc9824ad59c-00	671612297c410a8a973eb730c3262f40	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.23606-03	2026-04-27 09:58:47.245321-03	9	GET	/api/dashboard/funil	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Dashboard	GetFunnel	api/dashboard/funil	\N	\N	0	0	2026-04-27 09:58:47.236063-03
a15211e8-2b14-41ea-bbf2-d7795cbfa13c	dev	0HNL4B65QMA11:00000001	00-50682e00430fcb1ce37cb1340089e14c-ef0aca37552173f7-00	50682e00430fcb1ce37cb1340089e14c	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.235173-03	2026-04-27 09:58:47.249961-03	14	GET	/api/dashboard/kpis	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Dashboard	GetKpis	api/dashboard/kpis	\N	\N	0	0	2026-04-27 09:58:47.235181-03
ee801d85-141a-4a41-97a1-8792521c2e83	dev	0HNL4B65QMA14:00000001	00-c922efb8440666be5a62b76cf3a70782-c003e67c3a4a1ff5-00	c922efb8440666be5a62b76cf3a70782	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.237234-03	2026-04-27 09:58:47.246228-03	8	GET	/api/dashboard/vagas	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Dashboard	GetVagasLookup	api/dashboard/vagas	\N	\N	0	0	2026-04-27 09:58:47.237241-03
80be0670-6e47-46f7-87e5-8e242921a8de	dev	0HNL4B65QMA16:00000001	00-6ea8a4ac20213162de9e0ed17b38f74e-faef560c037ec750-00	6ea8a4ac20213162de9e0ed17b38f74e	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.244028-03	2026-04-27 09:58:47.251122-03	7	GET	/api/dashboard/top-matches	?minMatch=70&take=15	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Dashboard	GetTopMatches	api/dashboard/top-matches	\N	\N	0	0	2026-04-27 09:58:47.244035-03
e705432a-27ee-4d34-948f-468a141f2d5a	dev	0HNL4B65QMA17:00000001	00-276d5c14f1c91257921964b037a6662d-74990b60490366ab-00	276d5c14f1c91257921964b037a6662d	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.252556-03	2026-04-27 09:58:47.258854-03	6	GET	/api/lookup/enums	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Lookup	Enums	api/lookup/enums	\N	\N	0	0	2026-04-27 09:58:47.252562-03
3540eda5-99df-4a90-9ecd-a59f6a1806e2	dev	0HNL4B65QMA1B:00000001	00-82c689952f7bad8bbfa0eb1160276e0e-68abad23e2ff542f-00	82c689952f7bad8bbfa0eb1160276e0e	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:53.727457-03	2026-04-27 09:58:53.737423-03	9	GET	/api/lookup/enums	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Lookup	Enums	api/lookup/enums	\N	\N	0	0	2026-04-27 09:58:53.727465-03
1e740ef3-5e48-44ec-ac5a-b19ade616a28	dev	0HNL4B65QMA0P:00000001	00-4a03802d4f29b130a450f96cb5c39e3e-c430e5da1f70a62c-00	4a03802d4f29b130a450f96cb5c39e3e	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.177631-03	2026-04-27 09:58:47.197262-03	19	GET	/api/colaborador/solicitacoes-endereco	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesEndereco	List	api/colaborador/solicitacoes-endereco	\N	\N	0	0	2026-04-27 09:58:47.177638-03
cdf34249-73e6-4406-a58e-4671d5cccdaf	dev	0HNL4B65QMA0V:00000001	00-47939e198efbcac3f4f30695764bac02-c4ded72944cba3de-00	47939e198efbcac3f4f30695764bac02	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.220059-03	2026-04-27 09:58:47.227631-03	7	GET	/api/colaborador/solicitacoes-dependente	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesDependente	List	api/colaborador/solicitacoes-dependente	\N	\N	0	0	2026-04-27 09:58:47.220097-03
52528b33-54cb-4e97-8e46-1fb777ec5aac	dev	0HNL4B65QMA0R:00000001	00-2262dec069a881f7e926bf782c758f0e-f596a52331a555e5-00	2262dec069a881f7e926bf782c758f0e	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.213728-03	2026-04-27 09:58:47.230899-03	17	GET	/api/solicitacoes-promocao	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesPromocao	List	api/solicitacoes-promocao	\N	\N	0	0	2026-04-27 09:58:47.213737-03
3affba32-c095-403f-87b9-b6b538eba0d2	dev	0HNL4B65QMA1C:00000001	00-330980c77a1baaeedc6a0b2e39912b67-157e58c3c4c849ab-00	330980c77a1baaeedc6a0b2e39912b67	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:59:22.357163-03	2026-04-27 09:59:22.368468-03	11	POST	/api/me/switch-tenant	\N	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Me	SwitchTenant	api/me/switch-tenant	{"tenantId":"owner"}	\N	0	0	2026-04-27 09:59:22.357176-03
fb36d099-3748-4c21-867d-a3f6f5414348	dev	0HNL4B65QMA0M:00000001	00-8f369056a5d6b0382e38532398103301-0ab68b64e11433e6-00	8f369056a5d6b0382e38532398103301	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.18141-03	2026-04-27 09:58:47.198327-03	16	GET	/api/colaborador/solicitacoes-ferias	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesFerias	List	api/colaborador/solicitacoes-ferias	\N	\N	0	0	2026-04-27 09:58:47.18142-03
d4c07167-d11c-4c8d-88f4-69f208203948	dev	0HNL4B65QMA10:00000001	00-6231e51a5d787460a4f0b9983bf8a0b4-d883b383f167aeea-00	6231e51a5d787460a4f0b9983bf8a0b4	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.22904-03	2026-04-27 09:58:47.236791-03	7	GET	/api/colaborador/solicitacoes-endereco	?status=1	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	SolicitacoesEndereco	List	api/colaborador/solicitacoes-endereco	\N	\N	0	0	2026-04-27 09:58:47.229045-03
39c508d0-d961-4ee5-9687-0948c9e64a3e	dev	0HNL4B65QMA13:00000001	00-e161608a25b6d58aa79f6d4a8633581e-0e91697d07ea02cc-00	e161608a25b6d58aa79f6d4a8633581e	Development	dev	C5A1868B15ECCE216F81A41CAAB69C74E78F5CF8F831D4788A43F5A1530D65A8	web	mac	safari	1.0.0.0	pt-BR	2026-04-27 09:58:47.235993-03	2026-04-27 09:58:47.243912-03	7	GET	/api/dashboard/recebidos-series	?days=14	200	t	d5823d79-9c97-433b-8f63-1a3be431eaa9	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15	localhost:5056	Dashboard	GetRecebidosSeries	api/dashboard/recebidos-series	\N	\N	0	0	2026-04-27 09:58:47.235999-03
\.


--
-- Data for Name: RespostasCampoPersonalizadoVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RespostasCampoPersonalizadoVaga" ("Id", "TenantId", "VagaId", "CandidatoId", "CampoId", "ValorTexto", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: RespostasEntrevistaSaida; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RespostasEntrevistaSaida" ("Id", "TenantId", "EntrevistaId", "PerguntaId", "ValorTexto", "ValorEscala", "ValorOpcao") FROM stdin;
\.


--
-- Data for Name: RmSyncAlertas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RmSyncAlertas" ("Id", "TenantId", "Tipo", "EntidadeNome", "EntidadeId", "ChaveRm", "DetectadoEmUtc", "CiclosAusente", "ResolvidoEmUtc", "ResolvidoPorId", "Acao", "RunId") FROM stdin;
\.


--
-- Data for Name: RmSyncCheckpoints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RmSyncCheckpoints" ("Id", "TenantId", "Entidade", "LastRecModifiedOn", "LastRunAtUtc", "LastRunStatus", "Notes") FROM stdin;
\.


--
-- Data for Name: RmSyncRuns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RmSyncRuns" ("Id", "TenantId", "Entidade", "Operacao", "StartedAtUtc", "EndedAtUtc", "Status", "TotalLidos", "Criados", "Atualizados", "Ignorados", "ErroMensagem", "WatermarkAplicadoUtc", "WatermarkNovoUtc") FROM stdin;
\.


--
-- Data for Name: RoleMenus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RoleMenus" ("Id", "TenantId", "RoleId", "MenuId", "PermissionKey", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Roles" ("Id", "TenantId", "Description", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "Name", "NormalizedName", "ConcurrencyStamp", "AccessMode", "VagasDataScope", "VisibilityScope", "Tipo") FROM stdin;
fd4a2e0c-e247-4297-a1cc-83d1de299f9a	dev	Seed.AdminRoleDescription	t	2026-04-24 22:45:13.795494-03	2026-04-24 22:45:13.795494-03	Admin	ADMIN	\N	0	0	0	1
c1a9b66e-7998-4766-9c5b-d645162f254f	dev	Administrador do tenant — acesso total dentro do tenant.	t	2026-04-24 22:45:13.866757-03	2026-04-24 22:45:13.866757-03	Administrador	ADMINISTRADOR	\N	0	0	0	1
8f1eddd3-f904-4dd2-a0f9-f1320bd50347	dev	Seed.OperationalRoleDescription	t	2026-04-24 22:45:13.88799-03	2026-04-24 22:45:13.88799-03	Operacional	OPERACIONAL	\N	0	0	0	1
6255983b-2979-4486-8b5e-df3a91d97b57	dev	Seed.GestorRoleDescription	t	2026-04-24 22:45:13.889417-03	2026-04-24 22:45:13.889417-03	Gestor	GESTOR	\N	0	1	1	1
985a9ebd-98dd-4722-9278-e64f311dea0c	dev	Seed.RecruiterRoleDescription	t	2026-04-24 22:45:13.89078-03	2026-04-24 22:45:13.89078-03	Recrutador	RECRUTADOR	\N	0	0	0	1
\.


--
-- Data for Name: SkillAliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SkillAliases" ("Id", "TenantId", "SkillId", "AliasName") FROM stdin;
\.


--
-- Data for Name: Skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Skills" ("Id", "TenantId", "CanonicalName", "Category", "ParentSkillId", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: SlaStatusConfigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SlaStatusConfigs" ("Id", "TenantId", "TipoEntidade", "Status", "SlaHoras", "Ativo", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesAprovacaoEtapas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesAprovacaoEtapas" ("Id", "TenantId", "SolicitacaoId", "TipoFluxo", "Ordem", "Label", "AprovadorId", "RoleFilaId", "Status", "Observacao", "DataUtc", "AcaoEtapa", "MomentoAcao", "AssumedByUserId", "CreatedAtUtc", "LembretesEnviados", "UltimoLembreteUtc", "EscaladoEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesBeneficio; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesBeneficio" ("Id", "TenantId", "SolicitanteId", "TipoBeneficio", "TipoAlteracao", "Descricao", "IncluirDependentes", "DependenteIdsJson", "Status", "ObservacaoAprovador", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesDependente; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesDependente" ("Id", "TenantId", "SolicitanteId", "TipoSolicitacao", "DependenteId", "NomeCompleto", "Parentesco", "Cpf", "DataNascimento", "IsPcd", "DependenteIR", "Status", "ObservacaoAprovador", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesDesligamento; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesDesligamento" ("Id", "TenantId", "SolicitanteId", "FuncionarioId", "DataDesligamento", "TipoDesligamento", "MotivoDesligamento", "TipoAvisoPrevio", "DiasAvisoPrevio", "ElegivelRecontratacao", "SubstituirPosicao", "SolicitacaoVagaGeradaId", "Status", "ObservacaoAprovador", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "PossuiEstabilidade", "EmpresaId", "HistoricoMedidasDisciplinares", "UnitId", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc", "SolicitacaoVagaOrigemId") FROM stdin;
\.


--
-- Data for Name: SolicitacoesEndereco; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesEndereco" ("Id", "TenantId", "SolicitanteId", "Cep", "Logradouro", "Numero", "Bairro", "Complemento", "Cidade", "Uf", "Status", "ObservacaoAprovador", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesFerias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesFerias" ("Id", "TenantId", "SolicitanteId", "PeriodoAquisitivo", "DataInicio", "DataFim", "QtdDias", "AbonoPecuniario", "DiasAbono", "Adiantamento13", "Status", "ObservacaoAprovador", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesPagamentoExtra; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesPagamentoExtra" ("Id", "TenantId", "SolicitanteId", "FuncionarioId", "TipoPagamentoExtra", "Valor", "Descricao", "DataPagamento", "Competencia", "Status", "ImportadoPorId", "ImportadaEmUtc", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoResultado", "IntegracaoMensagem", "IntegradaEmUtc", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesPromocao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesPromocao" ("Id", "TenantId", "SolicitanteId", "FuncionarioId", "DataEfetiva", "CargoAtualId", "NovoCargoId", "CentroCustoAtualId", "NovoCentroCustoId", "Justificativa", "Status", "ObservacaoAprovador", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "MotivoMovimentacao", "NovaUnidadeId", "HorarioProposto", "NovaLocalidade", "NovaPericulosidade", "NovaRemuneracao", "NovoSalario", "UnitId", "EmpresaId", "CentroCustoId", "UnidadeLotacaoId", "ForaFaixaSalarial", "TentativasIntegracao", "UltimaTentativaUtc", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc") FROM stdin;
\.


--
-- Data for Name: SolicitacoesVaga; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SolicitacoesVaga" ("Id", "TenantId", "SolicitanteId", "AprovadorId", "JobPositionId", "UnitId", "Titulo", "Justificativa", "QtdPosicoes", "Urgencia", "Status", "VagaId", "ObservacaoAprovador", "CreatedAtUtc", "UpdatedAtUtc", "ApprovedAtUtc", "IsConfidencial", "SubstituidoFuncionarioId", "SubstituidoNome", "TipoSolicitacao", "CnhObrigatoria", "DisponibilidadeViagens", "EscalaTrabalho", "MotivoRequisicao", "PrazoDias", "TipoContrato", "EmpresaId", "CentroCustoId", "UnidadeLotacaoId", "IntegracaoMensagem", "IntegracaoResultado", "IntegradaEmUtc", "TentativasIntegracao", "UltimaTentativaUtc", "DecisaoRH", "DecisaoRHEmUtc", "DecisaoRHPrazoMeses", "DecisaoRHRevisadoPorId", "EfetivadoManualmentePorId", "EfetivadoManualmenteEmUtc", "DataDesligamento", "DesligamentoVinculadoId", "DiasAvisoPrevioDesligamento", "MotivoDesligamentoTexto", "PossuiEstabilidadeDesligamento", "TipoAvisoPrevioDesligamento", "CandidatoContratadoId", "DecisaoRHPrazoDataAlvo", "MotivoRequisicaoId") FROM stdin;
\.


--
-- Data for Name: SurveyAnswers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SurveyAnswers" ("Id", "TenantId", "ResponseId", "QuestionId", "OptionId", "TextAnswer") FROM stdin;
\.


--
-- Data for Name: SurveyOptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SurveyOptions" ("Id", "TenantId", "QuestionId", "Text", "Order") FROM stdin;
\.


--
-- Data for Name: SurveyQuestions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SurveyQuestions" ("Id", "TenantId", "SurveyId", "Text", "Type", "Order") FROM stdin;
\.


--
-- Data for Name: SurveyResponses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SurveyResponses" ("Id", "TenantId", "SurveyId", "UserId", "SubmittedAtUtc") FROM stdin;
\.


--
-- Data for Name: Surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Surveys" ("Id", "TenantId", "Title", "Type", "StartAtUtc", "EndAtUtc", "DepartmentsJson", "CreatedByUserId", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: TalentoCompetencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TalentoCompetencias" ("Id", "TenantId", "TalentoId", "Tipo", "Nome", "Nivel", "Evidencia", "CreatedAtUtc", "UpdatedAtUtc", "TempoAtuacao") FROM stdin;
\.


--
-- Data for Name: TalentoCvImportJobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TalentoCvImportJobs" ("Id", "TenantId", "TalentoId", "TalentoDocumentoId", "Status", "EnviarParaGpt", "CreatedAtUtc", "StartedAtUtc", "FinishedAtUtc", "SimilarTalentoId", "SuggestedDataJson", "ErrorMessage") FROM stdin;
\.


--
-- Data for Name: TalentoDocumentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TalentoDocumentos" ("Id", "TenantId", "TalentoId", "NomeArquivo", "ContentType", "Descricao", "StorageFileName", "TamanhoBytes", "DataReferencia", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: TalentoExperiencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TalentoExperiencias" ("Id", "TenantId", "TalentoId", "Empresa", "Cargo", "Inicio", "Fim", "Local", "Atividades", "CreatedAtUtc", "UpdatedAtUtc", "TipoContratacao", "NivelHierarquico", "NivelSenioridade", "ResumoAtividades") FROM stdin;
\.


--
-- Data for Name: TalentoFormacoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TalentoFormacoes" ("Id", "TenantId", "TalentoId", "Curso", "Instituicao", "Tipo", "Status", "Inicio", "Fim", "Observacoes", "Link", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: TalentoTreinamentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TalentoTreinamentos" ("Id", "TenantId", "TalentoId", "Nome", "Instituicao", "Ano", "Link", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Talentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Talentos" ("Id", "TenantId", "PessoaId", "Origem", "CreatedAtUtc", "UpdatedAtUtc", "CvProfileJson", "Versao") FROM stdin;
\.


--
-- Data for Name: TemplatesEntrevistaSaida; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TemplatesEntrevistaSaida" ("Id", "TenantId", "Nome", "Ativo", "CreatedAtUtc") FROM stdin;
\.


--
-- Data for Name: TenantAwsSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TenantAwsSettings" ("Id", "TenantId", "AccessKeyIdEncrypted", "SecretAccessKeyEncrypted", "Region", "BucketName", "PresignedUrlExpirationMinutes", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: TenantBrandings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TenantBrandings" ("Id", "TenantId", "NomePortal", "Subtitulo", "RodapeTexto", "CorPrimariaHex", "CorSecundariaHex", "LogoUrl", "VersaoExibida", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: TenantConfiguracoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TenantConfiguracoes" ("Id", "TenantId", "RhDeveAprovarAposGestor", "AprovadorRhId", "UpdatedAtUtc", "DiasProvisaoSubstituicao", "DiasAlertaVagaSemFill", "SlaAprovacaoHoras", "SlaEscalacaoHoras", "BloqueiaSalarioForaFaixa", "AzureAdClientId", "AzureAdClientSecret", "AzureAdTenantId", "BlipNumeroHospedeiro", "BlipApiKey", "BlipApiUrl", "LlmProvider", "LlmModel", "EmbeddingProvider", "EmbeddingModel") FROM stdin;
\.


--
-- Data for Name: Turnos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Turnos" ("Id", "TenantId", "Code", "Description", "StartTime", "EndTime", "Notes", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "UnidadeLotacaoId") FROM stdin;
\.


--
-- Data for Name: UnidadesLotacao; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UnidadesLotacao" ("Id", "TenantId", "Code", "Description", "Location", "Notes", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "Level", "OwnerCdnEmpresa", "OwnerCdnEstab", "OwnerCdnFuncionario", "OwnerFuncionarioId", "ParentId", "SequenceNumber", "CdnPlanoLotac") FROM stdin;
\.


--
-- Data for Name: Units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Units" ("Id", "TenantId", "Code", "Name", "Status", "City", "Uf", "AddressLine", "Neighborhood", "ZipCode", "Email", "Phone", "ResponsibleName", "Type", "Headcount", "Notes", "CreatedAtUtc", "UpdatedAtUtc", "EmpresaId", "NomAbrevPessoaFisic", "NomAbrevPessoaJurid", "NomPessoaJurid") FROM stdin;
af68a38b-2b4a-42c7-ab7e-8c20ee713874	dev	UNI-SPC	Sao Paulo - SP	1	Sao Paulo	SP	\N	\N	\N	sp@liotecnica.com.br	(11) 4001-1002	Responsavel SPC	Escritorio / Administrativo	180	Unidade administrativa.	2026-04-24 22:45:13.896574-03	2026-04-24 22:45:13.896574-03	\N	\N	\N	\N
f1fbd901-b684-4997-b582-9435840ac170	dev	UNI-EMB	Embu das Artes - SP	1	Embu das Artes	SP	Rua Exemplo, 100	Industrial	06800-000	embu@liotecnica.com.br	(11) 4001-1001	Responsavel EMB	Industria / Matriz	420	Unidade principal.	2026-04-24 22:45:13.896574-03	2026-04-24 22:45:13.896574-03	\N	\N	\N	\N
\.


--
-- Data for Name: UserRoles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserRoles" ("UserId", "RoleId", "TenantId") FROM stdin;
462756d3-8066-42bb-ad9c-6c29d8de1f99	fd4a2e0c-e247-4297-a1cc-83d1de299f9a	dev
\.


--
-- Data for Name: UserUnits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserUnits" ("UserId", "UnitId") FROM stdin;
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Users" ("Id", "TenantId", "FullName", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount", "FuncionarioId") FROM stdin;
462756d3-8066-42bb-ad9c-6c29d8de1f99	dev	DEV Administrador	t	2026-04-24 22:45:13.832093-03	2026-04-24 22:45:13.836243-03	admin@dev.local	ADMIN@DEV.LOCAL	admin@dev.local	ADMIN@DEV.LOCAL	f	AQAAAAIAAYagAAAAEBzAXiAw+I7UXKsF6sxpx6CLP5926dwm5TqbZI6F7hNwXkZFuEH1+nuwWVg85mFTZA==	FBF4RXYWDFSY4SRPC62QEEUHVS3LU5DR	db7bbc74-d3d9-4f35-81c6-effe21331c6c	\N	f	f	\N	t	0	\N
\.


--
-- Data for Name: VagaBeneficios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VagaBeneficios" ("Id", "TenantId", "VagaId", "Ordem", "Tipo", "Valor", "Recorrencia", "Obrigatorio", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: VagaEtapas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VagaEtapas" ("Id", "TenantId", "VagaId", "Ordem", "Nome", "Responsavel", "Modo", "SlaDias", "DescricaoInstrucoes", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: VagaPerguntas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VagaPerguntas" ("Id", "TenantId", "VagaId", "Ordem", "Texto", "Tipo", "Peso", "Obrigatoria", "Knockout", "OpcoesRaw", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: VagaRequisitos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VagaRequisitos" ("Id", "TenantId", "VagaId", "Ordem", "Nome", "Peso", "Obrigatorio", "AnosMinimos", "Nivel", "Avaliacao", "SinonimosRaw", "Observacoes", "CreatedAtUtc", "UpdatedAtUtc", "Categoria") FROM stdin;
\.


--
-- Data for Name: VagaUnifiedMatchingCaches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VagaUnifiedMatchingCaches" ("VagaId", "TenantId", "CurrentFiltersHash", "PendingFiltersHash", "Status", "StartedAtUtc", "ComputedAtUtc", "LastAccessAtUtc", "ItemsJson", "LastError") FROM stdin;
\.


--
-- Data for Name: Vagas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Vagas" ("Id", "TenantId", "Codigo", "Titulo", "AreaTime", "Modalidade", "Status", "Senioridade", "QuantidadeVagas", "TipoContratacao", "MatchMinimoPercentual", "DescricaoInterna", "CodigoInterno", "CodigoCbo", "MotivoAbertura", "OrcamentoAprovado", "GestorRequisitante", "RecrutadorResponsavel", "Prioridade", "ResumoPitch", "TagsResponsabilidadesRaw", "TagsKeywordsRaw", "Confidencial", "AceitaPcd", "Urgente", "GeneroPreferencia", "VagaAfirmativa", "LinguagemInclusiva", "PublicoAfirmativo", "ObservacoesPcd", "ProjetoNome", "ProjetoClienteAreaImpactada", "ProjetoPrazoPrevisto", "ProjetoDescricao", "Regime", "CargaSemanalHoras", "Escala", "HoraEntrada", "HoraSaida", "Intervalo", "Cep", "Logradouro", "Numero", "Bairro", "Cidade", "Uf", "PoliticaTrabalho", "ObservacoesDeslocamento", "Moeda", "SalarioMinimo", "SalarioMaximo", "Periodicidade", "BonusTipo", "BonusPercentual", "ObservacoesRemuneracao", "Escolaridade", "FormacaoArea", "ExperienciaMinimaAnos", "TagsStackRaw", "TagsIdiomasRaw", "Diferenciais", "ObservacoesProcesso", "Visibilidade", "DataInicio", "DataEncerramento", "CanalLinkedIn", "CanalSiteCarreiras", "CanalIndicacao", "CanalPortaisEmprego", "DescricaoPublica", "LgpdSolicitarConsentimentoExplicito", "LgpdCompartilharCurriculoInternamente", "LgpdRetencaoAtiva", "LgpdRetencaoMeses", "ExigeCnh", "DisponibilidadeParaViagens", "ChecagemAntecedentes", "CreatedAtUtc", "UpdatedAtUtc", "PesoCompetencia", "PesoExperiencia", "PesoFormacao", "PesoLocalidade", "DataAbertura", "SlaDiasMetaFechamento", "RecrutadorResponsavelUserId", "MatchingFiltrosOriginaisRaw", "MatchingFiltrosRaw", "NomeEngessado", "JobPositionId", "CategoriaSalarialId", "CentroCustoId", "TurnoId", "UnidadeLotacaoId", "EscalaTrabalhoRaw", "HeadcountAutorizado", "IsEstrutural", "HeadcountProvisorio", "HeadcountProvisorioExpiresAtUtc", "AlertaVagaSemFillSnoozeAteUtc", "HeadcountPendente", "EixoVagaId", "TravarFaixaSalarial", "AlcadaSalarialAprovadaPorUserId", "AlcadaSalarialAprovadaEmUtc", "AlcadaSalarialJustificativa", "AlcadaSalarialObservacaoAprovador", "PesoIdioma", "PesoConhecimentoTecnico", "PesoVivenciaEspecifica", "LocalidadeMaxDistanciaKm", "DescricaoCargoId", "HierarquiaId", "IdReqRmOrigem", "OrigemDesligamentoId", "OrigemTipo", "CodFuncaoRm", "FuncaoNomeRm", "CiclosAusenteRm", "UltimoCicloRmObservadoUtc") FROM stdin;
\.


--
-- Data for Name: WorkflowsRH; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WorkflowsRH" ("Id", "TenantId", "TipoWorkflow", "VagaId", "PreAdmissaoId", "Status", "ResponsavelId", "DataInicio", "DataConclusao", "SlaPrazoDias", "CreatedAtUtc", "UpdatedAtUtc", "DesligamentoId") FROM stdin;
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20260118163142_InitialPostgres	8.0.11
20260118172218_AddVagaWeightsAndRequisitoCategoria	8.0.11
20260118193515_AddAreaDescription	8.0.11
20260118210301_AddRequisitoCategorias	8.0.11
20260118212141_AddCostCenters	8.0.11
20260118225543_AddInbox	8.0.11
20260119123027_AddAgendaEvents	8.0.11
20260119141550_AddAuditTables	8.0.11
20260119160008_AddLoggingTables	8.0.11
20260119234124_AddCandidatoStatusHistory	8.0.11
20260120001923_AddInboxSuggestedVagas	8.0.11
20260120013335_AddInboxCandidateLink	8.0.11
20260121120950_AddMenuOpenInNewTab	8.0.11
20260121160223_AddCandidateAccessKey	8.0.11
20260121160350_AddCandidatePortalAccessKey	8.0.11
20260121164133_AddEmailMessaging	8.0.11
20260121190201_AddEmailConfig	8.0.11
20260122161503_AddCandidatePortalPassword	8.0.11
20260122171044_AllowCandidateWithoutVaga	8.0.11
20260122222457_AddEntraIdConfig	8.0.11
20260123115752_AddLocalizationConfig	8.0.11
20260123144238_AddMenuDisplayNameKey	8.0.11
20260123181814_ExpandLogMetadataLengths	8.0.11
20260123181839_ExpandLogMetadataLengthsV2	8.0.11
20260126023749_AddCandidateProfileFields	8.0.11
20260126032322_AddCandidateSkillsPortfolio	8.0.11
20260126111922_AddCandidateEducation	8.0.11
20260126121634_AddCandidateExperienceProjects	8.0.11
20260126125825_AddPortfolioTagsFix	8.0.11
20260126135851_AddCandidatePreferences	8.0.11
20260126161558_AddCandidateDocumentColumns	8.0.11
20260126163113_AddCandidateReferences	8.0.11
20260126165928_AddCandidateAccessibility	8.0.11
20260126174448_AddCandidateAgenda	8.0.11
20260126185400_AddCandidateNotifications	8.0.11
20260126195531_AddCandidateLgpdConsent	8.0.11
20260127101000_AddTenantNotifications	8.0.11
20260127112000_AddNotificationReceipts	8.0.11
20260129230450_AddCandidateApplicationRecruiter	8.0.11
20260129234814_RemoveTenantsFromTenantDb	8.0.11
20260130015748_AddAreaHierarchyAndOwner	8.0.11
20260130020002_AddUserUnits	8.0.11
20260130020349_AddApplicationUserManagerId	8.0.11
20260130210944_EnsureVagaDataAberturaColumn	8.0.11
20260131003104_AddCelebrationPosts	8.0.11
20260131003417_AddFeedbackItems	8.0.11
20260131003846_AddDevelopmentPlans	8.0.11
20260131004226_AddOneOnOneMeetings	8.0.11
20260131004811_AddRenderCoinGamification	8.0.11
20260131005826_RemoveCostCentersAndDepartmentCostCenter	8.0.11
20260131041608_AddProfileVisibilityScopeVagasDataScopeAccessModeToRoles	8.0.11
20260131055953_ReplaceManagersWithFuncionarios	8.0.11
20260131121225_AddPessoaTalento	8.0.11
20260131131128_AddPessoaBloqueios	8.0.11
20260131140232_AddPessoaOrigem	8.0.11
20260131144002_AddPessoaEnderecoDocumentos	8.0.11
20260131151012_AddTalentoProfileTables	8.0.11
20260131172938_AddTalentoExperienciaTipoContratacao	8.0.11
20260131173128_AddTalentoCvProfileJson	8.0.11
20260131175044_AddTalentoVersao	8.0.11
20260201013617_AddTalentoExperienciaResumoNivel	8.0.11
20260201025804_AddTalentoCvImportJob	8.0.11
20260201224835_AddPessoaDataNascimento	8.0.11
20260201234035_AddTalentoCompetenciaTempoAtuacao	8.0.11
20260204020518_AddApiKeys	8.0.11
20260204031304_FixMenuFuncaoCargoDisplay	8.0.11
20260204035326_AddFuncionarioRequisitoCategoriaId	8.0.11
20260204071246_EnsureVagaRecrutadorResponsavelUserId	8.0.11
20260210172043_AddVagaMatchingFiltros	8.0.11
20260211120000_EnsureVagaMatchingFiltrosColumns	8.0.11
20260219135135_AddCelebrationComments	8.0.11
20260219135650_AddCelebrationCommentReactions	8.0.11
20260219140137_AddNotificationUserId	8.0.11
20260224141715_AddFeedbackItemEnhancements	8.0.11
20260224173507_AddVagaUnifiedMatchingCache	8.0.11
20260303155603_AddMoodEntries	8.0.11
20260310141838_AddSolicitacaoVaga	8.0.11
20260311124301_Sprint1a6_HierarquiaProjetosFasesCamposComunicacao	8.0.11
20260311144314_Sprint_P2_PermissaoNivelVaga	8.0.11
20260318000000_AddVagaNomeEngessado	8.0.11
20260318210152_AddRegraAprovacaoVaga	8.0.11
20260319193124_AddRespostaCampoPersonalizadoVaga	8.0.11
20260325192801_AddNineBoxAssessment	8.0.11
20260325193943_AddMetas	8.0.11
20260325195459_AddAvaliacaoCiclos	8.0.11
20260326144714_AddTenantAwsSettings	8.0.11
20260327122905_AddDocumentoSolicitadoAndAccessToken	8.0.11
20260331130500_AddSolicitacoesRH	8.0.11
20260408134640_AddCargoCadastroAndOthers	8.0.11
20260408165425_AddCargoIdAndJobPositionFields	8.0.11
20260408175824_VagaJobPositionRef	8.0.11
20260408191424_AddIntegracaoTotvsPreAdmissao	8.0.11
20260408191717_AddVagaCadastroFKs	8.0.11
20260408200405_JobPositionTotvsFieldsAndCargoDataMigration	8.0.11
20260409170406_AddIntegracaoTotvsFieldsAndPagamentoExtra	8.0.11
20260410134234_AddTotvsFieldsCompleto	8.0.11
20260410200000_AddEmpresaAndUnitFK	8.0.11
20260411050349_AddNivelCargoAndJobPositionFields	8.0.11
20260411051412_AddUnidadeLotacaoHierarchyAndFuncionarioTotvsKeys	8.0.11
20260411060134_MakeJobPositionAreaIdNullable	8.0.11
20260411065456_AddJobPositionTotvsIds	8.0.11
20260411084124_AddRoleTipo	8.0.11
20260411084322_MakeFuncionarioEmailOptional	8.0.11
20260411084939_AddFuncionarioUnidadeLotacao	8.0.11
20260411090000_AddNivelCargoIdToFuncionarios	8.0.11
20260411100000_AddCdnNivCargoToFuncionarios	8.0.11
20260411100000_AddUnitNomPessoaJurid	8.0.11
20260411100515_AddFuncionarioCentroCusto	8.0.11
20260411110000_AddUnitEmpresaCodeUniqueIndex	8.0.11
20260411120000_AddCentroCustoEmpresaFK	8.0.11
20260411130000_AddCentroCustoValidade	8.0.11
20260411140000_AddCategoriaSalarialEmpresaEstabelecimento	8.0.11
20260411150000_AddUnitNomAbrevPessoaFisic	8.0.11
20260411160000_AddSolicitacoesFormFields	8.0.11
20260411170000_AddSolicitacaoVagaEmpresaCCLotacao	8.0.11
20260411180000_AddSolicitacaoPromocaoEmpresaCCLotacao	8.0.11
20260411190000_AddTenantConfiguracaoAndAprovador3	8.0.11
20260411200000_AddEtapasConfigAprovacao	8.0.11
20260411210000_AddFuncionarioHasIncompleteData	8.0.11
20260411220000_AddAprovadoresAlternativos	8.0.11
20260412000000_AddUnidadeLotacaoCdnPlanoLotac	8.0.11
20260412120543_AddAcaoEtapaMomentoAcao	8.0.11
20260412164044_RemoveAprovador123LegacyFields	8.0.11
20260412190932_AddFluxoAprovacaoConfig	8.0.11
20260412203514_AddAssumedByUserIdToEtapa	8.0.11
20260412230635_AddVagaEscalaTrabalhoRaw	8.0.11
20260414220530_SyncUnidadeLotacaoOwnerCdnFields	8.0.11
20260415061909_AddHeadcountEOcupacaoHistorico	8.0.11
20260415064242_AddVagaIsEstrutural	8.0.11
20260415205828_AddPreAdmissaoExtendedFields	8.0.11
20260416001440_AddHeadcountProvisorioEAlertas	8.0.11
20260416131449_AddPreAdmissaoTotvsValidationFields	8.0.11
20260417021603_AddSlaAprovacao	8.0.11
20260417022158_AddPayRangeValidation	8.0.11
20260417023138_AddFuncionarioIdMaterializadoToPreAdmissao	8.0.11
20260417023850_AddIntegracaoRetry	8.0.11
20260417024711_AddIntegracaoSolicitacaoVaga	8.0.11
20260417025601_AddApprovalMagicLink	8.0.11
20260417030230_AddEntrevistasSaida	8.0.11
20260417032205_AddWorkflowAprovacaoEtapasETotvs	8.0.11
20260417040230_AddDemografiaFuncionario	8.0.11
20260417055819_AddHeadcountPendenteToVaga	8.0.11
20260417055846_AddDecisaoRHToSolicitacaoVaga	8.0.11
20260417183628_AddUnidadeLotacaoIdToTurno	8.0.11
20260417184430_AddParentIdToCentroCusto	8.0.11
20260417190548_AddDescricoesCargoEEixosVaga	8.0.11
20260417191704_AddAlcadaSalarialToVaga	8.0.11
20260417193103_AddPropostasVaga	8.0.11
20260417232606_AddCandidaturasJunction	8.0.11
20260417234013_AddDocumentacaoPadraoPorNivelCargo	8.0.11
20260417235310_AddNotificacaoCandidaturaLog	8.0.11
20260418000730_AddAvaliacaoCicloLifecycleFields	8.0.11
20260420150348_AddAvaliacaoConvocacoesECalibragem	8.0.11
20260420171030_AddCandidaturaIdToPropostaVaga	8.0.11
20260420181606_AddRegIdentidCivilToPreAdmissao	8.0.11
20260420184228_SyncCandidatoVagaIdFromCandidaturas	8.0.11
20260420185058_AddNotificacoesTemplatesTable	8.0.11
20260420190629_AddDocumentacaoPadraoHistoricosTable	8.0.11
20260420203209_AddDocumentacaoPadraoPorCargoTable	8.0.11
20260420204952_AddWhatsAppRateLimitAndIdiomaTemplate	8.0.11
20260422081055_AddEfetivacaoManualToIntegracoes	8.0.11
20260422083903_AlterFuncionarioIdNullableEmOcupacoesHistorico	8.0.11
20260422084526_AlterVagaIdNullableOcupacaoHistorico	8.0.11
20260422132016_AddVagaIdAndEmIntegracaoToPreAdmissao	8.0.11
20260422134021_AddPagamentoExtraEtapasWorkflow	8.0.11
20260422144536_AlterSolicitanteIdNullableNaSolicitacaoPagamentoExtra	8.0.11
20260423024358_AddHistoricoStatusAndSlaConfig	8.0.11
20260423123127_AddDatasToProjetoVaga	8.0.11
20260423144603_AddVinculoVagaDesligamento	8.0.11
20260423152745_AddTenantBrandingsAndExtendCentroCustoFields	8.0.11
20260423171014_ConsolidateAreaDepartmentIntoCentroCusto	8.0.11
20260423172318_AddCandidatoContratadoNaSolicitacaoVaga	8.0.11
20260423183343_AlterCnhDatasParaDateOnly	8.0.11
20260423193739_AddBlipNumeroHospedeiroNaTenantConfiguracao	8.0.11
20260423193925_RemoveRequisitoCategoria	8.0.11
20260423195519_AddCategoriaSalarialValorBaseEGradePercentual	8.0.11
20260423200255_RemoveAguardandoDecisaoRHAndAddPrazoDataAlvo	8.0.11
20260423204003_AddBlipApiUrlAndKeyNaTenantConfiguracao	8.0.11
20260423233755_AddDescricaoCargoDnalioGeocodingPesos	8.0.11
20260424125643_AddEmbeddingsPgvector	8.0.11
20260424162734_AddCandidatoVagaLlmScore	8.0.11
20260424165530_AddMotivoRequisicaoVagaConfig	8.0.11
20260424174957_AddCelularNaCandidato	8.0.11
20260210180000_AddCandidatoVagaMatchingScore	9.0.0
20260414100000_AddDocumentacaoPadraoConfig	9.0.0
20260211150000_BackfillCandidatosTenantId	9.0.0
20260211000000_VagaDepartmentIdOptional	9.0.0
20260317100000_AddCandidatoPretensaoSalarialELinkedin	9.0.0
20260129120000_AddVagaSlaFields	9.0.0
20260303190000_AddGamificationDailyStateAndIdempotency	9.0.0
20260324000000_AddCamposIntegracaoPreAdmissao	9.0.0
20260425135252_AddLlmProviderFieldsToTenantConfiguracao	8.0.11
20260426213012_AddHierarquiasTable	8.0.11
20260426213413_AddDesligamentosTable	8.0.11
20260426213702_AddMatriculaRmToFuncionario	8.0.11
20260426220514_AddHierarquiaIdToFuncionario	8.0.11
20260426221339_AddOrigemHierarquiaToVagas	8.0.11
20260426232740_AddCodSituacaoRmToFuncionario	8.0.11
20260426234231_AddDocumentosLuc122ToPessoa	8.0.11
20260426235201_AddFuncionarioMovimentacao	8.0.11
20260427004326_AddFiliacaoToPessoa	8.0.11
20260427014241_AddFuncaoRmToFuncionario	8.0.11
20260427022320_AddFuncaoRmToVaga	8.0.11
20260427135138_AddRmSyncRunsTable	8.0.11
20260427140901_AddRmSyncCheckpointAlertasAndZumbiFields	8.0.11
\.


--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."AspNetRoleClaims_Id_seq"', 1, false);


--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."AspNetUserClaims_Id_seq"', 1, false);


--
-- Name: MotivosRequisicaoVagaConfig MotivosRequisicaoVagaConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MotivosRequisicaoVagaConfig"
    ADD CONSTRAINT "MotivosRequisicaoVagaConfig_pkey" PRIMARY KEY ("Id");


--
-- Name: AgendaEventTypes PK_AgendaEventTypes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgendaEventTypes"
    ADD CONSTRAINT "PK_AgendaEventTypes" PRIMARY KEY ("Id");


--
-- Name: AgendaEvents PK_AgendaEvents; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgendaEvents"
    ADD CONSTRAINT "PK_AgendaEvents" PRIMARY KEY ("Id");


--
-- Name: ApiKeys PK_ApiKeys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ApiKeys"
    ADD CONSTRAINT "PK_ApiKeys" PRIMARY KEY ("Id");


--
-- Name: ApprovalMagicLinks PK_ApprovalMagicLinks; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ApprovalMagicLinks"
    ADD CONSTRAINT "PK_ApprovalMagicLinks" PRIMARY KEY ("Id");


--
-- Name: AprovacoesFaixaSalarial PK_AprovacoesFaixaSalarial; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "PK_AprovacoesFaixaSalarial" PRIMARY KEY ("Id");


--
-- Name: AprovadoresAlternativos PK_AprovadoresAlternativos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovadoresAlternativos"
    ADD CONSTRAINT "PK_AprovadoresAlternativos" PRIMARY KEY ("Id");


--
-- Name: AspNetRoleClaims PK_AspNetRoleClaims; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "PK_AspNetRoleClaims" PRIMARY KEY ("Id");


--
-- Name: AspNetUserClaims PK_AspNetUserClaims; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "PK_AspNetUserClaims" PRIMARY KEY ("Id");


--
-- Name: AspNetUserLogins PK_AspNetUserLogins; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "PK_AspNetUserLogins" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: AspNetUserTokens PK_AspNetUserTokens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "PK_AspNetUserTokens" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: AuditEntityChanges PK_AuditEntityChanges; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityChanges"
    ADD CONSTRAINT "PK_AuditEntityChanges" PRIMARY KEY ("Id");


--
-- Name: AuditEntityPropertyChanges PK_AuditEntityPropertyChanges; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityPropertyChanges"
    ADD CONSTRAINT "PK_AuditEntityPropertyChanges" PRIMARY KEY ("Id");


--
-- Name: AuditEvents PK_AuditEvents; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEvents"
    ADD CONSTRAINT "PK_AuditEvents" PRIMARY KEY ("Id");


--
-- Name: AuditTransactions PK_AuditTransactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditTransactions"
    ADD CONSTRAINT "PK_AuditTransactions" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoCalibragens PK_AvaliacaoCalibragens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "PK_AvaliacaoCalibragens" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoCiclos PK_AvaliacaoCiclos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCiclos"
    ADD CONSTRAINT "PK_AvaliacaoCiclos" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoConvites PK_AvaliacaoConvites; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "PK_AvaliacaoConvites" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoPerguntas PK_AvaliacaoPerguntas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoPerguntas"
    ADD CONSTRAINT "PK_AvaliacaoPerguntas" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoRespostas PK_AvaliacaoRespostas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "PK_AvaliacaoRespostas" PRIMARY KEY ("Id");


--
-- Name: BatchMatchingRunVagas PK_BatchMatchingRunVagas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BatchMatchingRunVagas"
    ADD CONSTRAINT "PK_BatchMatchingRunVagas" PRIMARY KEY ("Id");


--
-- Name: BatchMatchingRuns PK_BatchMatchingRuns; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BatchMatchingRuns"
    ADD CONSTRAINT "PK_BatchMatchingRuns" PRIMARY KEY ("Id");


--
-- Name: CamposPersonalizadosVaga PK_CamposPersonalizadosVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CamposPersonalizadosVaga"
    ADD CONSTRAINT "PK_CamposPersonalizadosVaga" PRIMARY KEY ("Id");


--
-- Name: CandidatoAcessibilidades PK_CandidatoAcessibilidades; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAcessibilidades"
    ADD CONSTRAINT "PK_CandidatoAcessibilidades" PRIMARY KEY ("Id");


--
-- Name: CandidatoAgendaBloqueios PK_CandidatoAgendaBloqueios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaBloqueios"
    ADD CONSTRAINT "PK_CandidatoAgendaBloqueios" PRIMARY KEY ("Id");


--
-- Name: CandidatoAgendaPreferencias PK_CandidatoAgendaPreferencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaPreferencias"
    ADD CONSTRAINT "PK_CandidatoAgendaPreferencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoCertificacoes PK_CandidatoCertificacoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCertificacoes"
    ADD CONSTRAINT "PK_CandidatoCertificacoes" PRIMARY KEY ("Id");


--
-- Name: CandidatoCompetencias PK_CandidatoCompetencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCompetencias"
    ADD CONSTRAINT "PK_CandidatoCompetencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoDocumentos PK_CandidatoDocumentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoDocumentos"
    ADD CONSTRAINT "PK_CandidatoDocumentos" PRIMARY KEY ("Id");


--
-- Name: CandidatoEducacaoItens PK_CandidatoEducacaoItens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoItens"
    ADD CONSTRAINT "PK_CandidatoEducacaoItens" PRIMARY KEY ("Id");


--
-- Name: CandidatoEducacaoResumos PK_CandidatoEducacaoResumos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoResumos"
    ADD CONSTRAINT "PK_CandidatoEducacaoResumos" PRIMARY KEY ("Id");


--
-- Name: CandidatoEmbeddings PK_CandidatoEmbeddings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEmbeddings"
    ADD CONSTRAINT "PK_CandidatoEmbeddings" PRIMARY KEY ("Id");


--
-- Name: CandidatoExperiencias PK_CandidatoExperiencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoExperiencias"
    ADD CONSTRAINT "PK_CandidatoExperiencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoLgpdConsents PK_CandidatoLgpdConsents; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoLgpdConsents"
    ADD CONSTRAINT "PK_CandidatoLgpdConsents" PRIMARY KEY ("Id");


--
-- Name: CandidatoNotificacaoPreferencias PK_CandidatoNotificacaoPreferencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoNotificacaoPreferencias"
    ADD CONSTRAINT "PK_CandidatoNotificacaoPreferencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoPortfolios PK_CandidatoPortfolios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPortfolios"
    ADD CONSTRAINT "PK_CandidatoPortfolios" PRIMARY KEY ("Id");


--
-- Name: CandidatoPreferenciasVaga PK_CandidatoPreferenciasVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPreferenciasVaga"
    ADD CONSTRAINT "PK_CandidatoPreferenciasVaga" PRIMARY KEY ("Id");


--
-- Name: CandidatoProjetos PK_CandidatoProjetos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoProjetos"
    ADD CONSTRAINT "PK_CandidatoProjetos" PRIMARY KEY ("Id");


--
-- Name: CandidatoReferencias PK_CandidatoReferencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoReferencias"
    ADD CONSTRAINT "PK_CandidatoReferencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoStatusHistories PK_CandidatoStatusHistories; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoStatusHistories"
    ADD CONSTRAINT "PK_CandidatoStatusHistories" PRIMARY KEY ("Id");


--
-- Name: CandidatoVagaLlmScores PK_CandidatoVagaLlmScores; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaLlmScores"
    ADD CONSTRAINT "PK_CandidatoVagaLlmScores" PRIMARY KEY ("Id");


--
-- Name: CandidatoVagaMatchingScores PK_CandidatoVagaMatchingScores; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaMatchingScores"
    ADD CONSTRAINT "PK_CandidatoVagaMatchingScores" PRIMARY KEY ("CandidatoId", "VagaId");


--
-- Name: Candidatos PK_Candidatos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidatos"
    ADD CONSTRAINT "PK_Candidatos" PRIMARY KEY ("Id");


--
-- Name: CandidaturaEtapaHistoricos PK_CandidaturaEtapaHistoricos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidaturaEtapaHistoricos"
    ADD CONSTRAINT "PK_CandidaturaEtapaHistoricos" PRIMARY KEY ("Id");


--
-- Name: Candidaturas PK_Candidaturas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidaturas"
    ADD CONSTRAINT "PK_Candidaturas" PRIMARY KEY ("Id");


--
-- Name: Cargos PK_Cargos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cargos"
    ADD CONSTRAINT "PK_Cargos" PRIMARY KEY ("Id");


--
-- Name: CategoriaSalarialSteps PK_CategoriaSalarialSteps; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriaSalarialSteps"
    ADD CONSTRAINT "PK_CategoriaSalarialSteps" PRIMARY KEY ("Id");


--
-- Name: CategoriasSalariais PK_CategoriasSalariais; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriasSalariais"
    ADD CONSTRAINT "PK_CategoriasSalariais" PRIMARY KEY ("Id");


--
-- Name: CelebrationCommentMentions PK_CelebrationCommentMentions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentMentions"
    ADD CONSTRAINT "PK_CelebrationCommentMentions" PRIMARY KEY ("Id");


--
-- Name: CelebrationCommentReactions PK_CelebrationCommentReactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentReactions"
    ADD CONSTRAINT "PK_CelebrationCommentReactions" PRIMARY KEY ("Id");


--
-- Name: CelebrationComments PK_CelebrationComments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationComments"
    ADD CONSTRAINT "PK_CelebrationComments" PRIMARY KEY ("Id");


--
-- Name: CelebrationMentions PK_CelebrationMentions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationMentions"
    ADD CONSTRAINT "PK_CelebrationMentions" PRIMARY KEY ("Id");


--
-- Name: CelebrationPosts PK_CelebrationPosts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationPosts"
    ADD CONSTRAINT "PK_CelebrationPosts" PRIMARY KEY ("Id");


--
-- Name: CentrosCusto PK_CentrosCusto; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "PK_CentrosCusto" PRIMARY KEY ("Id");


--
-- Name: DadosBancarios PK_DadosBancarios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DadosBancarios"
    ADD CONSTRAINT "PK_DadosBancarios" PRIMARY KEY ("Id");


--
-- Name: Dependentes PK_Dependentes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Dependentes"
    ADD CONSTRAINT "PK_Dependentes" PRIMARY KEY ("Id");


--
-- Name: DescricaoCargoItemEmbeddings PK_DescricaoCargoItemEmbeddings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItemEmbeddings"
    ADD CONSTRAINT "PK_DescricaoCargoItemEmbeddings" PRIMARY KEY ("Id");


--
-- Name: DescricaoCargoItens PK_DescricaoCargoItens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItens"
    ADD CONSTRAINT "PK_DescricaoCargoItens" PRIMARY KEY ("Id");


--
-- Name: DescricoesCargo PK_DescricoesCargo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricoesCargo"
    ADD CONSTRAINT "PK_DescricoesCargo" PRIMARY KEY ("Id");


--
-- Name: Desligamentos PK_Desligamentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Desligamentos"
    ADD CONSTRAINT "PK_Desligamentos" PRIMARY KEY ("Id");


--
-- Name: DevelopmentPlanGoals PK_DevelopmentPlanGoals; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlanGoals"
    ADD CONSTRAINT "PK_DevelopmentPlanGoals" PRIMARY KEY ("Id");


--
-- Name: DevelopmentPlans PK_DevelopmentPlans; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlans"
    ADD CONSTRAINT "PK_DevelopmentPlans" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoConfigs PK_DocumentacaoPadraoConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoConfigs"
    ADD CONSTRAINT "PK_DocumentacaoPadraoConfigs" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoHistoricos PK_DocumentacaoPadraoHistoricos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoHistoricos"
    ADD CONSTRAINT "PK_DocumentacaoPadraoHistoricos" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoPorCargoConfigs PK_DocumentacaoPadraoPorCargoConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorCargoConfigs"
    ADD CONSTRAINT "PK_DocumentacaoPadraoPorCargoConfigs" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoPorNivelCargoConfigs PK_DocumentacaoPadraoPorNivelCargoConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorNivelCargoConfigs"
    ADD CONSTRAINT "PK_DocumentacaoPadraoPorNivelCargoConfigs" PRIMARY KEY ("Id");


--
-- Name: DocumentosColaborador PK_DocumentosColaborador; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentosColaborador"
    ADD CONSTRAINT "PK_DocumentosColaborador" PRIMARY KEY ("Id");


--
-- Name: EixosVaga PK_EixosVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EixosVaga"
    ADD CONSTRAINT "PK_EixosVaga" PRIMARY KEY ("Id");


--
-- Name: EmailAttempts PK_EmailAttempts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailAttempts"
    ADD CONSTRAINT "PK_EmailAttempts" PRIMARY KEY ("Id");


--
-- Name: EmailConfigs PK_EmailConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailConfigs"
    ADD CONSTRAINT "PK_EmailConfigs" PRIMARY KEY ("Id");


--
-- Name: EmailMessages PK_EmailMessages; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailMessages"
    ADD CONSTRAINT "PK_EmailMessages" PRIMARY KEY ("Id");


--
-- Name: EmailTemplates PK_EmailTemplates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailTemplates"
    ADD CONSTRAINT "PK_EmailTemplates" PRIMARY KEY ("Id");


--
-- Name: Empresas PK_Empresas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Empresas"
    ADD CONSTRAINT "PK_Empresas" PRIMARY KEY ("Id");


--
-- Name: EntraIdConfigs PK_EntraIdConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EntraIdConfigs"
    ADD CONSTRAINT "PK_EntraIdConfigs" PRIMARY KEY ("Id");


--
-- Name: EntrevistasSaida PK_EntrevistasSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EntrevistasSaida"
    ADD CONSTRAINT "PK_EntrevistasSaida" PRIMARY KEY ("Id");


--
-- Name: EtapasConfigAprovacao PK_EtapasConfigAprovacao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigAprovacao"
    ADD CONSTRAINT "PK_EtapasConfigAprovacao" PRIMARY KEY ("Id");


--
-- Name: EtapasConfigWorkflowRH PK_EtapasConfigWorkflowRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigWorkflowRH"
    ADD CONSTRAINT "PK_EtapasConfigWorkflowRH" PRIMARY KEY ("Id");


--
-- Name: EtapasWorkflowRH PK_EtapasWorkflowRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasWorkflowRH"
    ADD CONSTRAINT "PK_EtapasWorkflowRH" PRIMARY KEY ("Id");


--
-- Name: ExceptionLogs PK_ExceptionLogs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ExceptionLogs"
    ADD CONSTRAINT "PK_ExceptionLogs" PRIMARY KEY ("Id");


--
-- Name: FaixasSalariais PK_FaixasSalariais; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FaixasSalariais"
    ADD CONSTRAINT "PK_FaixasSalariais" PRIMARY KEY ("Id");


--
-- Name: FasesProcesso PK_FasesProcesso; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FasesProcesso"
    ADD CONSTRAINT "PK_FasesProcesso" PRIMARY KEY ("Id");


--
-- Name: FeedbackItemRatings PK_FeedbackItemRatings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItemRatings"
    ADD CONSTRAINT "PK_FeedbackItemRatings" PRIMARY KEY ("Id");


--
-- Name: FeedbackItems PK_FeedbackItems; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItems"
    ADD CONSTRAINT "PK_FeedbackItems" PRIMARY KEY ("Id");


--
-- Name: FluxosAprovacaoConfig PK_FluxosAprovacaoConfig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FluxosAprovacaoConfig"
    ADD CONSTRAINT "PK_FluxosAprovacaoConfig" PRIMARY KEY ("Id");


--
-- Name: FuncionarioMovimentacoes PK_FuncionarioMovimentacoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FuncionarioMovimentacoes"
    ADD CONSTRAINT "PK_FuncionarioMovimentacoes" PRIMARY KEY ("Id");


--
-- Name: Funcionarios PK_Funcionarios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "PK_Funcionarios" PRIMARY KEY ("Id");


--
-- Name: GamificationDailyStates PK_GamificationDailyStates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GamificationDailyStates"
    ADD CONSTRAINT "PK_GamificationDailyStates" PRIMARY KEY ("Id");


--
-- Name: Hierarquias PK_Hierarquias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Hierarquias"
    ADD CONSTRAINT "PK_Hierarquias" PRIMARY KEY ("Id");


--
-- Name: HistoricosAlteracaoWorkflowRH PK_HistoricosAlteracaoWorkflowRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "PK_HistoricosAlteracaoWorkflowRH" PRIMARY KEY ("Id");


--
-- Name: HistoricosStatus PK_HistoricosStatus; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosStatus"
    ADD CONSTRAINT "PK_HistoricosStatus" PRIMARY KEY ("Id");


--
-- Name: Holerites PK_Holerites; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holerites"
    ADD CONSTRAINT "PK_Holerites" PRIMARY KEY ("Id");


--
-- Name: InboxAttachments PK_InboxAttachments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxAttachments"
    ADD CONSTRAINT "PK_InboxAttachments" PRIMARY KEY ("Id");


--
-- Name: InboxItems PK_InboxItems; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxItems"
    ADD CONSTRAINT "PK_InboxItems" PRIMARY KEY ("Id");


--
-- Name: JobPositions PK_JobPositions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "PK_JobPositions" PRIMARY KEY ("Id");


--
-- Name: LocalizationConfigs PK_LocalizationConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LocalizationConfigs"
    ADD CONSTRAINT "PK_LocalizationConfigs" PRIMARY KEY ("Id");


--
-- Name: LogEntries PK_LogEntries; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogEntries"
    ADD CONSTRAINT "PK_LogEntries" PRIMARY KEY ("Id");


--
-- Name: LogsComunicacao PK_LogsComunicacao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogsComunicacao"
    ADD CONSTRAINT "PK_LogsComunicacao" PRIMARY KEY ("Id");


--
-- Name: Menus PK_Menus; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Menus"
    ADD CONSTRAINT "PK_Menus" PRIMARY KEY ("Id");


--
-- Name: Metas PK_Metas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Metas"
    ADD CONSTRAINT "PK_Metas" PRIMARY KEY ("Id");


--
-- Name: MoodEntries PK_MoodEntries; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MoodEntries"
    ADD CONSTRAINT "PK_MoodEntries" PRIMARY KEY ("Id");


--
-- Name: NineBoxAssessments PK_NineBoxAssessments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "PK_NineBoxAssessments" PRIMARY KEY ("Id");


--
-- Name: NiveisCargo PK_NiveisCargo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NiveisCargo"
    ADD CONSTRAINT "PK_NiveisCargo" PRIMARY KEY ("Id");


--
-- Name: NiveisHierarquicos PK_NiveisHierarquicos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NiveisHierarquicos"
    ADD CONSTRAINT "PK_NiveisHierarquicos" PRIMARY KEY ("Id");


--
-- Name: NotificacoesCandidaturaLogs PK_NotificacoesCandidaturaLogs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificacoesCandidaturaLogs"
    ADD CONSTRAINT "PK_NotificacoesCandidaturaLogs" PRIMARY KEY ("Id");


--
-- Name: NotificacoesTemplates PK_NotificacoesTemplates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificacoesTemplates"
    ADD CONSTRAINT "PK_NotificacoesTemplates" PRIMARY KEY ("Id");


--
-- Name: NotificationReceipts PK_NotificationReceipts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificationReceipts"
    ADD CONSTRAINT "PK_NotificationReceipts" PRIMARY KEY ("Id");


--
-- Name: Notifications PK_Notifications; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "PK_Notifications" PRIMARY KEY ("Id");


--
-- Name: OcupacoesHistorico PK_OcupacoesHistorico; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OcupacoesHistorico"
    ADD CONSTRAINT "PK_OcupacoesHistorico" PRIMARY KEY ("Id");


--
-- Name: OneOnOneMeetings PK_OneOnOneMeetings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOnOneMeetings"
    ADD CONSTRAINT "PK_OneOnOneMeetings" PRIMARY KEY ("Id");


--
-- Name: PerguntasEntrevistaSaida PK_PerguntasEntrevistaSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PerguntasEntrevistaSaida"
    ADD CONSTRAINT "PK_PerguntasEntrevistaSaida" PRIMARY KEY ("Id");


--
-- Name: PermissoesNivelVaga PK_PermissoesNivelVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PermissoesNivelVaga"
    ADD CONSTRAINT "PK_PermissoesNivelVaga" PRIMARY KEY ("Id");


--
-- Name: PessoaBloqueios PK_PessoaBloqueios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PessoaBloqueios"
    ADD CONSTRAINT "PK_PessoaBloqueios" PRIMARY KEY ("Id");


--
-- Name: Pessoas PK_Pessoas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Pessoas"
    ADD CONSTRAINT "PK_Pessoas" PRIMARY KEY ("Id");


--
-- Name: PreAdmissaoDependentes PK_PreAdmissaoDependentes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDependentes"
    ADD CONSTRAINT "PK_PreAdmissaoDependentes" PRIMARY KEY ("Id");


--
-- Name: PreAdmissaoDocumentos PK_PreAdmissaoDocumentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentos"
    ADD CONSTRAINT "PK_PreAdmissaoDocumentos" PRIMARY KEY ("Id");


--
-- Name: PreAdmissaoDocumentosSolicitados PK_PreAdmissaoDocumentosSolicitados; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentosSolicitados"
    ADD CONSTRAINT "PK_PreAdmissaoDocumentosSolicitados" PRIMARY KEY ("Id");


--
-- Name: PreAdmissoes PK_PreAdmissoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "PK_PreAdmissoes" PRIMARY KEY ("Id");


--
-- Name: ProjetoCandidatos PK_ProjetoCandidatos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "PK_ProjetoCandidatos" PRIMARY KEY ("Id");


--
-- Name: ProjetosVaga PK_ProjetosVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetosVaga"
    ADD CONSTRAINT "PK_ProjetosVaga" PRIMARY KEY ("Id");


--
-- Name: PropostasVaga PK_PropostasVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "PK_PropostasVaga" PRIMARY KEY ("Id");


--
-- Name: RecruiterMatchingFeedbacks PK_RecruiterMatchingFeedbacks; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RecruiterMatchingFeedbacks"
    ADD CONSTRAINT "PK_RecruiterMatchingFeedbacks" PRIMARY KEY ("Id");


--
-- Name: RenderCoinBalances PK_RenderCoinBalances; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinBalances"
    ADD CONSTRAINT "PK_RenderCoinBalances" PRIMARY KEY ("TenantId", "UserId");


--
-- Name: RenderCoinTransactions PK_RenderCoinTransactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinTransactions"
    ADD CONSTRAINT "PK_RenderCoinTransactions" PRIMARY KEY ("Id");


--
-- Name: RequestLogs PK_RequestLogs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RequestLogs"
    ADD CONSTRAINT "PK_RequestLogs" PRIMARY KEY ("Id");


--
-- Name: RespostasCampoPersonalizadoVaga PK_RespostasCampoPersonalizadoVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "PK_RespostasCampoPersonalizadoVaga" PRIMARY KEY ("Id");


--
-- Name: RespostasEntrevistaSaida PK_RespostasEntrevistaSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasEntrevistaSaida"
    ADD CONSTRAINT "PK_RespostasEntrevistaSaida" PRIMARY KEY ("Id");


--
-- Name: RmSyncAlertas PK_RmSyncAlertas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RmSyncAlertas"
    ADD CONSTRAINT "PK_RmSyncAlertas" PRIMARY KEY ("Id");


--
-- Name: RmSyncCheckpoints PK_RmSyncCheckpoints; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RmSyncCheckpoints"
    ADD CONSTRAINT "PK_RmSyncCheckpoints" PRIMARY KEY ("Id");


--
-- Name: RmSyncRuns PK_RmSyncRuns; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RmSyncRuns"
    ADD CONSTRAINT "PK_RmSyncRuns" PRIMARY KEY ("Id");


--
-- Name: RoleMenus PK_RoleMenus; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RoleMenus"
    ADD CONSTRAINT "PK_RoleMenus" PRIMARY KEY ("Id");


--
-- Name: Roles PK_Roles; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "PK_Roles" PRIMARY KEY ("Id");


--
-- Name: SkillAliases PK_SkillAliases; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SkillAliases"
    ADD CONSTRAINT "PK_SkillAliases" PRIMARY KEY ("Id");


--
-- Name: Skills PK_Skills; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "PK_Skills" PRIMARY KEY ("Id");


--
-- Name: SlaStatusConfigs PK_SlaStatusConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SlaStatusConfigs"
    ADD CONSTRAINT "PK_SlaStatusConfigs" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesAprovacaoEtapas PK_SolicitacoesAprovacaoEtapas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesAprovacaoEtapas"
    ADD CONSTRAINT "PK_SolicitacoesAprovacaoEtapas" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesBeneficio PK_SolicitacoesBeneficio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesBeneficio"
    ADD CONSTRAINT "PK_SolicitacoesBeneficio" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesDependente PK_SolicitacoesDependente; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDependente"
    ADD CONSTRAINT "PK_SolicitacoesDependente" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesDesligamento PK_SolicitacoesDesligamento; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "PK_SolicitacoesDesligamento" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesEndereco PK_SolicitacoesEndereco; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesEndereco"
    ADD CONSTRAINT "PK_SolicitacoesEndereco" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesFerias PK_SolicitacoesFerias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesFerias"
    ADD CONSTRAINT "PK_SolicitacoesFerias" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesPagamentoExtra PK_SolicitacoesPagamentoExtra; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "PK_SolicitacoesPagamentoExtra" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesPromocao PK_SolicitacoesPromocao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "PK_SolicitacoesPromocao" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesVaga PK_SolicitacoesVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "PK_SolicitacoesVaga" PRIMARY KEY ("Id");


--
-- Name: SurveyAnswers PK_SurveyAnswers; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyAnswers"
    ADD CONSTRAINT "PK_SurveyAnswers" PRIMARY KEY ("Id");


--
-- Name: SurveyOptions PK_SurveyOptions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyOptions"
    ADD CONSTRAINT "PK_SurveyOptions" PRIMARY KEY ("Id");


--
-- Name: SurveyQuestions PK_SurveyQuestions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyQuestions"
    ADD CONSTRAINT "PK_SurveyQuestions" PRIMARY KEY ("Id");


--
-- Name: SurveyResponses PK_SurveyResponses; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyResponses"
    ADD CONSTRAINT "PK_SurveyResponses" PRIMARY KEY ("Id");


--
-- Name: Surveys PK_Surveys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Surveys"
    ADD CONSTRAINT "PK_Surveys" PRIMARY KEY ("Id");


--
-- Name: TalentoCompetencias PK_TalentoCompetencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCompetencias"
    ADD CONSTRAINT "PK_TalentoCompetencias" PRIMARY KEY ("Id");


--
-- Name: TalentoCvImportJobs PK_TalentoCvImportJobs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCvImportJobs"
    ADD CONSTRAINT "PK_TalentoCvImportJobs" PRIMARY KEY ("Id");


--
-- Name: TalentoDocumentos PK_TalentoDocumentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoDocumentos"
    ADD CONSTRAINT "PK_TalentoDocumentos" PRIMARY KEY ("Id");


--
-- Name: TalentoExperiencias PK_TalentoExperiencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoExperiencias"
    ADD CONSTRAINT "PK_TalentoExperiencias" PRIMARY KEY ("Id");


--
-- Name: TalentoFormacoes PK_TalentoFormacoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoFormacoes"
    ADD CONSTRAINT "PK_TalentoFormacoes" PRIMARY KEY ("Id");


--
-- Name: TalentoTreinamentos PK_TalentoTreinamentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoTreinamentos"
    ADD CONSTRAINT "PK_TalentoTreinamentos" PRIMARY KEY ("Id");


--
-- Name: Talentos PK_Talentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Talentos"
    ADD CONSTRAINT "PK_Talentos" PRIMARY KEY ("Id");


--
-- Name: TemplatesEntrevistaSaida PK_TemplatesEntrevistaSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TemplatesEntrevistaSaida"
    ADD CONSTRAINT "PK_TemplatesEntrevistaSaida" PRIMARY KEY ("Id");


--
-- Name: TenantAwsSettings PK_TenantAwsSettings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantAwsSettings"
    ADD CONSTRAINT "PK_TenantAwsSettings" PRIMARY KEY ("Id");


--
-- Name: TenantBrandings PK_TenantBrandings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantBrandings"
    ADD CONSTRAINT "PK_TenantBrandings" PRIMARY KEY ("Id");


--
-- Name: TenantConfiguracoes PK_TenantConfiguracoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantConfiguracoes"
    ADD CONSTRAINT "PK_TenantConfiguracoes" PRIMARY KEY ("Id");


--
-- Name: Turnos PK_Turnos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Turnos"
    ADD CONSTRAINT "PK_Turnos" PRIMARY KEY ("Id");


--
-- Name: UnidadesLotacao PK_UnidadesLotacao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UnidadesLotacao"
    ADD CONSTRAINT "PK_UnidadesLotacao" PRIMARY KEY ("Id");


--
-- Name: Units PK_Units; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Units"
    ADD CONSTRAINT "PK_Units" PRIMARY KEY ("Id");


--
-- Name: UserRoles PK_UserRoles; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "PK_UserRoles" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: UserUnits PK_UserUnits; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserUnits"
    ADD CONSTRAINT "PK_UserUnits" PRIMARY KEY ("UserId", "UnitId");


--
-- Name: Users PK_Users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_Users" PRIMARY KEY ("Id");


--
-- Name: VagaBeneficios PK_VagaBeneficios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaBeneficios"
    ADD CONSTRAINT "PK_VagaBeneficios" PRIMARY KEY ("Id");


--
-- Name: VagaEtapas PK_VagaEtapas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaEtapas"
    ADD CONSTRAINT "PK_VagaEtapas" PRIMARY KEY ("Id");


--
-- Name: VagaPerguntas PK_VagaPerguntas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaPerguntas"
    ADD CONSTRAINT "PK_VagaPerguntas" PRIMARY KEY ("Id");


--
-- Name: VagaRequisitos PK_VagaRequisitos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaRequisitos"
    ADD CONSTRAINT "PK_VagaRequisitos" PRIMARY KEY ("Id");


--
-- Name: VagaUnifiedMatchingCaches PK_VagaUnifiedMatchingCaches; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaUnifiedMatchingCaches"
    ADD CONSTRAINT "PK_VagaUnifiedMatchingCaches" PRIMARY KEY ("VagaId");


--
-- Name: Vagas PK_Vagas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "PK_Vagas" PRIMARY KEY ("Id");


--
-- Name: WorkflowsRH PK_WorkflowsRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "PK_WorkflowsRH" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "EmailIndex" ON public."Users" USING btree ("NormalizedEmail");


--
-- Name: IX_AgendaEventTypes_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AgendaEventTypes_TenantId_Code" ON public."AgendaEventTypes" USING btree ("TenantId", "Code");


--
-- Name: IX_AgendaEvents_TenantId_StartAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AgendaEvents_TenantId_StartAtUtc" ON public."AgendaEvents" USING btree ("TenantId", "StartAtUtc");


--
-- Name: IX_AgendaEvents_TypeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AgendaEvents_TypeId" ON public."AgendaEvents" USING btree ("TypeId");


--
-- Name: IX_ApiKeys_TenantId_KeyHash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ApiKeys_TenantId_KeyHash" ON public."ApiKeys" USING btree ("TenantId", "KeyHash");


--
-- Name: IX_ApiKeys_TenantId_Name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ApiKeys_TenantId_Name" ON public."ApiKeys" USING btree ("TenantId", "Name");


--
-- Name: IX_ApprovalMagicLinks_TenantId_Token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ApprovalMagicLinks_TenantId_Token" ON public."ApprovalMagicLinks" USING btree ("TenantId", "Token");


--
-- Name: IX_AprovacoesFaixaSalarial_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_AprovadorId" ON public."AprovacoesFaixaSalarial" USING btree ("AprovadorId");


--
-- Name: IX_AprovacoesFaixaSalarial_FaixaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_FaixaSalarialId" ON public."AprovacoesFaixaSalarial" USING btree ("FaixaSalarialId");


--
-- Name: IX_AprovacoesFaixaSalarial_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_SolicitanteId" ON public."AprovacoesFaixaSalarial" USING btree ("SolicitanteId");


--
-- Name: IX_AprovacoesFaixaSalarial_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_TenantId_Status" ON public."AprovacoesFaixaSalarial" USING btree ("TenantId", "Status");


--
-- Name: IX_AprovadoresAlternativos_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_AprovadorId" ON public."AprovadoresAlternativos" USING btree ("AprovadorId");


--
-- Name: IX_AprovadoresAlternativos_GestorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_GestorId" ON public."AprovadoresAlternativos" USING btree ("GestorId");


--
-- Name: IX_AprovadoresAlternativos_TenantGestor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_TenantGestor" ON public."AprovadoresAlternativos" USING btree ("TenantId", "GestorId");


--
-- Name: IX_AprovadoresAlternativos_TenantId_GestorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_TenantId_GestorId" ON public."AprovadoresAlternativos" USING btree ("TenantId", "GestorId");


--
-- Name: IX_AspNetRoleClaims_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AspNetRoleClaims_RoleId" ON public."AspNetRoleClaims" USING btree ("RoleId");


--
-- Name: IX_AspNetUserClaims_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AspNetUserClaims_UserId" ON public."AspNetUserClaims" USING btree ("UserId");


--
-- Name: IX_AspNetUserLogins_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AspNetUserLogins_UserId" ON public."AspNetUserLogins" USING btree ("UserId");


--
-- Name: IX_AuditEntityChanges_AuditEventId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_AuditEventId" ON public."AuditEntityChanges" USING btree ("AuditEventId");


--
-- Name: IX_AuditEntityChanges_AuditTransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_AuditTransactionId" ON public."AuditEntityChanges" USING btree ("AuditTransactionId");


--
-- Name: IX_AuditEntityChanges_TenantId_EntityName; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_TenantId_EntityName" ON public."AuditEntityChanges" USING btree ("TenantId", "EntityName");


--
-- Name: IX_AuditEntityChanges_TenantId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_TenantId_OccurredAt" ON public."AuditEntityChanges" USING btree ("TenantId", "OccurredAt");


--
-- Name: IX_AuditEntityPropertyChanges_AuditEntityChangeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityPropertyChanges_AuditEntityChangeId" ON public."AuditEntityPropertyChanges" USING btree ("AuditEntityChangeId");


--
-- Name: IX_AuditEvents_AuditTransactionId_Order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEvents_AuditTransactionId_Order" ON public."AuditEvents" USING btree ("AuditTransactionId", "Order");


--
-- Name: IX_AuditTransactions_Path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_Path" ON public."AuditTransactions" USING btree ("Path");


--
-- Name: IX_AuditTransactions_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_StartedAt" ON public."AuditTransactions" USING btree ("StartedAt");


--
-- Name: IX_AuditTransactions_StatusCode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_StatusCode" ON public."AuditTransactions" USING btree ("StatusCode");


--
-- Name: IX_AuditTransactions_TenantId_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_TenantId_StartedAt" ON public."AuditTransactions" USING btree ("TenantId", "StartedAt");


--
-- Name: IX_AuditTransactions_TransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AuditTransactions_TransactionId" ON public."AuditTransactions" USING btree ("TransactionId");


--
-- Name: IX_AuditTransactions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_UserId" ON public."AuditTransactions" USING btree ("UserId");


--
-- Name: IX_AvaliacaoCalibragens_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_CicloId" ON public."AvaliacaoCalibragens" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoCalibragens_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_FuncionarioId" ON public."AvaliacaoCalibragens" USING btree ("FuncionarioId");


--
-- Name: IX_AvaliacaoCalibragens_NineBoxAssessmentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_NineBoxAssessmentId" ON public."AvaliacaoCalibragens" USING btree ("NineBoxAssessmentId");


--
-- Name: IX_AvaliacaoCalibragens_TenantId_CicloId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AvaliacaoCalibragens_TenantId_CicloId_FuncionarioId" ON public."AvaliacaoCalibragens" USING btree ("TenantId", "CicloId", "FuncionarioId");


--
-- Name: IX_AvaliacaoCalibragens_TenantId_CicloId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_TenantId_CicloId_Status" ON public."AvaliacaoCalibragens" USING btree ("TenantId", "CicloId", "Status");


--
-- Name: IX_AvaliacaoCiclos_CriadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCiclos_CriadoPorId" ON public."AvaliacaoCiclos" USING btree ("CriadoPorId");


--
-- Name: IX_AvaliacaoCiclos_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCiclos_TenantId_Status" ON public."AvaliacaoCiclos" USING btree ("TenantId", "Status");


--
-- Name: IX_AvaliacaoConvites_AvaliadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_AvaliadorId" ON public."AvaliacaoConvites" USING btree ("AvaliadorId");


--
-- Name: IX_AvaliacaoConvites_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_AvaliandoId" ON public."AvaliacaoConvites" USING btree ("AvaliandoId");


--
-- Name: IX_AvaliacaoConvites_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_CicloId" ON public."AvaliacaoConvites" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoConvites_TenantId_AvaliadorId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_TenantId_AvaliadorId_Status" ON public."AvaliacaoConvites" USING btree ("TenantId", "AvaliadorId", "Status");


--
-- Name: IX_AvaliacaoConvites_TenantId_CicloId_AvaliadorId_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AvaliacaoConvites_TenantId_CicloId_AvaliadorId_AvaliandoId" ON public."AvaliacaoConvites" USING btree ("TenantId", "CicloId", "AvaliadorId", "AvaliandoId");


--
-- Name: IX_AvaliacaoConvites_TenantId_CicloId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_TenantId_CicloId_Status" ON public."AvaliacaoConvites" USING btree ("TenantId", "CicloId", "Status");


--
-- Name: IX_AvaliacaoPerguntas_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoPerguntas_CicloId" ON public."AvaliacaoPerguntas" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoRespostas_AvaliadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_AvaliadorId" ON public."AvaliacaoRespostas" USING btree ("AvaliadorId");


--
-- Name: IX_AvaliacaoRespostas_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_AvaliandoId" ON public."AvaliacaoRespostas" USING btree ("AvaliandoId");


--
-- Name: IX_AvaliacaoRespostas_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_CicloId" ON public."AvaliacaoRespostas" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoRespostas_TenantId_CicloId_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_TenantId_CicloId_AvaliandoId" ON public."AvaliacaoRespostas" USING btree ("TenantId", "CicloId", "AvaliandoId");


--
-- Name: IX_BatchMatchingRunVagas_RunId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_BatchMatchingRunVagas_RunId" ON public."BatchMatchingRunVagas" USING btree ("RunId");


--
-- Name: IX_BatchMatchingRuns_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_BatchMatchingRuns_TenantId_CreatedAtUtc" ON public."BatchMatchingRuns" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_CamposPersonalizadosVaga_TenantId_VagaId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CamposPersonalizadosVaga_TenantId_VagaId_Ordem" ON public."CamposPersonalizadosVaga" USING btree ("TenantId", "VagaId", "Ordem");


--
-- Name: IX_CamposPersonalizadosVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CamposPersonalizadosVaga_VagaId" ON public."CamposPersonalizadosVaga" USING btree ("VagaId");


--
-- Name: IX_CandidatoAcessibilidades_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoAcessibilidades_CandidatoId" ON public."CandidatoAcessibilidades" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoAcessibilidades_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoAcessibilidades_TenantId_CandidatoId" ON public."CandidatoAcessibilidades" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoAgendaBloqueios_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoAgendaBloqueios_CandidatoId" ON public."CandidatoAgendaBloqueios" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoAgendaBloqueios_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoAgendaBloqueios_TenantId_CandidatoId" ON public."CandidatoAgendaBloqueios" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoAgendaPreferencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoAgendaPreferencias_CandidatoId" ON public."CandidatoAgendaPreferencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoAgendaPreferencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoAgendaPreferencias_TenantId_CandidatoId" ON public."CandidatoAgendaPreferencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoCertificacoes_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCertificacoes_CandidatoId" ON public."CandidatoCertificacoes" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoCertificacoes_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCertificacoes_TenantId_CandidatoId" ON public."CandidatoCertificacoes" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoCompetencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCompetencias_CandidatoId" ON public."CandidatoCompetencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoCompetencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCompetencias_TenantId_CandidatoId" ON public."CandidatoCompetencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoDocumentos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoDocumentos_CandidatoId" ON public."CandidatoDocumentos" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoDocumentos_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoDocumentos_TenantId_CandidatoId" ON public."CandidatoDocumentos" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoEducacaoItens_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEducacaoItens_CandidatoId" ON public."CandidatoEducacaoItens" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoEducacaoItens_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEducacaoItens_TenantId_CandidatoId" ON public."CandidatoEducacaoItens" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoEducacaoResumos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEducacaoResumos_CandidatoId" ON public."CandidatoEducacaoResumos" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoEducacaoResumos_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoEducacaoResumos_TenantId_CandidatoId" ON public."CandidatoEducacaoResumos" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoEmbeddings_Ann; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEmbeddings_Ann" ON public."CandidatoEmbeddings" USING ivfflat ("Embedding" public.vector_cosine_ops) WITH (lists='100');


--
-- Name: IX_CandidatoEmbeddings_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEmbeddings_Candidato" ON public."CandidatoEmbeddings" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoEmbeddings_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEmbeddings_TenantId" ON public."CandidatoEmbeddings" USING btree ("TenantId");


--
-- Name: IX_CandidatoEmbeddings_Tenant_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoEmbeddings_Tenant_Candidato" ON public."CandidatoEmbeddings" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoExperiencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoExperiencias_CandidatoId" ON public."CandidatoExperiencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoExperiencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoExperiencias_TenantId_CandidatoId" ON public."CandidatoExperiencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoLgpdConsents_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoLgpdConsents_CandidatoId" ON public."CandidatoLgpdConsents" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoLgpdConsents_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoLgpdConsents_TenantId_CandidatoId" ON public."CandidatoLgpdConsents" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoNotificacaoPreferencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoNotificacaoPreferencias_CandidatoId" ON public."CandidatoNotificacaoPreferencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoNotificacaoPreferencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoNotificacaoPreferencias_TenantId_CandidatoId" ON public."CandidatoNotificacaoPreferencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoPortfolios_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoPortfolios_CandidatoId" ON public."CandidatoPortfolios" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoPortfolios_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoPortfolios_TenantId_CandidatoId" ON public."CandidatoPortfolios" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoPreferenciasVaga_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoPreferenciasVaga_CandidatoId" ON public."CandidatoPreferenciasVaga" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoPreferenciasVaga_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoPreferenciasVaga_TenantId_CandidatoId" ON public."CandidatoPreferenciasVaga" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoProjetos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoProjetos_CandidatoId" ON public."CandidatoProjetos" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoProjetos_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoProjetos_TenantId_CandidatoId" ON public."CandidatoProjetos" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoReferencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoReferencias_CandidatoId" ON public."CandidatoReferencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoReferencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoReferencias_TenantId_CandidatoId" ON public."CandidatoReferencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoStatusHistories_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoStatusHistories_CandidatoId" ON public."CandidatoStatusHistories" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoStatusHistories_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoStatusHistories_TenantId_CandidatoId" ON public."CandidatoStatusHistories" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoStatusHistories_TenantId_CandidatoId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoStatusHistories_TenantId_CandidatoId_CreatedAtUtc" ON public."CandidatoStatusHistories" USING btree ("TenantId", "CandidatoId", "CreatedAtUtc");


--
-- Name: IX_CandidatoVagaLlmScores_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaLlmScores_Candidato" ON public."CandidatoVagaLlmScores" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoVagaLlmScores_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaLlmScores_TenantId" ON public."CandidatoVagaLlmScores" USING btree ("TenantId");


--
-- Name: IX_CandidatoVagaLlmScores_Tenant_Vaga_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoVagaLlmScores_Tenant_Vaga_Candidato" ON public."CandidatoVagaLlmScores" USING btree ("TenantId", "VagaId", "CandidatoId");


--
-- Name: IX_CandidatoVagaLlmScores_Vaga; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaLlmScores_Vaga" ON public."CandidatoVagaLlmScores" USING btree ("VagaId");


--
-- Name: IX_CandidatoVagaMatchingScores_VagaId_Score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaMatchingScores_VagaId_Score" ON public."CandidatoVagaMatchingScores" USING btree ("VagaId", "Score");


--
-- Name: IX_Candidatos_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_TalentoId" ON public."Candidatos" USING btree ("TalentoId");


--
-- Name: IX_Candidatos_TenantId_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_TenantId_Email" ON public."Candidatos" USING btree ("TenantId", "Email");


--
-- Name: IX_Candidatos_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_TenantId_VagaId" ON public."Candidatos" USING btree ("TenantId", "VagaId");


--
-- Name: IX_Candidatos_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_VagaId" ON public."Candidatos" USING btree ("VagaId");


--
-- Name: IX_CandidaturaEtapaHistoricos_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidaturaEtapaHistoricos_CandidaturaId" ON public."CandidaturaEtapaHistoricos" USING btree ("CandidaturaId");


--
-- Name: IX_CandidaturaEtapaHistoricos_TenantId_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidaturaEtapaHistoricos_TenantId_CandidaturaId" ON public."CandidaturaEtapaHistoricos" USING btree ("TenantId", "CandidaturaId");


--
-- Name: IX_Candidaturas_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_CandidatoId" ON public."Candidaturas" USING btree ("CandidatoId");


--
-- Name: IX_Candidaturas_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_TenantId_CandidatoId" ON public."Candidaturas" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_Candidaturas_TenantId_CandidatoId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Candidaturas_TenantId_CandidatoId_VagaId" ON public."Candidaturas" USING btree ("TenantId", "CandidatoId", "VagaId");


--
-- Name: IX_Candidaturas_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_TenantId_VagaId" ON public."Candidaturas" USING btree ("TenantId", "VagaId");


--
-- Name: IX_Candidaturas_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_VagaId" ON public."Candidaturas" USING btree ("VagaId");


--
-- Name: IX_Cargos_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Cargos_IsActive" ON public."Cargos" USING btree ("IsActive");


--
-- Name: IX_Cargos_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Cargos_TenantId_Code" ON public."Cargos" USING btree ("TenantId", "Code");


--
-- Name: IX_CategoriaSalarialSteps_CategoriaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriaSalarialSteps_CategoriaSalarialId" ON public."CategoriaSalarialSteps" USING btree ("CategoriaSalarialId");


--
-- Name: IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId" ON public."CategoriaSalarialSteps" USING btree ("TenantId", "CategoriaSalarialId");


--
-- Name: IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId_Percentu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId_Percentu" ON public."CategoriaSalarialSteps" USING btree ("TenantId", "CategoriaSalarialId", "Percentual");


--
-- Name: IX_CategoriasSalariais_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriasSalariais_EmpresaId" ON public."CategoriasSalariais" USING btree ("EmpresaId");


--
-- Name: IX_CategoriasSalariais_EstabelecimentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriasSalariais_EstabelecimentoId" ON public."CategoriasSalariais" USING btree ("EstabelecimentoId");


--
-- Name: IX_CategoriasSalariais_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriasSalariais_IsActive" ON public."CategoriasSalariais" USING btree ("IsActive");


--
-- Name: IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Cod; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Cod" ON public."CategoriasSalariais" USING btree ("TenantId", "EmpresaId", "EstabelecimentoId", "Code") WHERE (("EmpresaId" IS NOT NULL) AND ("EstabelecimentoId" IS NOT NULL));


--
-- Name: IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Co~; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Co~" ON public."CategoriasSalariais" USING btree ("TenantId", "EmpresaId", "EstabelecimentoId", "Code") WHERE (("EmpresaId" IS NOT NULL) AND ("EstabelecimentoId" IS NOT NULL));


--
-- Name: IX_CelebrationCommentMentions_CommentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentMentions_CommentId" ON public."CelebrationCommentMentions" USING btree ("CommentId");


--
-- Name: IX_CelebrationCommentMentions_CommentId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CelebrationCommentMentions_CommentId_UserId" ON public."CelebrationCommentMentions" USING btree ("CommentId", "UserId");


--
-- Name: IX_CelebrationCommentMentions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentMentions_UserId" ON public."CelebrationCommentMentions" USING btree ("UserId");


--
-- Name: IX_CelebrationCommentReactions_CommentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentReactions_CommentId" ON public."CelebrationCommentReactions" USING btree ("CommentId");


--
-- Name: IX_CelebrationCommentReactions_CommentId_Type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentReactions_CommentId_Type" ON public."CelebrationCommentReactions" USING btree ("CommentId", "Type");


--
-- Name: IX_CelebrationCommentReactions_CommentId_UserId_Type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CelebrationCommentReactions_CommentId_UserId_Type" ON public."CelebrationCommentReactions" USING btree ("CommentId", "UserId", "Type");


--
-- Name: IX_CelebrationCommentReactions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentReactions_UserId" ON public."CelebrationCommentReactions" USING btree ("UserId");


--
-- Name: IX_CelebrationComments_AuthorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationComments_AuthorId" ON public."CelebrationComments" USING btree ("AuthorId");


--
-- Name: IX_CelebrationComments_PostId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationComments_PostId" ON public."CelebrationComments" USING btree ("PostId");


--
-- Name: IX_CelebrationComments_TenantId_PostId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationComments_TenantId_PostId_CreatedAtUtc" ON public."CelebrationComments" USING btree ("TenantId", "PostId", "CreatedAtUtc");


--
-- Name: IX_CelebrationMentions_PostId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationMentions_PostId" ON public."CelebrationMentions" USING btree ("PostId");


--
-- Name: IX_CelebrationMentions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationMentions_UserId" ON public."CelebrationMentions" USING btree ("UserId");


--
-- Name: IX_CelebrationPosts_AuthorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationPosts_AuthorId" ON public."CelebrationPosts" USING btree ("AuthorId");


--
-- Name: IX_CelebrationPosts_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationPosts_TenantId_CreatedAtUtc" ON public."CelebrationPosts" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_CentrosCusto_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_EmpresaId" ON public."CentrosCusto" USING btree ("EmpresaId");


--
-- Name: IX_CentrosCusto_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_IsActive" ON public."CentrosCusto" USING btree ("IsActive");


--
-- Name: IX_CentrosCusto_OwnerFuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_OwnerFuncionarioId" ON public."CentrosCusto" USING btree ("OwnerFuncionarioId");


--
-- Name: IX_CentrosCusto_ParentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_ParentId" ON public."CentrosCusto" USING btree ("ParentId");


--
-- Name: IX_CentrosCusto_TenantId_EmpresaId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CentrosCusto_TenantId_EmpresaId_Code" ON public."CentrosCusto" USING btree ("TenantId", "EmpresaId", "Code") WHERE ("EmpresaId" IS NOT NULL);


--
-- Name: IX_DadosBancarios_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DadosBancarios_FuncionarioId" ON public."DadosBancarios" USING btree ("FuncionarioId");


--
-- Name: IX_Dependentes_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Dependentes_FuncionarioId" ON public."Dependentes" USING btree ("FuncionarioId");


--
-- Name: IX_Dependentes_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Dependentes_TenantId_FuncionarioId" ON public."Dependentes" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_DescricaoCargoItemEmbeddings_Ann; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItemEmbeddings_Ann" ON public."DescricaoCargoItemEmbeddings" USING ivfflat ("Embedding" public.vector_cosine_ops) WITH (lists='100');


--
-- Name: IX_DescricaoCargoItemEmbeddings_Item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItemEmbeddings_Item" ON public."DescricaoCargoItemEmbeddings" USING btree ("DescricaoCargoItemId");


--
-- Name: IX_DescricaoCargoItemEmbeddings_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItemEmbeddings_TenantId" ON public."DescricaoCargoItemEmbeddings" USING btree ("TenantId");


--
-- Name: IX_DescricaoCargoItemEmbeddings_Tenant_Item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DescricaoCargoItemEmbeddings_Tenant_Item" ON public."DescricaoCargoItemEmbeddings" USING btree ("TenantId", "DescricaoCargoItemId");


--
-- Name: IX_DescricaoCargoItens_DescricaoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItens_DescricaoCargoId" ON public."DescricaoCargoItens" USING btree ("DescricaoCargoId");


--
-- Name: IX_DescricaoCargoItens_TenantId_DescricaoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItens_TenantId_DescricaoCargoId" ON public."DescricaoCargoItens" USING btree ("TenantId", "DescricaoCargoId");


--
-- Name: IX_DescricaoCargoItens_TenantId_DescricaoCargoId_Categoria; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItens_TenantId_DescricaoCargoId_Categoria" ON public."DescricaoCargoItens" USING btree ("TenantId", "DescricaoCargoId", "Categoria");


--
-- Name: IX_DescricoesCargo_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricoesCargo_IsActive" ON public."DescricoesCargo" USING btree ("IsActive");


--
-- Name: IX_DescricoesCargo_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricoesCargo_NivelCargoId" ON public."DescricoesCargo" USING btree ("NivelCargoId");


--
-- Name: IX_DescricoesCargo_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DescricoesCargo_TenantId_Code" ON public."DescricoesCargo" USING btree ("TenantId", "Code");


--
-- Name: IX_Desligamentos_ChapaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_ChapaRm" ON public."Desligamentos" USING btree ("ChapaRm");


--
-- Name: IX_Desligamentos_CodStatus; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_CodStatus" ON public."Desligamentos" USING btree ("CodStatus");


--
-- Name: IX_Desligamentos_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_FuncionarioId" ON public."Desligamentos" USING btree ("FuncionarioId");


--
-- Name: IX_Desligamentos_GerouSubstituicao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_GerouSubstituicao" ON public."Desligamentos" USING btree ("GerouSubstituicao");


--
-- Name: IX_Desligamentos_TenantId_IdReqRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Desligamentos_TenantId_IdReqRm" ON public."Desligamentos" USING btree ("TenantId", "IdReqRm");


--
-- Name: IX_DevelopmentPlanGoals_PlanId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlanGoals_PlanId" ON public."DevelopmentPlanGoals" USING btree ("PlanId");


--
-- Name: IX_DevelopmentPlans_OwnerUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_OwnerUserId" ON public."DevelopmentPlans" USING btree ("OwnerUserId");


--
-- Name: IX_DevelopmentPlans_TargetUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_TargetUserId" ON public."DevelopmentPlans" USING btree ("TargetUserId");


--
-- Name: IX_DevelopmentPlans_TenantId_OwnerUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_TenantId_OwnerUserId" ON public."DevelopmentPlans" USING btree ("TenantId", "OwnerUserId");


--
-- Name: IX_DevelopmentPlans_TenantId_TargetUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_TenantId_TargetUserId" ON public."DevelopmentPlans" USING btree ("TenantId", "TargetUserId");


--
-- Name: IX_DocumentacaoPadraoConfigs_TenantId_TipoDocumento; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DocumentacaoPadraoConfigs_TenantId_TipoDocumento" ON public."DocumentacaoPadraoConfigs" USING btree ("TenantId", "TipoDocumento");


--
-- Name: IX_DocumentacaoPadraoHistoricos_CargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_CargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("CargoId");


--
-- Name: IX_DocumentacaoPadraoHistoricos_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_NivelCargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoHistoricos_TenantId_CriadoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_TenantId_CriadoEmUtc" ON public."DocumentacaoPadraoHistoricos" USING btree ("TenantId", "CriadoEmUtc");


--
-- Name: IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_CargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_CargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("TenantId", "Escopo", "CargoId");


--
-- Name: IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_NivelCargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("TenantId", "Escopo", "NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoPorCargoConfigs_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorCargoConfigs_JobPositionId" ON public."DocumentacaoPadraoPorCargoConfigs" USING btree ("JobPositionId");


--
-- Name: IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId" ON public."DocumentacaoPadraoPorCargoConfigs" USING btree ("TenantId", "JobPositionId");


--
-- Name: IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId_Ti~; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId_Ti~" ON public."DocumentacaoPadraoPorCargoConfigs" USING btree ("TenantId", "JobPositionId", "TipoDocumento");


--
-- Name: IX_DocumentacaoPadraoPorNivelCargoConfigs_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorNivelCargoConfigs_NivelCargoId" ON public."DocumentacaoPadraoPorNivelCargoConfigs" USING btree ("NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoId" ON public."DocumentacaoPadraoPorNivelCargoConfigs" USING btree ("TenantId", "NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoI~; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoI~" ON public."DocumentacaoPadraoPorNivelCargoConfigs" USING btree ("TenantId", "NivelCargoId", "TipoDocumento");


--
-- Name: IX_DocumentosColaborador_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentosColaborador_FuncionarioId" ON public."DocumentosColaborador" USING btree ("FuncionarioId");


--
-- Name: IX_DocumentosColaborador_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentosColaborador_TenantId_FuncionarioId" ON public."DocumentosColaborador" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_EixosVaga_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EixosVaga_IsActive" ON public."EixosVaga" USING btree ("IsActive");


--
-- Name: IX_EixosVaga_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EixosVaga_TenantId_Code" ON public."EixosVaga" USING btree ("TenantId", "Code");


--
-- Name: IX_EmailAttempts_EmailMessageId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailAttempts_EmailMessageId" ON public."EmailAttempts" USING btree ("EmailMessageId");


--
-- Name: IX_EmailAttempts_TenantId_EmailMessageId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailAttempts_TenantId_EmailMessageId" ON public."EmailAttempts" USING btree ("TenantId", "EmailMessageId");


--
-- Name: IX_EmailAttempts_TenantId_StartedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailAttempts_TenantId_StartedAtUtc" ON public."EmailAttempts" USING btree ("TenantId", "StartedAtUtc");


--
-- Name: IX_EmailConfigs_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EmailConfigs_TenantId" ON public."EmailConfigs" USING btree ("TenantId");


--
-- Name: IX_EmailMessages_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_CreatedAtUtc" ON public."EmailMessages" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_EmailMessages_TenantId_IsSystem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_IsSystem" ON public."EmailMessages" USING btree ("TenantId", "IsSystem");


--
-- Name: IX_EmailMessages_TenantId_OwnerUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_OwnerUserId" ON public."EmailMessages" USING btree ("TenantId", "OwnerUserId");


--
-- Name: IX_EmailMessages_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_Status" ON public."EmailMessages" USING btree ("TenantId", "Status");


--
-- Name: IX_EmailTemplates_TenantId_Name_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailTemplates_TenantId_Name_IsActive" ON public."EmailTemplates" USING btree ("TenantId", "Name", "IsActive");


--
-- Name: IX_EmailTemplates_TenantId_Name_Version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailTemplates_TenantId_Name_Version" ON public."EmailTemplates" USING btree ("TenantId", "Name", "Version");


--
-- Name: IX_Empresas_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Empresas_TenantId_Code" ON public."Empresas" USING btree ("TenantId", "Code");


--
-- Name: IX_EntraIdConfigs_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EntraIdConfigs_TenantId" ON public."EntraIdConfigs" USING btree ("TenantId");


--
-- Name: IX_EntrevistasSaida_TenantId_DesligamentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EntrevistasSaida_TenantId_DesligamentoId" ON public."EntrevistasSaida" USING btree ("TenantId", "DesligamentoId");


--
-- Name: IX_EntrevistasSaida_TenantId_Token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EntrevistasSaida_TenantId_Token" ON public."EntrevistasSaida" USING btree ("TenantId", "Token");


--
-- Name: IX_EtapasConfigAprovacao_FuncionarioFixoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasConfigAprovacao_FuncionarioFixoId" ON public."EtapasConfigAprovacao" USING btree ("FuncionarioFixoId");


--
-- Name: IX_EtapasConfigAprovacao_RoleFilaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasConfigAprovacao_RoleFilaId" ON public."EtapasConfigAprovacao" USING btree ("RoleFilaId");


--
-- Name: IX_EtapasConfigAprovacao_TenantId_TipoFluxo_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EtapasConfigAprovacao_TenantId_TipoFluxo_Ordem" ON public."EtapasConfigAprovacao" USING btree ("TenantId", "TipoFluxo", "Ordem");


--
-- Name: IX_EtapasConfigWorkflowRH_RoleFilaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasConfigWorkflowRH_RoleFilaId" ON public."EtapasConfigWorkflowRH" USING btree ("RoleFilaId");


--
-- Name: IX_EtapasConfigWorkflowRH_TenantId_TipoWorkflow_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EtapasConfigWorkflowRH_TenantId_TipoWorkflow_Ordem" ON public."EtapasConfigWorkflowRH" USING btree ("TenantId", "TipoWorkflow", "Ordem");


--
-- Name: IX_EtapasWorkflowRH_ResponsavelId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasWorkflowRH_ResponsavelId" ON public."EtapasWorkflowRH" USING btree ("ResponsavelId");


--
-- Name: IX_EtapasWorkflowRH_WorkflowId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasWorkflowRH_WorkflowId_Ordem" ON public."EtapasWorkflowRH" USING btree ("WorkflowId", "Ordem");


--
-- Name: IX_ExceptionLogs_TenantId_DeviceId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_DeviceId_OccurredAt" ON public."ExceptionLogs" USING btree ("TenantId", "DeviceId", "OccurredAt");


--
-- Name: IX_ExceptionLogs_TenantId_EnvironmentNormalized_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_EnvironmentNormalized_OccurredAt" ON public."ExceptionLogs" USING btree ("TenantId", "EnvironmentNormalized", "OccurredAt");


--
-- Name: IX_ExceptionLogs_TenantId_ExceptionType; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_ExceptionType" ON public."ExceptionLogs" USING btree ("TenantId", "ExceptionType");


--
-- Name: IX_ExceptionLogs_TenantId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_OccurredAt" ON public."ExceptionLogs" USING btree ("TenantId", "OccurredAt");


--
-- Name: IX_ExceptionLogs_TenantId_StatusCode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_StatusCode" ON public."ExceptionLogs" USING btree ("TenantId", "StatusCode");


--
-- Name: IX_ExceptionLogs_TenantId_TransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_TransactionId" ON public."ExceptionLogs" USING btree ("TenantId", "TransactionId");


--
-- Name: IX_FaixasSalariais_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FaixasSalariais_JobPositionId" ON public."FaixasSalariais" USING btree ("JobPositionId");


--
-- Name: IX_FaixasSalariais_TenantId_JobPositionId_EstabelecimentoCodigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FaixasSalariais_TenantId_JobPositionId_EstabelecimentoCodigo" ON public."FaixasSalariais" USING btree ("TenantId", "JobPositionId", "EstabelecimentoCodigo");


--
-- Name: IX_FasesProcesso_ProjetoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FasesProcesso_ProjetoId" ON public."FasesProcesso" USING btree ("ProjetoId");


--
-- Name: IX_FasesProcesso_TenantId_ProjetoId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FasesProcesso_TenantId_ProjetoId_Ordem" ON public."FasesProcesso" USING btree ("TenantId", "ProjetoId", "Ordem");


--
-- Name: IX_FeedbackItemRatings_FeedbackItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItemRatings_FeedbackItemId" ON public."FeedbackItemRatings" USING btree ("FeedbackItemId");


--
-- Name: IX_FeedbackItems_FromUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_FromUserId" ON public."FeedbackItems" USING btree ("FromUserId");


--
-- Name: IX_FeedbackItems_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_TenantId_CreatedAtUtc" ON public."FeedbackItems" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_FeedbackItems_TenantId_FromUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_TenantId_FromUserId" ON public."FeedbackItems" USING btree ("TenantId", "FromUserId");


--
-- Name: IX_FeedbackItems_TenantId_ToUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_TenantId_ToUserId" ON public."FeedbackItems" USING btree ("TenantId", "ToUserId");


--
-- Name: IX_FeedbackItems_ToUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_ToUserId" ON public."FeedbackItems" USING btree ("ToUserId");


--
-- Name: IX_FluxosAprovacaoConfig_TenantId_TipoFluxo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_FluxosAprovacaoConfig_TenantId_TipoFluxo" ON public."FluxosAprovacaoConfig" USING btree ("TenantId", "TipoFluxo");


--
-- Name: IX_FuncionarioMovimentacoes_ChapaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FuncionarioMovimentacoes_ChapaRm" ON public."FuncionarioMovimentacoes" USING btree ("ChapaRm");


--
-- Name: IX_FuncionarioMovimentacoes_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FuncionarioMovimentacoes_FuncionarioId" ON public."FuncionarioMovimentacoes" USING btree ("FuncionarioId");


--
-- Name: IX_FuncionarioMovimentacoes_TenantId_IdReqRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_FuncionarioMovimentacoes_TenantId_IdReqRm" ON public."FuncionarioMovimentacoes" USING btree ("TenantId", "IdReqRm");


--
-- Name: IX_FuncionarioMovimentacoes_TipoMovimentacao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FuncionarioMovimentacoes_TipoMovimentacao" ON public."FuncionarioMovimentacoes" USING btree ("TipoMovimentacao");


--
-- Name: IX_Funcionarios_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_CentroCustoId" ON public."Funcionarios" USING btree ("CentroCustoId");


--
-- Name: IX_Funcionarios_GestorDiretoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_GestorDiretoId" ON public."Funcionarios" USING btree ("GestorDiretoId");


--
-- Name: IX_Funcionarios_HierarquiaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_HierarquiaId" ON public."Funcionarios" USING btree ("HierarquiaId");


--
-- Name: IX_Funcionarios_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_JobPositionId" ON public."Funcionarios" USING btree ("JobPositionId");


--
-- Name: IX_Funcionarios_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_NivelCargoId" ON public."Funcionarios" USING btree ("NivelCargoId");


--
-- Name: IX_Funcionarios_NivelHierarquicoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_NivelHierarquicoId" ON public."Funcionarios" USING btree ("NivelHierarquicoId");


--
-- Name: IX_Funcionarios_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_PessoaId" ON public."Funcionarios" USING btree ("PessoaId");


--
-- Name: IX_Funcionarios_TenantId_CdnEmpresa_CdnEstab_CdnFuncionario; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Funcionarios_TenantId_CdnEmpresa_CdnEstab_CdnFuncionario" ON public."Funcionarios" USING btree ("TenantId", "CdnEmpresa", "CdnEstab", "CdnFuncionario") WHERE ("CdnFuncionario" IS NOT NULL);


--
-- Name: IX_Funcionarios_TenantId_CodSituacaoRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_TenantId_CodSituacaoRm" ON public."Funcionarios" USING btree ("TenantId", "CodSituacaoRm");


--
-- Name: IX_Funcionarios_TenantId_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_TenantId_Email" ON public."Funcionarios" USING btree ("TenantId", "Email") WHERE ("Email" IS NOT NULL);


--
-- Name: IX_Funcionarios_TenantId_MatriculaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_TenantId_MatriculaRm" ON public."Funcionarios" USING btree ("TenantId", "MatriculaRm");


--
-- Name: IX_Funcionarios_UnidadeLotacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_UnidadeLotacaoId" ON public."Funcionarios" USING btree ("UnidadeLotacaoId");


--
-- Name: IX_Funcionarios_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_UnitId" ON public."Funcionarios" USING btree ("UnitId");


--
-- Name: IX_Funcionarios_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_UserId" ON public."Funcionarios" USING btree ("UserId");


--
-- Name: IX_GamificationDailyStates_TenantId_LastCheckInDate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_GamificationDailyStates_TenantId_LastCheckInDate" ON public."GamificationDailyStates" USING btree ("TenantId", "LastCheckInDate");


--
-- Name: IX_GamificationDailyStates_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_GamificationDailyStates_TenantId_UserId" ON public."GamificationDailyStates" USING btree ("TenantId", "UserId");


--
-- Name: IX_GamificationDailyStates_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_GamificationDailyStates_UserId" ON public."GamificationDailyStates" USING btree ("UserId");


--
-- Name: IX_Hierarquias_Estrutura; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Hierarquias_Estrutura" ON public."Hierarquias" USING btree ("Estrutura");


--
-- Name: IX_Hierarquias_HierarquiaSuperiorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Hierarquias_HierarquiaSuperiorId" ON public."Hierarquias" USING btree ("HierarquiaSuperiorId");


--
-- Name: IX_Hierarquias_IdHierarquiaSuperiorRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Hierarquias_IdHierarquiaSuperiorRm" ON public."Hierarquias" USING btree ("IdHierarquiaSuperiorRm");


--
-- Name: IX_Hierarquias_TenantId_IdHierarquiaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Hierarquias_TenantId_IdHierarquiaRm" ON public."Hierarquias" USING btree ("TenantId", "IdHierarquiaRm");


--
-- Name: IX_HistoricosAlteracaoWorkflowRH_AlteradoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosAlteracaoWorkflowRH_AlteradoPorId" ON public."HistoricosAlteracaoWorkflowRH" USING btree ("AlteradoPorId");


--
-- Name: IX_HistoricosAlteracaoWorkflowRH_EtapaWorkflowId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosAlteracaoWorkflowRH_EtapaWorkflowId" ON public."HistoricosAlteracaoWorkflowRH" USING btree ("EtapaWorkflowId");


--
-- Name: IX_HistoricosAlteracaoWorkflowRH_WorkflowId_DataAlteracaoUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosAlteracaoWorkflowRH_WorkflowId_DataAlteracaoUtc" ON public."HistoricosAlteracaoWorkflowRH" USING btree ("WorkflowId", "DataAlteracaoUtc");


--
-- Name: IX_HistoricosStatus_TenantId_AlteradoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_AlteradoEmUtc" ON public."HistoricosStatus" USING btree ("TenantId", "AlteradoEmUtc");


--
-- Name: IX_HistoricosStatus_TenantId_TipoEntidade_DentroDoSla; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_TipoEntidade_DentroDoSla" ON public."HistoricosStatus" USING btree ("TenantId", "TipoEntidade", "DentroDoSla");


--
-- Name: IX_HistoricosStatus_TenantId_TipoEntidade_EntidadeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_TipoEntidade_EntidadeId" ON public."HistoricosStatus" USING btree ("TenantId", "TipoEntidade", "EntidadeId");


--
-- Name: IX_HistoricosStatus_TenantId_TipoEntidade_StatusNovo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_TipoEntidade_StatusNovo" ON public."HistoricosStatus" USING btree ("TenantId", "TipoEntidade", "StatusNovo");


--
-- Name: IX_Holerites_EnviadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Holerites_EnviadoPorId" ON public."Holerites" USING btree ("EnviadoPorId");


--
-- Name: IX_Holerites_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Holerites_FuncionarioId" ON public."Holerites" USING btree ("FuncionarioId");


--
-- Name: IX_InboxAttachments_InboxItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxAttachments_InboxItemId" ON public."InboxAttachments" USING btree ("InboxItemId");


--
-- Name: IX_InboxAttachments_TenantId_InboxItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxAttachments_TenantId_InboxItemId" ON public."InboxAttachments" USING btree ("TenantId", "InboxItemId");


--
-- Name: IX_InboxItems_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_CandidatoId" ON public."InboxItems" USING btree ("CandidatoId");


--
-- Name: IX_InboxItems_TenantId_Origem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_TenantId_Origem" ON public."InboxItems" USING btree ("TenantId", "Origem");


--
-- Name: IX_InboxItems_TenantId_RecebidoEm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_TenantId_RecebidoEm" ON public."InboxItems" USING btree ("TenantId", "RecebidoEm");


--
-- Name: IX_InboxItems_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_TenantId_Status" ON public."InboxItems" USING btree ("TenantId", "Status");


--
-- Name: IX_InboxItems_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_VagaId" ON public."InboxItems" USING btree ("VagaId");


--
-- Name: IX_JobPositions_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_JobPositions_CentroCustoId" ON public."JobPositions" USING btree ("CentroCustoId");


--
-- Name: IX_JobPositions_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_JobPositions_NivelCargoId" ON public."JobPositions" USING btree ("NivelCargoId");


--
-- Name: IX_JobPositions_NivelHierarquicoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_JobPositions_NivelHierarquicoId" ON public."JobPositions" USING btree ("NivelHierarquicoId");


--
-- Name: IX_JobPositions_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_JobPositions_TenantId_Code" ON public."JobPositions" USING btree ("TenantId", "Code");


--
-- Name: IX_JobPositions_TenantId_TotvsCargoBasicId_TotvsNivCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_JobPositions_TenantId_TotvsCargoBasicId_TotvsNivCargoId" ON public."JobPositions" USING btree ("TenantId", "TotvsCargoBasicId", "TotvsNivCargoId") WHERE (("TotvsCargoBasicId" IS NOT NULL) AND ("TotvsNivCargoId" IS NOT NULL));


--
-- Name: IX_LocalizationConfigs_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_LocalizationConfigs_TenantId" ON public."LocalizationConfigs" USING btree ("TenantId");


--
-- Name: IX_LogEntries_RequestLogId_Order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_RequestLogId_Order" ON public."LogEntries" USING btree ("RequestLogId", "Order");


--
-- Name: IX_LogEntries_TenantId_Category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_Category" ON public."LogEntries" USING btree ("TenantId", "Category");


--
-- Name: IX_LogEntries_TenantId_DeviceId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_DeviceId_OccurredAt" ON public."LogEntries" USING btree ("TenantId", "DeviceId", "OccurredAt");


--
-- Name: IX_LogEntries_TenantId_EnvironmentNormalized_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_EnvironmentNormalized_OccurredAt" ON public."LogEntries" USING btree ("TenantId", "EnvironmentNormalized", "OccurredAt");


--
-- Name: IX_LogEntries_TenantId_Level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_Level" ON public."LogEntries" USING btree ("TenantId", "Level");


--
-- Name: IX_LogEntries_TenantId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_OccurredAt" ON public."LogEntries" USING btree ("TenantId", "OccurredAt");


--
-- Name: IX_LogsComunicacao_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogsComunicacao_CandidatoId" ON public."LogsComunicacao" USING btree ("CandidatoId");


--
-- Name: IX_LogsComunicacao_ProjetoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogsComunicacao_ProjetoId" ON public."LogsComunicacao" USING btree ("ProjetoId");


--
-- Name: IX_LogsComunicacao_TenantId_CandidatoId_DataUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogsComunicacao_TenantId_CandidatoId_DataUtc" ON public."LogsComunicacao" USING btree ("TenantId", "CandidatoId", "DataUtc");


--
-- Name: IX_Menus_TenantId_PermissionKey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Menus_TenantId_PermissionKey" ON public."Menus" USING btree ("TenantId", "PermissionKey");


--
-- Name: IX_Menus_TenantId_Route; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Menus_TenantId_Route" ON public."Menus" USING btree ("TenantId", "Route");


--
-- Name: IX_Metas_CriadaPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_CriadaPorId" ON public."Metas" USING btree ("CriadaPorId");


--
-- Name: IX_Metas_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_FuncionarioId" ON public."Metas" USING btree ("FuncionarioId");


--
-- Name: IX_Metas_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_TenantId_FuncionarioId" ON public."Metas" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_Metas_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_TenantId_Status" ON public."Metas" USING btree ("TenantId", "Status");


--
-- Name: IX_MoodEntries_TenantId_UserId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_MoodEntries_TenantId_UserId_CreatedAtUtc" ON public."MoodEntries" USING btree ("TenantId", "UserId", "CreatedAtUtc");


--
-- Name: IX_MoodEntries_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_MoodEntries_UserId" ON public."MoodEntries" USING btree ("UserId");


--
-- Name: IX_MotivosRequisicaoVagaConfig_TenantId_Codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_MotivosRequisicaoVagaConfig_TenantId_Codigo" ON public."MotivosRequisicaoVagaConfig" USING btree ("TenantId", "Codigo");


--
-- Name: IX_MotivosRequisicaoVagaConfig_TenantId_IsActive_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_MotivosRequisicaoVagaConfig_TenantId_IsActive_Ordem" ON public."MotivosRequisicaoVagaConfig" USING btree ("TenantId", "IsActive", "Ordem");


--
-- Name: IX_NineBoxAssessments_AvaliadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_AvaliadorId" ON public."NineBoxAssessments" USING btree ("AvaliadorId");


--
-- Name: IX_NineBoxAssessments_CicloAvaliacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_CicloAvaliacaoId" ON public."NineBoxAssessments" USING btree ("CicloAvaliacaoId");


--
-- Name: IX_NineBoxAssessments_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_FuncionarioId" ON public."NineBoxAssessments" USING btree ("FuncionarioId");


--
-- Name: IX_NineBoxAssessments_TenantId_CicloAvaliacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_TenantId_CicloAvaliacaoId" ON public."NineBoxAssessments" USING btree ("TenantId", "CicloAvaliacaoId");


--
-- Name: IX_NineBoxAssessments_TenantId_CriadoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_TenantId_CriadoEmUtc" ON public."NineBoxAssessments" USING btree ("TenantId", "CriadoEmUtc");


--
-- Name: IX_NineBoxAssessments_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_TenantId_FuncionarioId" ON public."NineBoxAssessments" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_NiveisHierarquicos_TenantId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NiveisHierarquicos_TenantId_Ordem" ON public."NiveisHierarquicos" USING btree ("TenantId", "Ordem");


--
-- Name: IX_NotificacoesCandidaturaLogs_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificacoesCandidaturaLogs_TenantId_CandidatoId" ON public."NotificacoesCandidaturaLogs" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_NotificacoesCandidaturaLogs_TenantId_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificacoesCandidaturaLogs_TenantId_CandidaturaId" ON public."NotificacoesCandidaturaLogs" USING btree ("TenantId", "CandidaturaId");


--
-- Name: IX_NotificacoesTemplates_TenantId_Etapa_Canal_Idioma; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_NotificacoesTemplates_TenantId_Etapa_Canal_Idioma" ON public."NotificacoesTemplates" USING btree ("TenantId", "Etapa", "Canal", "Idioma");


--
-- Name: IX_NotificationReceipts_TenantId_NotificationId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificationReceipts_TenantId_NotificationId" ON public."NotificationReceipts" USING btree ("TenantId", "NotificationId");


--
-- Name: IX_NotificationReceipts_TenantId_NotificationId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_NotificationReceipts_TenantId_NotificationId_UserId" ON public."NotificationReceipts" USING btree ("TenantId", "NotificationId", "UserId");


--
-- Name: IX_NotificationReceipts_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificationReceipts_TenantId_UserId" ON public."NotificationReceipts" USING btree ("TenantId", "UserId");


--
-- Name: IX_Notifications_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_TenantId_CreatedAtUtc" ON public."Notifications" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_Notifications_TenantId_IsRead; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_TenantId_IsRead" ON public."Notifications" USING btree ("TenantId", "IsRead");


--
-- Name: IX_Notifications_TenantId_UserId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_TenantId_UserId_CreatedAtUtc" ON public."Notifications" USING btree ("TenantId", "UserId", "CreatedAtUtc");


--
-- Name: IX_Notifications_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_UserId" ON public."Notifications" USING btree ("UserId");


--
-- Name: IX_OcupacoesHistorico_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_FuncionarioId" ON public."OcupacoesHistorico" USING btree ("FuncionarioId");


--
-- Name: IX_OcupacoesHistorico_TenantId_FuncionarioId_DataSaida; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_TenantId_FuncionarioId_DataSaida" ON public."OcupacoesHistorico" USING btree ("TenantId", "FuncionarioId", "DataSaida");


--
-- Name: IX_OcupacoesHistorico_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_TenantId_VagaId" ON public."OcupacoesHistorico" USING btree ("TenantId", "VagaId");


--
-- Name: IX_OcupacoesHistorico_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_VagaId" ON public."OcupacoesHistorico" USING btree ("VagaId");


--
-- Name: IX_OneOnOneMeetings_CollaboratorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_CollaboratorId" ON public."OneOnOneMeetings" USING btree ("CollaboratorId");


--
-- Name: IX_OneOnOneMeetings_ManagerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_ManagerId" ON public."OneOnOneMeetings" USING btree ("ManagerId");


--
-- Name: IX_OneOnOneMeetings_TenantId_CollaboratorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_TenantId_CollaboratorId" ON public."OneOnOneMeetings" USING btree ("TenantId", "CollaboratorId");


--
-- Name: IX_OneOnOneMeetings_TenantId_ManagerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_TenantId_ManagerId" ON public."OneOnOneMeetings" USING btree ("TenantId", "ManagerId");


--
-- Name: IX_OneOnOneMeetings_TenantId_MeetingDate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_TenantId_MeetingDate" ON public."OneOnOneMeetings" USING btree ("TenantId", "MeetingDate");


--
-- Name: IX_PerguntasEntrevistaSaida_TemplateId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PerguntasEntrevistaSaida_TemplateId" ON public."PerguntasEntrevistaSaida" USING btree ("TemplateId");


--
-- Name: IX_PerguntasEntrevistaSaida_TenantId_TemplateId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PerguntasEntrevistaSaida_TenantId_TemplateId_Ordem" ON public."PerguntasEntrevistaSaida" USING btree ("TenantId", "TemplateId", "Ordem");


--
-- Name: IX_PermissoesNivelVaga_NivelHierarquicoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PermissoesNivelVaga_NivelHierarquicoId" ON public."PermissoesNivelVaga" USING btree ("NivelHierarquicoId");


--
-- Name: IX_PermissoesNivelVaga_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PermissoesNivelVaga_RoleId" ON public."PermissoesNivelVaga" USING btree ("RoleId");


--
-- Name: IX_PermissoesNivelVaga_TenantId_NivelHierarquicoId_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_PermissoesNivelVaga_TenantId_NivelHierarquicoId_RoleId" ON public."PermissoesNivelVaga" USING btree ("TenantId", "NivelHierarquicoId", "RoleId");


--
-- Name: IX_PessoaBloqueios_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PessoaBloqueios_PessoaId" ON public."PessoaBloqueios" USING btree ("PessoaId");


--
-- Name: IX_PessoaBloqueios_TenantId_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_PessoaBloqueios_TenantId_PessoaId" ON public."PessoaBloqueios" USING btree ("TenantId", "PessoaId");


--
-- Name: IX_Pessoas_TenantId_Cpf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Pessoas_TenantId_Cpf" ON public."Pessoas" USING btree ("TenantId", "Cpf");


--
-- Name: IX_Pessoas_TenantId_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Pessoas_TenantId_Email" ON public."Pessoas" USING btree ("TenantId", "Email");


--
-- Name: IX_PreAdmissaoDependentes_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDependentes_PreAdmissaoId" ON public."PreAdmissaoDependentes" USING btree ("PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDependentes_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDependentes_TenantId_PreAdmissaoId" ON public."PreAdmissaoDependentes" USING btree ("TenantId", "PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentosSolicitados_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentosSolicitados_PreAdmissaoId" ON public."PreAdmissaoDocumentosSolicitados" USING btree ("PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentosSolicitados_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentosSolicitados_TenantId_PreAdmissaoId" ON public."PreAdmissaoDocumentosSolicitados" USING btree ("TenantId", "PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentos_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentos_PreAdmissaoId" ON public."PreAdmissaoDocumentos" USING btree ("PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentos_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentos_TenantId_PreAdmissaoId" ON public."PreAdmissaoDocumentos" USING btree ("TenantId", "PreAdmissaoId");


--
-- Name: IX_PreAdmissoes_AprovadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_AprovadoPorId" ON public."PreAdmissoes" USING btree ("AprovadoPorId");


--
-- Name: IX_PreAdmissoes_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_CandidatoId" ON public."PreAdmissoes" USING btree ("CandidatoId");


--
-- Name: IX_PreAdmissoes_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_CentroCustoId" ON public."PreAdmissoes" USING btree ("CentroCustoId");


--
-- Name: IX_PreAdmissoes_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_JobPositionId" ON public."PreAdmissoes" USING btree ("JobPositionId");


--
-- Name: IX_PreAdmissoes_RevisadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_RevisadoPorId" ON public."PreAdmissoes" USING btree ("RevisadoPorId");


--
-- Name: IX_PreAdmissoes_TenantId_AccessToken; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_TenantId_AccessToken" ON public."PreAdmissoes" USING btree ("TenantId", "AccessToken") WHERE ("AccessToken" IS NOT NULL);


--
-- Name: IX_PreAdmissoes_TenantId_Cpf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_TenantId_Cpf" ON public."PreAdmissoes" USING btree ("TenantId", "Cpf");


--
-- Name: IX_PreAdmissoes_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_TenantId_Status" ON public."PreAdmissoes" USING btree ("TenantId", "Status");


--
-- Name: IX_PreAdmissoes_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_UnitId" ON public."PreAdmissoes" USING btree ("UnitId");


--
-- Name: IX_PreAdmissoes_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_VagaId" ON public."PreAdmissoes" USING btree ("VagaId") WHERE ("VagaId" IS NOT NULL);


--
-- Name: IX_ProjetoCandidatos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetoCandidatos_CandidatoId" ON public."ProjetoCandidatos" USING btree ("CandidatoId");


--
-- Name: IX_ProjetoCandidatos_FaseAtualId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetoCandidatos_FaseAtualId" ON public."ProjetoCandidatos" USING btree ("FaseAtualId");


--
-- Name: IX_ProjetoCandidatos_ProjetoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetoCandidatos_ProjetoId" ON public."ProjetoCandidatos" USING btree ("ProjetoId");


--
-- Name: IX_ProjetoCandidatos_TenantId_ProjetoId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ProjetoCandidatos_TenantId_ProjetoId_CandidatoId" ON public."ProjetoCandidatos" USING btree ("TenantId", "ProjetoId", "CandidatoId");


--
-- Name: IX_ProjetosVaga_TenantId_VagaId_Numero; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ProjetosVaga_TenantId_VagaId_Numero" ON public."ProjetosVaga" USING btree ("TenantId", "VagaId", "Numero");


--
-- Name: IX_ProjetosVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetosVaga_VagaId" ON public."ProjetosVaga" USING btree ("VagaId");


--
-- Name: IX_PropostasVaga_AccessToken; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_PropostasVaga_AccessToken" ON public."PropostasVaga" USING btree ("AccessToken");


--
-- Name: IX_PropostasVaga_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_CandidatoId" ON public."PropostasVaga" USING btree ("CandidatoId");


--
-- Name: IX_PropostasVaga_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_CandidaturaId" ON public."PropostasVaga" USING btree ("CandidaturaId");


--
-- Name: IX_PropostasVaga_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_TenantId_CandidatoId" ON public."PropostasVaga" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_PropostasVaga_TenantId_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_TenantId_CandidaturaId" ON public."PropostasVaga" USING btree ("TenantId", "CandidaturaId");


--
-- Name: IX_PropostasVaga_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_TenantId_VagaId" ON public."PropostasVaga" USING btree ("TenantId", "VagaId");


--
-- Name: IX_PropostasVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_VagaId" ON public."PropostasVaga" USING btree ("VagaId");


--
-- Name: IX_RecruiterMatchingFeedbacks_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RecruiterMatchingFeedbacks_TenantId_VagaId" ON public."RecruiterMatchingFeedbacks" USING btree ("TenantId", "VagaId");


--
-- Name: IX_RecruiterMatchingFeedbacks_VagaId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RecruiterMatchingFeedbacks_VagaId_CandidatoId" ON public."RecruiterMatchingFeedbacks" USING btree ("VagaId", "CandidatoId");


--
-- Name: IX_RenderCoinBalances_TenantId_Balance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinBalances_TenantId_Balance" ON public."RenderCoinBalances" USING btree ("TenantId", "Balance");


--
-- Name: IX_RenderCoinBalances_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinBalances_UserId" ON public."RenderCoinBalances" USING btree ("UserId");


--
-- Name: IX_RenderCoinTransactions_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinTransactions_TenantId_CreatedAtUtc" ON public."RenderCoinTransactions" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_RenderCoinTransactions_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinTransactions_TenantId_UserId" ON public."RenderCoinTransactions" USING btree ("TenantId", "UserId");


--
-- Name: IX_RenderCoinTransactions_TenantId_UserId_SourceType_SourceId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RenderCoinTransactions_TenantId_UserId_SourceType_SourceId" ON public."RenderCoinTransactions" USING btree ("TenantId", "UserId", "SourceType", "SourceId");


--
-- Name: IX_RenderCoinTransactions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinTransactions_UserId" ON public."RenderCoinTransactions" USING btree ("UserId");


--
-- Name: IX_RequestLogs_TenantId_DeviceId_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_DeviceId_StartedAt" ON public."RequestLogs" USING btree ("TenantId", "DeviceId", "StartedAt");


--
-- Name: IX_RequestLogs_TenantId_EnvironmentNormalized_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_EnvironmentNormalized_StartedAt" ON public."RequestLogs" USING btree ("TenantId", "EnvironmentNormalized", "StartedAt");


--
-- Name: IX_RequestLogs_TenantId_Path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_Path" ON public."RequestLogs" USING btree ("TenantId", "Path");


--
-- Name: IX_RequestLogs_TenantId_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_StartedAt" ON public."RequestLogs" USING btree ("TenantId", "StartedAt");


--
-- Name: IX_RequestLogs_TenantId_StatusCode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_StatusCode" ON public."RequestLogs" USING btree ("TenantId", "StatusCode");


--
-- Name: IX_RequestLogs_TenantId_TransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_TransactionId" ON public."RequestLogs" USING btree ("TenantId", "TransactionId");


--
-- Name: IX_RequestLogs_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_UserId" ON public."RequestLogs" USING btree ("TenantId", "UserId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_CampoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_CampoId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("CampoId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_CandidatoId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("CandidatoId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_TenantId_VagaId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_TenantId_VagaId_CandidatoId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("TenantId", "VagaId", "CandidatoId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_VagaId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("VagaId");


--
-- Name: IX_RespostasEntrevistaSaida_EntrevistaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasEntrevistaSaida_EntrevistaId" ON public."RespostasEntrevistaSaida" USING btree ("EntrevistaId");


--
-- Name: IX_RespostasEntrevistaSaida_PerguntaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasEntrevistaSaida_PerguntaId" ON public."RespostasEntrevistaSaida" USING btree ("PerguntaId");


--
-- Name: IX_RespostasEntrevistaSaida_TenantId_EntrevistaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasEntrevistaSaida_TenantId_EntrevistaId" ON public."RespostasEntrevistaSaida" USING btree ("TenantId", "EntrevistaId");


--
-- Name: IX_RmSyncAlertas_TenantId_ResolvidoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RmSyncAlertas_TenantId_ResolvidoEmUtc" ON public."RmSyncAlertas" USING btree ("TenantId", "ResolvidoEmUtc");


--
-- Name: IX_RmSyncAlertas_TenantId_Tipo_ChaveRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RmSyncAlertas_TenantId_Tipo_ChaveRm" ON public."RmSyncAlertas" USING btree ("TenantId", "Tipo", "ChaveRm");


--
-- Name: IX_RmSyncCheckpoints_TenantId_Entidade; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RmSyncCheckpoints_TenantId_Entidade" ON public."RmSyncCheckpoints" USING btree ("TenantId", "Entidade");


--
-- Name: IX_RmSyncRuns_TenantId_Entidade_StartedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RmSyncRuns_TenantId_Entidade_StartedAtUtc" ON public."RmSyncRuns" USING btree ("TenantId", "Entidade", "StartedAtUtc" DESC);


--
-- Name: IX_RmSyncRuns_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RmSyncRuns_TenantId_Status" ON public."RmSyncRuns" USING btree ("TenantId", "Status");


--
-- Name: IX_RoleMenus_MenuId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RoleMenus_MenuId" ON public."RoleMenus" USING btree ("MenuId");


--
-- Name: IX_RoleMenus_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RoleMenus_RoleId" ON public."RoleMenus" USING btree ("RoleId");


--
-- Name: IX_RoleMenus_TenantId_RoleId_MenuId_PermissionKey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RoleMenus_TenantId_RoleId_MenuId_PermissionKey" ON public."RoleMenus" USING btree ("TenantId", "RoleId", "MenuId", "PermissionKey");


--
-- Name: IX_Roles_TenantId_NormalizedName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Roles_TenantId_NormalizedName" ON public."Roles" USING btree ("TenantId", "NormalizedName");


--
-- Name: IX_SkillAliases_SkillId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SkillAliases_SkillId" ON public."SkillAliases" USING btree ("SkillId");


--
-- Name: IX_SkillAliases_TenantId_AliasName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_SkillAliases_TenantId_AliasName" ON public."SkillAliases" USING btree ("TenantId", "AliasName");


--
-- Name: IX_Skills_ParentSkillId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Skills_ParentSkillId" ON public."Skills" USING btree ("ParentSkillId");


--
-- Name: IX_Skills_TenantId_CanonicalName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Skills_TenantId_CanonicalName" ON public."Skills" USING btree ("TenantId", "CanonicalName");


--
-- Name: IX_SlaStatusConfigs_TenantId_TipoEntidade_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_SlaStatusConfigs_TenantId_TipoEntidade_Status" ON public."SlaStatusConfigs" USING btree ("TenantId", "TipoEntidade", "Status");


--
-- Name: IX_SolicitacoesAprovacaoEtapas_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_AprovadorId" ON public."SolicitacoesAprovacaoEtapas" USING btree ("AprovadorId");


--
-- Name: IX_SolicitacoesAprovacaoEtapas_FilaPendente; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_FilaPendente" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "RoleFilaId", "Status") WHERE ("RoleFilaId" IS NOT NULL);


--
-- Name: IX_SolicitacoesAprovacaoEtapas_Solicitacao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_Solicitacao" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "SolicitacaoId", "TipoFluxo");


--
-- Name: IX_SolicitacoesAprovacaoEtapas_TenantId_RoleFilaId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_TenantId_RoleFilaId_Status" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "RoleFilaId", "Status") WHERE ("RoleFilaId" IS NOT NULL);


--
-- Name: IX_SolicitacoesAprovacaoEtapas_TenantId_SolicitacaoId_TipoFluxo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_TenantId_SolicitacaoId_TipoFluxo" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "SolicitacaoId", "TipoFluxo");


--
-- Name: IX_SolicitacoesBeneficio_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesBeneficio_SolicitanteId" ON public."SolicitacoesBeneficio" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesDependente_DependenteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDependente_DependenteId" ON public."SolicitacoesDependente" USING btree ("DependenteId");


--
-- Name: IX_SolicitacoesDependente_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDependente_SolicitanteId" ON public."SolicitacoesDependente" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesDesligamento_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_EmpresaId" ON public."SolicitacoesDesligamento" USING btree ("EmpresaId");


--
-- Name: IX_SolicitacoesDesligamento_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_FuncionarioId" ON public."SolicitacoesDesligamento" USING btree ("FuncionarioId");


--
-- Name: IX_SolicitacoesDesligamento_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_SolicitanteId" ON public."SolicitacoesDesligamento" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesDesligamento_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_UnitId" ON public."SolicitacoesDesligamento" USING btree ("UnitId");


--
-- Name: IX_SolicitacoesEndereco_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesEndereco_SolicitanteId" ON public."SolicitacoesEndereco" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesFerias_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesFerias_SolicitanteId" ON public."SolicitacoesFerias" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesPagamentoExtra_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPagamentoExtra_FuncionarioId" ON public."SolicitacoesPagamentoExtra" USING btree ("FuncionarioId");


--
-- Name: IX_SolicitacoesPagamentoExtra_ImportadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPagamentoExtra_ImportadoPorId" ON public."SolicitacoesPagamentoExtra" USING btree ("ImportadoPorId");


--
-- Name: IX_SolicitacoesPagamentoExtra_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPagamentoExtra_SolicitanteId" ON public."SolicitacoesPagamentoExtra" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesPromocao_CargoAtualId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_CargoAtualId" ON public."SolicitacoesPromocao" USING btree ("CargoAtualId");


--
-- Name: IX_SolicitacoesPromocao_CentroCustoAtualId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_CentroCustoAtualId" ON public."SolicitacoesPromocao" USING btree ("CentroCustoAtualId");


--
-- Name: IX_SolicitacoesPromocao_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_FuncionarioId" ON public."SolicitacoesPromocao" USING btree ("FuncionarioId");


--
-- Name: IX_SolicitacoesPromocao_NovaUnidadeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_NovaUnidadeId" ON public."SolicitacoesPromocao" USING btree ("NovaUnidadeId");


--
-- Name: IX_SolicitacoesPromocao_NovoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_NovoCargoId" ON public."SolicitacoesPromocao" USING btree ("NovoCargoId");


--
-- Name: IX_SolicitacoesPromocao_NovoCentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_NovoCentroCustoId" ON public."SolicitacoesPromocao" USING btree ("NovoCentroCustoId");


--
-- Name: IX_SolicitacoesPromocao_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_SolicitanteId" ON public."SolicitacoesPromocao" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesPromocao_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_UnitId" ON public."SolicitacoesPromocao" USING btree ("UnitId");


--
-- Name: IX_SolicitacoesVaga_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_AprovadorId" ON public."SolicitacoesVaga" USING btree ("AprovadorId");


--
-- Name: IX_SolicitacoesVaga_CandidatoContratadoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_CandidatoContratadoId" ON public."SolicitacoesVaga" USING btree ("CandidatoContratadoId");


--
-- Name: IX_SolicitacoesVaga_DecisaoRHRevisadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_DecisaoRHRevisadoPorId" ON public."SolicitacoesVaga" USING btree ("DecisaoRHRevisadoPorId");


--
-- Name: IX_SolicitacoesVaga_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_JobPositionId" ON public."SolicitacoesVaga" USING btree ("JobPositionId");


--
-- Name: IX_SolicitacoesVaga_MotivoRequisicaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_MotivoRequisicaoId" ON public."SolicitacoesVaga" USING btree ("MotivoRequisicaoId");


--
-- Name: IX_SolicitacoesVaga_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_SolicitanteId" ON public."SolicitacoesVaga" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesVaga_SubstituidoFuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_SubstituidoFuncionarioId" ON public."SolicitacoesVaga" USING btree ("SubstituidoFuncionarioId");


--
-- Name: IX_SolicitacoesVaga_TenantId_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_TenantId_SolicitanteId" ON public."SolicitacoesVaga" USING btree ("TenantId", "SolicitanteId");


--
-- Name: IX_SolicitacoesVaga_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_TenantId_Status" ON public."SolicitacoesVaga" USING btree ("TenantId", "Status");


--
-- Name: IX_SolicitacoesVaga_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_UnitId" ON public."SolicitacoesVaga" USING btree ("UnitId");


--
-- Name: IX_SurveyAnswers_ResponseId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyAnswers_ResponseId" ON public."SurveyAnswers" USING btree ("ResponseId");


--
-- Name: IX_SurveyAnswers_TenantId_ResponseId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyAnswers_TenantId_ResponseId" ON public."SurveyAnswers" USING btree ("TenantId", "ResponseId");


--
-- Name: IX_SurveyOptions_QuestionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyOptions_QuestionId" ON public."SurveyOptions" USING btree ("QuestionId");


--
-- Name: IX_SurveyOptions_TenantId_QuestionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyOptions_TenantId_QuestionId" ON public."SurveyOptions" USING btree ("TenantId", "QuestionId");


--
-- Name: IX_SurveyQuestions_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyQuestions_SurveyId" ON public."SurveyQuestions" USING btree ("SurveyId");


--
-- Name: IX_SurveyQuestions_TenantId_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyQuestions_TenantId_SurveyId" ON public."SurveyQuestions" USING btree ("TenantId", "SurveyId");


--
-- Name: IX_SurveyResponses_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyResponses_SurveyId" ON public."SurveyResponses" USING btree ("SurveyId");


--
-- Name: IX_SurveyResponses_TenantId_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyResponses_TenantId_SurveyId" ON public."SurveyResponses" USING btree ("TenantId", "SurveyId");


--
-- Name: IX_SurveyResponses_TenantId_SurveyId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_SurveyResponses_TenantId_SurveyId_UserId" ON public."SurveyResponses" USING btree ("TenantId", "SurveyId", "UserId");


--
-- Name: IX_SurveyResponses_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyResponses_TenantId_UserId" ON public."SurveyResponses" USING btree ("TenantId", "UserId");


--
-- Name: IX_Surveys_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Surveys_TenantId_CreatedAtUtc" ON public."Surveys" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_TalentoCompetencias_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCompetencias_TalentoId" ON public."TalentoCompetencias" USING btree ("TalentoId");


--
-- Name: IX_TalentoCompetencias_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCompetencias_TenantId_TalentoId" ON public."TalentoCompetencias" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoCvImportJobs_TalentoDocumentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TalentoDocumentoId" ON public."TalentoCvImportJobs" USING btree ("TalentoDocumentoId");


--
-- Name: IX_TalentoCvImportJobs_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TalentoId" ON public."TalentoCvImportJobs" USING btree ("TalentoId");


--
-- Name: IX_TalentoCvImportJobs_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TenantId_Status" ON public."TalentoCvImportJobs" USING btree ("TenantId", "Status");


--
-- Name: IX_TalentoCvImportJobs_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TenantId_TalentoId" ON public."TalentoCvImportJobs" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoDocumentos_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoDocumentos_TalentoId" ON public."TalentoDocumentos" USING btree ("TalentoId");


--
-- Name: IX_TalentoDocumentos_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoDocumentos_TenantId_TalentoId" ON public."TalentoDocumentos" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoExperiencias_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoExperiencias_TalentoId" ON public."TalentoExperiencias" USING btree ("TalentoId");


--
-- Name: IX_TalentoExperiencias_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoExperiencias_TenantId_TalentoId" ON public."TalentoExperiencias" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoFormacoes_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoFormacoes_TalentoId" ON public."TalentoFormacoes" USING btree ("TalentoId");


--
-- Name: IX_TalentoFormacoes_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoFormacoes_TenantId_TalentoId" ON public."TalentoFormacoes" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoTreinamentos_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoTreinamentos_TalentoId" ON public."TalentoTreinamentos" USING btree ("TalentoId");


--
-- Name: IX_TalentoTreinamentos_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoTreinamentos_TenantId_TalentoId" ON public."TalentoTreinamentos" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_Talentos_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Talentos_PessoaId" ON public."Talentos" USING btree ("PessoaId");


--
-- Name: IX_Talentos_TenantId_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Talentos_TenantId_PessoaId" ON public."Talentos" USING btree ("TenantId", "PessoaId");


--
-- Name: IX_TemplatesEntrevistaSaida_TenantId_Ativo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TemplatesEntrevistaSaida_TenantId_Ativo" ON public."TemplatesEntrevistaSaida" USING btree ("TenantId", "Ativo");


--
-- Name: IX_TenantBrandings_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantBrandings_TenantId" ON public."TenantBrandings" USING btree ("TenantId");


--
-- Name: IX_TenantConfiguracoes_AprovadorRhId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TenantConfiguracoes_AprovadorRhId" ON public."TenantConfiguracoes" USING btree ("AprovadorRhId");


--
-- Name: IX_TenantConfiguracoes_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantConfiguracoes_TenantId" ON public."TenantConfiguracoes" USING btree ("TenantId");


--
-- Name: IX_Turnos_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Turnos_IsActive" ON public."Turnos" USING btree ("IsActive");


--
-- Name: IX_Turnos_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Turnos_TenantId_Code" ON public."Turnos" USING btree ("TenantId", "Code");


--
-- Name: IX_Turnos_UnidadeLotacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Turnos_UnidadeLotacaoId" ON public."Turnos" USING btree ("UnidadeLotacaoId");


--
-- Name: IX_UnidadesLotacao_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UnidadesLotacao_IsActive" ON public."UnidadesLotacao" USING btree ("IsActive");


--
-- Name: IX_UnidadesLotacao_OwnerFuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UnidadesLotacao_OwnerFuncionarioId" ON public."UnidadesLotacao" USING btree ("OwnerFuncionarioId");


--
-- Name: IX_UnidadesLotacao_ParentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UnidadesLotacao_ParentId" ON public."UnidadesLotacao" USING btree ("ParentId");


--
-- Name: IX_UnidadesLotacao_TenantId_CdnPlanoLotac_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_UnidadesLotacao_TenantId_CdnPlanoLotac_Code" ON public."UnidadesLotacao" USING btree ("TenantId", "CdnPlanoLotac", "Code");


--
-- Name: IX_Units_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Units_EmpresaId" ON public."Units" USING btree ("EmpresaId");


--
-- Name: IX_Units_TenantId_EmpresaId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Units_TenantId_EmpresaId_Code" ON public."Units" USING btree ("TenantId", "EmpresaId", "Code") WHERE ("EmpresaId" IS NOT NULL);


--
-- Name: IX_UserRoles_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserRoles_RoleId" ON public."UserRoles" USING btree ("RoleId");


--
-- Name: IX_UserRoles_TenantId_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserRoles_TenantId_RoleId" ON public."UserRoles" USING btree ("TenantId", "RoleId");


--
-- Name: IX_UserRoles_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserRoles_TenantId_UserId" ON public."UserRoles" USING btree ("TenantId", "UserId");


--
-- Name: IX_UserUnits_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserUnits_UnitId" ON public."UserUnits" USING btree ("UnitId");


--
-- Name: IX_Users_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Users_FuncionarioId" ON public."Users" USING btree ("FuncionarioId");


--
-- Name: IX_Users_TenantId_NormalizedEmail; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Users_TenantId_NormalizedEmail" ON public."Users" USING btree ("TenantId", "NormalizedEmail");


--
-- Name: IX_Users_TenantId_NormalizedUserName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Users_TenantId_NormalizedUserName" ON public."Users" USING btree ("TenantId", "NormalizedUserName");


--
-- Name: IX_VagaBeneficios_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaBeneficios_TenantId_VagaId" ON public."VagaBeneficios" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaBeneficios_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaBeneficios_VagaId" ON public."VagaBeneficios" USING btree ("VagaId");


--
-- Name: IX_VagaEtapas_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaEtapas_TenantId_VagaId" ON public."VagaEtapas" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaEtapas_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaEtapas_VagaId" ON public."VagaEtapas" USING btree ("VagaId");


--
-- Name: IX_VagaPerguntas_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaPerguntas_TenantId_VagaId" ON public."VagaPerguntas" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaPerguntas_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaPerguntas_VagaId" ON public."VagaPerguntas" USING btree ("VagaId");


--
-- Name: IX_VagaRequisitos_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaRequisitos_TenantId_VagaId" ON public."VagaRequisitos" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaRequisitos_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaRequisitos_VagaId" ON public."VagaRequisitos" USING btree ("VagaId");


--
-- Name: IX_VagaUnifiedMatchingCaches_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaUnifiedMatchingCaches_TenantId_Status" ON public."VagaUnifiedMatchingCaches" USING btree ("TenantId", "Status");


--
-- Name: IX_VagaUnifiedMatchingCaches_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_VagaUnifiedMatchingCaches_TenantId_VagaId" ON public."VagaUnifiedMatchingCaches" USING btree ("TenantId", "VagaId");


--
-- Name: IX_Vagas_CategoriaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_CategoriaSalarialId" ON public."Vagas" USING btree ("CategoriaSalarialId");


--
-- Name: IX_Vagas_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_CentroCustoId" ON public."Vagas" USING btree ("CentroCustoId");


--
-- Name: IX_Vagas_DescricaoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_DescricaoCargoId" ON public."Vagas" USING btree ("DescricaoCargoId");


--
-- Name: IX_Vagas_EixoVagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_EixoVagaId" ON public."Vagas" USING btree ("EixoVagaId");


--
-- Name: IX_Vagas_HierarquiaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_HierarquiaId" ON public."Vagas" USING btree ("HierarquiaId");


--
-- Name: IX_Vagas_IdReqRmOrigem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_IdReqRmOrigem" ON public."Vagas" USING btree ("IdReqRmOrigem");


--
-- Name: IX_Vagas_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_JobPositionId" ON public."Vagas" USING btree ("JobPositionId");


--
-- Name: IX_Vagas_OrigemDesligamentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_OrigemDesligamentoId" ON public."Vagas" USING btree ("OrigemDesligamentoId");


--
-- Name: IX_Vagas_OrigemTipo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_OrigemTipo" ON public."Vagas" USING btree ("OrigemTipo");


--
-- Name: IX_Vagas_RecrutadorResponsavelUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_RecrutadorResponsavelUserId" ON public."Vagas" USING btree ("RecrutadorResponsavelUserId");


--
-- Name: IX_Vagas_TenantId_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_TenantId_CentroCustoId" ON public."Vagas" USING btree ("TenantId", "CentroCustoId");


--
-- Name: IX_Vagas_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_TenantId_Status" ON public."Vagas" USING btree ("TenantId", "Status");


--
-- Name: IX_Vagas_TurnoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_TurnoId" ON public."Vagas" USING btree ("TurnoId");


--
-- Name: IX_Vagas_UnidadeLotacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_UnidadeLotacaoId" ON public."Vagas" USING btree ("UnidadeLotacaoId");


--
-- Name: IX_WorkflowsRH_DesligamentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_DesligamentoId" ON public."WorkflowsRH" USING btree ("DesligamentoId");


--
-- Name: IX_WorkflowsRH_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_PreAdmissaoId" ON public."WorkflowsRH" USING btree ("PreAdmissaoId");


--
-- Name: IX_WorkflowsRH_ResponsavelId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_ResponsavelId" ON public."WorkflowsRH" USING btree ("ResponsavelId");


--
-- Name: IX_WorkflowsRH_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_TenantId_PreAdmissaoId" ON public."WorkflowsRH" USING btree ("TenantId", "PreAdmissaoId") WHERE ("PreAdmissaoId" IS NOT NULL);


--
-- Name: IX_WorkflowsRH_TenantId_TipoWorkflow_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_TenantId_TipoWorkflow_Status" ON public."WorkflowsRH" USING btree ("TenantId", "TipoWorkflow", "Status");


--
-- Name: IX_WorkflowsRH_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_TenantId_VagaId" ON public."WorkflowsRH" USING btree ("TenantId", "VagaId") WHERE ("VagaId" IS NOT NULL);


--
-- Name: IX_WorkflowsRH_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_VagaId" ON public."WorkflowsRH" USING btree ("VagaId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RoleNameIndex" ON public."Roles" USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "UserNameIndex" ON public."Users" USING btree ("NormalizedUserName");


--
-- Name: AgendaEvents FK_AgendaEvents_AgendaEventTypes_TypeId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgendaEvents"
    ADD CONSTRAINT "FK_AgendaEvents_AgendaEventTypes_TypeId" FOREIGN KEY ("TypeId") REFERENCES public."AgendaEventTypes"("Id") ON DELETE RESTRICT;


--
-- Name: AprovacoesFaixaSalarial FK_AprovacoesFaixaSalarial_FaixasSalariais_FaixaSalarialId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "FK_AprovacoesFaixaSalarial_FaixasSalariais_FaixaSalarialId" FOREIGN KEY ("FaixaSalarialId") REFERENCES public."FaixasSalariais"("Id") ON DELETE CASCADE;


--
-- Name: AprovacoesFaixaSalarial FK_AprovacoesFaixaSalarial_Funcionarios_AprovadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "FK_AprovacoesFaixaSalarial_Funcionarios_AprovadorId" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: AprovacoesFaixaSalarial FK_AprovacoesFaixaSalarial_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "FK_AprovacoesFaixaSalarial_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: AprovadoresAlternativos FK_AprovadoresAlternativos_Aprovador; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovadoresAlternativos"
    ADD CONSTRAINT "FK_AprovadoresAlternativos_Aprovador" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: AprovadoresAlternativos FK_AprovadoresAlternativos_Gestor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovadoresAlternativos"
    ADD CONSTRAINT "FK_AprovadoresAlternativos_Gestor" FOREIGN KEY ("GestorId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: AspNetRoleClaims FK_AspNetRoleClaims_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "FK_AspNetRoleClaims_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserClaims FK_AspNetUserClaims_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "FK_AspNetUserClaims_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserLogins FK_AspNetUserLogins_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "FK_AspNetUserLogins_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserTokens FK_AspNetUserTokens_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "FK_AspNetUserTokens_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: AuditEntityChanges FK_AuditEntityChanges_AuditEvents_AuditEventId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityChanges"
    ADD CONSTRAINT "FK_AuditEntityChanges_AuditEvents_AuditEventId" FOREIGN KEY ("AuditEventId") REFERENCES public."AuditEvents"("Id") ON DELETE SET NULL;


--
-- Name: AuditEntityChanges FK_AuditEntityChanges_AuditTransactions_AuditTransactionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityChanges"
    ADD CONSTRAINT "FK_AuditEntityChanges_AuditTransactions_AuditTransactionId" FOREIGN KEY ("AuditTransactionId") REFERENCES public."AuditTransactions"("Id") ON DELETE CASCADE;


--
-- Name: AuditEntityPropertyChanges FK_AuditEntityPropertyChanges_AuditEntityChanges_AuditEntityCha; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityPropertyChanges"
    ADD CONSTRAINT "FK_AuditEntityPropertyChanges_AuditEntityChanges_AuditEntityCha" FOREIGN KEY ("AuditEntityChangeId") REFERENCES public."AuditEntityChanges"("Id") ON DELETE CASCADE;


--
-- Name: AuditEvents FK_AuditEvents_AuditTransactions_AuditTransactionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEvents"
    ADD CONSTRAINT "FK_AuditEvents_AuditTransactions_AuditTransactionId" FOREIGN KEY ("AuditTransactionId") REFERENCES public."AuditTransactions"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoCalibragens FK_AvaliacaoCalibragens_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "FK_AvaliacaoCalibragens_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoCalibragens FK_AvaliacaoCalibragens_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "FK_AvaliacaoCalibragens_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoCalibragens FK_AvaliacaoCalibragens_NineBoxAssessments_NineBoxAssessmentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "FK_AvaliacaoCalibragens_NineBoxAssessments_NineBoxAssessmentId" FOREIGN KEY ("NineBoxAssessmentId") REFERENCES public."NineBoxAssessments"("Id") ON DELETE SET NULL;


--
-- Name: AvaliacaoCiclos FK_AvaliacaoCiclos_Funcionarios_CriadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCiclos"
    ADD CONSTRAINT "FK_AvaliacaoCiclos_Funcionarios_CriadoPorId" FOREIGN KEY ("CriadoPorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoConvites FK_AvaliacaoConvites_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "FK_AvaliacaoConvites_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoConvites FK_AvaliacaoConvites_Funcionarios_AvaliadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "FK_AvaliacaoConvites_Funcionarios_AvaliadorId" FOREIGN KEY ("AvaliadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoConvites FK_AvaliacaoConvites_Funcionarios_AvaliandoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "FK_AvaliacaoConvites_Funcionarios_AvaliandoId" FOREIGN KEY ("AvaliandoId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoPerguntas FK_AvaliacaoPerguntas_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoPerguntas"
    ADD CONSTRAINT "FK_AvaliacaoPerguntas_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoRespostas FK_AvaliacaoRespostas_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "FK_AvaliacaoRespostas_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoRespostas FK_AvaliacaoRespostas_Funcionarios_AvaliadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "FK_AvaliacaoRespostas_Funcionarios_AvaliadorId" FOREIGN KEY ("AvaliadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoRespostas FK_AvaliacaoRespostas_Funcionarios_AvaliandoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "FK_AvaliacaoRespostas_Funcionarios_AvaliandoId" FOREIGN KEY ("AvaliandoId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: BatchMatchingRunVagas FK_BatchMatchingRunVagas_BatchMatchingRuns_RunId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BatchMatchingRunVagas"
    ADD CONSTRAINT "FK_BatchMatchingRunVagas_BatchMatchingRuns_RunId" FOREIGN KEY ("RunId") REFERENCES public."BatchMatchingRuns"("Id") ON DELETE CASCADE;


--
-- Name: CamposPersonalizadosVaga FK_CamposPersonalizadosVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CamposPersonalizadosVaga"
    ADD CONSTRAINT "FK_CamposPersonalizadosVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoAcessibilidades FK_CandidatoAcessibilidades_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAcessibilidades"
    ADD CONSTRAINT "FK_CandidatoAcessibilidades_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoAgendaBloqueios FK_CandidatoAgendaBloqueios_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaBloqueios"
    ADD CONSTRAINT "FK_CandidatoAgendaBloqueios_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoAgendaPreferencias FK_CandidatoAgendaPreferencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaPreferencias"
    ADD CONSTRAINT "FK_CandidatoAgendaPreferencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoCertificacoes FK_CandidatoCertificacoes_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCertificacoes"
    ADD CONSTRAINT "FK_CandidatoCertificacoes_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoCompetencias FK_CandidatoCompetencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCompetencias"
    ADD CONSTRAINT "FK_CandidatoCompetencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoDocumentos FK_CandidatoDocumentos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoDocumentos"
    ADD CONSTRAINT "FK_CandidatoDocumentos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoEducacaoItens FK_CandidatoEducacaoItens_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoItens"
    ADD CONSTRAINT "FK_CandidatoEducacaoItens_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoEducacaoResumos FK_CandidatoEducacaoResumos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoResumos"
    ADD CONSTRAINT "FK_CandidatoEducacaoResumos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoEmbeddings FK_CandidatoEmbeddings_Candidato; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEmbeddings"
    ADD CONSTRAINT "FK_CandidatoEmbeddings_Candidato" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoExperiencias FK_CandidatoExperiencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoExperiencias"
    ADD CONSTRAINT "FK_CandidatoExperiencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoLgpdConsents FK_CandidatoLgpdConsents_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoLgpdConsents"
    ADD CONSTRAINT "FK_CandidatoLgpdConsents_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoNotificacaoPreferencias FK_CandidatoNotificacaoPreferencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoNotificacaoPreferencias"
    ADD CONSTRAINT "FK_CandidatoNotificacaoPreferencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoPortfolios FK_CandidatoPortfolios_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPortfolios"
    ADD CONSTRAINT "FK_CandidatoPortfolios_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoPreferenciasVaga FK_CandidatoPreferenciasVaga_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPreferenciasVaga"
    ADD CONSTRAINT "FK_CandidatoPreferenciasVaga_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoProjetos FK_CandidatoProjetos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoProjetos"
    ADD CONSTRAINT "FK_CandidatoProjetos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoReferencias FK_CandidatoReferencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoReferencias"
    ADD CONSTRAINT "FK_CandidatoReferencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoStatusHistories FK_CandidatoStatusHistories_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoStatusHistories"
    ADD CONSTRAINT "FK_CandidatoStatusHistories_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaLlmScores FK_CandidatoVagaLlmScores_Candidato; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaLlmScores"
    ADD CONSTRAINT "FK_CandidatoVagaLlmScores_Candidato" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaLlmScores FK_CandidatoVagaLlmScores_Vaga; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaLlmScores"
    ADD CONSTRAINT "FK_CandidatoVagaLlmScores_Vaga" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaMatchingScores FK_CandidatoVagaMatchingScores_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaMatchingScores"
    ADD CONSTRAINT "FK_CandidatoVagaMatchingScores_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaMatchingScores FK_CandidatoVagaMatchingScores_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaMatchingScores"
    ADD CONSTRAINT "FK_CandidatoVagaMatchingScores_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: Candidatos FK_Candidatos_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidatos"
    ADD CONSTRAINT "FK_Candidatos_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE SET NULL;


--
-- Name: Candidatos FK_Candidatos_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidatos"
    ADD CONSTRAINT "FK_Candidatos_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE RESTRICT;


--
-- Name: CandidaturaEtapaHistoricos FK_CandidaturaEtapaHistoricos_Candidaturas_CandidaturaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidaturaEtapaHistoricos"
    ADD CONSTRAINT "FK_CandidaturaEtapaHistoricos_Candidaturas_CandidaturaId" FOREIGN KEY ("CandidaturaId") REFERENCES public."Candidaturas"("Id") ON DELETE CASCADE;


--
-- Name: Candidaturas FK_Candidaturas_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidaturas"
    ADD CONSTRAINT "FK_Candidaturas_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: Candidaturas FK_Candidaturas_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidaturas"
    ADD CONSTRAINT "FK_Candidaturas_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE RESTRICT;


--
-- Name: CategoriaSalarialSteps FK_CategoriaSalarialSteps_CategoriasSalariais_CategoriaSalaria~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriaSalarialSteps"
    ADD CONSTRAINT "FK_CategoriaSalarialSteps_CategoriasSalariais_CategoriaSalaria~" FOREIGN KEY ("CategoriaSalarialId") REFERENCES public."CategoriasSalariais"("Id") ON DELETE CASCADE;


--
-- Name: CategoriasSalariais FK_CategoriasSalariais_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriasSalariais"
    ADD CONSTRAINT "FK_CategoriasSalariais_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: CategoriasSalariais FK_CategoriasSalariais_Units_EstabelecimentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriasSalariais"
    ADD CONSTRAINT "FK_CategoriasSalariais_Units_EstabelecimentoId" FOREIGN KEY ("EstabelecimentoId") REFERENCES public."Units"("Id") ON DELETE SET NULL;


--
-- Name: CelebrationCommentMentions FK_CelebrationCommentMentions_CelebrationComments_CommentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentMentions"
    ADD CONSTRAINT "FK_CelebrationCommentMentions_CelebrationComments_CommentId" FOREIGN KEY ("CommentId") REFERENCES public."CelebrationComments"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationCommentMentions FK_CelebrationCommentMentions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentMentions"
    ADD CONSTRAINT "FK_CelebrationCommentMentions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationCommentReactions FK_CelebrationCommentReactions_CelebrationComments_CommentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentReactions"
    ADD CONSTRAINT "FK_CelebrationCommentReactions_CelebrationComments_CommentId" FOREIGN KEY ("CommentId") REFERENCES public."CelebrationComments"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationCommentReactions FK_CelebrationCommentReactions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentReactions"
    ADD CONSTRAINT "FK_CelebrationCommentReactions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationComments FK_CelebrationComments_CelebrationPosts_PostId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationComments"
    ADD CONSTRAINT "FK_CelebrationComments_CelebrationPosts_PostId" FOREIGN KEY ("PostId") REFERENCES public."CelebrationPosts"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationComments FK_CelebrationComments_Users_AuthorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationComments"
    ADD CONSTRAINT "FK_CelebrationComments_Users_AuthorId" FOREIGN KEY ("AuthorId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationMentions FK_CelebrationMentions_CelebrationPosts_PostId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationMentions"
    ADD CONSTRAINT "FK_CelebrationMentions_CelebrationPosts_PostId" FOREIGN KEY ("PostId") REFERENCES public."CelebrationPosts"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationMentions FK_CelebrationMentions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationMentions"
    ADD CONSTRAINT "FK_CelebrationMentions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationPosts FK_CelebrationPosts_Users_AuthorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationPosts"
    ADD CONSTRAINT "FK_CelebrationPosts_Users_AuthorId" FOREIGN KEY ("AuthorId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CentrosCusto FK_CentrosCusto_CentrosCusto_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "FK_CentrosCusto_CentrosCusto_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."CentrosCusto"("Id") ON DELETE RESTRICT;


--
-- Name: CentrosCusto FK_CentrosCusto_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "FK_CentrosCusto_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: CentrosCusto FK_CentrosCusto_Funcionarios_OwnerFuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "FK_CentrosCusto_Funcionarios_OwnerFuncionarioId" FOREIGN KEY ("OwnerFuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: DadosBancarios FK_DadosBancarios_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DadosBancarios"
    ADD CONSTRAINT "FK_DadosBancarios_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: Dependentes FK_Dependentes_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Dependentes"
    ADD CONSTRAINT "FK_Dependentes_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: DescricaoCargoItemEmbeddings FK_DescricaoCargoItemEmbeddings_Item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItemEmbeddings"
    ADD CONSTRAINT "FK_DescricaoCargoItemEmbeddings_Item" FOREIGN KEY ("DescricaoCargoItemId") REFERENCES public."DescricaoCargoItens"("Id") ON DELETE CASCADE;


--
-- Name: DescricaoCargoItens FK_DescricaoCargoItens_DescricoesCargo_DescricaoCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItens"
    ADD CONSTRAINT "FK_DescricaoCargoItens_DescricoesCargo_DescricaoCargoId" FOREIGN KEY ("DescricaoCargoId") REFERENCES public."DescricoesCargo"("Id") ON DELETE CASCADE;


--
-- Name: DescricoesCargo FK_DescricoesCargo_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricoesCargo"
    ADD CONSTRAINT "FK_DescricoesCargo_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE SET NULL;


--
-- Name: Desligamentos FK_Desligamentos_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Desligamentos"
    ADD CONSTRAINT "FK_Desligamentos_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: DevelopmentPlanGoals FK_DevelopmentPlanGoals_DevelopmentPlans_PlanId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlanGoals"
    ADD CONSTRAINT "FK_DevelopmentPlanGoals_DevelopmentPlans_PlanId" FOREIGN KEY ("PlanId") REFERENCES public."DevelopmentPlans"("Id") ON DELETE CASCADE;


--
-- Name: DevelopmentPlans FK_DevelopmentPlans_Users_OwnerUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlans"
    ADD CONSTRAINT "FK_DevelopmentPlans_Users_OwnerUserId" FOREIGN KEY ("OwnerUserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: DevelopmentPlans FK_DevelopmentPlans_Users_TargetUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlans"
    ADD CONSTRAINT "FK_DevelopmentPlans_Users_TargetUserId" FOREIGN KEY ("TargetUserId") REFERENCES public."Users"("Id") ON DELETE SET NULL;


--
-- Name: DocumentacaoPadraoHistoricos FK_DocumentacaoPadraoHistoricos_JobPositions_CargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoHistoricos"
    ADD CONSTRAINT "FK_DocumentacaoPadraoHistoricos_JobPositions_CargoId" FOREIGN KEY ("CargoId") REFERENCES public."JobPositions"("Id") ON DELETE SET NULL;


--
-- Name: DocumentacaoPadraoHistoricos FK_DocumentacaoPadraoHistoricos_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoHistoricos"
    ADD CONSTRAINT "FK_DocumentacaoPadraoHistoricos_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE SET NULL;


--
-- Name: DocumentacaoPadraoPorCargoConfigs FK_DocumentacaoPadraoPorCargoConfigs_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorCargoConfigs"
    ADD CONSTRAINT "FK_DocumentacaoPadraoPorCargoConfigs_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE CASCADE;


--
-- Name: DocumentacaoPadraoPorNivelCargoConfigs FK_DocumentacaoPadraoPorNivelCargoConfigs_NiveisCargo_NivelCar~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorNivelCargoConfigs"
    ADD CONSTRAINT "FK_DocumentacaoPadraoPorNivelCargoConfigs_NiveisCargo_NivelCar~" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE CASCADE;


--
-- Name: DocumentosColaborador FK_DocumentosColaborador_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentosColaborador"
    ADD CONSTRAINT "FK_DocumentosColaborador_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: EmailAttempts FK_EmailAttempts_EmailMessages_EmailMessageId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailAttempts"
    ADD CONSTRAINT "FK_EmailAttempts_EmailMessages_EmailMessageId" FOREIGN KEY ("EmailMessageId") REFERENCES public."EmailMessages"("Id") ON DELETE CASCADE;


--
-- Name: EtapasConfigAprovacao FK_EtapasConfigAprovacao_Funcionarios_FuncionarioFixoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigAprovacao"
    ADD CONSTRAINT "FK_EtapasConfigAprovacao_Funcionarios_FuncionarioFixoId" FOREIGN KEY ("FuncionarioFixoId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: EtapasConfigAprovacao FK_EtapasConfigAprovacao_Roles_RoleFilaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigAprovacao"
    ADD CONSTRAINT "FK_EtapasConfigAprovacao_Roles_RoleFilaId" FOREIGN KEY ("RoleFilaId") REFERENCES public."Roles"("Id") ON DELETE SET NULL;


--
-- Name: EtapasConfigWorkflowRH FK_EtapasConfigWorkflowRH_Roles_RoleFilaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigWorkflowRH"
    ADD CONSTRAINT "FK_EtapasConfigWorkflowRH_Roles_RoleFilaId" FOREIGN KEY ("RoleFilaId") REFERENCES public."Roles"("Id") ON DELETE SET NULL;


--
-- Name: EtapasWorkflowRH FK_EtapasWorkflowRH_Funcionarios_ResponsavelId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasWorkflowRH"
    ADD CONSTRAINT "FK_EtapasWorkflowRH_Funcionarios_ResponsavelId" FOREIGN KEY ("ResponsavelId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: EtapasWorkflowRH FK_EtapasWorkflowRH_WorkflowsRH_WorkflowId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasWorkflowRH"
    ADD CONSTRAINT "FK_EtapasWorkflowRH_WorkflowsRH_WorkflowId" FOREIGN KEY ("WorkflowId") REFERENCES public."WorkflowsRH"("Id") ON DELETE CASCADE;


--
-- Name: FaixasSalariais FK_FaixasSalariais_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FaixasSalariais"
    ADD CONSTRAINT "FK_FaixasSalariais_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE SET NULL;


--
-- Name: FasesProcesso FK_FasesProcesso_ProjetosVaga_ProjetoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FasesProcesso"
    ADD CONSTRAINT "FK_FasesProcesso_ProjetosVaga_ProjetoId" FOREIGN KEY ("ProjetoId") REFERENCES public."ProjetosVaga"("Id") ON DELETE CASCADE;


--
-- Name: FeedbackItemRatings FK_FeedbackItemRatings_FeedbackItems_FeedbackItemId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItemRatings"
    ADD CONSTRAINT "FK_FeedbackItemRatings_FeedbackItems_FeedbackItemId" FOREIGN KEY ("FeedbackItemId") REFERENCES public."FeedbackItems"("Id") ON DELETE CASCADE;


--
-- Name: FeedbackItems FK_FeedbackItems_Users_FromUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItems"
    ADD CONSTRAINT "FK_FeedbackItems_Users_FromUserId" FOREIGN KEY ("FromUserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: FeedbackItems FK_FeedbackItems_Users_ToUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItems"
    ADD CONSTRAINT "FK_FeedbackItems_Users_ToUserId" FOREIGN KEY ("ToUserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: FuncionarioMovimentacoes FK_FuncionarioMovimentacoes_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FuncionarioMovimentacoes"
    ADD CONSTRAINT "FK_FuncionarioMovimentacoes_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Funcionarios_GestorDiretoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Funcionarios_GestorDiretoId" FOREIGN KEY ("GestorDiretoId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Hierarquias_HierarquiaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Hierarquias_HierarquiaId" FOREIGN KEY ("HierarquiaId") REFERENCES public."Hierarquias"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE RESTRICT;


--
-- Name: Funcionarios FK_Funcionarios_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_NiveisHierarquicos_NivelHierarquicoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_NiveisHierarquicos_NivelHierarquicoId" FOREIGN KEY ("NivelHierarquicoId") REFERENCES public."NiveisHierarquicos"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Pessoas_PessoaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Pessoas_PessoaId" FOREIGN KEY ("PessoaId") REFERENCES public."Pessoas"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE RESTRICT;


--
-- Name: Funcionarios FK_Funcionarios_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE SET NULL;


--
-- Name: GamificationDailyStates FK_GamificationDailyStates_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GamificationDailyStates"
    ADD CONSTRAINT "FK_GamificationDailyStates_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: Hierarquias FK_Hierarquias_Hierarquias_HierarquiaSuperiorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Hierarquias"
    ADD CONSTRAINT "FK_Hierarquias_Hierarquias_HierarquiaSuperiorId" FOREIGN KEY ("HierarquiaSuperiorId") REFERENCES public."Hierarquias"("Id") ON DELETE RESTRICT;


--
-- Name: HistoricosAlteracaoWorkflowRH FK_HistoricosAlteracaoWorkflowRH_EtapasWorkflowRH_EtapaWorkflo~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "FK_HistoricosAlteracaoWorkflowRH_EtapasWorkflowRH_EtapaWorkflo~" FOREIGN KEY ("EtapaWorkflowId") REFERENCES public."EtapasWorkflowRH"("Id") ON DELETE SET NULL;


--
-- Name: HistoricosAlteracaoWorkflowRH FK_HistoricosAlteracaoWorkflowRH_Funcionarios_AlteradoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "FK_HistoricosAlteracaoWorkflowRH_Funcionarios_AlteradoPorId" FOREIGN KEY ("AlteradoPorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: HistoricosAlteracaoWorkflowRH FK_HistoricosAlteracaoWorkflowRH_WorkflowsRH_WorkflowId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "FK_HistoricosAlteracaoWorkflowRH_WorkflowsRH_WorkflowId" FOREIGN KEY ("WorkflowId") REFERENCES public."WorkflowsRH"("Id") ON DELETE CASCADE;


--
-- Name: Holerites FK_Holerites_Funcionarios_EnviadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holerites"
    ADD CONSTRAINT "FK_Holerites_Funcionarios_EnviadoPorId" FOREIGN KEY ("EnviadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: Holerites FK_Holerites_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holerites"
    ADD CONSTRAINT "FK_Holerites_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: InboxAttachments FK_InboxAttachments_InboxItems_InboxItemId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxAttachments"
    ADD CONSTRAINT "FK_InboxAttachments_InboxItems_InboxItemId" FOREIGN KEY ("InboxItemId") REFERENCES public."InboxItems"("Id") ON DELETE CASCADE;


--
-- Name: InboxItems FK_InboxItems_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxItems"
    ADD CONSTRAINT "FK_InboxItems_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE SET NULL;


--
-- Name: InboxItems FK_InboxItems_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxItems"
    ADD CONSTRAINT "FK_InboxItems_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE SET NULL;


--
-- Name: JobPositions FK_JobPositions_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "FK_JobPositions_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: JobPositions FK_JobPositions_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "FK_JobPositions_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id");


--
-- Name: JobPositions FK_JobPositions_NiveisHierarquicos_NivelHierarquicoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "FK_JobPositions_NiveisHierarquicos_NivelHierarquicoId" FOREIGN KEY ("NivelHierarquicoId") REFERENCES public."NiveisHierarquicos"("Id");


--
-- Name: LogsComunicacao FK_LogsComunicacao_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogsComunicacao"
    ADD CONSTRAINT "FK_LogsComunicacao_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: LogsComunicacao FK_LogsComunicacao_ProjetosVaga_ProjetoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogsComunicacao"
    ADD CONSTRAINT "FK_LogsComunicacao_ProjetosVaga_ProjetoId" FOREIGN KEY ("ProjetoId") REFERENCES public."ProjetosVaga"("Id") ON DELETE SET NULL;


--
-- Name: Metas FK_Metas_Funcionarios_CriadaPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Metas"
    ADD CONSTRAINT "FK_Metas_Funcionarios_CriadaPorId" FOREIGN KEY ("CriadaPorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: Metas FK_Metas_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Metas"
    ADD CONSTRAINT "FK_Metas_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: MoodEntries FK_MoodEntries_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MoodEntries"
    ADD CONSTRAINT "FK_MoodEntries_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: NineBoxAssessments FK_NineBoxAssessments_AvaliacaoCiclos_CicloAvaliacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "FK_NineBoxAssessments_AvaliacaoCiclos_CicloAvaliacaoId" FOREIGN KEY ("CicloAvaliacaoId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE SET NULL;


--
-- Name: NineBoxAssessments FK_NineBoxAssessments_Funcionarios_AvaliadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "FK_NineBoxAssessments_Funcionarios_AvaliadorId" FOREIGN KEY ("AvaliadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: NineBoxAssessments FK_NineBoxAssessments_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "FK_NineBoxAssessments_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: Notifications FK_Notifications_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "FK_Notifications_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: OcupacoesHistorico FK_OcupacoesHistorico_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OcupacoesHistorico"
    ADD CONSTRAINT "FK_OcupacoesHistorico_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: OcupacoesHistorico FK_OcupacoesHistorico_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OcupacoesHistorico"
    ADD CONSTRAINT "FK_OcupacoesHistorico_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: OneOnOneMeetings FK_OneOnOneMeetings_Users_CollaboratorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOnOneMeetings"
    ADD CONSTRAINT "FK_OneOnOneMeetings_Users_CollaboratorId" FOREIGN KEY ("CollaboratorId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: OneOnOneMeetings FK_OneOnOneMeetings_Users_ManagerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOnOneMeetings"
    ADD CONSTRAINT "FK_OneOnOneMeetings_Users_ManagerId" FOREIGN KEY ("ManagerId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: PerguntasEntrevistaSaida FK_PerguntasEntrevistaSaida_TemplatesEntrevistaSaida_TemplateId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PerguntasEntrevistaSaida"
    ADD CONSTRAINT "FK_PerguntasEntrevistaSaida_TemplatesEntrevistaSaida_TemplateId" FOREIGN KEY ("TemplateId") REFERENCES public."TemplatesEntrevistaSaida"("Id") ON DELETE CASCADE;


--
-- Name: PermissoesNivelVaga FK_PermissoesNivelVaga_NiveisHierarquicos_NivelHierarquicoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PermissoesNivelVaga"
    ADD CONSTRAINT "FK_PermissoesNivelVaga_NiveisHierarquicos_NivelHierarquicoId" FOREIGN KEY ("NivelHierarquicoId") REFERENCES public."NiveisHierarquicos"("Id") ON DELETE CASCADE;


--
-- Name: PermissoesNivelVaga FK_PermissoesNivelVaga_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PermissoesNivelVaga"
    ADD CONSTRAINT "FK_PermissoesNivelVaga_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: PessoaBloqueios FK_PessoaBloqueios_Pessoas_PessoaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PessoaBloqueios"
    ADD CONSTRAINT "FK_PessoaBloqueios_Pessoas_PessoaId" FOREIGN KEY ("PessoaId") REFERENCES public."Pessoas"("Id") ON DELETE RESTRICT;


--
-- Name: PreAdmissaoDependentes FK_PreAdmissaoDependentes_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDependentes"
    ADD CONSTRAINT "FK_PreAdmissaoDependentes_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE CASCADE;


--
-- Name: PreAdmissaoDocumentosSolicitados FK_PreAdmissaoDocumentosSolicitados_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentosSolicitados"
    ADD CONSTRAINT "FK_PreAdmissaoDocumentosSolicitados_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE CASCADE;


--
-- Name: PreAdmissaoDocumentos FK_PreAdmissaoDocumentos_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentos"
    ADD CONSTRAINT "FK_PreAdmissaoDocumentos_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE CASCADE;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Funcionarios_AprovadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Funcionarios_AprovadoPorId" FOREIGN KEY ("AprovadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: PreAdmissoes FK_PreAdmissoes_Funcionarios_RevisadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Funcionarios_RevisadoPorId" FOREIGN KEY ("RevisadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: PreAdmissoes FK_PreAdmissoes_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE SET NULL;


--
-- Name: ProjetoCandidatos FK_ProjetoCandidatos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "FK_ProjetoCandidatos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE RESTRICT;


--
-- Name: ProjetoCandidatos FK_ProjetoCandidatos_FasesProcesso_FaseAtualId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "FK_ProjetoCandidatos_FasesProcesso_FaseAtualId" FOREIGN KEY ("FaseAtualId") REFERENCES public."FasesProcesso"("Id") ON DELETE SET NULL;


--
-- Name: ProjetoCandidatos FK_ProjetoCandidatos_ProjetosVaga_ProjetoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "FK_ProjetoCandidatos_ProjetosVaga_ProjetoId" FOREIGN KEY ("ProjetoId") REFERENCES public."ProjetosVaga"("Id") ON DELETE CASCADE;


--
-- Name: ProjetosVaga FK_ProjetosVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetosVaga"
    ADD CONSTRAINT "FK_ProjetosVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: PropostasVaga FK_PropostasVaga_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "FK_PropostasVaga_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE RESTRICT;


--
-- Name: PropostasVaga FK_PropostasVaga_Candidaturas_CandidaturaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "FK_PropostasVaga_Candidaturas_CandidaturaId" FOREIGN KEY ("CandidaturaId") REFERENCES public."Candidaturas"("Id") ON DELETE SET NULL;


--
-- Name: PropostasVaga FK_PropostasVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "FK_PropostasVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE RESTRICT;


--
-- Name: RenderCoinBalances FK_RenderCoinBalances_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinBalances"
    ADD CONSTRAINT "FK_RenderCoinBalances_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: RenderCoinTransactions FK_RenderCoinTransactions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinTransactions"
    ADD CONSTRAINT "FK_RenderCoinTransactions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: RespostasCampoPersonalizadoVaga FK_RespostasCampoPersonalizadoVaga_CamposPersonalizadosVaga_Ca~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "FK_RespostasCampoPersonalizadoVaga_CamposPersonalizadosVaga_Ca~" FOREIGN KEY ("CampoId") REFERENCES public."CamposPersonalizadosVaga"("Id") ON DELETE CASCADE;


--
-- Name: RespostasCampoPersonalizadoVaga FK_RespostasCampoPersonalizadoVaga_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "FK_RespostasCampoPersonalizadoVaga_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: RespostasCampoPersonalizadoVaga FK_RespostasCampoPersonalizadoVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "FK_RespostasCampoPersonalizadoVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: RespostasEntrevistaSaida FK_RespostasEntrevistaSaida_EntrevistasSaida_EntrevistaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasEntrevistaSaida"
    ADD CONSTRAINT "FK_RespostasEntrevistaSaida_EntrevistasSaida_EntrevistaId" FOREIGN KEY ("EntrevistaId") REFERENCES public."EntrevistasSaida"("Id") ON DELETE CASCADE;


--
-- Name: RespostasEntrevistaSaida FK_RespostasEntrevistaSaida_PerguntasEntrevistaSaida_PerguntaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasEntrevistaSaida"
    ADD CONSTRAINT "FK_RespostasEntrevistaSaida_PerguntasEntrevistaSaida_PerguntaId" FOREIGN KEY ("PerguntaId") REFERENCES public."PerguntasEntrevistaSaida"("Id") ON DELETE RESTRICT;


--
-- Name: RoleMenus FK_RoleMenus_Menus_MenuId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RoleMenus"
    ADD CONSTRAINT "FK_RoleMenus_Menus_MenuId" FOREIGN KEY ("MenuId") REFERENCES public."Menus"("Id") ON DELETE CASCADE;


--
-- Name: RoleMenus FK_RoleMenus_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RoleMenus"
    ADD CONSTRAINT "FK_RoleMenus_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: SkillAliases FK_SkillAliases_Skills_SkillId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SkillAliases"
    ADD CONSTRAINT "FK_SkillAliases_Skills_SkillId" FOREIGN KEY ("SkillId") REFERENCES public."Skills"("Id") ON DELETE CASCADE;


--
-- Name: Skills FK_Skills_Skills_ParentSkillId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "FK_Skills_Skills_ParentSkillId" FOREIGN KEY ("ParentSkillId") REFERENCES public."Skills"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesAprovacaoEtapas FK_SolicitacoesAprovacaoEtapas_Funcionarios_AprovadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesAprovacaoEtapas"
    ADD CONSTRAINT "FK_SolicitacoesAprovacaoEtapas_Funcionarios_AprovadorId" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesBeneficio FK_SolicitacoesBeneficio_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesBeneficio"
    ADD CONSTRAINT "FK_SolicitacoesBeneficio_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDependente FK_SolicitacoesDependente_Dependentes_DependenteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDependente"
    ADD CONSTRAINT "FK_SolicitacoesDependente_Dependentes_DependenteId" FOREIGN KEY ("DependenteId") REFERENCES public."Dependentes"("Id");


--
-- Name: SolicitacoesDependente FK_SolicitacoesDependente_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDependente"
    ADD CONSTRAINT "FK_SolicitacoesDependente_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id");


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id");


--
-- Name: SolicitacoesEndereco FK_SolicitacoesEndereco_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesEndereco"
    ADD CONSTRAINT "FK_SolicitacoesEndereco_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesFerias FK_SolicitacoesFerias_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesFerias"
    ADD CONSTRAINT "FK_SolicitacoesFerias_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPagamentoExtra FK_SolicitacoesPagamentoExtra_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "FK_SolicitacoesPagamentoExtra_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPagamentoExtra FK_SolicitacoesPagamentoExtra_Funcionarios_ImportadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "FK_SolicitacoesPagamentoExtra_Funcionarios_ImportadoPorId" FOREIGN KEY ("ImportadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: SolicitacoesPagamentoExtra FK_SolicitacoesPagamentoExtra_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "FK_SolicitacoesPagamentoExtra_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_CentrosCusto_CentroCustoAtualId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoAtualId" FOREIGN KEY ("CentroCustoAtualId") REFERENCES public."CentrosCusto"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_CentrosCusto_NovoCentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_CentrosCusto_NovoCentroCustoId" FOREIGN KEY ("NovoCentroCustoId") REFERENCES public."CentrosCusto"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_JobPositions_CargoAtualId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_JobPositions_CargoAtualId" FOREIGN KEY ("CargoAtualId") REFERENCES public."JobPositions"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_JobPositions_NovoCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_JobPositions_NovoCargoId" FOREIGN KEY ("NovoCargoId") REFERENCES public."JobPositions"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Units_NovaUnidadeId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Units_NovaUnidadeId" FOREIGN KEY ("NovaUnidadeId") REFERENCES public."Units"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id");


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Candidatos_CandidatoContratadoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Candidatos_CandidatoContratadoId" FOREIGN KEY ("CandidatoContratadoId") REFERENCES public."Candidatos"("Id");


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_AprovadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_AprovadorId" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_DecisaoRHRevisadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_DecisaoRHRevisadoPorId" FOREIGN KEY ("DecisaoRHRevisadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_SubstituidoFuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_SubstituidoFuncionarioId" FOREIGN KEY ("SubstituidoFuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_MotivosRequisicaoVagaConfig_MotivoRequisic~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_MotivosRequisicaoVagaConfig_MotivoRequisic~" FOREIGN KEY ("MotivoRequisicaoId") REFERENCES public."MotivosRequisicaoVagaConfig"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE RESTRICT;


--
-- Name: SurveyAnswers FK_SurveyAnswers_SurveyResponses_ResponseId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyAnswers"
    ADD CONSTRAINT "FK_SurveyAnswers_SurveyResponses_ResponseId" FOREIGN KEY ("ResponseId") REFERENCES public."SurveyResponses"("Id") ON DELETE CASCADE;


--
-- Name: SurveyOptions FK_SurveyOptions_SurveyQuestions_QuestionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyOptions"
    ADD CONSTRAINT "FK_SurveyOptions_SurveyQuestions_QuestionId" FOREIGN KEY ("QuestionId") REFERENCES public."SurveyQuestions"("Id") ON DELETE CASCADE;


--
-- Name: SurveyQuestions FK_SurveyQuestions_Surveys_SurveyId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyQuestions"
    ADD CONSTRAINT "FK_SurveyQuestions_Surveys_SurveyId" FOREIGN KEY ("SurveyId") REFERENCES public."Surveys"("Id") ON DELETE CASCADE;


--
-- Name: SurveyResponses FK_SurveyResponses_Surveys_SurveyId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyResponses"
    ADD CONSTRAINT "FK_SurveyResponses_Surveys_SurveyId" FOREIGN KEY ("SurveyId") REFERENCES public."Surveys"("Id") ON DELETE CASCADE;


--
-- Name: TalentoCompetencias FK_TalentoCompetencias_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCompetencias"
    ADD CONSTRAINT "FK_TalentoCompetencias_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoCvImportJobs FK_TalentoCvImportJobs_TalentoDocumentos_TalentoDocumentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCvImportJobs"
    ADD CONSTRAINT "FK_TalentoCvImportJobs_TalentoDocumentos_TalentoDocumentoId" FOREIGN KEY ("TalentoDocumentoId") REFERENCES public."TalentoDocumentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoCvImportJobs FK_TalentoCvImportJobs_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCvImportJobs"
    ADD CONSTRAINT "FK_TalentoCvImportJobs_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoDocumentos FK_TalentoDocumentos_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoDocumentos"
    ADD CONSTRAINT "FK_TalentoDocumentos_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoExperiencias FK_TalentoExperiencias_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoExperiencias"
    ADD CONSTRAINT "FK_TalentoExperiencias_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoFormacoes FK_TalentoFormacoes_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoFormacoes"
    ADD CONSTRAINT "FK_TalentoFormacoes_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoTreinamentos FK_TalentoTreinamentos_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoTreinamentos"
    ADD CONSTRAINT "FK_TalentoTreinamentos_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: Talentos FK_Talentos_Pessoas_PessoaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Talentos"
    ADD CONSTRAINT "FK_Talentos_Pessoas_PessoaId" FOREIGN KEY ("PessoaId") REFERENCES public."Pessoas"("Id") ON DELETE RESTRICT;


--
-- Name: TenantConfiguracoes FK_TenantConfiguracoes_Funcionarios_AprovadorRhId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantConfiguracoes"
    ADD CONSTRAINT "FK_TenantConfiguracoes_Funcionarios_AprovadorRhId" FOREIGN KEY ("AprovadorRhId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: Turnos FK_Turnos_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Turnos"
    ADD CONSTRAINT "FK_Turnos_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: UnidadesLotacao FK_UnidadesLotacao_Funcionarios_OwnerFuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UnidadesLotacao"
    ADD CONSTRAINT "FK_UnidadesLotacao_Funcionarios_OwnerFuncionarioId" FOREIGN KEY ("OwnerFuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: UnidadesLotacao FK_UnidadesLotacao_UnidadesLotacao_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UnidadesLotacao"
    ADD CONSTRAINT "FK_UnidadesLotacao_UnidadesLotacao_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE RESTRICT;


--
-- Name: Units FK_Units_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Units"
    ADD CONSTRAINT "FK_Units_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: UserRoles FK_UserRoles_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "FK_UserRoles_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: UserRoles FK_UserRoles_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "FK_UserRoles_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: UserUnits FK_UserUnits_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserUnits"
    ADD CONSTRAINT "FK_UserUnits_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE CASCADE;


--
-- Name: UserUnits FK_UserUnits_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserUnits"
    ADD CONSTRAINT "FK_UserUnits_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: Users FK_Users_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "FK_Users_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: VagaBeneficios FK_VagaBeneficios_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaBeneficios"
    ADD CONSTRAINT "FK_VagaBeneficios_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaEtapas FK_VagaEtapas_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaEtapas"
    ADD CONSTRAINT "FK_VagaEtapas_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaPerguntas FK_VagaPerguntas_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaPerguntas"
    ADD CONSTRAINT "FK_VagaPerguntas_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaRequisitos FK_VagaRequisitos_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaRequisitos"
    ADD CONSTRAINT "FK_VagaRequisitos_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaUnifiedMatchingCaches FK_VagaUnifiedMatchingCaches_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaUnifiedMatchingCaches"
    ADD CONSTRAINT "FK_VagaUnifiedMatchingCaches_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: Vagas FK_Vagas_CategoriasSalariais_CategoriaSalarialId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_CategoriasSalariais_CategoriaSalarialId" FOREIGN KEY ("CategoriaSalarialId") REFERENCES public."CategoriasSalariais"("Id");


--
-- Name: Vagas FK_Vagas_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE RESTRICT;


--
-- Name: Vagas FK_Vagas_DescricoesCargo_DescricaoCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_DescricoesCargo_DescricaoCargoId" FOREIGN KEY ("DescricaoCargoId") REFERENCES public."DescricoesCargo"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_Desligamentos_OrigemDesligamentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Desligamentos_OrigemDesligamentoId" FOREIGN KEY ("OrigemDesligamentoId") REFERENCES public."Desligamentos"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_EixosVaga_EixoVagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_EixosVaga_EixoVagaId" FOREIGN KEY ("EixoVagaId") REFERENCES public."EixosVaga"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_Hierarquias_HierarquiaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Hierarquias_HierarquiaId" FOREIGN KEY ("HierarquiaId") REFERENCES public."Hierarquias"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id");


--
-- Name: Vagas FK_Vagas_Turnos_TurnoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Turnos_TurnoId" FOREIGN KEY ("TurnoId") REFERENCES public."Turnos"("Id");


--
-- Name: Vagas FK_Vagas_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id");


--
-- Name: Vagas FK_Vagas_Users_RecrutadorResponsavelUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Users_RecrutadorResponsavelUserId" FOREIGN KEY ("RecrutadorResponsavelUserId") REFERENCES public."Users"("Id") ON DELETE SET NULL;


--
-- Name: WorkflowsRH FK_WorkflowsRH_Funcionarios_ResponsavelId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_Funcionarios_ResponsavelId" FOREIGN KEY ("ResponsavelId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: WorkflowsRH FK_WorkflowsRH_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE SET NULL;


--
-- Name: WorkflowsRH FK_WorkflowsRH_SolicitacoesDesligamento_DesligamentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_SolicitacoesDesligamento_DesligamentoId" FOREIGN KEY ("DesligamentoId") REFERENCES public."SolicitacoesDesligamento"("Id");


--
-- Name: WorkflowsRH FK_WorkflowsRH_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 4eYtXaQlGhTapfNWsW0rRcwulxJcsx17v9vLKTi61rfdLgCxF6qWEMmxxLaV7bP

