--
-- PostgreSQL database dump
--

\restrict 7sf5tYfFEbBieg3TvamheNBLd8mJKFz08nUzVdDapDA9cvY1FdFqqboUHlSV7gw

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."Tenants" DROP CONSTRAINT IF EXISTS "FK_Tenants_Owners_CreatedByOwnerId";
ALTER TABLE IF EXISTS ONLY public."TenantScreens" DROP CONSTRAINT IF EXISTS "FK_TenantScreens_Tenants_TenantId";
ALTER TABLE IF EXISTS ONLY public."TenantScreens" DROP CONSTRAINT IF EXISTS "FK_TenantScreens_Owners_UpdatedByOwnerId";
ALTER TABLE IF EXISTS ONLY public."TenantPackages" DROP CONSTRAINT IF EXISTS "FK_TenantPackages_Tenants_TenantId";
ALTER TABLE IF EXISTS ONLY public."TenantPackages" DROP CONSTRAINT IF EXISTS "FK_TenantPackages_Owners_UpdatedByOwnerId";
ALTER TABLE IF EXISTS ONLY public."TenantModules" DROP CONSTRAINT IF EXISTS "FK_TenantModules_Tenants_TenantId";
ALTER TABLE IF EXISTS ONLY public."TenantModules" DROP CONSTRAINT IF EXISTS "FK_TenantModules_Owners_UpdatedByOwnerId";
ALTER TABLE IF EXISTS ONLY public."AiUsageRecords" DROP CONSTRAINT IF EXISTS "FK_AiUsageRecords_AiModels_AiModelId";
ALTER TABLE IF EXISTS ONLY public."AiModels" DROP CONSTRAINT IF EXISTS "FK_AiModels_AiProviderKeys_AiProviderKeyId";
DROP INDEX IF EXISTS public."IX_Tenants_CreatedByOwnerId";
DROP INDEX IF EXISTS public."IX_TenantScreens_UpdatedByOwnerId";
DROP INDEX IF EXISTS public."IX_TenantScreens_TenantId_NavItemId";
DROP INDEX IF EXISTS public."IX_TenantPackages_UpdatedByOwnerId";
DROP INDEX IF EXISTS public."IX_TenantPackages_TenantId_PackageKey";
DROP INDEX IF EXISTS public."IX_TenantModules_UpdatedByOwnerId";
DROP INDEX IF EXISTS public."IX_TenantModules_TenantId_ModuleKey";
DROP INDEX IF EXISTS public."IX_Owners_Email";
DROP INDEX IF EXISTS public."IX_AiUsageRecords_UserId";
DROP INDEX IF EXISTS public."IX_AiUsageRecords_TenantId";
DROP INDEX IF EXISTS public."IX_AiUsageRecords_Module";
DROP INDEX IF EXISTS public."IX_AiUsageRecords_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_AiUsageRecords_AiModelId";
DROP INDEX IF EXISTS public."IX_AiModels_AiProviderKeyId";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY public."Tenants" DROP CONSTRAINT IF EXISTS "PK_Tenants";
ALTER TABLE IF EXISTS ONLY public."TenantScreens" DROP CONSTRAINT IF EXISTS "PK_TenantScreens";
ALTER TABLE IF EXISTS ONLY public."TenantPackages" DROP CONSTRAINT IF EXISTS "PK_TenantPackages";
ALTER TABLE IF EXISTS ONLY public."TenantModules" DROP CONSTRAINT IF EXISTS "PK_TenantModules";
ALTER TABLE IF EXISTS ONLY public."Owners" DROP CONSTRAINT IF EXISTS "PK_Owners";
ALTER TABLE IF EXISTS ONLY public."OwnerAwsSettings" DROP CONSTRAINT IF EXISTS "PK_OwnerAwsSettings";
ALTER TABLE IF EXISTS ONLY public."AiUsageRecords" DROP CONSTRAINT IF EXISTS "PK_AiUsageRecords";
ALTER TABLE IF EXISTS ONLY public."AiProviderKeys" DROP CONSTRAINT IF EXISTS "PK_AiProviderKeys";
ALTER TABLE IF EXISTS ONLY public."AiModels" DROP CONSTRAINT IF EXISTS "PK_AiModels";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS public."Tenants";
DROP TABLE IF EXISTS public."TenantScreens";
DROP TABLE IF EXISTS public."TenantPackages";
DROP TABLE IF EXISTS public."TenantModules";
DROP TABLE IF EXISTS public."Owners";
DROP TABLE IF EXISTS public."OwnerAwsSettings";
DROP TABLE IF EXISTS public."AiUsageRecords";
DROP TABLE IF EXISTS public."AiProviderKeys";
DROP TABLE IF EXISTS public."AiModels";
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AiModels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiModels" (
    "Id" uuid NOT NULL,
    "AiProviderKeyId" uuid NOT NULL,
    "ModelId" character varying(120) NOT NULL,
    "DisplayName" character varying(160) NOT NULL,
    "IsDefault" boolean NOT NULL
);


--
-- Name: AiProviderKeys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiProviderKeys" (
    "Id" uuid NOT NULL,
    "Provider" character varying(64) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "EncryptedKey" character varying(500) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "IsDefault" boolean DEFAULT false NOT NULL
);


--
-- Name: AiUsageRecords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiUsageRecords" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid,
    "UserName" character varying(200),
    "Module" character varying(120) NOT NULL,
    "AiModelId" uuid NOT NULL,
    "Cost" numeric(18,6) NOT NULL,
    "ActionDescription" character varying(500),
    "RequestMessage" character varying(8000),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: OwnerAwsSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OwnerAwsSettings" (
    "Id" uuid NOT NULL,
    "AccessKeyIdEncrypted" text,
    "SecretAccessKeyEncrypted" text,
    "Region" character varying(50),
    "BucketName" character varying(200),
    "PresignedUrlExpirationMinutes" integer NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Owners" (
    "Id" uuid NOT NULL,
    "Email" character varying(256) NOT NULL,
    "PasswordHash" character varying(500) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantModules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantModules" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ModuleKey" character varying(64) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedByOwnerId" uuid
);


--
-- Name: TenantPackages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantPackages" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PackageKey" character varying(64) NOT NULL,
    "IsEnabled" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedByOwnerId" uuid
);


--
-- Name: TenantScreens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantScreens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NavItemId" character varying(64) NOT NULL,
    "Estado" character varying(16) DEFAULT 'ativo'::character varying NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedByOwnerId" uuid
);


--
-- Name: Tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Tenants" (
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "CreatedByOwnerId" uuid
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Data for Name: AiModels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiModels" ("Id", "AiProviderKeyId", "ModelId", "DisplayName", "IsDefault") FROM stdin;
cd98c103-cf7f-4519-8e0e-2a133279d3bc	20947a1e-9ebe-4b2c-8511-db58f5b0af0e	gemini-2.5-flash	Gemini 2.5 Flash	t
\.


--
-- Data for Name: AiProviderKeys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiProviderKeys" ("Id", "Provider", "Name", "EncryptedKey", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "IsDefault") FROM stdin;
20947a1e-9ebe-4b2c-8511-db58f5b0af0e	Gemini	Gemini_Lio	XbhPwvXEpyXKbgHRjkhNog==:p8QBwKXj2vQhXSemds0QCkR/IB785RGlphzrYj+5nRB28HD91sCM5T5jXlGSDbNQ	t	2026-04-27 09:52:16.868787-03	2026-04-27 09:52:16.868787-03	t
\.


--
-- Data for Name: AiUsageRecords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiUsageRecords" ("Id", "TenantId", "UserId", "UserName", "Module", "AiModelId", "Cost", "ActionDescription", "RequestMessage", "CreatedAtUtc") FROM stdin;
f5dc73ce-9d39-4353-9c8f-abbcc1a9da5e	liotecnica	\N		CvExtract	cd98c103-cf7f-4519-8e0e-2a133279d3bc	0.000000	Extrair dados do currículo	Extrair dados estruturados do currículo (JSON).	2026-04-27 10:02:45.36551-03
080effd3-b2fb-4c45-8d22-ca0a96550e61	liotecnica	\N		CvExtract	cd98c103-cf7f-4519-8e0e-2a133279d3bc	0.000000	Extrair dados do currículo	Extrair dados estruturados do currículo (JSON).	2026-04-27 11:24:53.589838-03
682bebb9-4b41-4bed-a35e-89df0732895d	liotecnica	\N		CvExtract	cd98c103-cf7f-4519-8e0e-2a133279d3bc	0.000000	Extrair dados do currículo	Extrair dados estruturados do currículo (JSON).	2026-04-27 11:53:39.726751-03
e77a28ca-4e0c-43b9-95eb-5ea541b0566e	liotecnica	\N		CvExtract	cd98c103-cf7f-4519-8e0e-2a133279d3bc	0.007025	Extrair dados do currículo	Extrair dados estruturados do currículo (JSON).	2026-04-27 11:59:06.17499-03
673935bd-5e18-4871-896c-7c79e006973f	liotecnica	\N		CvExtract	cd98c103-cf7f-4519-8e0e-2a133279d3bc	0.002264	Extrair dados do currículo	Extrair dados estruturados do currículo (JSON).	2026-04-27 12:55:51.315488-03
d67d2c3b-d22e-490a-abc3-1c1af059bff9	liotecnica	\N		CvExtract	cd98c103-cf7f-4519-8e0e-2a133279d3bc	0.003881	Extrair dados do currículo	Extrair dados estruturados do currículo (JSON).	2026-04-27 12:57:25.269292-03
\.


--
-- Data for Name: OwnerAwsSettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OwnerAwsSettings" ("Id", "AccessKeyIdEncrypted", "SecretAccessKeyEncrypted", "Region", "BucketName", "PresignedUrlExpirationMinutes", "UpdatedAtUtc") FROM stdin;
\.


--
-- Data for Name: Owners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Owners" ("Id", "Email", "PasswordHash", "IsActive", "CreatedAtUtc", "UpdatedAtUtc") FROM stdin;
d5823d79-9c97-433b-8f63-1a3be431eaa9	owner@dev.local	AQAAAAIAAYagAAAAEJ3GWPL0K2m51dMpdeUIBOemj8vMP9bYLRxbmgxQEolIkPw905Kx4ZETUv42cS6HLg==	t	2026-04-24 22:43:17.907253-03	2026-04-24 22:43:17.907253-03
\.


--
-- Data for Name: TenantModules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TenantModules" ("Id", "TenantId", "ModuleKey", "IsEnabled", "UpdatedAtUtc", "UpdatedByOwnerId") FROM stdin;
108e3ecf-164d-4ba2-9980-1168688173af	liotecnica	dashboard	t	2026-04-24 22:45:09.406791-03	\N
2af4f2dd-974d-424a-bf8d-fdf07e0e711b	liotecnica	portal-vagas	t	2026-04-24 22:45:09.406791-03	\N
55ed708c-ec44-4516-ac62-12b1d430fccf	liotecnica	configuracoes	t	2026-04-24 22:45:09.406791-03	\N
6ca2eeac-ee81-4041-807f-8c9dff2741d5	liotecnica	folha-pagamento	t	2026-04-24 22:45:09.406791-03	\N
7ac4d041-a062-4e03-b641-419ad67de828	liotecnica	admissao	t	2026-04-24 22:45:09.406791-03	\N
86bec3d1-888a-4b65-8185-bf7f63c3ecbf	liotecnica	relatorios	t	2026-04-24 22:45:09.406791-03	\N
8fd2fe08-8494-43fe-bbf5-235678cfb82d	liotecnica	candidatos	t	2026-04-24 22:45:09.406791-03	\N
a3e640df-4fe1-48ec-bc1c-cb3dd62422fe	liotecnica	administracao	t	2026-04-24 22:45:09.406791-03	\N
bfc1254b-50bd-49c4-a27c-2d2888531268	liotecnica	recrutamento	t	2026-04-24 22:45:09.406791-03	\N
d8e645cd-1514-49b7-81c0-98b59b6d5c24	liotecnica	cadastros	t	2026-04-24 22:45:09.406791-03	\N
f10f4c7d-5f1f-471f-a9a6-6ef233d282fb	liotecnica	matching	t	2026-04-24 22:45:09.406791-03	\N
f87cda6c-7cf9-4c47-806b-0a734c24721f	liotecnica	agenda	t	2026-04-24 22:45:09.406791-03	\N
0969a4fa-a89f-408b-b947-d0f980e263af	dev	configuracoes	t	2026-04-24 22:45:13.904108-03	\N
0bc14ea4-6bdb-424d-b8db-81b4bb21ec19	dev	relatorios	t	2026-04-24 22:45:13.904108-03	\N
35a81f2e-2787-43bf-94b0-8a19ce08e53b	dev	feedback	t	2026-04-24 22:45:13.904108-03	\N
61aa021f-9ce9-460a-8af5-69dfe6470586	dev	dashboard	t	2026-04-24 22:45:13.904108-03	\N
6a678376-e096-46ce-948e-8f9f880d62ae	dev	gestao	t	2026-04-24 22:45:13.904108-03	\N
8fafa43f-8cba-435e-b0bb-7e42d6523cf6	dev	administracao	t	2026-04-24 22:45:13.904108-03	\N
b0f3e795-0938-442b-81d6-080efca027b5	dev	desempenho	t	2026-04-24 22:45:13.904108-03	\N
c1f78034-df00-4312-8889-da2453294541	dev	portal-vagas	t	2026-04-24 22:45:13.904108-03	\N
c3b1e99f-39c5-452f-a98a-05a024853344	dev	matching	t	2026-04-24 22:45:13.904108-03	\N
cf99e431-5840-4293-810d-61ef36486365	dev	agenda	t	2026-04-24 22:45:13.904108-03	\N
d375afa4-ba16-49e7-bbde-96fd30f6de25	dev	cadastros	t	2026-04-24 22:45:13.904108-03	\N
d9eb63bd-a25f-46eb-a03a-e66ccc7c99ad	dev	folha-pagamento	t	2026-04-24 22:45:13.904108-03	\N
e4d8bace-b530-4f79-a0af-96ebde10c5a3	dev	admissao	t	2026-04-24 22:45:13.904108-03	\N
f2353cb3-c2bf-40a8-a472-d945cbbf0ece	dev	candidatos	t	2026-04-24 22:45:13.904108-03	\N
fca96054-8a14-4973-b1e3-7d91eda57db9	dev	recrutamento	t	2026-04-24 22:45:13.904108-03	\N
939a36e6-d681-4161-b13e-243f52f89b96	dev	ai	t	2026-04-26 11:25:50.082072-03	\N
fcf30878-6199-4175-bec4-9f3ad51ae635	liotecnica	ai	t	2026-04-26 12:05:13.872013-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
dcee815a-f473-4927-9127-4d387bde40bd	dev	totvs-rm	t	2026-04-26 15:11:02.997305-03	\N
40b30ae0-917f-4f8f-8335-42cf35af5c69	liotecnica	totvs-rm	t	2026-04-26 15:19:09.790884-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
db7a0fd2-1cb5-4699-b7b8-757c4ffb653e	liotecnica	feedback	t	2026-04-27 10:36:49.156934-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
d3ea028a-d5fe-4170-9d82-0c88db472178	liotecnica	desempenho	t	2026-04-27 10:36:49.716223-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
39976ec9-6937-4b33-8cbc-41a1205ffe53	liotecnica	gestao	t	2026-04-27 10:36:50.82229-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
\.


--
-- Data for Name: TenantPackages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TenantPackages" ("Id", "TenantId", "PackageKey", "IsEnabled", "UpdatedAtUtc", "UpdatedByOwnerId") FROM stdin;
4609ea0e-5742-4d65-9f29-cbf4f88398ab	liotecnica	recrutamento-selecao	t	2026-04-24 22:45:09.398651-03	\N
82c899aa-1da4-4ec8-a570-b6dac017ec68	dev	gestao-pessoas	t	2026-04-24 22:45:13.903364-03	\N
a13a5651-33bd-4ccf-b109-fdcd1310d57c	dev	recrutamento-selecao	t	2026-04-24 22:45:13.903364-03	\N
0b833804-c99e-4dc4-a389-d38741a1c124	liotecnica	gestao-pessoas	f	2026-04-27 10:36:53.050019-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
\.


--
-- Data for Name: TenantScreens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TenantScreens" ("Id", "TenantId", "NavItemId", "Estado", "UpdatedAtUtc", "UpdatedByOwnerId") FROM stdin;
0151a393-7dce-4174-ad68-dd16ede66dee	liotecnica	nav-admin-emails	ativo	2026-04-24 22:45:09.416835-03	\N
02a76b40-8ede-4ec4-8a2b-125186190c0a	liotecnica	nav-admin-organograma	ativo	2026-04-24 22:45:09.416835-03	\N
0b1c4781-cb99-498e-848c-db482fc6f290	liotecnica	nav-admissao	ativo	2026-04-24 22:45:09.416835-03	\N
1cdfdb19-1d74-480b-b1cc-381d93ec5a7f	liotecnica	nav-descricao-cargo	ativo	2026-04-24 22:45:09.416835-03	\N
1d3acce6-dfd7-40d7-8a5a-7898e29f4398	liotecnica	nav-admin-email-templates	ativo	2026-04-24 22:45:09.416835-03	\N
20ee8b79-24a1-4885-9b28-730b75f60500	liotecnica	nav-feedback-lista	ativo	2026-04-24 22:45:09.416835-03	\N
22a7880b-b168-4b7c-b9e9-ca10eb7fc7a8	liotecnica	nav-admin-headcount	ativo	2026-04-24 22:45:09.416835-03	\N
252d0a58-3ac0-45b2-ad3c-9c484a79790f	liotecnica	nav-admin-operational-logs	ativo	2026-04-24 22:45:09.416835-03	\N
268c0041-e963-4d78-86db-a6b3d68c713d	liotecnica	nav-pagamento-extra	ativo	2026-04-24 22:45:09.416835-03	\N
2ad79616-3e29-4580-9a53-a5ad0de3b6e2	liotecnica	nav-admin-api-keys	ativo	2026-04-24 22:45:09.416835-03	\N
2b35cc74-c958-4c7f-b130-99ee894b2330	liotecnica	nav-matching	ativo	2026-04-24 22:45:09.416835-03	\N
334ded5a-51b4-42cc-a656-55612561ad89	liotecnica	nav-desligamentos	ativo	2026-04-24 22:45:09.416835-03	\N
3798ce83-0d9f-49a3-ba77-a642fb268e94	liotecnica	nav-candidaturas	ativo	2026-04-24 22:45:09.416835-03	\N
393a903c-705f-4364-8c44-bf5fe25f447e	liotecnica	nav-admin-gestores	ativo	2026-04-24 22:45:09.416835-03	\N
3cf61a6a-42c5-436c-9c62-949bb7e90c1f	liotecnica	nav-cargos	ativo	2026-04-24 22:45:09.416835-03	\N
3e90e68e-b976-4bb9-964a-0c58824a0985	liotecnica	nav-funcionarios	ativo	2026-04-24 22:45:09.416835-03	\N
3ece8b60-9af6-4b99-8443-f147c42dae71	liotecnica	nav-portalvagas	ativo	2026-04-24 22:45:09.416835-03	\N
41ae7cad-e2e4-4aeb-a4dc-f4aee56d1115	liotecnica	nav-turnos	ativo	2026-04-24 22:45:09.416835-03	\N
42513433-9ec0-46c3-97df-f665573546bf	liotecnica	nav-admin-tenant-config	ativo	2026-04-24 22:45:09.416835-03	\N
48240b9b-b414-46cb-94cb-cef2818d64d2	liotecnica	nav-desempenho-ciclos	ativo	2026-04-24 22:45:09.416835-03	\N
48e1b78e-d237-445b-9084-b46300f92846	liotecnica	nav-resumo-atividades	ativo	2026-04-24 22:45:09.416835-03	\N
4b159767-4a1c-4b5b-9eb9-b18f9e3b049f	liotecnica	nav-painel-solicitacoes	ativo	2026-04-24 22:45:09.416835-03	\N
4e588cc2-9f31-42d7-9867-9c8b2cc294a3	liotecnica	nav-empresas	ativo	2026-04-24 22:45:09.416835-03	\N
560623f2-8271-4121-b746-29cb5d11ba78	liotecnica	nav-categorias-salariais	ativo	2026-04-24 22:45:09.416835-03	\N
5ed1690f-d608-4817-9b3d-edc8ecc2362a	liotecnica	nav-admin-localization	ativo	2026-04-24 22:45:09.416835-03	\N
60437890-6989-4355-bfa7-676f7227abb7	liotecnica	nav-planos-desenvolvimento	ativo	2026-04-24 22:45:09.416835-03	\N
66eb7337-2ede-40df-8482-03015cdb9000	liotecnica	nav-admin-roles	ativo	2026-04-24 22:45:09.416835-03	\N
71934c93-5ba4-4edc-8f36-21ffe8cf1039	liotecnica	nav-feedback-celebracao	ativo	2026-04-24 22:45:09.416835-03	\N
739e6e31-07d3-41a8-8a01-4c9aaa30b4ae	liotecnica	nav-centros-custo	ativo	2026-04-24 22:45:09.416835-03	\N
75f23bd4-d267-4db6-a26b-be94073444f5	liotecnica	nav-feedback-1a1	ativo	2026-04-24 22:45:09.416835-03	\N
761a537a-fd63-4a62-9390-07b3df6675b7	liotecnica	nav-admin-users	ativo	2026-04-24 22:45:09.416835-03	\N
769ba1ff-6056-4f88-81f7-37e4ca028667	liotecnica	nav-unidades	ativo	2026-04-24 22:45:09.416835-03	\N
787bcff2-1548-4514-915b-78b9195f984b	liotecnica	nav-desempenho-ninebox	ativo	2026-04-24 22:45:09.416835-03	\N
799ba04a-708d-41f8-b1e6-744e1fbf940a	liotecnica	nav-admin-email-config	ativo	2026-04-24 22:45:09.416835-03	\N
8722c445-e379-4d47-908a-040ef7c2682f	liotecnica	nav-admin-accesses	ativo	2026-04-24 22:45:09.416835-03	\N
8c229147-15f0-4171-bad9-def1d98d92c3	liotecnica	nav-batida-ponto	ativo	2026-04-24 22:45:09.416835-03	\N
8c9bff9a-7ddb-4ad5-a0cd-fe4b6af2eec8	liotecnica	nav-sla-vagas	ativo	2026-04-24 22:45:09.416835-03	\N
95132f54-2181-4bc3-abca-7da80bbebd25	liotecnica	nav-admin-entra-id	ativo	2026-04-24 22:45:09.416835-03	\N
970604cc-36cb-45a1-abf6-28db2515f6d0	liotecnica	nav-feedback-enviar	ativo	2026-04-24 22:45:09.416835-03	\N
9a668ed1-14e0-4c37-9368-60cbd594042f	liotecnica	nav-admin-logs	ativo	2026-04-24 22:45:09.416835-03	\N
a733c0b6-099e-41f8-b6d0-e9dac629f5c8	liotecnica	nav-desempenho-minhas	ativo	2026-04-24 22:45:09.416835-03	\N
aa8dd3ec-2a57-4265-9644-d6a317643839	liotecnica	nav-dashboard	ativo	2026-04-24 22:45:09.416835-03	\N
ae339898-5ae3-408e-b4d1-7a5ae8499c08	liotecnica	nav-painel-rh	ativo	2026-04-24 22:45:09.416835-03	\N
af32f7f4-f10a-4042-ac74-2319f4a11505	liotecnica	nav-admin-hierarquia	ativo	2026-04-24 22:45:09.416835-03	\N
be74aa1a-0be9-45b3-b590-39273cd6094b	liotecnica	nav-humor	ativo	2026-04-24 22:45:09.416835-03	\N
c040f03c-25c6-45e3-9021-37f6402c1077	liotecnica	nav-talentos	ativo	2026-04-24 22:45:09.416835-03	\N
cd0c6340-7243-47a7-a1f6-810dd1a68a89	liotecnica	nav-funil	ativo	2026-04-24 22:45:09.416835-03	\N
cf374703-4056-4d8c-bfc3-2db5b4854f27	liotecnica	nav-candidatos	ativo	2026-04-24 22:45:09.416835-03	\N
d8fc6ad7-8776-4abb-8638-11dff70a8ee6	liotecnica	nav-processo-seletivo	ativo	2026-04-24 22:45:09.416835-03	\N
db4f2d09-609b-4a79-bc62-4e94a9b22eca	liotecnica	nav-relatorios	ativo	2026-04-24 22:45:09.416835-03	\N
e6a69bd9-517e-4226-a2ed-cf7b370e657a	liotecnica	nav-admin-notif-templates	ativo	2026-04-24 22:45:09.416835-03	\N
e8dab8a6-7126-468b-aff2-aa044b1b0ded	liotecnica	nav-vagas	ativo	2026-04-24 22:45:09.416835-03	\N
eb752aa5-ab98-429b-b839-09cd7f641a3b	liotecnica	nav-gestao-dashboard	ativo	2026-04-24 22:45:09.416835-03	\N
f448e7ef-2148-472b-8275-ef99a5565a0c	liotecnica	nav-admin-tenant-branding	ativo	2026-04-24 22:45:09.416835-03	\N
fca981e5-ea1b-4225-bdc3-041acaa2e78f	liotecnica	nav-agendas	ativo	2026-04-24 22:45:09.416835-03	\N
fe85ead7-8aa3-44ea-b0fd-3ff187c31950	liotecnica	nav-admin-notif-candidatura	ativo	2026-04-24 22:45:09.416835-03	\N
05398374-e4c7-4ae4-8071-65e212de1441	dev	nav-admin-email-config	ativo	2026-04-24 22:45:13.904807-03	\N
0c69a83d-6fea-4a9a-97ce-2ea3d575a213	dev	nav-feedback-enviar	ativo	2026-04-24 22:45:13.904807-03	\N
12705e1e-d5af-43c6-afb1-a5b33768c82c	dev	nav-assistente-ia	ativo	2026-04-24 22:45:13.904807-03	\N
18ad374e-880c-4edc-b1ac-17c2e789ca85	dev	nav-empresas	ativo	2026-04-24 22:45:13.904807-03	\N
1da1e0ae-f5db-465f-b15e-f8d6fd3fd8bf	dev	nav-admin-tenant-config	ativo	2026-04-24 22:45:13.904807-03	\N
2636ba77-f3b1-43a4-8b00-83dbd216f73d	dev	nav-feedback-lista	ativo	2026-04-24 22:45:13.904807-03	\N
280b9e26-22b7-4b43-a99c-dc379fec0fee	dev	nav-admin-localization	ativo	2026-04-24 22:45:13.904807-03	\N
2c28060f-4f5b-4b08-b9a3-d24d3a13183a	dev	nav-solicitacoes	ativo	2026-04-24 22:45:13.904807-03	\N
33494201-fdd9-450f-a9ab-d0634d83bb34	dev	nav-dashboard	ativo	2026-04-24 22:45:13.904807-03	\N
37eb2c3e-3819-4746-b146-bf0520cb032a	dev	nav-resumo-atividades	ativo	2026-04-24 22:45:13.904807-03	\N
3a8229d7-7725-4b5c-8b1a-0b3f43ae640e	dev	nav-centros-custo	ativo	2026-04-24 22:45:13.904807-03	\N
41b57a92-160c-4d10-b3d7-ed5c27aaee7d	dev	nav-admin-logs	ativo	2026-04-24 22:45:13.904807-03	\N
47e01db3-f387-4614-b0e1-c9dc6bc26a9e	dev	nav-admin-email-templates	ativo	2026-04-24 22:45:13.904807-03	\N
4f1578fc-3110-4752-a316-c6d1f281a7a3	dev	nav-gestao-dashboard	ativo	2026-04-24 22:45:13.904807-03	\N
4fc87f62-e20d-4011-9313-76c91d5865f8	dev	nav-portalvagas	ativo	2026-04-24 22:45:13.904807-03	\N
5269f9a0-42cb-4e41-8fd4-8e4b7ed65819	dev	nav-admin-notif-templates	ativo	2026-04-24 22:45:13.904807-03	\N
54ffcd6a-2ed0-4c30-9282-c31258fdcd50	dev	nav-pessoas	ativo	2026-04-24 22:45:13.904807-03	\N
565238a8-3db8-4438-a297-c485dff49108	dev	nav-categorias-salariais	ativo	2026-04-24 22:45:13.904807-03	\N
598c3797-1616-4175-a9cd-6e5126c7332d	dev	nav-pagamento-extra	ativo	2026-04-24 22:45:13.904807-03	\N
68f131ef-efa6-485b-8b64-45137364ead5	dev	nav-feedback-1a1	ativo	2026-04-24 22:45:13.904807-03	\N
6e41d28d-3331-4c5d-b1b4-6caf5fa1d595	dev	nav-admin-operational-logs	ativo	2026-04-24 22:45:13.904807-03	\N
6e81e864-e9bd-415a-bb3d-ac0f8ad489c3	dev	nav-processo-seletivo	ativo	2026-04-24 22:45:13.904807-03	\N
70210996-2d07-4ece-b3ec-402c311ef02b	dev	nav-desempenho-ciclos	ativo	2026-04-24 22:45:13.904807-03	\N
7038de47-4bb4-4f0e-b2ee-83dfaa9cd52e	dev	nav-funil	ativo	2026-04-24 22:45:13.904807-03	\N
747d6504-d346-4d6e-a50d-4148c2d3eb93	dev	nav-relatorios	ativo	2026-04-24 22:45:13.904807-03	\N
92287a44-deb4-4d7c-b28d-252cad9c3217	liotecnica	nav-solicitacoes	oculto	2026-04-27 09:40:46.136123-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
66d4fe3e-49d9-406c-b683-83bb6d54549a	liotecnica	nav-unidades-lotacao	oculto	2026-04-27 11:16:57.632822-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
3f256520-9996-4b71-9059-14d7aef68034	liotecnica	nav-pessoas	oculto	2026-04-27 11:17:09.8992-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
8d3d0dad-c9f1-47ff-99af-4472ba01cb64	liotecnica	nav-admin-menus	oculto	2026-04-27 11:17:42.175145-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
f333b397-a263-4962-8b58-448580dfcd97	liotecnica	nav-aprovadores-alternativos	oculto	2026-04-27 11:17:48.98891-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
63616872-e384-4fdd-b6dc-0c262e13ac3d	liotecnica	nav-configuracao-aprovacoes	oculto	2026-04-27 11:17:50.824282-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
332d55bf-d948-4c98-a0c1-0a6fda655a8e	liotecnica	nav-triagem	ativo	2026-04-27 13:38:46.477626-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
7b6c1e48-c0f6-4a21-b73a-e209044db3bb	dev	nav-candidatos	ativo	2026-04-24 22:45:13.904807-03	\N
8096bfcd-983e-4b33-a6da-d236c7cf7e0a	dev	nav-vagas	ativo	2026-04-24 22:45:13.904807-03	\N
80f405eb-2892-4a75-bd1f-31142d3012fb	dev	nav-agendas	ativo	2026-04-24 22:45:13.904807-03	\N
85d2f854-d0c7-4a2a-8867-f5b19f8c5cb9	dev	nav-admin-organograma	ativo	2026-04-24 22:45:13.904807-03	\N
86d0f065-036a-43ef-8ac4-efa1e62a85c7	dev	nav-humor	ativo	2026-04-24 22:45:13.904807-03	\N
8935a380-ce81-4a29-b1d4-cdd087147ad9	dev	nav-desligamentos	ativo	2026-04-24 22:45:13.904807-03	\N
8bb72ee2-aa6f-4aa7-aa24-888597746e53	dev	nav-unidades-lotacao	ativo	2026-04-24 22:45:13.904807-03	\N
8e3b6d9c-a916-49b9-ada9-22578d1ecf62	dev	nav-cargos	ativo	2026-04-24 22:45:13.904807-03	\N
90c7de3e-1cd8-4d22-b8e9-fccdc141f674	dev	nav-turnos	ativo	2026-04-24 22:45:13.904807-03	\N
93685f90-73d4-45ee-932d-571c5b10c155	dev	nav-admin-tenant-branding	ativo	2026-04-24 22:45:13.904807-03	\N
94f591a3-5079-4157-9733-3cb1b56f61bc	dev	nav-painel-solicitacoes	ativo	2026-04-24 22:45:13.904807-03	\N
a041a2ec-6804-45fc-8607-3deb27052fa8	dev	nav-planos-desenvolvimento	ativo	2026-04-24 22:45:13.904807-03	\N
a45c8008-9b71-4766-9a1f-6fa0b229edcf	dev	nav-funcionarios	ativo	2026-04-24 22:45:13.904807-03	\N
a5c03853-5d95-4ab0-9017-610f776ae583	dev	nav-desempenho-minhas	ativo	2026-04-24 22:45:13.904807-03	\N
a86efe59-10a6-4723-abfb-366047827320	dev	nav-admin-entra-id	ativo	2026-04-24 22:45:13.904807-03	\N
b14a4196-516d-4717-b7f4-3ab1d7bef4ac	dev	nav-talentos	ativo	2026-04-24 22:45:13.904807-03	\N
b27ffc32-4c06-4fff-a6a3-8c672056b4ac	dev	nav-batida-ponto	ativo	2026-04-24 22:45:13.904807-03	\N
b2873b0e-8198-47ec-8bfc-6007f1a1cbbb	dev	nav-feedback-celebracao	ativo	2026-04-24 22:45:13.904807-03	\N
b8618790-d858-4962-b2f9-66cb8797614d	dev	nav-desempenho-ninebox	ativo	2026-04-24 22:45:13.904807-03	\N
bbd868d6-91b6-4bce-b5dd-9b7acfb85f94	dev	nav-candidaturas	ativo	2026-04-24 22:45:13.904807-03	\N
c0363521-8198-45f2-917d-73e057942b98	dev	nav-admin-api-keys	ativo	2026-04-24 22:45:13.904807-03	\N
c0da9e1a-d804-49e2-9e90-91692d19853a	dev	nav-configuracao-aprovacoes	ativo	2026-04-24 22:45:13.904807-03	\N
c54582a9-a655-4dc9-b33e-6bc56ee22816	dev	nav-admin-gestores	ativo	2026-04-24 22:45:13.904807-03	\N
cb97e9d8-c423-4440-81b9-576fe703b28e	dev	nav-descricao-cargo	ativo	2026-04-24 22:45:13.904807-03	\N
cd2867fc-2268-412b-9168-21f11b6555e6	dev	nav-aprovadores-alternativos	ativo	2026-04-24 22:45:13.904807-03	\N
d4a8af00-e867-4d68-9aa8-a535ccdbc349	dev	nav-unidades	ativo	2026-04-24 22:45:13.904807-03	\N
d6b122d2-1390-49d5-b0cf-f6ae2db7da0b	dev	nav-admin-headcount	ativo	2026-04-24 22:45:13.904807-03	\N
d8834f3d-68aa-482b-b109-e67804a0bd52	dev	nav-sla-vagas	ativo	2026-04-24 22:45:13.904807-03	\N
de48b1a8-2179-40a9-9643-5437d909e0d3	dev	nav-admin-roles	ativo	2026-04-24 22:45:13.904807-03	\N
e343da95-5bb1-4630-bdca-780fa5c432bf	dev	nav-admin-hierarquia	ativo	2026-04-24 22:45:13.904807-03	\N
e49c2ff6-b51b-41ca-a2ba-b04951b78d5e	dev	nav-admin-accesses	ativo	2026-04-24 22:45:13.904807-03	\N
e6aaf3c3-2d41-45b2-a2f1-1c843712cf82	dev	nav-admin-users	ativo	2026-04-24 22:45:13.904807-03	\N
e7fb62c3-c6d4-4082-855f-fc7c33afc38e	dev	nav-admin-doc-padrao	ativo	2026-04-24 22:45:13.904807-03	\N
e8f6389f-aeec-4391-8510-890c3856d31a	dev	nav-triagem	ativo	2026-04-24 22:45:13.904807-03	\N
edae5ade-e269-4be7-bc9d-25d967fbb4f7	dev	nav-painel-rh	ativo	2026-04-24 22:45:13.904807-03	\N
f17601bc-2d74-4678-a761-4d09d5327a15	dev	nav-admin-emails	ativo	2026-04-24 22:45:13.904807-03	\N
f4aa1e3a-0e19-4fb7-bbca-6a62024f74d2	dev	nav-aprovacoes	ativo	2026-04-24 22:45:13.904807-03	\N
f837051f-3438-4413-8ac1-8ef59e886814	dev	nav-matching	ativo	2026-04-24 22:45:13.904807-03	\N
f8bd5a0e-9ba1-41d6-97d2-9eb03c5c7ba8	dev	nav-admin-menus	ativo	2026-04-24 22:45:13.904807-03	\N
fb8f36d8-3db6-4d78-948c-a39f0c514b58	dev	nav-admissao	ativo	2026-04-24 22:45:13.904807-03	\N
ffeba2b7-a0cb-4275-a1d9-98dd5db1db26	dev	nav-admin-notif-candidatura	ativo	2026-04-24 22:45:13.904807-03	\N
551baa76-7f9a-4222-aaf1-031591859847	liotecnica	nav-admin-ia	ativo	2026-04-26 12:28:19.409347-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
67fe28bd-187b-4c5b-aa86-a9faf2b4166a	liotecnica	nav-aprovacoes	oculto	2026-04-27 09:45:36.212322-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
368db791-9469-4c60-8436-9c475e27c81c	liotecnica	nav-assistente-ia	ativo	2026-04-27 11:17:15.242131-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
7d77cf98-8413-4879-a6c5-978057c9fd2d	liotecnica	nav-admin-doc-padrao	ativo	2026-04-27 11:17:46.890237-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
\.


--
-- Data for Name: Tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Tenants" ("TenantId", "Name", "IsActive", "CreatedAtUtc", "UpdatedAtUtc", "CreatedByOwnerId") FROM stdin;
liotecnica	Liotecnica	t	2026-04-24 22:45:04.585532-03	2026-04-24 22:45:04.585532-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
dev	Dev	f	2026-04-24 22:45:09.452178-03	2026-04-27 11:22:14.395174-03	d5823d79-9c97-433b-8f63-1a3be431eaa9
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20260129140000_InitialMaster	8.0.11
20260130234549_AddTenantCreatedByOwner	8.0.11
20260131124354_AddAiModule	8.0.11
20260131160000_AddAiProviderKeyIsDefault	8.0.11
20260411080223_AddOwnerAwsSettings	8.0.11
20260417121734_AddTenantModules	8.0.11
20260417180257_AddTenantPackages	8.0.11
20260424233704_AddTenantScreens	8.0.11
\.


--
-- Name: AiModels PK_AiModels; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiModels"
    ADD CONSTRAINT "PK_AiModels" PRIMARY KEY ("Id");


--
-- Name: AiProviderKeys PK_AiProviderKeys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiProviderKeys"
    ADD CONSTRAINT "PK_AiProviderKeys" PRIMARY KEY ("Id");


--
-- Name: AiUsageRecords PK_AiUsageRecords; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiUsageRecords"
    ADD CONSTRAINT "PK_AiUsageRecords" PRIMARY KEY ("Id");


--
-- Name: OwnerAwsSettings PK_OwnerAwsSettings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OwnerAwsSettings"
    ADD CONSTRAINT "PK_OwnerAwsSettings" PRIMARY KEY ("Id");


--
-- Name: Owners PK_Owners; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Owners"
    ADD CONSTRAINT "PK_Owners" PRIMARY KEY ("Id");


--
-- Name: TenantModules PK_TenantModules; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantModules"
    ADD CONSTRAINT "PK_TenantModules" PRIMARY KEY ("Id");


--
-- Name: TenantPackages PK_TenantPackages; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantPackages"
    ADD CONSTRAINT "PK_TenantPackages" PRIMARY KEY ("Id");


--
-- Name: TenantScreens PK_TenantScreens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantScreens"
    ADD CONSTRAINT "PK_TenantScreens" PRIMARY KEY ("Id");


--
-- Name: Tenants PK_Tenants; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tenants"
    ADD CONSTRAINT "PK_Tenants" PRIMARY KEY ("TenantId");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: IX_AiModels_AiProviderKeyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AiModels_AiProviderKeyId" ON public."AiModels" USING btree ("AiProviderKeyId");


--
-- Name: IX_AiUsageRecords_AiModelId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AiUsageRecords_AiModelId" ON public."AiUsageRecords" USING btree ("AiModelId");


--
-- Name: IX_AiUsageRecords_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AiUsageRecords_CreatedAtUtc" ON public."AiUsageRecords" USING btree ("CreatedAtUtc");


--
-- Name: IX_AiUsageRecords_Module; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AiUsageRecords_Module" ON public."AiUsageRecords" USING btree ("Module");


--
-- Name: IX_AiUsageRecords_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AiUsageRecords_TenantId" ON public."AiUsageRecords" USING btree ("TenantId");


--
-- Name: IX_AiUsageRecords_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AiUsageRecords_UserId" ON public."AiUsageRecords" USING btree ("UserId");


--
-- Name: IX_Owners_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Owners_Email" ON public."Owners" USING btree ("Email");


--
-- Name: IX_TenantModules_TenantId_ModuleKey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantModules_TenantId_ModuleKey" ON public."TenantModules" USING btree ("TenantId", "ModuleKey");


--
-- Name: IX_TenantModules_UpdatedByOwnerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TenantModules_UpdatedByOwnerId" ON public."TenantModules" USING btree ("UpdatedByOwnerId");


--
-- Name: IX_TenantPackages_TenantId_PackageKey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantPackages_TenantId_PackageKey" ON public."TenantPackages" USING btree ("TenantId", "PackageKey");


--
-- Name: IX_TenantPackages_UpdatedByOwnerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TenantPackages_UpdatedByOwnerId" ON public."TenantPackages" USING btree ("UpdatedByOwnerId");


--
-- Name: IX_TenantScreens_TenantId_NavItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantScreens_TenantId_NavItemId" ON public."TenantScreens" USING btree ("TenantId", "NavItemId");


--
-- Name: IX_TenantScreens_UpdatedByOwnerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TenantScreens_UpdatedByOwnerId" ON public."TenantScreens" USING btree ("UpdatedByOwnerId");


--
-- Name: IX_Tenants_CreatedByOwnerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Tenants_CreatedByOwnerId" ON public."Tenants" USING btree ("CreatedByOwnerId");


--
-- Name: AiModels FK_AiModels_AiProviderKeys_AiProviderKeyId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiModels"
    ADD CONSTRAINT "FK_AiModels_AiProviderKeys_AiProviderKeyId" FOREIGN KEY ("AiProviderKeyId") REFERENCES public."AiProviderKeys"("Id") ON DELETE RESTRICT;


--
-- Name: AiUsageRecords FK_AiUsageRecords_AiModels_AiModelId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiUsageRecords"
    ADD CONSTRAINT "FK_AiUsageRecords_AiModels_AiModelId" FOREIGN KEY ("AiModelId") REFERENCES public."AiModels"("Id") ON DELETE RESTRICT;


--
-- Name: TenantModules FK_TenantModules_Owners_UpdatedByOwnerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantModules"
    ADD CONSTRAINT "FK_TenantModules_Owners_UpdatedByOwnerId" FOREIGN KEY ("UpdatedByOwnerId") REFERENCES public."Owners"("Id") ON DELETE SET NULL;


--
-- Name: TenantModules FK_TenantModules_Tenants_TenantId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantModules"
    ADD CONSTRAINT "FK_TenantModules_Tenants_TenantId" FOREIGN KEY ("TenantId") REFERENCES public."Tenants"("TenantId") ON DELETE CASCADE;


--
-- Name: TenantPackages FK_TenantPackages_Owners_UpdatedByOwnerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantPackages"
    ADD CONSTRAINT "FK_TenantPackages_Owners_UpdatedByOwnerId" FOREIGN KEY ("UpdatedByOwnerId") REFERENCES public."Owners"("Id") ON DELETE SET NULL;


--
-- Name: TenantPackages FK_TenantPackages_Tenants_TenantId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantPackages"
    ADD CONSTRAINT "FK_TenantPackages_Tenants_TenantId" FOREIGN KEY ("TenantId") REFERENCES public."Tenants"("TenantId") ON DELETE CASCADE;


--
-- Name: TenantScreens FK_TenantScreens_Owners_UpdatedByOwnerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantScreens"
    ADD CONSTRAINT "FK_TenantScreens_Owners_UpdatedByOwnerId" FOREIGN KEY ("UpdatedByOwnerId") REFERENCES public."Owners"("Id") ON DELETE SET NULL;


--
-- Name: TenantScreens FK_TenantScreens_Tenants_TenantId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantScreens"
    ADD CONSTRAINT "FK_TenantScreens_Tenants_TenantId" FOREIGN KEY ("TenantId") REFERENCES public."Tenants"("TenantId") ON DELETE CASCADE;


--
-- Name: Tenants FK_Tenants_Owners_CreatedByOwnerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Tenants"
    ADD CONSTRAINT "FK_Tenants_Owners_CreatedByOwnerId" FOREIGN KEY ("CreatedByOwnerId") REFERENCES public."Owners"("Id") ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 7sf5tYfFEbBieg3TvamheNBLd8mJKFz08nUzVdDapDA9cvY1FdFqqboUHlSV7gw

