--
-- PostgreSQL database dump
--

\restrict QAmxMxuwmw2sf3aCARohi2QZRAOIFKf9CCHWOcZA46SRaxnaJOLslnwy4Gc3tvZ

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_SolicitacoesDesligamento_DesligamentoId";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "FK_WorkflowsRH_Funcionarios_ResponsavelId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Users_RecrutadorResponsavelUserId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Turnos_TurnoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Hierarquias_HierarquiaId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_EixosVaga_EixoVagaId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_Desligamentos_OrigemDesligamentoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_DescricoesCargo_DescricaoCargoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "FK_Vagas_CategoriasSalariais_CategoriaSalarialId";
ALTER TABLE IF EXISTS ONLY public."VagaUnifiedMatchingCaches" DROP CONSTRAINT IF EXISTS "FK_VagaUnifiedMatchingCaches_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaRequisitos" DROP CONSTRAINT IF EXISTS "FK_VagaRequisitos_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaPerguntas" DROP CONSTRAINT IF EXISTS "FK_VagaPerguntas_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaEtapas" DROP CONSTRAINT IF EXISTS "FK_VagaEtapas_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."VagaBeneficios" DROP CONSTRAINT IF EXISTS "FK_VagaBeneficios_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."Users" DROP CONSTRAINT IF EXISTS "FK_Users_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."UserUnits" DROP CONSTRAINT IF EXISTS "FK_UserUnits_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."UserUnits" DROP CONSTRAINT IF EXISTS "FK_UserUnits_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "FK_UserRoles_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "FK_UserRoles_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."Units" DROP CONSTRAINT IF EXISTS "FK_Units_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."UnidadesLotacao" DROP CONSTRAINT IF EXISTS "FK_UnidadesLotacao_UnidadesLotacao_ParentId";
ALTER TABLE IF EXISTS ONLY public."UnidadesLotacao" DROP CONSTRAINT IF EXISTS "FK_UnidadesLotacao_Funcionarios_OwnerFuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Turnos" DROP CONSTRAINT IF EXISTS "FK_Turnos_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."TenantConfiguracoes" DROP CONSTRAINT IF EXISTS "FK_TenantConfiguracoes_Funcionarios_AprovadorRhId";
ALTER TABLE IF EXISTS ONLY public."Talentos" DROP CONSTRAINT IF EXISTS "FK_Talentos_Pessoas_PessoaId";
ALTER TABLE IF EXISTS ONLY public."TalentoTreinamentos" DROP CONSTRAINT IF EXISTS "FK_TalentoTreinamentos_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoFormacoes" DROP CONSTRAINT IF EXISTS "FK_TalentoFormacoes_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoExperiencias" DROP CONSTRAINT IF EXISTS "FK_TalentoExperiencias_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoDocumentos" DROP CONSTRAINT IF EXISTS "FK_TalentoDocumentos_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoCvImportJobs" DROP CONSTRAINT IF EXISTS "FK_TalentoCvImportJobs_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoCvImportJobs" DROP CONSTRAINT IF EXISTS "FK_TalentoCvImportJobs_TalentoDocumentos_TalentoDocumentoId";
ALTER TABLE IF EXISTS ONLY public."TalentoCompetencias" DROP CONSTRAINT IF EXISTS "FK_TalentoCompetencias_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."SurveyResponses" DROP CONSTRAINT IF EXISTS "FK_SurveyResponses_Surveys_SurveyId";
ALTER TABLE IF EXISTS ONLY public."SurveyQuestions" DROP CONSTRAINT IF EXISTS "FK_SurveyQuestions_Surveys_SurveyId";
ALTER TABLE IF EXISTS ONLY public."SurveyOptions" DROP CONSTRAINT IF EXISTS "FK_SurveyOptions_SurveyQuestions_QuestionId";
ALTER TABLE IF EXISTS ONLY public."SurveyAnswers" DROP CONSTRAINT IF EXISTS "FK_SurveyAnswers_SurveyResponses_ResponseId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_MotivosRequisicaoVagaConfig_MotivoRequisic~";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_SubstituidoFuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_DecisaoRHRevisadoPorId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Funcionarios_AprovadorId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesVaga_Candidatos_CandidatoContratadoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Units_NovaUnidadeId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_JobPositions_NovoCargoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_JobPositions_CargoAtualId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_CentrosCusto_NovoCentroCustoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoAtualId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPagamentoExtra_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPagamentoExtra_Funcionarios_ImportadoPorId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesPagamentoExtra_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesFerias" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesFerias_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesEndereco" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesEndereco_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDesligamento_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDependente" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDependente_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDependente" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesDependente_Dependentes_DependenteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesBeneficio" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesBeneficio_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesAprovacaoEtapas" DROP CONSTRAINT IF EXISTS "FK_SolicitacoesAprovacaoEtapas_Funcionarios_AprovadorId";
ALTER TABLE IF EXISTS ONLY public."Skills" DROP CONSTRAINT IF EXISTS "FK_Skills_Skills_ParentSkillId";
ALTER TABLE IF EXISTS ONLY public."SkillAliases" DROP CONSTRAINT IF EXISTS "FK_SkillAliases_Skills_SkillId";
ALTER TABLE IF EXISTS ONLY public."RoleMenus" DROP CONSTRAINT IF EXISTS "FK_RoleMenus_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."RoleMenus" DROP CONSTRAINT IF EXISTS "FK_RoleMenus_Menus_MenuId";
ALTER TABLE IF EXISTS ONLY public."RespostasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "FK_RespostasEntrevistaSaida_PerguntasEntrevistaSaida_PerguntaId";
ALTER TABLE IF EXISTS ONLY public."RespostasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "FK_RespostasEntrevistaSaida_EntrevistasSaida_EntrevistaId";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "FK_RespostasCampoPersonalizadoVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "FK_RespostasCampoPersonalizadoVaga_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "FK_RespostasCampoPersonalizadoVaga_CamposPersonalizadosVaga_Ca~";
ALTER TABLE IF EXISTS ONLY public."RenderCoinTransactions" DROP CONSTRAINT IF EXISTS "FK_RenderCoinTransactions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."RenderCoinBalances" DROP CONSTRAINT IF EXISTS "FK_RenderCoinBalances_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "FK_PropostasVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "FK_PropostasVaga_Candidaturas_CandidaturaId";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "FK_PropostasVaga_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."ProjetosVaga" DROP CONSTRAINT IF EXISTS "FK_ProjetosVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "FK_ProjetoCandidatos_ProjetosVaga_ProjetoId";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "FK_ProjetoCandidatos_FasesProcesso_FaseAtualId";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "FK_ProjetoCandidatos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Funcionarios_RevisadoPorId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Funcionarios_AprovadoPorId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissoes_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentos" DROP CONSTRAINT IF EXISTS "FK_PreAdmissaoDocumentos_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentosSolicitados" DROP CONSTRAINT IF EXISTS "FK_PreAdmissaoDocumentosSolicitados_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDependentes" DROP CONSTRAINT IF EXISTS "FK_PreAdmissaoDependentes_PreAdmissoes_PreAdmissaoId";
ALTER TABLE IF EXISTS ONLY public."PessoaBloqueios" DROP CONSTRAINT IF EXISTS "FK_PessoaBloqueios_Pessoas_PessoaId";
ALTER TABLE IF EXISTS ONLY public."PermissoesNivelVaga" DROP CONSTRAINT IF EXISTS "FK_PermissoesNivelVaga_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."PermissoesNivelVaga" DROP CONSTRAINT IF EXISTS "FK_PermissoesNivelVaga_NiveisHierarquicos_NivelHierarquicoId";
ALTER TABLE IF EXISTS ONLY public."PerguntasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "FK_PerguntasEntrevistaSaida_TemplatesEntrevistaSaida_TemplateId";
ALTER TABLE IF EXISTS ONLY public."OneOnOneMeetings" DROP CONSTRAINT IF EXISTS "FK_OneOnOneMeetings_Users_ManagerId";
ALTER TABLE IF EXISTS ONLY public."OneOnOneMeetings" DROP CONSTRAINT IF EXISTS "FK_OneOnOneMeetings_Users_CollaboratorId";
ALTER TABLE IF EXISTS ONLY public."OcupacoesHistorico" DROP CONSTRAINT IF EXISTS "FK_OcupacoesHistorico_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."OcupacoesHistorico" DROP CONSTRAINT IF EXISTS "FK_OcupacoesHistorico_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Notifications" DROP CONSTRAINT IF EXISTS "FK_Notifications_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "FK_NineBoxAssessments_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "FK_NineBoxAssessments_Funcionarios_AvaliadorId";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "FK_NineBoxAssessments_AvaliacaoCiclos_CicloAvaliacaoId";
ALTER TABLE IF EXISTS ONLY public."MoodEntries" DROP CONSTRAINT IF EXISTS "FK_MoodEntries_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."Metas" DROP CONSTRAINT IF EXISTS "FK_Metas_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Metas" DROP CONSTRAINT IF EXISTS "FK_Metas_Funcionarios_CriadaPorId";
ALTER TABLE IF EXISTS ONLY public."LogsComunicacao" DROP CONSTRAINT IF EXISTS "FK_LogsComunicacao_ProjetosVaga_ProjetoId";
ALTER TABLE IF EXISTS ONLY public."LogsComunicacao" DROP CONSTRAINT IF EXISTS "FK_LogsComunicacao_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "FK_JobPositions_NiveisHierarquicos_NivelHierarquicoId";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "FK_JobPositions_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "FK_JobPositions_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."InboxItems" DROP CONSTRAINT IF EXISTS "FK_InboxItems_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."InboxItems" DROP CONSTRAINT IF EXISTS "FK_InboxItems_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."InboxAttachments" DROP CONSTRAINT IF EXISTS "FK_InboxAttachments_InboxItems_InboxItemId";
ALTER TABLE IF EXISTS ONLY public."Holerites" DROP CONSTRAINT IF EXISTS "FK_Holerites_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."Holerites" DROP CONSTRAINT IF EXISTS "FK_Holerites_Funcionarios_EnviadoPorId";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_HistoricosAlteracaoWorkflowRH_WorkflowsRH_WorkflowId";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_HistoricosAlteracaoWorkflowRH_Funcionarios_AlteradoPorId";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_HistoricosAlteracaoWorkflowRH_EtapasWorkflowRH_EtapaWorkflo~";
ALTER TABLE IF EXISTS ONLY public."Hierarquias" DROP CONSTRAINT IF EXISTS "FK_Hierarquias_Hierarquias_HierarquiaSuperiorId";
ALTER TABLE IF EXISTS ONLY public."GamificationDailyStates" DROP CONSTRAINT IF EXISTS "FK_GamificationDailyStates_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Units_UnitId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_UnidadesLotacao_UnidadeLotacaoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Pessoas_PessoaId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_NiveisHierarquicos_NivelHierarquicoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Hierarquias_HierarquiaId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_Funcionarios_GestorDiretoId";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "FK_Funcionarios_CentrosCusto_CentroCustoId";
ALTER TABLE IF EXISTS ONLY public."FuncionarioMovimentacoes" DROP CONSTRAINT IF EXISTS "FK_FuncionarioMovimentacoes_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."FeedbackItems" DROP CONSTRAINT IF EXISTS "FK_FeedbackItems_Users_ToUserId";
ALTER TABLE IF EXISTS ONLY public."FeedbackItems" DROP CONSTRAINT IF EXISTS "FK_FeedbackItems_Users_FromUserId";
ALTER TABLE IF EXISTS ONLY public."FeedbackItemRatings" DROP CONSTRAINT IF EXISTS "FK_FeedbackItemRatings_FeedbackItems_FeedbackItemId";
ALTER TABLE IF EXISTS ONLY public."FasesProcesso" DROP CONSTRAINT IF EXISTS "FK_FasesProcesso_ProjetosVaga_ProjetoId";
ALTER TABLE IF EXISTS ONLY public."FaixasSalariais" DROP CONSTRAINT IF EXISTS "FK_FaixasSalariais_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."EtapasWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_EtapasWorkflowRH_WorkflowsRH_WorkflowId";
ALTER TABLE IF EXISTS ONLY public."EtapasWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_EtapasWorkflowRH_Funcionarios_ResponsavelId";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigWorkflowRH" DROP CONSTRAINT IF EXISTS "FK_EtapasConfigWorkflowRH_Roles_RoleFilaId";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigAprovacao" DROP CONSTRAINT IF EXISTS "FK_EtapasConfigAprovacao_Roles_RoleFilaId";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigAprovacao" DROP CONSTRAINT IF EXISTS "FK_EtapasConfigAprovacao_Funcionarios_FuncionarioFixoId";
ALTER TABLE IF EXISTS ONLY public."EmailAttempts" DROP CONSTRAINT IF EXISTS "FK_EmailAttempts_EmailMessages_EmailMessageId";
ALTER TABLE IF EXISTS ONLY public."DocumentosColaborador" DROP CONSTRAINT IF EXISTS "FK_DocumentosColaborador_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorNivelCargoConfigs" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoPorNivelCargoConfigs_NiveisCargo_NivelCar~";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorCargoConfigs" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoPorCargoConfigs_JobPositions_JobPositionId";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoHistoricos" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoHistoricos_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoHistoricos" DROP CONSTRAINT IF EXISTS "FK_DocumentacaoPadraoHistoricos_JobPositions_CargoId";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlans" DROP CONSTRAINT IF EXISTS "FK_DevelopmentPlans_Users_TargetUserId";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlans" DROP CONSTRAINT IF EXISTS "FK_DevelopmentPlans_Users_OwnerUserId";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlanGoals" DROP CONSTRAINT IF EXISTS "FK_DevelopmentPlanGoals_DevelopmentPlans_PlanId";
ALTER TABLE IF EXISTS ONLY public."Desligamentos" DROP CONSTRAINT IF EXISTS "FK_Desligamentos_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."DescricoesCargo" DROP CONSTRAINT IF EXISTS "FK_DescricoesCargo_NiveisCargo_NivelCargoId";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItens" DROP CONSTRAINT IF EXISTS "FK_DescricaoCargoItens_DescricoesCargo_DescricaoCargoId";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItemEmbeddings" DROP CONSTRAINT IF EXISTS "FK_DescricaoCargoItemEmbeddings_Item";
ALTER TABLE IF EXISTS ONLY public."Dependentes" DROP CONSTRAINT IF EXISTS "FK_Dependentes_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."DadosBancarios" DROP CONSTRAINT IF EXISTS "FK_DadosBancarios_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "FK_CentrosCusto_Funcionarios_OwnerFuncionarioId";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "FK_CentrosCusto_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "FK_CentrosCusto_CentrosCusto_ParentId";
ALTER TABLE IF EXISTS ONLY public."CelebrationPosts" DROP CONSTRAINT IF EXISTS "FK_CelebrationPosts_Users_AuthorId";
ALTER TABLE IF EXISTS ONLY public."CelebrationMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationMentions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."CelebrationMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationMentions_CelebrationPosts_PostId";
ALTER TABLE IF EXISTS ONLY public."CelebrationComments" DROP CONSTRAINT IF EXISTS "FK_CelebrationComments_Users_AuthorId";
ALTER TABLE IF EXISTS ONLY public."CelebrationComments" DROP CONSTRAINT IF EXISTS "FK_CelebrationComments_CelebrationPosts_PostId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentReactions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentReactions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentReactions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentReactions_CelebrationComments_CommentId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentMentions_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentMentions" DROP CONSTRAINT IF EXISTS "FK_CelebrationCommentMentions_CelebrationComments_CommentId";
ALTER TABLE IF EXISTS ONLY public."CategoriasSalariais" DROP CONSTRAINT IF EXISTS "FK_CategoriasSalariais_Units_EstabelecimentoId";
ALTER TABLE IF EXISTS ONLY public."CategoriasSalariais" DROP CONSTRAINT IF EXISTS "FK_CategoriasSalariais_Empresas_EmpresaId";
ALTER TABLE IF EXISTS ONLY public."CategoriaSalarialSteps" DROP CONSTRAINT IF EXISTS "FK_CategoriaSalarialSteps_CategoriasSalariais_CategoriaSalaria~";
ALTER TABLE IF EXISTS ONLY public."Candidaturas" DROP CONSTRAINT IF EXISTS "FK_Candidaturas_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."Candidaturas" DROP CONSTRAINT IF EXISTS "FK_Candidaturas_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidaturaEtapaHistoricos" DROP CONSTRAINT IF EXISTS "FK_CandidaturaEtapaHistoricos_Candidaturas_CandidaturaId";
ALTER TABLE IF EXISTS ONLY public."Candidatos" DROP CONSTRAINT IF EXISTS "FK_Candidatos_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."Candidatos" DROP CONSTRAINT IF EXISTS "FK_Candidatos_Talentos_TalentoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaMatchingScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaMatchingScores_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaMatchingScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaMatchingScores_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaLlmScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaLlmScores_Vaga";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaLlmScores" DROP CONSTRAINT IF EXISTS "FK_CandidatoVagaLlmScores_Candidato";
ALTER TABLE IF EXISTS ONLY public."CandidatoStatusHistories" DROP CONSTRAINT IF EXISTS "FK_CandidatoStatusHistories_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoReferencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoReferencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoProjetos" DROP CONSTRAINT IF EXISTS "FK_CandidatoProjetos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoPreferenciasVaga" DROP CONSTRAINT IF EXISTS "FK_CandidatoPreferenciasVaga_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoPortfolios" DROP CONSTRAINT IF EXISTS "FK_CandidatoPortfolios_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoNotificacaoPreferencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoNotificacaoPreferencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoLgpdConsents" DROP CONSTRAINT IF EXISTS "FK_CandidatoLgpdConsents_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoExperiencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoExperiencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoEmbeddings" DROP CONSTRAINT IF EXISTS "FK_CandidatoEmbeddings_Candidato";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoResumos" DROP CONSTRAINT IF EXISTS "FK_CandidatoEducacaoResumos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoItens" DROP CONSTRAINT IF EXISTS "FK_CandidatoEducacaoItens_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoDocumentos" DROP CONSTRAINT IF EXISTS "FK_CandidatoDocumentos_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoCompetencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoCompetencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoCertificacoes" DROP CONSTRAINT IF EXISTS "FK_CandidatoCertificacoes_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaPreferencias" DROP CONSTRAINT IF EXISTS "FK_CandidatoAgendaPreferencias_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaBloqueios" DROP CONSTRAINT IF EXISTS "FK_CandidatoAgendaBloqueios_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CandidatoAcessibilidades" DROP CONSTRAINT IF EXISTS "FK_CandidatoAcessibilidades_Candidatos_CandidatoId";
ALTER TABLE IF EXISTS ONLY public."CamposPersonalizadosVaga" DROP CONSTRAINT IF EXISTS "FK_CamposPersonalizadosVaga_Vagas_VagaId";
ALTER TABLE IF EXISTS ONLY public."BatchMatchingRunVagas" DROP CONSTRAINT IF EXISTS "FK_BatchMatchingRunVagas_BatchMatchingRuns_RunId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoRespostas_Funcionarios_AvaliandoId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoRespostas_Funcionarios_AvaliadorId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoRespostas_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoPerguntas" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoPerguntas_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoConvites_Funcionarios_AvaliandoId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoConvites_Funcionarios_AvaliadorId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoConvites_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCiclos" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCiclos_Funcionarios_CriadoPorId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCalibragens_NineBoxAssessments_NineBoxAssessmentId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCalibragens_Funcionarios_FuncionarioId";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "FK_AvaliacaoCalibragens_AvaliacaoCiclos_CicloId";
ALTER TABLE IF EXISTS ONLY public."AuditEvents" DROP CONSTRAINT IF EXISTS "FK_AuditEvents_AuditTransactions_AuditTransactionId";
ALTER TABLE IF EXISTS ONLY public."AuditEntityPropertyChanges" DROP CONSTRAINT IF EXISTS "FK_AuditEntityPropertyChanges_AuditEntityChanges_AuditEntityCha";
ALTER TABLE IF EXISTS ONLY public."AuditEntityChanges" DROP CONSTRAINT IF EXISTS "FK_AuditEntityChanges_AuditTransactions_AuditTransactionId";
ALTER TABLE IF EXISTS ONLY public."AuditEntityChanges" DROP CONSTRAINT IF EXISTS "FK_AuditEntityChanges_AuditEvents_AuditEventId";
ALTER TABLE IF EXISTS ONLY public."AspNetUserTokens" DROP CONSTRAINT IF EXISTS "FK_AspNetUserTokens_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."AspNetUserLogins" DROP CONSTRAINT IF EXISTS "FK_AspNetUserLogins_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."AspNetUserClaims" DROP CONSTRAINT IF EXISTS "FK_AspNetUserClaims_Users_UserId";
ALTER TABLE IF EXISTS ONLY public."AspNetRoleClaims" DROP CONSTRAINT IF EXISTS "FK_AspNetRoleClaims_Roles_RoleId";
ALTER TABLE IF EXISTS ONLY public."AprovadoresAlternativos" DROP CONSTRAINT IF EXISTS "FK_AprovadoresAlternativos_Gestor";
ALTER TABLE IF EXISTS ONLY public."AprovadoresAlternativos" DROP CONSTRAINT IF EXISTS "FK_AprovadoresAlternativos_Aprovador";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "FK_AprovacoesFaixaSalarial_Funcionarios_SolicitanteId";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "FK_AprovacoesFaixaSalarial_Funcionarios_AprovadorId";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "FK_AprovacoesFaixaSalarial_FaixasSalariais_FaixaSalarialId";
ALTER TABLE IF EXISTS ONLY public."AgendaEvents" DROP CONSTRAINT IF EXISTS "FK_AgendaEvents_AgendaEventTypes_TypeId";
DROP INDEX IF EXISTS public.idx_vagas_embedding;
DROP INDEX IF EXISTS public.idx_candidatos_embedding;
DROP INDEX IF EXISTS public."UserNameIndex";
DROP INDEX IF EXISTS public."RoleNameIndex";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_VagaId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_TenantId_TipoWorkflow_Status";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_ResponsavelId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_WorkflowsRH_DesligamentoId";
DROP INDEX IF EXISTS public."IX_Vagas_UnidadeLotacaoId";
DROP INDEX IF EXISTS public."IX_Vagas_TurnoId";
DROP INDEX IF EXISTS public."IX_Vagas_TenantId_Status";
DROP INDEX IF EXISTS public."IX_Vagas_TenantId_CentroCustoId";
DROP INDEX IF EXISTS public."IX_Vagas_RecrutadorResponsavelUserId";
DROP INDEX IF EXISTS public."IX_Vagas_OrigemTipo";
DROP INDEX IF EXISTS public."IX_Vagas_OrigemDesligamentoId";
DROP INDEX IF EXISTS public."IX_Vagas_JobPositionId";
DROP INDEX IF EXISTS public."IX_Vagas_IdReqRmOrigem";
DROP INDEX IF EXISTS public."IX_Vagas_HierarquiaId";
DROP INDEX IF EXISTS public."IX_Vagas_EixoVagaId";
DROP INDEX IF EXISTS public."IX_Vagas_DescricaoCargoId";
DROP INDEX IF EXISTS public."IX_Vagas_CentroCustoId";
DROP INDEX IF EXISTS public."IX_Vagas_CategoriaSalarialId";
DROP INDEX IF EXISTS public."IX_VagaUnifiedMatchingCaches_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaUnifiedMatchingCaches_TenantId_Status";
DROP INDEX IF EXISTS public."IX_VagaRequisitos_VagaId";
DROP INDEX IF EXISTS public."IX_VagaRequisitos_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaPerguntas_VagaId";
DROP INDEX IF EXISTS public."IX_VagaPerguntas_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaEtapas_VagaId";
DROP INDEX IF EXISTS public."IX_VagaEtapas_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_VagaBeneficios_VagaId";
DROP INDEX IF EXISTS public."IX_VagaBeneficios_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_Users_TenantId_NormalizedUserName";
DROP INDEX IF EXISTS public."IX_Users_TenantId_NormalizedEmail";
DROP INDEX IF EXISTS public."IX_Users_FuncionarioId";
DROP INDEX IF EXISTS public."IX_UserUnits_UnitId";
DROP INDEX IF EXISTS public."IX_UserRoles_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_UserRoles_TenantId_RoleId";
DROP INDEX IF EXISTS public."IX_UserRoles_RoleId";
DROP INDEX IF EXISTS public."IX_Units_TenantId_EmpresaId_Code";
DROP INDEX IF EXISTS public."IX_Units_EmpresaId";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_TenantId_CdnPlanoLotac_Code";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_ParentId";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_OwnerFuncionarioId";
DROP INDEX IF EXISTS public."IX_UnidadesLotacao_IsActive";
DROP INDEX IF EXISTS public."IX_Turnos_UnidadeLotacaoId";
DROP INDEX IF EXISTS public."IX_Turnos_TenantId_Code";
DROP INDEX IF EXISTS public."IX_Turnos_IsActive";
DROP INDEX IF EXISTS public."IX_TenantConfiguracoes_TenantId";
DROP INDEX IF EXISTS public."IX_TenantConfiguracoes_AprovadorRhId";
DROP INDEX IF EXISTS public."IX_TenantBrandings_TenantId";
DROP INDEX IF EXISTS public."IX_TemplatesEntrevistaSaida_TenantId_Ativo";
DROP INDEX IF EXISTS public."IX_Talentos_TenantId_PessoaId";
DROP INDEX IF EXISTS public."IX_Talentos_PessoaId";
DROP INDEX IF EXISTS public."IX_TalentoTreinamentos_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoTreinamentos_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoFormacoes_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoFormacoes_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoExperiencias_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoExperiencias_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoDocumentos_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoDocumentos_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TenantId_Status";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCvImportJobs_TalentoDocumentoId";
DROP INDEX IF EXISTS public."IX_TalentoCompetencias_TenantId_TalentoId";
DROP INDEX IF EXISTS public."IX_TalentoCompetencias_TalentoId";
DROP INDEX IF EXISTS public."IX_Surveys_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_SurveyResponses_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_SurveyResponses_TenantId_SurveyId_UserId";
DROP INDEX IF EXISTS public."IX_SurveyResponses_TenantId_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyResponses_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyQuestions_TenantId_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyQuestions_SurveyId";
DROP INDEX IF EXISTS public."IX_SurveyOptions_TenantId_QuestionId";
DROP INDEX IF EXISTS public."IX_SurveyOptions_QuestionId";
DROP INDEX IF EXISTS public."IX_SurveyAnswers_TenantId_ResponseId";
DROP INDEX IF EXISTS public."IX_SurveyAnswers_ResponseId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_UnitId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_TenantId_Status";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_TenantId_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_SubstituidoFuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_MotivoRequisicaoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_JobPositionId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_DecisaoRHRevisadoPorId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_CandidatoContratadoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesVaga_AprovadorId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_UnitId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_NovoCentroCustoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_NovoCargoId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_NovaUnidadeId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_FuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_CentroCustoAtualId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPromocao_CargoAtualId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPagamentoExtra_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPagamentoExtra_ImportadoPorId";
DROP INDEX IF EXISTS public."IX_SolicitacoesPagamentoExtra_FuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesFerias_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesEndereco_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_UnitId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_FuncionarioId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDesligamento_EmpresaId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDependente_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesDependente_DependenteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesBeneficio_SolicitanteId";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_TenantId_SolicitacaoId_TipoFluxo";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_TenantId_RoleFilaId_Status";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_Solicitacao";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_FilaPendente";
DROP INDEX IF EXISTS public."IX_SolicitacoesAprovacaoEtapas_AprovadorId";
DROP INDEX IF EXISTS public."IX_SlaStatusConfigs_TenantId_TipoEntidade_Status";
DROP INDEX IF EXISTS public."IX_Skills_TenantId_CanonicalName";
DROP INDEX IF EXISTS public."IX_Skills_ParentSkillId";
DROP INDEX IF EXISTS public."IX_SkillAliases_TenantId_AliasName";
DROP INDEX IF EXISTS public."IX_SkillAliases_SkillId";
DROP INDEX IF EXISTS public."IX_Roles_TenantId_NormalizedName";
DROP INDEX IF EXISTS public."IX_RoleMenus_TenantId_RoleId_MenuId_PermissionKey";
DROP INDEX IF EXISTS public."IX_RoleMenus_RoleId";
DROP INDEX IF EXISTS public."IX_RoleMenus_MenuId";
DROP INDEX IF EXISTS public."IX_RmSyncRuns_TenantId_Status";
DROP INDEX IF EXISTS public."IX_RmSyncRuns_TenantId_Entidade_StartedAtUtc";
DROP INDEX IF EXISTS public."IX_RmSyncCheckpoints_TenantId_Entidade";
DROP INDEX IF EXISTS public."IX_RmSyncAlertas_TenantId_Tipo_ChaveRm";
DROP INDEX IF EXISTS public."IX_RmSyncAlertas_TenantId_ResolvidoEmUtc";
DROP INDEX IF EXISTS public."IX_RespostasEntrevistaSaida_TenantId_EntrevistaId";
DROP INDEX IF EXISTS public."IX_RespostasEntrevistaSaida_PerguntaId";
DROP INDEX IF EXISTS public."IX_RespostasEntrevistaSaida_EntrevistaId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_VagaId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_TenantId_VagaId_CandidatoId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_CandidatoId";
DROP INDEX IF EXISTS public."IX_RespostasCampoPersonalizadoVaga_CampoId";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_TransactionId";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_StatusCode";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_StartedAt";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_Path";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_EnvironmentNormalized_StartedAt";
DROP INDEX IF EXISTS public."IX_RequestLogs_TenantId_DeviceId_StartedAt";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_UserId";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_TenantId_UserId_SourceType_SourceId";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_RenderCoinTransactions_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_RenderCoinBalances_UserId";
DROP INDEX IF EXISTS public."IX_RenderCoinBalances_TenantId_Balance";
DROP INDEX IF EXISTS public."IX_RecruiterMatchingFeedbacks_VagaId_CandidatoId";
DROP INDEX IF EXISTS public."IX_RecruiterMatchingFeedbacks_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_VagaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_TenantId_CandidaturaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_CandidaturaId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_CandidatoId";
DROP INDEX IF EXISTS public."IX_PropostasVaga_AccessToken";
DROP INDEX IF EXISTS public."IX_ProjetosVaga_VagaId";
DROP INDEX IF EXISTS public."IX_ProjetosVaga_TenantId_VagaId_Numero";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_TenantId_ProjetoId_CandidatoId";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_ProjetoId";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_FaseAtualId";
DROP INDEX IF EXISTS public."IX_ProjetoCandidatos_CandidatoId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_VagaId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_UnitId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_TenantId_Status";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_TenantId_Cpf";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_TenantId_AccessToken";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_RevisadoPorId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_JobPositionId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_CentroCustoId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_CandidatoId";
DROP INDEX IF EXISTS public."IX_PreAdmissoes_AprovadoPorId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentos_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentos_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentosSolicitados_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDocumentosSolicitados_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDependentes_TenantId_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_PreAdmissaoDependentes_PreAdmissaoId";
DROP INDEX IF EXISTS public."IX_Pessoas_TenantId_Email";
DROP INDEX IF EXISTS public."IX_Pessoas_TenantId_Cpf";
DROP INDEX IF EXISTS public."IX_PessoaBloqueios_TenantId_PessoaId";
DROP INDEX IF EXISTS public."IX_PessoaBloqueios_PessoaId";
DROP INDEX IF EXISTS public."IX_PermissoesNivelVaga_TenantId_NivelHierarquicoId_RoleId";
DROP INDEX IF EXISTS public."IX_PermissoesNivelVaga_RoleId";
DROP INDEX IF EXISTS public."IX_PermissoesNivelVaga_NivelHierarquicoId";
DROP INDEX IF EXISTS public."IX_PerguntasEntrevistaSaida_TenantId_TemplateId_Ordem";
DROP INDEX IF EXISTS public."IX_PerguntasEntrevistaSaida_TemplateId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_TenantId_MeetingDate";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_TenantId_ManagerId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_TenantId_CollaboratorId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_ManagerId";
DROP INDEX IF EXISTS public."IX_OneOnOneMeetings_CollaboratorId";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_VagaId";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_TenantId_FuncionarioId_DataSaida";
DROP INDEX IF EXISTS public."IX_OcupacoesHistorico_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Notifications_UserId";
DROP INDEX IF EXISTS public."IX_Notifications_TenantId_UserId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_Notifications_TenantId_IsRead";
DROP INDEX IF EXISTS public."IX_Notifications_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_NotificationReceipts_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_NotificationReceipts_TenantId_NotificationId_UserId";
DROP INDEX IF EXISTS public."IX_NotificationReceipts_TenantId_NotificationId";
DROP INDEX IF EXISTS public."IX_NotificacoesTemplates_TenantId_Etapa_Canal_Idioma";
DROP INDEX IF EXISTS public."IX_NotificacoesCandidaturaLogs_TenantId_CandidaturaId";
DROP INDEX IF EXISTS public."IX_NotificacoesCandidaturaLogs_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_NiveisHierarquicos_TenantId_Ordem";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_TenantId_CriadoEmUtc";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_TenantId_CicloAvaliacaoId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_FuncionarioId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_CicloAvaliacaoId";
DROP INDEX IF EXISTS public."IX_NineBoxAssessments_AvaliadorId";
DROP INDEX IF EXISTS public."IX_MotivosRequisicaoVagaConfig_TenantId_IsActive_Ordem";
DROP INDEX IF EXISTS public."IX_MotivosRequisicaoVagaConfig_TenantId_Codigo";
DROP INDEX IF EXISTS public."IX_MoodEntries_UserId";
DROP INDEX IF EXISTS public."IX_MoodEntries_TenantId_UserId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_Metas_TenantId_Status";
DROP INDEX IF EXISTS public."IX_Metas_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Metas_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Metas_CriadaPorId";
DROP INDEX IF EXISTS public."IX_Menus_TenantId_Route";
DROP INDEX IF EXISTS public."IX_Menus_TenantId_PermissionKey";
DROP INDEX IF EXISTS public."IX_LogsComunicacao_TenantId_CandidatoId_DataUtc";
DROP INDEX IF EXISTS public."IX_LogsComunicacao_ProjetoId";
DROP INDEX IF EXISTS public."IX_LogsComunicacao_CandidatoId";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_OccurredAt";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_Level";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_EnvironmentNormalized_OccurredAt";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_DeviceId_OccurredAt";
DROP INDEX IF EXISTS public."IX_LogEntries_TenantId_Category";
DROP INDEX IF EXISTS public."IX_LogEntries_RequestLogId_Order";
DROP INDEX IF EXISTS public."IX_LocalizationConfigs_TenantId";
DROP INDEX IF EXISTS public."IX_JobPositions_TenantId_TotvsCargoBasicId_TotvsNivCargoId";
DROP INDEX IF EXISTS public."IX_JobPositions_TenantId_Code";
DROP INDEX IF EXISTS public."IX_JobPositions_NivelHierarquicoId";
DROP INDEX IF EXISTS public."IX_JobPositions_NivelCargoId";
DROP INDEX IF EXISTS public."IX_JobPositions_CentroCustoId";
DROP INDEX IF EXISTS public."IX_InboxItems_VagaId";
DROP INDEX IF EXISTS public."IX_InboxItems_TenantId_Status";
DROP INDEX IF EXISTS public."IX_InboxItems_TenantId_RecebidoEm";
DROP INDEX IF EXISTS public."IX_InboxItems_TenantId_Origem";
DROP INDEX IF EXISTS public."IX_InboxItems_CandidatoId";
DROP INDEX IF EXISTS public."IX_InboxAttachments_TenantId_InboxItemId";
DROP INDEX IF EXISTS public."IX_InboxAttachments_InboxItemId";
DROP INDEX IF EXISTS public."IX_Holerites_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Holerites_EnviadoPorId";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_TipoEntidade_StatusNovo";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_TipoEntidade_EntidadeId";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_TipoEntidade_DentroDoSla";
DROP INDEX IF EXISTS public."IX_HistoricosStatus_TenantId_AlteradoEmUtc";
DROP INDEX IF EXISTS public."IX_HistoricosAlteracaoWorkflowRH_WorkflowId_DataAlteracaoUtc";
DROP INDEX IF EXISTS public."IX_HistoricosAlteracaoWorkflowRH_EtapaWorkflowId";
DROP INDEX IF EXISTS public."IX_HistoricosAlteracaoWorkflowRH_AlteradoPorId";
DROP INDEX IF EXISTS public."IX_Hierarquias_TenantId_IdHierarquiaRm";
DROP INDEX IF EXISTS public."IX_Hierarquias_IdHierarquiaSuperiorRm";
DROP INDEX IF EXISTS public."IX_Hierarquias_HierarquiaSuperiorId";
DROP INDEX IF EXISTS public."IX_Hierarquias_Estrutura";
DROP INDEX IF EXISTS public."IX_GamificationDailyStates_UserId";
DROP INDEX IF EXISTS public."IX_GamificationDailyStates_TenantId_UserId";
DROP INDEX IF EXISTS public."IX_GamificationDailyStates_TenantId_LastCheckInDate";
DROP INDEX IF EXISTS public."IX_Funcionarios_UserId";
DROP INDEX IF EXISTS public."IX_Funcionarios_UnitId";
DROP INDEX IF EXISTS public."IX_Funcionarios_UnidadeLotacaoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_MatriculaRm";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_Email";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_CodSituacaoRm";
DROP INDEX IF EXISTS public."IX_Funcionarios_TenantId_CdnEmpresa_CdnEstab_CdnFuncionario";
DROP INDEX IF EXISTS public."IX_Funcionarios_PessoaId";
DROP INDEX IF EXISTS public."IX_Funcionarios_NivelHierarquicoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_NivelCargoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_JobPositionId";
DROP INDEX IF EXISTS public."IX_Funcionarios_HierarquiaId";
DROP INDEX IF EXISTS public."IX_Funcionarios_GestorDiretoId";
DROP INDEX IF EXISTS public."IX_Funcionarios_CentroCustoId";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_TipoMovimentacao";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_TenantId_IdReqRm";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_FuncionarioId";
DROP INDEX IF EXISTS public."IX_FuncionarioMovimentacoes_ChapaRm";
DROP INDEX IF EXISTS public."IX_FluxosAprovacaoConfig_TenantId_TipoFluxo";
DROP INDEX IF EXISTS public."IX_FeedbackItems_ToUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItems_TenantId_ToUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItems_TenantId_FromUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItems_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_FeedbackItems_FromUserId";
DROP INDEX IF EXISTS public."IX_FeedbackItemRatings_FeedbackItemId";
DROP INDEX IF EXISTS public."IX_FasesProcesso_TenantId_ProjetoId_Ordem";
DROP INDEX IF EXISTS public."IX_FasesProcesso_ProjetoId";
DROP INDEX IF EXISTS public."IX_FaixasSalariais_TenantId_JobPositionId_EstabelecimentoCodigo";
DROP INDEX IF EXISTS public."IX_FaixasSalariais_JobPositionId";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_TransactionId";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_StatusCode";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_OccurredAt";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_ExceptionType";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_EnvironmentNormalized_OccurredAt";
DROP INDEX IF EXISTS public."IX_ExceptionLogs_TenantId_DeviceId_OccurredAt";
DROP INDEX IF EXISTS public."IX_EtapasWorkflowRH_WorkflowId_Ordem";
DROP INDEX IF EXISTS public."IX_EtapasWorkflowRH_ResponsavelId";
DROP INDEX IF EXISTS public."IX_EtapasConfigWorkflowRH_TenantId_TipoWorkflow_Ordem";
DROP INDEX IF EXISTS public."IX_EtapasConfigWorkflowRH_RoleFilaId";
DROP INDEX IF EXISTS public."IX_EtapasConfigAprovacao_TenantId_TipoFluxo_Ordem";
DROP INDEX IF EXISTS public."IX_EtapasConfigAprovacao_RoleFilaId";
DROP INDEX IF EXISTS public."IX_EtapasConfigAprovacao_FuncionarioFixoId";
DROP INDEX IF EXISTS public."IX_EntrevistasSaida_TenantId_Token";
DROP INDEX IF EXISTS public."IX_EntrevistasSaida_TenantId_DesligamentoId";
DROP INDEX IF EXISTS public."IX_EntraIdConfigs_TenantId";
DROP INDEX IF EXISTS public."IX_Empresas_TenantId_Code";
DROP INDEX IF EXISTS public."IX_EmailTemplates_TenantId_Name_Version";
DROP INDEX IF EXISTS public."IX_EmailTemplates_TenantId_Name_IsActive";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_Status";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_OwnerUserId";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_IsSystem";
DROP INDEX IF EXISTS public."IX_EmailMessages_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_EmailConfigs_TenantId";
DROP INDEX IF EXISTS public."IX_EmailAttempts_TenantId_StartedAtUtc";
DROP INDEX IF EXISTS public."IX_EmailAttempts_TenantId_EmailMessageId";
DROP INDEX IF EXISTS public."IX_EmailAttempts_EmailMessageId";
DROP INDEX IF EXISTS public."IX_EixosVaga_TenantId_Code";
DROP INDEX IF EXISTS public."IX_EixosVaga_IsActive";
DROP INDEX IF EXISTS public."IX_DocumentosColaborador_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_DocumentosColaborador_FuncionarioId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoI~";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorNivelCargoConfigs_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId_Ti~";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoPorCargoConfigs_JobPositionId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_CargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_TenantId_CriadoEmUtc";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoHistoricos_CargoId";
DROP INDEX IF EXISTS public."IX_DocumentacaoPadraoConfigs_TenantId_TipoDocumento";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_TenantId_TargetUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_TenantId_OwnerUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_TargetUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlans_OwnerUserId";
DROP INDEX IF EXISTS public."IX_DevelopmentPlanGoals_PlanId";
DROP INDEX IF EXISTS public."IX_Desligamentos_TenantId_IdReqRm";
DROP INDEX IF EXISTS public."IX_Desligamentos_GerouSubstituicao";
DROP INDEX IF EXISTS public."IX_Desligamentos_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Desligamentos_CodStatus";
DROP INDEX IF EXISTS public."IX_Desligamentos_ChapaRm";
DROP INDEX IF EXISTS public."IX_DescricoesCargo_TenantId_Code";
DROP INDEX IF EXISTS public."IX_DescricoesCargo_NivelCargoId";
DROP INDEX IF EXISTS public."IX_DescricoesCargo_IsActive";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItens_TenantId_DescricaoCargoId_Categoria";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItens_TenantId_DescricaoCargoId";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItens_DescricaoCargoId";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_Tenant_Item";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_TenantId";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_Item";
DROP INDEX IF EXISTS public."IX_DescricaoCargoItemEmbeddings_Ann";
DROP INDEX IF EXISTS public."IX_Dependentes_TenantId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_Dependentes_FuncionarioId";
DROP INDEX IF EXISTS public."IX_DadosBancarios_FuncionarioId";
DROP INDEX IF EXISTS public."IX_CentrosCusto_TenantId_EmpresaId_Code";
DROP INDEX IF EXISTS public."IX_CentrosCusto_ParentId";
DROP INDEX IF EXISTS public."IX_CentrosCusto_OwnerFuncionarioId";
DROP INDEX IF EXISTS public."IX_CentrosCusto_IsActive";
DROP INDEX IF EXISTS public."IX_CentrosCusto_EmpresaId";
DROP INDEX IF EXISTS public."IX_CelebrationPosts_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_CelebrationPosts_AuthorId";
DROP INDEX IF EXISTS public."IX_CelebrationMentions_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationMentions_PostId";
DROP INDEX IF EXISTS public."IX_CelebrationComments_TenantId_PostId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_CelebrationComments_PostId";
DROP INDEX IF EXISTS public."IX_CelebrationComments_AuthorId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_CommentId_UserId_Type";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_CommentId_Type";
DROP INDEX IF EXISTS public."IX_CelebrationCommentReactions_CommentId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentMentions_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentMentions_CommentId_UserId";
DROP INDEX IF EXISTS public."IX_CelebrationCommentMentions_CommentId";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Co~";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Cod";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_IsActive";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_EstabelecimentoId";
DROP INDEX IF EXISTS public."IX_CategoriasSalariais_EmpresaId";
DROP INDEX IF EXISTS public."IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId_Percentu";
DROP INDEX IF EXISTS public."IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId";
DROP INDEX IF EXISTS public."IX_CategoriaSalarialSteps_CategoriaSalarialId";
DROP INDEX IF EXISTS public."IX_Cargos_TenantId_Code";
DROP INDEX IF EXISTS public."IX_Cargos_IsActive";
DROP INDEX IF EXISTS public."IX_Candidaturas_VagaId";
DROP INDEX IF EXISTS public."IX_Candidaturas_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_Candidaturas_TenantId_CandidatoId_VagaId";
DROP INDEX IF EXISTS public."IX_Candidaturas_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_Candidaturas_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidaturaEtapaHistoricos_TenantId_CandidaturaId";
DROP INDEX IF EXISTS public."IX_CandidaturaEtapaHistoricos_CandidaturaId";
DROP INDEX IF EXISTS public."IX_Candidatos_VagaId";
DROP INDEX IF EXISTS public."IX_Candidatos_TenantId_VagaId";
DROP INDEX IF EXISTS public."IX_Candidatos_TenantId_Email";
DROP INDEX IF EXISTS public."IX_Candidatos_TalentoId";
DROP INDEX IF EXISTS public."IX_CandidatoVagaMatchingScores_VagaId_Score";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_Vaga";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_Tenant_Vaga_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_TenantId";
DROP INDEX IF EXISTS public."IX_CandidatoVagaLlmScores_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoStatusHistories_TenantId_CandidatoId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_CandidatoStatusHistories_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoStatusHistories_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoReferencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoReferencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoProjetos_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoProjetos_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPreferenciasVaga_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPreferenciasVaga_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPortfolios_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoPortfolios_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoNotificacaoPreferencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoNotificacaoPreferencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoLgpdConsents_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoLgpdConsents_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoExperiencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoExperiencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_Tenant_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_TenantId";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_Candidato";
DROP INDEX IF EXISTS public."IX_CandidatoEmbeddings_Ann";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoResumos_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoResumos_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoItens_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoEducacaoItens_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoDocumentos_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoDocumentos_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCompetencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCompetencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCertificacoes_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoCertificacoes_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaPreferencias_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaPreferencias_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaBloqueios_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAgendaBloqueios_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAcessibilidades_TenantId_CandidatoId";
DROP INDEX IF EXISTS public."IX_CandidatoAcessibilidades_CandidatoId";
DROP INDEX IF EXISTS public."IX_CamposPersonalizadosVaga_VagaId";
DROP INDEX IF EXISTS public."IX_CamposPersonalizadosVaga_TenantId_VagaId_Ordem";
DROP INDEX IF EXISTS public."IX_BatchMatchingRuns_TenantId_CreatedAtUtc";
DROP INDEX IF EXISTS public."IX_BatchMatchingRunVagas_RunId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_TenantId_CicloId_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_CicloId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoRespostas_AvaliadorId";
DROP INDEX IF EXISTS public."IX_AvaliacaoPerguntas_CicloId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_TenantId_CicloId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_TenantId_CicloId_AvaliadorId_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_TenantId_AvaliadorId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_CicloId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_AvaliandoId";
DROP INDEX IF EXISTS public."IX_AvaliacaoConvites_AvaliadorId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCiclos_TenantId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoCiclos_CriadoPorId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_TenantId_CicloId_Status";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_TenantId_CicloId_FuncionarioId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_NineBoxAssessmentId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_FuncionarioId";
DROP INDEX IF EXISTS public."IX_AvaliacaoCalibragens_CicloId";
DROP INDEX IF EXISTS public."IX_AuditTransactions_UserId";
DROP INDEX IF EXISTS public."IX_AuditTransactions_TransactionId";
DROP INDEX IF EXISTS public."IX_AuditTransactions_TenantId_StartedAt";
DROP INDEX IF EXISTS public."IX_AuditTransactions_StatusCode";
DROP INDEX IF EXISTS public."IX_AuditTransactions_StartedAt";
DROP INDEX IF EXISTS public."IX_AuditTransactions_Path";
DROP INDEX IF EXISTS public."IX_AuditEvents_AuditTransactionId_Order";
DROP INDEX IF EXISTS public."IX_AuditEntityPropertyChanges_AuditEntityChangeId";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_TenantId_OccurredAt";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_TenantId_EntityName";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_AuditTransactionId";
DROP INDEX IF EXISTS public."IX_AuditEntityChanges_AuditEventId";
DROP INDEX IF EXISTS public."IX_AspNetUserLogins_UserId";
DROP INDEX IF EXISTS public."IX_AspNetUserClaims_UserId";
DROP INDEX IF EXISTS public."IX_AspNetRoleClaims_RoleId";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_TenantId_GestorId";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_TenantGestor";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_GestorId";
DROP INDEX IF EXISTS public."IX_AprovadoresAlternativos_AprovadorId";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_TenantId_Status";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_SolicitanteId";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_FaixaSalarialId";
DROP INDEX IF EXISTS public."IX_AprovacoesFaixaSalarial_AprovadorId";
DROP INDEX IF EXISTS public."IX_ApprovalMagicLinks_TenantId_Token";
DROP INDEX IF EXISTS public."IX_ApiKeys_TenantId_Name";
DROP INDEX IF EXISTS public."IX_ApiKeys_TenantId_KeyHash";
DROP INDEX IF EXISTS public."IX_AgendaEvents_TypeId";
DROP INDEX IF EXISTS public."IX_AgendaEvents_TenantId_StartAtUtc";
DROP INDEX IF EXISTS public."IX_AgendaEventTypes_TenantId_Code";
DROP INDEX IF EXISTS public."EmailIndex";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY public."WorkflowsRH" DROP CONSTRAINT IF EXISTS "PK_WorkflowsRH";
ALTER TABLE IF EXISTS ONLY public."Vagas" DROP CONSTRAINT IF EXISTS "PK_Vagas";
ALTER TABLE IF EXISTS ONLY public."VagaUnifiedMatchingCaches" DROP CONSTRAINT IF EXISTS "PK_VagaUnifiedMatchingCaches";
ALTER TABLE IF EXISTS ONLY public."VagaRequisitos" DROP CONSTRAINT IF EXISTS "PK_VagaRequisitos";
ALTER TABLE IF EXISTS ONLY public."VagaPerguntas" DROP CONSTRAINT IF EXISTS "PK_VagaPerguntas";
ALTER TABLE IF EXISTS ONLY public."VagaEtapas" DROP CONSTRAINT IF EXISTS "PK_VagaEtapas";
ALTER TABLE IF EXISTS ONLY public."VagaBeneficios" DROP CONSTRAINT IF EXISTS "PK_VagaBeneficios";
ALTER TABLE IF EXISTS ONLY public."Users" DROP CONSTRAINT IF EXISTS "PK_Users";
ALTER TABLE IF EXISTS ONLY public."UserUnits" DROP CONSTRAINT IF EXISTS "PK_UserUnits";
ALTER TABLE IF EXISTS ONLY public."UserRoles" DROP CONSTRAINT IF EXISTS "PK_UserRoles";
ALTER TABLE IF EXISTS ONLY public."Units" DROP CONSTRAINT IF EXISTS "PK_Units";
ALTER TABLE IF EXISTS ONLY public."UnidadesLotacao" DROP CONSTRAINT IF EXISTS "PK_UnidadesLotacao";
ALTER TABLE IF EXISTS ONLY public."Turnos" DROP CONSTRAINT IF EXISTS "PK_Turnos";
ALTER TABLE IF EXISTS ONLY public."TenantConfiguracoes" DROP CONSTRAINT IF EXISTS "PK_TenantConfiguracoes";
ALTER TABLE IF EXISTS ONLY public."TenantBrandings" DROP CONSTRAINT IF EXISTS "PK_TenantBrandings";
ALTER TABLE IF EXISTS ONLY public."TenantAwsSettings" DROP CONSTRAINT IF EXISTS "PK_TenantAwsSettings";
ALTER TABLE IF EXISTS ONLY public."TemplatesEntrevistaSaida" DROP CONSTRAINT IF EXISTS "PK_TemplatesEntrevistaSaida";
ALTER TABLE IF EXISTS ONLY public."Talentos" DROP CONSTRAINT IF EXISTS "PK_Talentos";
ALTER TABLE IF EXISTS ONLY public."TalentoTreinamentos" DROP CONSTRAINT IF EXISTS "PK_TalentoTreinamentos";
ALTER TABLE IF EXISTS ONLY public."TalentoFormacoes" DROP CONSTRAINT IF EXISTS "PK_TalentoFormacoes";
ALTER TABLE IF EXISTS ONLY public."TalentoExperiencias" DROP CONSTRAINT IF EXISTS "PK_TalentoExperiencias";
ALTER TABLE IF EXISTS ONLY public."TalentoDocumentos" DROP CONSTRAINT IF EXISTS "PK_TalentoDocumentos";
ALTER TABLE IF EXISTS ONLY public."TalentoCvImportJobs" DROP CONSTRAINT IF EXISTS "PK_TalentoCvImportJobs";
ALTER TABLE IF EXISTS ONLY public."TalentoCompetencias" DROP CONSTRAINT IF EXISTS "PK_TalentoCompetencias";
ALTER TABLE IF EXISTS ONLY public."Surveys" DROP CONSTRAINT IF EXISTS "PK_Surveys";
ALTER TABLE IF EXISTS ONLY public."SurveyResponses" DROP CONSTRAINT IF EXISTS "PK_SurveyResponses";
ALTER TABLE IF EXISTS ONLY public."SurveyQuestions" DROP CONSTRAINT IF EXISTS "PK_SurveyQuestions";
ALTER TABLE IF EXISTS ONLY public."SurveyOptions" DROP CONSTRAINT IF EXISTS "PK_SurveyOptions";
ALTER TABLE IF EXISTS ONLY public."SurveyAnswers" DROP CONSTRAINT IF EXISTS "PK_SurveyAnswers";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesVaga" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesVaga";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPromocao" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesPromocao";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesPagamentoExtra" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesPagamentoExtra";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesFerias" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesFerias";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesEndereco" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesEndereco";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDesligamento" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesDesligamento";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesDependente" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesDependente";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesBeneficio" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesBeneficio";
ALTER TABLE IF EXISTS ONLY public."SolicitacoesAprovacaoEtapas" DROP CONSTRAINT IF EXISTS "PK_SolicitacoesAprovacaoEtapas";
ALTER TABLE IF EXISTS ONLY public."SlaStatusConfigs" DROP CONSTRAINT IF EXISTS "PK_SlaStatusConfigs";
ALTER TABLE IF EXISTS ONLY public."Skills" DROP CONSTRAINT IF EXISTS "PK_Skills";
ALTER TABLE IF EXISTS ONLY public."SkillAliases" DROP CONSTRAINT IF EXISTS "PK_SkillAliases";
ALTER TABLE IF EXISTS ONLY public."Roles" DROP CONSTRAINT IF EXISTS "PK_Roles";
ALTER TABLE IF EXISTS ONLY public."RoleMenus" DROP CONSTRAINT IF EXISTS "PK_RoleMenus";
ALTER TABLE IF EXISTS ONLY public."RmSyncRuns" DROP CONSTRAINT IF EXISTS "PK_RmSyncRuns";
ALTER TABLE IF EXISTS ONLY public."RmSyncCheckpoints" DROP CONSTRAINT IF EXISTS "PK_RmSyncCheckpoints";
ALTER TABLE IF EXISTS ONLY public."RmSyncAlertas" DROP CONSTRAINT IF EXISTS "PK_RmSyncAlertas";
ALTER TABLE IF EXISTS ONLY public."RespostasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "PK_RespostasEntrevistaSaida";
ALTER TABLE IF EXISTS ONLY public."RespostasCampoPersonalizadoVaga" DROP CONSTRAINT IF EXISTS "PK_RespostasCampoPersonalizadoVaga";
ALTER TABLE IF EXISTS ONLY public."RequestLogs" DROP CONSTRAINT IF EXISTS "PK_RequestLogs";
ALTER TABLE IF EXISTS ONLY public."RenderCoinTransactions" DROP CONSTRAINT IF EXISTS "PK_RenderCoinTransactions";
ALTER TABLE IF EXISTS ONLY public."RenderCoinBalances" DROP CONSTRAINT IF EXISTS "PK_RenderCoinBalances";
ALTER TABLE IF EXISTS ONLY public."RecruiterMatchingFeedbacks" DROP CONSTRAINT IF EXISTS "PK_RecruiterMatchingFeedbacks";
ALTER TABLE IF EXISTS ONLY public."PropostasVaga" DROP CONSTRAINT IF EXISTS "PK_PropostasVaga";
ALTER TABLE IF EXISTS ONLY public."ProjetosVaga" DROP CONSTRAINT IF EXISTS "PK_ProjetosVaga";
ALTER TABLE IF EXISTS ONLY public."ProjetoCandidatos" DROP CONSTRAINT IF EXISTS "PK_ProjetoCandidatos";
ALTER TABLE IF EXISTS ONLY public."PreAdmissoes" DROP CONSTRAINT IF EXISTS "PK_PreAdmissoes";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentosSolicitados" DROP CONSTRAINT IF EXISTS "PK_PreAdmissaoDocumentosSolicitados";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDocumentos" DROP CONSTRAINT IF EXISTS "PK_PreAdmissaoDocumentos";
ALTER TABLE IF EXISTS ONLY public."PreAdmissaoDependentes" DROP CONSTRAINT IF EXISTS "PK_PreAdmissaoDependentes";
ALTER TABLE IF EXISTS ONLY public."Pessoas" DROP CONSTRAINT IF EXISTS "PK_Pessoas";
ALTER TABLE IF EXISTS ONLY public."PessoaBloqueios" DROP CONSTRAINT IF EXISTS "PK_PessoaBloqueios";
ALTER TABLE IF EXISTS ONLY public."PermissoesNivelVaga" DROP CONSTRAINT IF EXISTS "PK_PermissoesNivelVaga";
ALTER TABLE IF EXISTS ONLY public."PerguntasEntrevistaSaida" DROP CONSTRAINT IF EXISTS "PK_PerguntasEntrevistaSaida";
ALTER TABLE IF EXISTS ONLY public."OneOnOneMeetings" DROP CONSTRAINT IF EXISTS "PK_OneOnOneMeetings";
ALTER TABLE IF EXISTS ONLY public."OcupacoesHistorico" DROP CONSTRAINT IF EXISTS "PK_OcupacoesHistorico";
ALTER TABLE IF EXISTS ONLY public."Notifications" DROP CONSTRAINT IF EXISTS "PK_Notifications";
ALTER TABLE IF EXISTS ONLY public."NotificationReceipts" DROP CONSTRAINT IF EXISTS "PK_NotificationReceipts";
ALTER TABLE IF EXISTS ONLY public."NotificacoesTemplates" DROP CONSTRAINT IF EXISTS "PK_NotificacoesTemplates";
ALTER TABLE IF EXISTS ONLY public."NotificacoesCandidaturaLogs" DROP CONSTRAINT IF EXISTS "PK_NotificacoesCandidaturaLogs";
ALTER TABLE IF EXISTS ONLY public."NiveisHierarquicos" DROP CONSTRAINT IF EXISTS "PK_NiveisHierarquicos";
ALTER TABLE IF EXISTS ONLY public."NiveisCargo" DROP CONSTRAINT IF EXISTS "PK_NiveisCargo";
ALTER TABLE IF EXISTS ONLY public."NineBoxAssessments" DROP CONSTRAINT IF EXISTS "PK_NineBoxAssessments";
ALTER TABLE IF EXISTS ONLY public."MoodEntries" DROP CONSTRAINT IF EXISTS "PK_MoodEntries";
ALTER TABLE IF EXISTS ONLY public."Metas" DROP CONSTRAINT IF EXISTS "PK_Metas";
ALTER TABLE IF EXISTS ONLY public."Menus" DROP CONSTRAINT IF EXISTS "PK_Menus";
ALTER TABLE IF EXISTS ONLY public."LogsComunicacao" DROP CONSTRAINT IF EXISTS "PK_LogsComunicacao";
ALTER TABLE IF EXISTS ONLY public."LogEntries" DROP CONSTRAINT IF EXISTS "PK_LogEntries";
ALTER TABLE IF EXISTS ONLY public."LocalizationConfigs" DROP CONSTRAINT IF EXISTS "PK_LocalizationConfigs";
ALTER TABLE IF EXISTS ONLY public."JobPositions" DROP CONSTRAINT IF EXISTS "PK_JobPositions";
ALTER TABLE IF EXISTS ONLY public."InboxItems" DROP CONSTRAINT IF EXISTS "PK_InboxItems";
ALTER TABLE IF EXISTS ONLY public."InboxAttachments" DROP CONSTRAINT IF EXISTS "PK_InboxAttachments";
ALTER TABLE IF EXISTS ONLY public."Holerites" DROP CONSTRAINT IF EXISTS "PK_Holerites";
ALTER TABLE IF EXISTS ONLY public."HistoricosStatus" DROP CONSTRAINT IF EXISTS "PK_HistoricosStatus";
ALTER TABLE IF EXISTS ONLY public."HistoricosAlteracaoWorkflowRH" DROP CONSTRAINT IF EXISTS "PK_HistoricosAlteracaoWorkflowRH";
ALTER TABLE IF EXISTS ONLY public."Hierarquias" DROP CONSTRAINT IF EXISTS "PK_Hierarquias";
ALTER TABLE IF EXISTS ONLY public."GamificationDailyStates" DROP CONSTRAINT IF EXISTS "PK_GamificationDailyStates";
ALTER TABLE IF EXISTS ONLY public."Funcionarios" DROP CONSTRAINT IF EXISTS "PK_Funcionarios";
ALTER TABLE IF EXISTS ONLY public."FuncionarioMovimentacoes" DROP CONSTRAINT IF EXISTS "PK_FuncionarioMovimentacoes";
ALTER TABLE IF EXISTS ONLY public."FluxosAprovacaoConfig" DROP CONSTRAINT IF EXISTS "PK_FluxosAprovacaoConfig";
ALTER TABLE IF EXISTS ONLY public."FeedbackItems" DROP CONSTRAINT IF EXISTS "PK_FeedbackItems";
ALTER TABLE IF EXISTS ONLY public."FeedbackItemRatings" DROP CONSTRAINT IF EXISTS "PK_FeedbackItemRatings";
ALTER TABLE IF EXISTS ONLY public."FasesProcesso" DROP CONSTRAINT IF EXISTS "PK_FasesProcesso";
ALTER TABLE IF EXISTS ONLY public."FaixasSalariais" DROP CONSTRAINT IF EXISTS "PK_FaixasSalariais";
ALTER TABLE IF EXISTS ONLY public."ExceptionLogs" DROP CONSTRAINT IF EXISTS "PK_ExceptionLogs";
ALTER TABLE IF EXISTS ONLY public."EtapasWorkflowRH" DROP CONSTRAINT IF EXISTS "PK_EtapasWorkflowRH";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigWorkflowRH" DROP CONSTRAINT IF EXISTS "PK_EtapasConfigWorkflowRH";
ALTER TABLE IF EXISTS ONLY public."EtapasConfigAprovacao" DROP CONSTRAINT IF EXISTS "PK_EtapasConfigAprovacao";
ALTER TABLE IF EXISTS ONLY public."EntrevistasSaida" DROP CONSTRAINT IF EXISTS "PK_EntrevistasSaida";
ALTER TABLE IF EXISTS ONLY public."EntraIdConfigs" DROP CONSTRAINT IF EXISTS "PK_EntraIdConfigs";
ALTER TABLE IF EXISTS ONLY public."Empresas" DROP CONSTRAINT IF EXISTS "PK_Empresas";
ALTER TABLE IF EXISTS ONLY public."EmailTemplates" DROP CONSTRAINT IF EXISTS "PK_EmailTemplates";
ALTER TABLE IF EXISTS ONLY public."EmailMessages" DROP CONSTRAINT IF EXISTS "PK_EmailMessages";
ALTER TABLE IF EXISTS ONLY public."EmailConfigs" DROP CONSTRAINT IF EXISTS "PK_EmailConfigs";
ALTER TABLE IF EXISTS ONLY public."EmailAttempts" DROP CONSTRAINT IF EXISTS "PK_EmailAttempts";
ALTER TABLE IF EXISTS ONLY public."EixosVaga" DROP CONSTRAINT IF EXISTS "PK_EixosVaga";
ALTER TABLE IF EXISTS ONLY public."DocumentosColaborador" DROP CONSTRAINT IF EXISTS "PK_DocumentosColaborador";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorNivelCargoConfigs" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoPorNivelCargoConfigs";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoPorCargoConfigs" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoPorCargoConfigs";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoHistoricos" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoHistoricos";
ALTER TABLE IF EXISTS ONLY public."DocumentacaoPadraoConfigs" DROP CONSTRAINT IF EXISTS "PK_DocumentacaoPadraoConfigs";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlans" DROP CONSTRAINT IF EXISTS "PK_DevelopmentPlans";
ALTER TABLE IF EXISTS ONLY public."DevelopmentPlanGoals" DROP CONSTRAINT IF EXISTS "PK_DevelopmentPlanGoals";
ALTER TABLE IF EXISTS ONLY public."Desligamentos" DROP CONSTRAINT IF EXISTS "PK_Desligamentos";
ALTER TABLE IF EXISTS ONLY public."DescricoesCargo" DROP CONSTRAINT IF EXISTS "PK_DescricoesCargo";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItens" DROP CONSTRAINT IF EXISTS "PK_DescricaoCargoItens";
ALTER TABLE IF EXISTS ONLY public."DescricaoCargoItemEmbeddings" DROP CONSTRAINT IF EXISTS "PK_DescricaoCargoItemEmbeddings";
ALTER TABLE IF EXISTS ONLY public."Dependentes" DROP CONSTRAINT IF EXISTS "PK_Dependentes";
ALTER TABLE IF EXISTS ONLY public."DadosBancarios" DROP CONSTRAINT IF EXISTS "PK_DadosBancarios";
ALTER TABLE IF EXISTS ONLY public."CentrosCusto" DROP CONSTRAINT IF EXISTS "PK_CentrosCusto";
ALTER TABLE IF EXISTS ONLY public."CelebrationPosts" DROP CONSTRAINT IF EXISTS "PK_CelebrationPosts";
ALTER TABLE IF EXISTS ONLY public."CelebrationMentions" DROP CONSTRAINT IF EXISTS "PK_CelebrationMentions";
ALTER TABLE IF EXISTS ONLY public."CelebrationComments" DROP CONSTRAINT IF EXISTS "PK_CelebrationComments";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentReactions" DROP CONSTRAINT IF EXISTS "PK_CelebrationCommentReactions";
ALTER TABLE IF EXISTS ONLY public."CelebrationCommentMentions" DROP CONSTRAINT IF EXISTS "PK_CelebrationCommentMentions";
ALTER TABLE IF EXISTS ONLY public."CategoriasSalariais" DROP CONSTRAINT IF EXISTS "PK_CategoriasSalariais";
ALTER TABLE IF EXISTS ONLY public."CategoriaSalarialSteps" DROP CONSTRAINT IF EXISTS "PK_CategoriaSalarialSteps";
ALTER TABLE IF EXISTS ONLY public."Cargos" DROP CONSTRAINT IF EXISTS "PK_Cargos";
ALTER TABLE IF EXISTS ONLY public."Candidaturas" DROP CONSTRAINT IF EXISTS "PK_Candidaturas";
ALTER TABLE IF EXISTS ONLY public."CandidaturaEtapaHistoricos" DROP CONSTRAINT IF EXISTS "PK_CandidaturaEtapaHistoricos";
ALTER TABLE IF EXISTS ONLY public."Candidatos" DROP CONSTRAINT IF EXISTS "PK_Candidatos";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaMatchingScores" DROP CONSTRAINT IF EXISTS "PK_CandidatoVagaMatchingScores";
ALTER TABLE IF EXISTS ONLY public."CandidatoVagaLlmScores" DROP CONSTRAINT IF EXISTS "PK_CandidatoVagaLlmScores";
ALTER TABLE IF EXISTS ONLY public."CandidatoStatusHistories" DROP CONSTRAINT IF EXISTS "PK_CandidatoStatusHistories";
ALTER TABLE IF EXISTS ONLY public."CandidatoReferencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoReferencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoProjetos" DROP CONSTRAINT IF EXISTS "PK_CandidatoProjetos";
ALTER TABLE IF EXISTS ONLY public."CandidatoPreferenciasVaga" DROP CONSTRAINT IF EXISTS "PK_CandidatoPreferenciasVaga";
ALTER TABLE IF EXISTS ONLY public."CandidatoPortfolios" DROP CONSTRAINT IF EXISTS "PK_CandidatoPortfolios";
ALTER TABLE IF EXISTS ONLY public."CandidatoNotificacaoPreferencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoNotificacaoPreferencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoLgpdConsents" DROP CONSTRAINT IF EXISTS "PK_CandidatoLgpdConsents";
ALTER TABLE IF EXISTS ONLY public."CandidatoExperiencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoExperiencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoEmbeddings" DROP CONSTRAINT IF EXISTS "PK_CandidatoEmbeddings";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoResumos" DROP CONSTRAINT IF EXISTS "PK_CandidatoEducacaoResumos";
ALTER TABLE IF EXISTS ONLY public."CandidatoEducacaoItens" DROP CONSTRAINT IF EXISTS "PK_CandidatoEducacaoItens";
ALTER TABLE IF EXISTS ONLY public."CandidatoDocumentos" DROP CONSTRAINT IF EXISTS "PK_CandidatoDocumentos";
ALTER TABLE IF EXISTS ONLY public."CandidatoCompetencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoCompetencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoCertificacoes" DROP CONSTRAINT IF EXISTS "PK_CandidatoCertificacoes";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaPreferencias" DROP CONSTRAINT IF EXISTS "PK_CandidatoAgendaPreferencias";
ALTER TABLE IF EXISTS ONLY public."CandidatoAgendaBloqueios" DROP CONSTRAINT IF EXISTS "PK_CandidatoAgendaBloqueios";
ALTER TABLE IF EXISTS ONLY public."CandidatoAcessibilidades" DROP CONSTRAINT IF EXISTS "PK_CandidatoAcessibilidades";
ALTER TABLE IF EXISTS ONLY public."CamposPersonalizadosVaga" DROP CONSTRAINT IF EXISTS "PK_CamposPersonalizadosVaga";
ALTER TABLE IF EXISTS ONLY public."BatchMatchingRuns" DROP CONSTRAINT IF EXISTS "PK_BatchMatchingRuns";
ALTER TABLE IF EXISTS ONLY public."BatchMatchingRunVagas" DROP CONSTRAINT IF EXISTS "PK_BatchMatchingRunVagas";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoRespostas" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoRespostas";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoPerguntas" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoPerguntas";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoConvites" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoConvites";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCiclos" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoCiclos";
ALTER TABLE IF EXISTS ONLY public."AvaliacaoCalibragens" DROP CONSTRAINT IF EXISTS "PK_AvaliacaoCalibragens";
ALTER TABLE IF EXISTS ONLY public."AuditTransactions" DROP CONSTRAINT IF EXISTS "PK_AuditTransactions";
ALTER TABLE IF EXISTS ONLY public."AuditEvents" DROP CONSTRAINT IF EXISTS "PK_AuditEvents";
ALTER TABLE IF EXISTS ONLY public."AuditEntityPropertyChanges" DROP CONSTRAINT IF EXISTS "PK_AuditEntityPropertyChanges";
ALTER TABLE IF EXISTS ONLY public."AuditEntityChanges" DROP CONSTRAINT IF EXISTS "PK_AuditEntityChanges";
ALTER TABLE IF EXISTS ONLY public."AspNetUserTokens" DROP CONSTRAINT IF EXISTS "PK_AspNetUserTokens";
ALTER TABLE IF EXISTS ONLY public."AspNetUserLogins" DROP CONSTRAINT IF EXISTS "PK_AspNetUserLogins";
ALTER TABLE IF EXISTS ONLY public."AspNetUserClaims" DROP CONSTRAINT IF EXISTS "PK_AspNetUserClaims";
ALTER TABLE IF EXISTS ONLY public."AspNetRoleClaims" DROP CONSTRAINT IF EXISTS "PK_AspNetRoleClaims";
ALTER TABLE IF EXISTS ONLY public."AprovadoresAlternativos" DROP CONSTRAINT IF EXISTS "PK_AprovadoresAlternativos";
ALTER TABLE IF EXISTS ONLY public."AprovacoesFaixaSalarial" DROP CONSTRAINT IF EXISTS "PK_AprovacoesFaixaSalarial";
ALTER TABLE IF EXISTS ONLY public."ApprovalMagicLinks" DROP CONSTRAINT IF EXISTS "PK_ApprovalMagicLinks";
ALTER TABLE IF EXISTS ONLY public."ApiKeys" DROP CONSTRAINT IF EXISTS "PK_ApiKeys";
ALTER TABLE IF EXISTS ONLY public."AgendaEvents" DROP CONSTRAINT IF EXISTS "PK_AgendaEvents";
ALTER TABLE IF EXISTS ONLY public."AgendaEventTypes" DROP CONSTRAINT IF EXISTS "PK_AgendaEventTypes";
ALTER TABLE IF EXISTS ONLY public."MotivosRequisicaoVagaConfig" DROP CONSTRAINT IF EXISTS "MotivosRequisicaoVagaConfig_pkey";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS public."WorkflowsRH";
DROP TABLE IF EXISTS public."Vagas";
DROP TABLE IF EXISTS public."VagaUnifiedMatchingCaches";
DROP TABLE IF EXISTS public."VagaRequisitos";
DROP TABLE IF EXISTS public."VagaPerguntas";
DROP TABLE IF EXISTS public."VagaEtapas";
DROP TABLE IF EXISTS public."VagaBeneficios";
DROP TABLE IF EXISTS public."Users";
DROP TABLE IF EXISTS public."UserUnits";
DROP TABLE IF EXISTS public."UserRoles";
DROP TABLE IF EXISTS public."Units";
DROP TABLE IF EXISTS public."UnidadesLotacao";
DROP TABLE IF EXISTS public."Turnos";
DROP TABLE IF EXISTS public."TenantConfiguracoes";
DROP TABLE IF EXISTS public."TenantBrandings";
DROP TABLE IF EXISTS public."TenantAwsSettings";
DROP TABLE IF EXISTS public."TemplatesEntrevistaSaida";
DROP TABLE IF EXISTS public."Talentos";
DROP TABLE IF EXISTS public."TalentoTreinamentos";
DROP TABLE IF EXISTS public."TalentoFormacoes";
DROP TABLE IF EXISTS public."TalentoExperiencias";
DROP TABLE IF EXISTS public."TalentoDocumentos";
DROP TABLE IF EXISTS public."TalentoCvImportJobs";
DROP TABLE IF EXISTS public."TalentoCompetencias";
DROP TABLE IF EXISTS public."Surveys";
DROP TABLE IF EXISTS public."SurveyResponses";
DROP TABLE IF EXISTS public."SurveyQuestions";
DROP TABLE IF EXISTS public."SurveyOptions";
DROP TABLE IF EXISTS public."SurveyAnswers";
DROP TABLE IF EXISTS public."SolicitacoesVaga";
DROP TABLE IF EXISTS public."SolicitacoesPromocao";
DROP TABLE IF EXISTS public."SolicitacoesPagamentoExtra";
DROP TABLE IF EXISTS public."SolicitacoesFerias";
DROP TABLE IF EXISTS public."SolicitacoesEndereco";
DROP TABLE IF EXISTS public."SolicitacoesDesligamento";
DROP TABLE IF EXISTS public."SolicitacoesDependente";
DROP TABLE IF EXISTS public."SolicitacoesBeneficio";
DROP TABLE IF EXISTS public."SolicitacoesAprovacaoEtapas";
DROP TABLE IF EXISTS public."SlaStatusConfigs";
DROP TABLE IF EXISTS public."Skills";
DROP TABLE IF EXISTS public."SkillAliases";
DROP TABLE IF EXISTS public."Roles";
DROP TABLE IF EXISTS public."RoleMenus";
DROP TABLE IF EXISTS public."RmSyncRuns";
DROP TABLE IF EXISTS public."RmSyncCheckpoints";
DROP TABLE IF EXISTS public."RmSyncAlertas";
DROP TABLE IF EXISTS public."RespostasEntrevistaSaida";
DROP TABLE IF EXISTS public."RespostasCampoPersonalizadoVaga";
DROP TABLE IF EXISTS public."RequestLogs";
DROP TABLE IF EXISTS public."RenderCoinTransactions";
DROP TABLE IF EXISTS public."RenderCoinBalances";
DROP TABLE IF EXISTS public."RecruiterMatchingFeedbacks";
DROP TABLE IF EXISTS public."PropostasVaga";
DROP TABLE IF EXISTS public."ProjetosVaga";
DROP TABLE IF EXISTS public."ProjetoCandidatos";
DROP TABLE IF EXISTS public."PreAdmissoes";
DROP TABLE IF EXISTS public."PreAdmissaoDocumentosSolicitados";
DROP TABLE IF EXISTS public."PreAdmissaoDocumentos";
DROP TABLE IF EXISTS public."PreAdmissaoDependentes";
DROP TABLE IF EXISTS public."Pessoas";
DROP TABLE IF EXISTS public."PessoaBloqueios";
DROP TABLE IF EXISTS public."PermissoesNivelVaga";
DROP TABLE IF EXISTS public."PerguntasEntrevistaSaida";
DROP TABLE IF EXISTS public."OneOnOneMeetings";
DROP TABLE IF EXISTS public."OcupacoesHistorico";
DROP TABLE IF EXISTS public."Notifications";
DROP TABLE IF EXISTS public."NotificationReceipts";
DROP TABLE IF EXISTS public."NotificacoesTemplates";
DROP TABLE IF EXISTS public."NotificacoesCandidaturaLogs";
DROP TABLE IF EXISTS public."NiveisHierarquicos";
DROP TABLE IF EXISTS public."NiveisCargo";
DROP TABLE IF EXISTS public."NineBoxAssessments";
DROP TABLE IF EXISTS public."MotivosRequisicaoVagaConfig";
DROP TABLE IF EXISTS public."MoodEntries";
DROP TABLE IF EXISTS public."Metas";
DROP TABLE IF EXISTS public."Menus";
DROP TABLE IF EXISTS public."LogsComunicacao";
DROP TABLE IF EXISTS public."LogEntries";
DROP TABLE IF EXISTS public."LocalizationConfigs";
DROP TABLE IF EXISTS public."JobPositions";
DROP TABLE IF EXISTS public."InboxItems";
DROP TABLE IF EXISTS public."InboxAttachments";
DROP TABLE IF EXISTS public."Holerites";
DROP TABLE IF EXISTS public."HistoricosStatus";
DROP TABLE IF EXISTS public."HistoricosAlteracaoWorkflowRH";
DROP TABLE IF EXISTS public."Hierarquias";
DROP TABLE IF EXISTS public."GamificationDailyStates";
DROP TABLE IF EXISTS public."Funcionarios";
DROP TABLE IF EXISTS public."FuncionarioMovimentacoes";
DROP TABLE IF EXISTS public."FluxosAprovacaoConfig";
DROP TABLE IF EXISTS public."FeedbackItems";
DROP TABLE IF EXISTS public."FeedbackItemRatings";
DROP TABLE IF EXISTS public."FasesProcesso";
DROP TABLE IF EXISTS public."FaixasSalariais";
DROP TABLE IF EXISTS public."ExceptionLogs";
DROP TABLE IF EXISTS public."EtapasWorkflowRH";
DROP TABLE IF EXISTS public."EtapasConfigWorkflowRH";
DROP TABLE IF EXISTS public."EtapasConfigAprovacao";
DROP TABLE IF EXISTS public."EntrevistasSaida";
DROP TABLE IF EXISTS public."EntraIdConfigs";
DROP TABLE IF EXISTS public."Empresas";
DROP TABLE IF EXISTS public."EmailTemplates";
DROP TABLE IF EXISTS public."EmailMessages";
DROP TABLE IF EXISTS public."EmailConfigs";
DROP TABLE IF EXISTS public."EmailAttempts";
DROP TABLE IF EXISTS public."EixosVaga";
DROP TABLE IF EXISTS public."DocumentosColaborador";
DROP TABLE IF EXISTS public."DocumentacaoPadraoPorNivelCargoConfigs";
DROP TABLE IF EXISTS public."DocumentacaoPadraoPorCargoConfigs";
DROP TABLE IF EXISTS public."DocumentacaoPadraoHistoricos";
DROP TABLE IF EXISTS public."DocumentacaoPadraoConfigs";
DROP TABLE IF EXISTS public."DevelopmentPlans";
DROP TABLE IF EXISTS public."DevelopmentPlanGoals";
DROP TABLE IF EXISTS public."Desligamentos";
DROP TABLE IF EXISTS public."DescricoesCargo";
DROP TABLE IF EXISTS public."DescricaoCargoItens";
DROP TABLE IF EXISTS public."DescricaoCargoItemEmbeddings";
DROP TABLE IF EXISTS public."Dependentes";
DROP TABLE IF EXISTS public."DadosBancarios";
DROP TABLE IF EXISTS public."CentrosCusto";
DROP TABLE IF EXISTS public."CelebrationPosts";
DROP TABLE IF EXISTS public."CelebrationMentions";
DROP TABLE IF EXISTS public."CelebrationComments";
DROP TABLE IF EXISTS public."CelebrationCommentReactions";
DROP TABLE IF EXISTS public."CelebrationCommentMentions";
DROP TABLE IF EXISTS public."CategoriasSalariais";
DROP TABLE IF EXISTS public."CategoriaSalarialSteps";
DROP TABLE IF EXISTS public."Cargos";
DROP TABLE IF EXISTS public."Candidaturas";
DROP TABLE IF EXISTS public."CandidaturaEtapaHistoricos";
DROP TABLE IF EXISTS public."Candidatos";
DROP TABLE IF EXISTS public."CandidatoVagaMatchingScores";
DROP TABLE IF EXISTS public."CandidatoVagaLlmScores";
DROP TABLE IF EXISTS public."CandidatoStatusHistories";
DROP TABLE IF EXISTS public."CandidatoReferencias";
DROP TABLE IF EXISTS public."CandidatoProjetos";
DROP TABLE IF EXISTS public."CandidatoPreferenciasVaga";
DROP TABLE IF EXISTS public."CandidatoPortfolios";
DROP TABLE IF EXISTS public."CandidatoNotificacaoPreferencias";
DROP TABLE IF EXISTS public."CandidatoLgpdConsents";
DROP TABLE IF EXISTS public."CandidatoExperiencias";
DROP TABLE IF EXISTS public."CandidatoEmbeddings";
DROP TABLE IF EXISTS public."CandidatoEducacaoResumos";
DROP TABLE IF EXISTS public."CandidatoEducacaoItens";
DROP TABLE IF EXISTS public."CandidatoDocumentos";
DROP TABLE IF EXISTS public."CandidatoCompetencias";
DROP TABLE IF EXISTS public."CandidatoCertificacoes";
DROP TABLE IF EXISTS public."CandidatoAgendaPreferencias";
DROP TABLE IF EXISTS public."CandidatoAgendaBloqueios";
DROP TABLE IF EXISTS public."CandidatoAcessibilidades";
DROP TABLE IF EXISTS public."CamposPersonalizadosVaga";
DROP TABLE IF EXISTS public."BatchMatchingRuns";
DROP TABLE IF EXISTS public."BatchMatchingRunVagas";
DROP TABLE IF EXISTS public."AvaliacaoRespostas";
DROP TABLE IF EXISTS public."AvaliacaoPerguntas";
DROP TABLE IF EXISTS public."AvaliacaoConvites";
DROP TABLE IF EXISTS public."AvaliacaoCiclos";
DROP TABLE IF EXISTS public."AvaliacaoCalibragens";
DROP TABLE IF EXISTS public."AuditTransactions";
DROP TABLE IF EXISTS public."AuditEvents";
DROP TABLE IF EXISTS public."AuditEntityPropertyChanges";
DROP TABLE IF EXISTS public."AuditEntityChanges";
DROP TABLE IF EXISTS public."AspNetUserTokens";
DROP TABLE IF EXISTS public."AspNetUserLogins";
DROP TABLE IF EXISTS public."AspNetUserClaims";
DROP TABLE IF EXISTS public."AspNetRoleClaims";
DROP TABLE IF EXISTS public."AprovadoresAlternativos";
DROP TABLE IF EXISTS public."AprovacoesFaixaSalarial";
DROP TABLE IF EXISTS public."ApprovalMagicLinks";
DROP TABLE IF EXISTS public."ApiKeys";
DROP TABLE IF EXISTS public."AgendaEvents";
DROP TABLE IF EXISTS public."AgendaEventTypes";
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AgendaEventTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AgendaEventTypes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(40) NOT NULL,
    "Label" character varying(120) NOT NULL,
    "Color" character varying(20) NOT NULL,
    "Icon" character varying(80) NOT NULL,
    "SortOrder" integer NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: AgendaEvents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AgendaEvents" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TypeId" uuid NOT NULL,
    "Title" character varying(240) NOT NULL,
    "StartAtUtc" timestamp with time zone NOT NULL,
    "EndAtUtc" timestamp with time zone NOT NULL,
    "AllDay" boolean NOT NULL,
    "Status" character varying(40) NOT NULL,
    "Location" character varying(160),
    "Owner" character varying(120),
    "Candidate" character varying(160),
    "VagaTitle" character varying(200),
    "VagaCode" character varying(40),
    "Notes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: ApiKeys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ApiKeys" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "KeyHash" character varying(64) NOT NULL,
    "Description" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "LastUsedAtUtc" timestamp with time zone
);


--
-- Name: ApprovalMagicLinks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ApprovalMagicLinks" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Token" character varying(64) NOT NULL,
    "EtapaId" uuid NOT NULL,
    "SolicitacaoId" uuid NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "AprovadorFuncionarioId" uuid NOT NULL,
    "ExpiresAtUtc" timestamp with time zone NOT NULL,
    "UsedAtUtc" timestamp with time zone,
    "AcaoRealizada" smallint,
    "IpAddress" character varying(45),
    "UserAgent" character varying(512),
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: AprovacoesFaixaSalarial; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AprovacoesFaixaSalarial" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FaixaSalarialId" uuid NOT NULL,
    "SolicitanteId" uuid,
    "ValorProposto" numeric(18,2) NOT NULL,
    "Justificativa" character varying(1000),
    "Status" smallint NOT NULL,
    "AprovadorId" uuid,
    "ObservacaoAprovador" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "AprovadoEmUtc" timestamp with time zone
);


--
-- Name: AprovadoresAlternativos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AprovadoresAlternativos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "GestorId" uuid NOT NULL,
    "AprovadorId" uuid NOT NULL,
    "DataInicio" date NOT NULL,
    "DataFim" date,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: AspNetRoleClaims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetRoleClaims" (
    "Id" integer NOT NULL,
    "RoleId" uuid NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."AspNetRoleClaims" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."AspNetRoleClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: AspNetUserClaims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetUserClaims" (
    "Id" integer NOT NULL,
    "UserId" uuid NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public."AspNetUserClaims" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."AspNetUserClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: AspNetUserLogins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetUserLogins" (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" uuid NOT NULL
);


--
-- Name: AspNetUserTokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AspNetUserTokens" (
    "UserId" uuid NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


--
-- Name: AuditEntityChanges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditEntityChanges" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuditTransactionId" uuid NOT NULL,
    "AuditEventId" uuid,
    "Order" integer NOT NULL,
    "EntityName" character varying(200) NOT NULL,
    "TableName" character varying(200),
    "State" character varying(20) NOT NULL,
    "PrimaryKeyJson" jsonb NOT NULL,
    "BeforeJson" jsonb,
    "AfterJson" jsonb,
    "ChangedColumns" character varying(500),
    "DataJson" jsonb,
    "OccurredAt" timestamp with time zone NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AuditEntityPropertyChanges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditEntityPropertyChanges" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuditEntityChangeId" uuid NOT NULL,
    "PropertyName" character varying(200) NOT NULL,
    "BeforeValue" character varying(2000),
    "AfterValue" character varying(2000),
    "IsSensitive" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AuditEvents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditEvents" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuditTransactionId" uuid NOT NULL,
    "Order" integer NOT NULL,
    "EventType" character varying(40) NOT NULL,
    "Name" character varying(200) NOT NULL,
    "OccurredAt" timestamp with time zone NOT NULL,
    "DataJson" jsonb,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AuditTransactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditTransactions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "CorrelationId" character varying(200),
    "TraceId" character varying(200),
    "SpanId" character varying(200),
    "ParentSpanId" character varying(200),
    "Environment" character varying(40) NOT NULL,
    "AppVersion" character varying(40) NOT NULL,
    "StartedAt" timestamp with time zone NOT NULL,
    "EndedAt" timestamp with time zone,
    "DurationMs" bigint NOT NULL,
    "UserId" character varying(120),
    "UserName" character varying(200),
    "ClientId" character varying(120),
    "Ip" character varying(80),
    "UserAgent" character varying(400),
    "Host" character varying(200),
    "Method" character varying(16) NOT NULL,
    "Path" character varying(512) NOT NULL,
    "QueryString" character varying(1024),
    "RouteTemplate" character varying(512),
    "Controller" character varying(120),
    "Action" character varying(120),
    "StatusCode" integer,
    "IsSuccess" boolean NOT NULL,
    "RequestContentType" text,
    "ResponseContentType" text,
    "RequestBody" text,
    "ResponseBody" text,
    "RequestBodyHash" character varying(64),
    "ResponseBodyHash" character varying(64),
    "RequestIsTruncated" boolean NOT NULL,
    "ResponseIsTruncated" boolean NOT NULL,
    "RequestTruncatedBytes" integer NOT NULL,
    "ResponseTruncatedBytes" integer NOT NULL,
    "ErrorMessage" text,
    "ErrorStackTrace" text,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: AvaliacaoCalibragens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoCalibragens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CicloId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "ScoreGestor" numeric(5,2) NOT NULL,
    "DesempenhoGestor" integer,
    "PotencialGestor" integer,
    "ScoreComite" numeric(5,2),
    "DesempenhoComite" integer,
    "PotencialComite" integer,
    "JustificativaComite" character varying(2000),
    "Status" smallint NOT NULL,
    "Decisao" smallint NOT NULL,
    "DecididoPorUserId" uuid,
    "DecididoEmUtc" timestamp with time zone,
    "ObservacaoDecisao" character varying(2000),
    "NineBoxAssessmentId" uuid,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: AvaliacaoCiclos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoCiclos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(200) NOT NULL,
    "Periodo" character varying(50) NOT NULL,
    "Status" smallint NOT NULL,
    "CriadoPorId" uuid NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL,
    "DataFim" date,
    "DataInicio" date,
    "Descricao" character varying(2000)
);


--
-- Name: AvaliacaoConvites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoConvites" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CicloId" uuid NOT NULL,
    "AvaliadorId" uuid NOT NULL,
    "AvaliandoId" uuid NOT NULL,
    "Tipo" smallint NOT NULL,
    "Status" smallint NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "NotificadoEmUtc" timestamp with time zone,
    "RespondidoEmUtc" timestamp with time zone
);


--
-- Name: AvaliacaoPerguntas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoPerguntas" (
    "Id" uuid NOT NULL,
    "CicloId" uuid NOT NULL,
    "Texto" character varying(500) NOT NULL,
    "Ordem" integer NOT NULL
);


--
-- Name: AvaliacaoRespostas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AvaliacaoRespostas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CicloId" uuid NOT NULL,
    "AvaliadorId" uuid NOT NULL,
    "AvaliandoId" uuid NOT NULL,
    "Score" numeric(5,2) NOT NULL,
    "RespostasJson" text NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: BatchMatchingRunVagas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BatchMatchingRunVagas" (
    "Id" uuid NOT NULL,
    "RunId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Status" smallint NOT NULL,
    "ScoresGenerated" integer NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "CompletedAtUtc" timestamp with time zone,
    "ErrorMessage" character varying(2000)
);


--
-- Name: BatchMatchingRuns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BatchMatchingRuns" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Status" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "CompletedAtUtc" timestamp with time zone,
    "TotalVagas" integer NOT NULL,
    "ProcessedVagas" integer NOT NULL,
    "FailedVagas" integer NOT NULL,
    "TotalCandidatesScored" integer NOT NULL,
    "LastProcessedVagaId" uuid,
    "LastError" character varying(2000)
);


--
-- Name: CamposPersonalizadosVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CamposPersonalizadosVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Label" character varying(200) NOT NULL,
    "Tipo" smallint NOT NULL,
    "Obrigatorio" boolean NOT NULL,
    "Ordem" integer NOT NULL,
    "Opcoes" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "IsReadOnly" boolean DEFAULT false NOT NULL,
    "ValorPadrao" character varying(500)
);


--
-- Name: CandidatoAcessibilidades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoAcessibilidades" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Idioma" character varying(40),
    "Canal" character varying(40),
    "MelhorHorario" character varying(40),
    "ObservacoesComunicacao" character varying(400),
    "PrecisaLegendas" boolean NOT NULL,
    "PrecisaInterprete" boolean NOT NULL,
    "PrecisaLeitorTela" boolean NOT NULL,
    "PrecisaBaixaEstimulo" boolean NOT NULL,
    "PrecisaMobilidade" boolean NOT NULL,
    "PrecisaTempoExtra" boolean NOT NULL,
    "DetalhesNecessidades" character varying(1200),
    "ConsentimentoPcd" boolean NOT NULL,
    "PcdIdentificacao" character varying(40),
    "PcdTipo" character varying(60),
    "PcdComprovacao" character varying(40),
    "PcdObservacoes" character varying(1200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoAgendaBloqueios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoAgendaBloqueios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Tipo" character varying(40),
    "Titulo" character varying(120),
    "Data" character varying(40),
    "Horario" character varying(40),
    "Observacoes" character varying(400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoAgendaPreferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoAgendaPreferencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "FormatoEntrevista" character varying(40),
    "InicioDisponivel" character varying(40),
    "AvisoPrevio" character varying(40),
    "Observacoes" character varying(400),
    "DiaSeg" boolean DEFAULT false NOT NULL,
    "DiaTer" boolean DEFAULT false NOT NULL,
    "DiaQua" boolean DEFAULT false NOT NULL,
    "DiaQui" boolean DEFAULT false NOT NULL,
    "DiaSex" boolean DEFAULT false NOT NULL,
    "DiaSab" boolean DEFAULT false NOT NULL,
    "DiaDom" boolean DEFAULT false NOT NULL,
    "PeriodoManha" boolean DEFAULT false NOT NULL,
    "PeriodoTarde" boolean DEFAULT false NOT NULL,
    "PeriodoNoite" boolean DEFAULT false NOT NULL,
    "HorarioPreferido" character varying(40),
    "FusoHorario" character varying(60),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoCertificacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoCertificacoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Ano" character varying(10),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoCompetencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoCompetencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Tipo" character varying(40) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Nivel" character varying(40) NOT NULL,
    "Evidencia" character varying(300),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoDocumentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoDocumentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Tipo" integer NOT NULL,
    "NomeArquivo" character varying(200) NOT NULL,
    "ContentType" character varying(120),
    "Descricao" character varying(240),
    "StorageFileName" character varying(260),
    "TamanhoBytes" bigint,
    "Url" character varying(400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ArquivoNome" character varying(260),
    "DataReferencia" character varying(20)
);


--
-- Name: CandidatoEducacaoItens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoEducacaoItens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Curso" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Tipo" character varying(40),
    "Status" character varying(40),
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Observacoes" character varying(800),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoEducacaoResumos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoEducacaoResumos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nivel" character varying(60),
    "AreaPrincipal" character varying(120),
    "Situacao" character varying(40),
    "Destaques" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoEmbeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoEmbeddings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "ModelVersion" character varying(60) NOT NULL,
    "Dimensions" integer NOT NULL,
    "Embedding" public.vector(1024),
    "TextoSource" character varying(8000) DEFAULT ''::character varying NOT NULL,
    "ConteudoHash" character varying(64) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoExperiencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoExperiencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Empresa" character varying(160) NOT NULL,
    "Cargo" character varying(160) NOT NULL,
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Local" character varying(160),
    "Atividades" character varying(2400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoLgpdConsents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoLgpdConsents" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "ProcessarCandidatura" boolean NOT NULL,
    "PermitirContato" boolean NOT NULL,
    "BancoTalentos" boolean NOT NULL,
    "RetencaoMeses" integer,
    "Compartilhamento" smallint,
    "DadosSensiveis" boolean NOT NULL,
    "Comunicacoes" boolean NOT NULL,
    "ConsentidoEmUtc" timestamp with time zone,
    "RevogadoEmUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoNotificacaoPreferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoNotificacaoPreferencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "CanalEmail" boolean NOT NULL,
    "CanalWhatsapp" boolean NOT NULL,
    "CanalSms" boolean NOT NULL,
    "CanalPush" boolean NOT NULL,
    "Frequencia" character varying(40),
    "Idioma" character varying(20),
    "Email" character varying(180),
    "Telefone" character varying(40),
    "PermiteContato" boolean NOT NULL,
    "AlertaNovasVagas" boolean NOT NULL,
    "AlertaAtualizacoes" boolean NOT NULL,
    "AlertaEntrevistas" boolean NOT NULL,
    "AlertaMensagens" boolean NOT NULL,
    "AlertaDocumentos" boolean NOT NULL,
    "AlertaLembretes" boolean NOT NULL,
    "SilencioAtivo" character varying(10),
    "SilencioInicio" character varying(10),
    "SilencioFim" character varying(10),
    "SilencioPrioridade" character varying(20),
    "Assinatura" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "WhatsAppRateLimitMaxMensagens" integer,
    "WhatsAppRateLimitJanelaMinutos" integer
);


--
-- Name: CandidatoPortfolios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoPortfolios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "WorkModel" character varying(40),
    "Availability" character varying(40),
    "Salary" character varying(40),
    "Shift" character varying(40),
    "Note" character varying(200),
    "Linkedin" character varying(260),
    "Github" character varying(260),
    "Portfolio" character varying(260),
    "Drive" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Tags" character varying(400)
);


--
-- Name: CandidatoPreferenciasVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoPreferenciasVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "CargoAlvo" character varying(160),
    "Senioridade" character varying(60),
    "InicioDisponivel" character varying(60),
    "Resumo" character varying(1200),
    "AreasInteresse" character varying(240),
    "ModeloTrabalho" character varying(40),
    "Jornada" character varying(40),
    "TipoContrato" character varying(40),
    "Viagens" character varying(40),
    "Mudanca" character varying(40),
    "CidadePreferida" character varying(160),
    "DistanciaMaxKm" character varying(20),
    "ObsDeslocamento" character varying(200),
    "PretensaoSalarial" character varying(40),
    "PretensaoNegociavel" character varying(40),
    "BeneficiosDesejados" character varying(200),
    "NaoAbreMaoDe" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoProjetos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoProjetos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Periodo" character varying(60),
    "Descricao" character varying(600),
    "Link" character varying(260),
    "Stack" character varying(400),
    "Destaques" character varying(1600),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoReferencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoReferencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Relacao" character varying(80),
    "Empresa" character varying(160),
    "Cargo" character varying(120),
    "Contato" character varying(220),
    "Periodo" character varying(60),
    "Linkedin" character varying(260),
    "Observacoes" character varying(1200),
    "PodeContatar" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoStatusHistories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoStatusHistories" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "FromStatus" integer NOT NULL,
    "ToStatus" integer NOT NULL,
    "Reason" character varying(120),
    "Note" character varying(400),
    "Source" character varying(60),
    "UserId" character varying(120),
    "UserName" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoVagaLlmScores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoVagaLlmScores" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "ScoreFinal" integer DEFAULT 0 NOT NULL,
    "PassouMatchMinimo" boolean DEFAULT false NOT NULL,
    "JustificativaTexto" character varying(4000) DEFAULT ''::character varying NOT NULL,
    "CriteriosJson" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "PontosFortes" character varying(2000),
    "Gaps" character varying(2000),
    "InputHash" character varying(64) NOT NULL,
    "ModelVersion" character varying(60) NOT NULL,
    "DurationMs" integer DEFAULT 0 NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CandidatoVagaMatchingScores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidatoVagaMatchingScores" (
    "CandidatoId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "Score" integer NOT NULL,
    "CalculatedAtUtc" timestamp with time zone NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Justificativa" character varying(2000),
    "RuleVersion" character varying(30),
    "ScoreCompetencia" integer,
    "ScoreExperiencia" integer,
    "ScoreFormacao" integer,
    "ScoreLocalidade" integer,
    "Source" character varying(20)
);


--
-- Name: Candidatos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Candidatos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Email" character varying(180) NOT NULL,
    "Fone" character varying(40),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "Fonte" integer NOT NULL,
    "Status" integer NOT NULL,
    "VagaId" uuid,
    "Obs" character varying(2000),
    "CvText" text,
    "LastMatchScore" integer,
    "LastMatchPass" boolean,
    "LastMatchAtUtc" timestamp with time zone,
    "LastMatchVagaId" uuid,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "PortalAccessKey" character varying(80),
    "PortalPasswordHash" character varying(400),
    "AvatarContentType" character varying(120),
    "AvatarFileName" character varying(260),
    "LinkedinUrl" character varying(260),
    "ResumoProfissional" character varying(2000),
    "ApplicationRecruiterUserId" character varying(120),
    "ApplicationRecruiterUserName" character varying(200),
    "TalentoId" uuid,
    "TrabalhandoAtualmente" boolean,
    "Celular" character varying(40),
    "PretensaoSalarial" numeric(18,2),
    embedding public.vector(1536),
    embedding_generated_at_utc timestamp with time zone
);


--
-- Name: CandidaturaEtapaHistoricos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CandidaturaEtapaHistoricos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidaturaId" uuid NOT NULL,
    "EtapaAnterior" smallint NOT NULL,
    "EtapaNova" smallint NOT NULL,
    "Observacao" character varying(2000),
    "UserId" uuid,
    "EmUtc" timestamp with time zone NOT NULL
);


--
-- Name: Candidaturas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Candidaturas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "VagaId" uuid NOT NULL,
    "Status" smallint NOT NULL,
    "EtapaMacro" smallint NOT NULL,
    "Fonte" character varying(60),
    "Observacoes" character varying(2000),
    "AplicadaEmUtc" timestamp with time zone NOT NULL,
    "EtapaAtualDesdeUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Cargos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Cargos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "OccupationalClassification" character varying(30),
    "CargoType" character varying(30),
    "SimilarityIndicator" character varying(1),
    "FullDescription" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CategoriaSalarialSteps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CategoriaSalarialSteps" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CategoriaSalarialId" uuid NOT NULL,
    "Percentual" numeric(8,2) NOT NULL,
    "ValorOverride" numeric(18,2),
    "Ordem" integer DEFAULT 0 NOT NULL,
    "Observacao" character varying(200),
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL,
    "UpdatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: CategoriasSalariais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CategoriasSalariais" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(10) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "EmpresaId" uuid,
    "EstabelecimentoId" uuid,
    "ValorBase" numeric(18,2)
);


--
-- Name: CelebrationCommentMentions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationCommentMentions" (
    "Id" uuid NOT NULL,
    "CommentId" uuid NOT NULL,
    "UserId" uuid NOT NULL
);


--
-- Name: CelebrationCommentReactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationCommentReactions" (
    "Id" uuid NOT NULL,
    "CommentId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "Type" character varying(20) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CelebrationComments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationComments" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PostId" uuid NOT NULL,
    "AuthorId" uuid NOT NULL,
    "Content" character varying(2000) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CelebrationMentions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationMentions" (
    "Id" uuid NOT NULL,
    "PostId" uuid NOT NULL,
    "UserId" uuid NOT NULL
);


--
-- Name: CelebrationPosts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CelebrationPosts" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "AuthorId" uuid NOT NULL,
    "Content" character varying(4000) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: CentrosCusto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CentrosCusto" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "Manager" character varying(120),
    "Notes" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "EmpresaId" uuid,
    "ValidFrom" date,
    "ValidUntil" date,
    "ParentId" uuid,
    "BranchOrLocation" character varying(160),
    "Description2" character varying(1000),
    "Headcount" integer DEFAULT 0 NOT NULL,
    "OwnerFuncionarioId" uuid,
    "Phone" character varying(40)
);


--
-- Name: DadosBancarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DadosBancarios" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "Banco" character varying(200) NOT NULL,
    "Agencia" character varying(20) NOT NULL,
    "Conta" character varying(30) NOT NULL,
    "TipoConta" smallint NOT NULL,
    "Pix" character varying(150),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Dependentes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Dependentes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "NomeCompleto" character varying(200) NOT NULL,
    "Parentesco" smallint NOT NULL,
    "Cpf" character varying(14),
    "DataNascimento" date NOT NULL,
    "IsPcd" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DescricaoCargoItemEmbeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DescricaoCargoItemEmbeddings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DescricaoCargoItemId" uuid NOT NULL,
    "ModelVersion" character varying(60) NOT NULL,
    "Dimensions" integer NOT NULL,
    "Embedding" public.vector(1024),
    "TextoSource" character varying(4000) DEFAULT ''::character varying NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DescricaoCargoItens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DescricaoCargoItens" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DescricaoCargoId" uuid NOT NULL,
    "Categoria" smallint NOT NULL,
    "Texto" character varying(500) NOT NULL,
    "IsObrigatoria" boolean DEFAULT true NOT NULL,
    "NivelMinimo" character varying(40),
    "Subcategoria" character varying(80),
    "Ordem" integer DEFAULT 0 NOT NULL,
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL,
    "UpdatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: DescricoesCargo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DescricoesCargo" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Summary" character varying(2000),
    "Responsibilities" text,
    "Requirements" text,
    "NiceToHave" text,
    "Benefits" text,
    "IsTemplate" boolean NOT NULL,
    "NivelCargoId" uuid,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "AreaTemplate" character varying(120),
    "CboCodigo" character varying(20),
    "FormacaoMinima" character varying(200),
    "FormacaoDesejavel" character varying(200),
    "FormacaoAreaEstudo" character varying(200),
    "ExperienciaTempoMinimo" character varying(80),
    "ExperienciaTempoDesejavel" character varying(80),
    "ExperienciaEspecificacao" character varying(500),
    "RevisaoNumero" character varying(10),
    "RevisaoData" date,
    "RevisaoNatureza" character varying(200),
    "GestorNome" character varying(200),
    "GestorEmail" character varying(200)
);


--
-- Name: Desligamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Desligamentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "IdReqRm" character varying(40) NOT NULL,
    "ChapaRm" character varying(20) NOT NULL,
    "FuncionarioId" uuid,
    "CodMotivoRescisao" character varying(10),
    "MotivoRescisaoDescricao" character varying(120),
    "CodTipoRescisao" character varying(5),
    "TipoRescisaoDescricao" character varying(120),
    "GerouSubstituicao" boolean NOT NULL,
    "DataAbertura" timestamp with time zone NOT NULL,
    "DataPrevista" timestamp with time zone,
    "DataConclusao" timestamp with time zone,
    "DataCancelamento" timestamp with time zone,
    "CodStatus" integer NOT NULL,
    "Justificativa" text,
    "NumDiasAviso" integer,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DevelopmentPlanGoals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DevelopmentPlanGoals" (
    "Id" uuid NOT NULL,
    "PlanId" uuid NOT NULL,
    "Description" character varying(500) NOT NULL,
    "DueDate" timestamp with time zone,
    "ConcludedAt" timestamp with time zone,
    "Order" integer NOT NULL
);


--
-- Name: DevelopmentPlans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DevelopmentPlans" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "OwnerUserId" uuid NOT NULL,
    "TargetUserId" uuid,
    "Title" character varying(200) NOT NULL,
    "Description" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentacaoPadraoConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Configuracao" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentacaoPadraoHistoricos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoHistoricos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Escopo" smallint NOT NULL,
    "NivelCargoId" uuid,
    "TipoDocumento" smallint NOT NULL,
    "ConfiguracaoAnterior" smallint,
    "ConfiguracaoNova" smallint,
    "Acao" smallint NOT NULL,
    "UserId" uuid,
    "UserNome" character varying(200),
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "CargoId" uuid
);


--
-- Name: DocumentacaoPadraoPorCargoConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoPorCargoConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "JobPositionId" uuid NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Configuracao" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentacaoPadraoPorNivelCargoConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentacaoPadraoPorNivelCargoConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NivelCargoId" uuid NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Configuracao" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: DocumentosColaborador; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DocumentosColaborador" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "Tipo" smallint NOT NULL,
    "NomeArquivo" character varying(260) NOT NULL,
    "ContentType" character varying(100) NOT NULL,
    "TamanhoBytes" bigint NOT NULL,
    "StoragePath" character varying(500) NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoRh" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EixosVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EixosVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "Description" character varying(400),
    "SlaDiasMetaFechamento" integer,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EmailAttempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailAttempts" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EmailMessageId" uuid NOT NULL,
    "AttemptNumber" integer NOT NULL,
    "Provider" character varying(40) NOT NULL,
    "StartedAtUtc" timestamp with time zone NOT NULL,
    "CompletedAtUtc" timestamp with time zone,
    "IsSuccess" boolean NOT NULL,
    "ErrorMessage" character varying(1200),
    "ErrorStackTrace" character varying(2000)
);


--
-- Name: EmailConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Provider" character varying(20) NOT NULL,
    "SmtpHost" character varying(200),
    "SmtpPort" integer NOT NULL,
    "SmtpEnableSsl" boolean NOT NULL,
    "SmtpUserName" character varying(200),
    "SmtpPasswordEncrypted" text,
    "SmtpFromName" character varying(200),
    "SmtpFromAddress" character varying(200),
    "ImapHost" character varying(200),
    "ImapPort" integer NOT NULL,
    "ImapEnableSsl" boolean NOT NULL,
    "ImapUserName" character varying(200),
    "ImapPasswordEncrypted" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EmailMessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailMessages" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "OwnerUserId" character varying(120),
    "OwnerUserName" character varying(200),
    "IsSystem" boolean NOT NULL,
    "Source" character varying(120),
    "To" character varying(320) NOT NULL,
    "Cc" character varying(640),
    "Bcc" character varying(640),
    "Subject" character varying(260) NOT NULL,
    "BodyHtml" text NOT NULL,
    "BodyText" text,
    "TemplateId" uuid,
    "TemplateName" character varying(120),
    "TemplateVersion" integer,
    "PayloadJson" text,
    "Status" integer NOT NULL,
    "AttemptCount" integer NOT NULL,
    "MaxAttempts" integer NOT NULL,
    "NextAttemptAtUtc" timestamp with time zone,
    "LastError" character varying(1200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EmailTemplates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailTemplates" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(120) NOT NULL,
    "SubjectTemplate" character varying(200) NOT NULL,
    "BodyHtml" text NOT NULL,
    "Version" integer NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Empresas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Empresas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Cep" character varying(20),
    "Logradouro" character varying(200),
    "Numero" character varying(40),
    "Bairro" character varying(120),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "Latitude" numeric,
    "Longitude" numeric,
    "GeocodificadoEmUtc" timestamp with time zone
);


--
-- Name: EntraIdConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EntraIdConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EntraTenantId" character varying(120),
    "ClientId" character varying(120),
    "ClientSecretEncrypted" character varying(400),
    "IsEnabled" boolean NOT NULL,
    "CallbackPath" character varying(120),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EntrevistasSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EntrevistasSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DesligamentoId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "TemplateId" uuid NOT NULL,
    "Token" character varying(64) NOT NULL,
    "ExpiresAtUtc" timestamp with time zone NOT NULL,
    "SubmittedAtUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EtapasConfigAprovacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EtapasConfigAprovacao" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "Ordem" integer NOT NULL,
    "Label" character varying(120) NOT NULL,
    "TipoAprovador" smallint NOT NULL,
    "FuncionarioFixoId" uuid,
    "RoleFilaId" uuid,
    "Ativo" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "AcaoEtapa" smallint DEFAULT 0 NOT NULL,
    "MomentoAcao" smallint DEFAULT 0 NOT NULL,
    "SlaHoras" integer
);


--
-- Name: EtapasConfigWorkflowRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EtapasConfigWorkflowRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoWorkflow" smallint NOT NULL,
    "Ordem" integer NOT NULL,
    "Codigo" character varying(50) NOT NULL,
    "Label" character varying(160) NOT NULL,
    "Descricao" character varying(500),
    "SlaPrazoDias" integer,
    "Obrigatoria" boolean NOT NULL,
    "RoleFilaId" uuid,
    "Ativo" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: EtapasWorkflowRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EtapasWorkflowRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "WorkflowId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Codigo" character varying(50) NOT NULL,
    "Label" character varying(160) NOT NULL,
    "Descricao" character varying(500),
    "Status" smallint NOT NULL,
    "Obrigatoria" boolean NOT NULL,
    "ResponsavelId" uuid,
    "RoleFilaId" uuid,
    "SlaPrazoDias" integer,
    "DataInicio" timestamp with time zone,
    "DataConclusao" timestamp with time zone,
    "DadosJson" text,
    "Observacoes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: ExceptionLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ExceptionLogs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RequestLogId" uuid NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "EnvironmentName" character varying(80) NOT NULL,
    "EnvironmentNormalized" character varying(16) NOT NULL,
    "DeviceId" character varying(64) NOT NULL,
    "DeviceType" character varying(40),
    "Platform" character varying(40),
    "Browser" character varying(40),
    "DeviceAppVersion" character varying(120),
    "Locale" character varying(200),
    "Order" integer NOT NULL,
    "OccurredAt" timestamp with time zone NOT NULL,
    "IsHandled" boolean NOT NULL,
    "StatusCode" integer NOT NULL,
    "ExceptionType" character varying(300) NOT NULL,
    "Message" character varying(4096) NOT NULL,
    "StackTrace" character varying(16384),
    "InnerExceptionType" character varying(300),
    "InnerMessage" character varying(4096),
    "ProblemTitle" character varying(4096),
    "ProblemDetail" character varying(4096),
    "ProblemType" character varying(200),
    "ValidationErrorsJson" jsonb,
    "Tags" character varying(200),
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: FaixasSalariais; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FaixasSalariais" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EstabelecimentoCodigo" character varying(10),
    "JobPositionId" uuid,
    "SalarioMinimo" numeric(18,2) NOT NULL,
    "SalarioMaximo" numeric(18,2) NOT NULL,
    "Descricao" character varying(200),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: FasesProcesso; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FasesProcesso" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ProjetoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Ordem" integer NOT NULL,
    "ResponsavelTipo" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Descricao" character varying(500),
    "Observacoes" character varying(2000),
    "SlaDias" integer
);


--
-- Name: FeedbackItemRatings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FeedbackItemRatings" (
    "Id" uuid NOT NULL,
    "FeedbackItemId" uuid NOT NULL,
    "ItemName" character varying(120) NOT NULL,
    "Stars" integer NOT NULL
);


--
-- Name: FeedbackItems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FeedbackItems" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FromUserId" uuid NOT NULL,
    "ToUserId" uuid NOT NULL,
    "Content" character varying(4000) NOT NULL,
    "Tipo" character varying(40),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "InternalNotes" character varying(4000),
    "IsPresencial" boolean DEFAULT false NOT NULL
);


--
-- Name: FluxosAprovacaoConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FluxosAprovacaoConfig" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "ReferenciaUnidade" smallint NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: FuncionarioMovimentacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FuncionarioMovimentacoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid,
    "ChapaRm" character varying(20) NOT NULL,
    "IdReqRm" character varying(40) NOT NULL,
    "TipoMovimentacao" smallint NOT NULL,
    "TipoDescricao" character varying(60),
    "DataAbertura" timestamp with time zone NOT NULL,
    "DataConclusao" timestamp with time zone,
    "DataCancelamento" timestamp with time zone,
    "CodStatus" integer NOT NULL,
    "StatusDescricao" character varying(60),
    "CodFuncaoOrigem" character varying(20),
    "FuncaoOrigemNome" character varying(160),
    "CodSecaoOrigem" character varying(60),
    "CodSecaoDestino" character varying(60),
    "CodFuncaoDestino" character varying(20),
    "FuncaoDestinoNome" character varying(160),
    "HierarquiaOrigemId" uuid,
    "HierarquiaDestinoId" uuid,
    "IdHierarquiaOrigemRm" integer,
    "IdHierarquiaDestinoRm" integer,
    "SalarioOrigem" numeric(18,2),
    "SalarioDestino" numeric(18,2),
    "Justificativa" text,
    "GerouSubstituicao" boolean,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Funcionarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Funcionarios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Name" character varying(160) NOT NULL,
    "Email" character varying(180),
    "Phone" character varying(40),
    "Status" integer NOT NULL,
    "UserId" uuid,
    "UnitId" uuid,
    "Headcount" integer NOT NULL,
    "JobPositionId" uuid,
    "Notes" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "PessoaId" uuid,
    "AvatarFileName" text,
    "GestorDiretoId" uuid,
    "NivelHierarquicoId" uuid,
    "CdnEmpresa" character varying(3),
    "CdnEstab" character varying(5),
    "CdnFuncionario" character varying(12),
    "UnidadeLotacaoId" uuid,
    "NivelCargoId" uuid,
    "CdnNivCargo" integer,
    "CentroCustoId" uuid,
    "HasIncompleteData" boolean DEFAULT false NOT NULL,
    "DataAdmissao" date,
    "DataNascimento" date,
    "PeriodoExperienciaDias" integer DEFAULT 90 NOT NULL,
    "Sexo" character varying(1),
    "MatriculaRm" character varying(20),
    "HierarquiaId" uuid,
    "CodSituacaoRm" character varying(5),
    "SituacaoRmDescricao" character varying(60),
    "CodFuncaoRm" character varying(20),
    "FuncaoNomeRm" character varying(160),
    "CiclosAusenteRm" integer DEFAULT 0 NOT NULL,
    "UltimoCicloRmObservadoUtc" timestamp with time zone
);


--
-- Name: GamificationDailyStates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GamificationDailyStates" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "CurrentStreak" integer NOT NULL,
    "BestStreak" integer NOT NULL,
    "LastCheckInDate" date,
    "LastActivityDate" date,
    "FeedbackSentToday" integer NOT NULL,
    "CelebrationPostsToday" integer NOT NULL,
    "CelebrationCommentsToday" integer NOT NULL,
    "OneOnOneCompletedToday" integer NOT NULL,
    "DevelopmentPlansCreatedToday" integer NOT NULL,
    "SurveyAnsweredToday" integer NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Hierarquias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Hierarquias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "IdHierarquiaRm" integer NOT NULL,
    "Descricao" character varying(200) NOT NULL,
    "IdHierarquiaSuperiorRm" integer,
    "HierarquiaSuperiorId" uuid,
    "Estrutura" character varying(200),
    "IdNivelHierarquiaRm" integer,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: HistoricosAlteracaoWorkflowRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HistoricosAlteracaoWorkflowRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "WorkflowId" uuid NOT NULL,
    "EtapaWorkflowId" uuid,
    "Campo" character varying(120) NOT NULL,
    "ValorAnterior" character varying(2000),
    "ValorNovo" character varying(2000),
    "OrigemPreenchimento" smallint NOT NULL,
    "AlteradoPorId" uuid NOT NULL,
    "AlteradoPorNome" character varying(200) NOT NULL,
    "DataAlteracaoUtc" timestamp with time zone NOT NULL,
    "Observacao" character varying(2000)
);


--
-- Name: HistoricosStatus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HistoricosStatus" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoEntidade" smallint NOT NULL,
    "EntidadeId" uuid NOT NULL,
    "StatusAnterior" character varying(80) NOT NULL,
    "StatusNovo" character varying(80) NOT NULL,
    "AlteradoPorFuncionarioId" uuid,
    "AlteradoPorUserId" uuid,
    "AlteradoPorNome" character varying(200) NOT NULL,
    "AlteradoEmUtc" timestamp with time zone NOT NULL,
    "SlaEsperadoHoras" integer,
    "TempoNoStatusAnteriorHoras" double precision,
    "DentroDoSla" boolean,
    "Observacao" character varying(1000)
);


--
-- Name: Holerites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Holerites" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "MesReferencia" integer NOT NULL,
    "AnoReferencia" integer NOT NULL,
    "ArquivoPath" character varying(500) NOT NULL,
    "ArquivoNome" character varying(255) NOT NULL,
    "TamanhoBytes" bigint NOT NULL,
    "EnviadoPorId" uuid,
    "EnviadoEmUtc" timestamp with time zone NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: InboxAttachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InboxAttachments" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "InboxItemId" uuid NOT NULL,
    "Nome" character varying(200) NOT NULL,
    "Tipo" character varying(20),
    "TamanhoKB" integer NOT NULL,
    "Hash" character varying(120),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: InboxItems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InboxItems" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Origem" integer NOT NULL,
    "Status" integer NOT NULL,
    "RecebidoEm" timestamp with time zone NOT NULL,
    "Remetente" character varying(180),
    "Assunto" character varying(220),
    "Destinatario" character varying(200),
    "VagaId" uuid,
    "PreviewText" text,
    "ProcessamentoPct" integer NOT NULL,
    "ProcessamentoEtapa" character varying(120),
    "ProcessamentoTentativas" integer NOT NULL,
    "ProcessamentoUltimoErro" character varying(400),
    "ProcessamentoLogRaw" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "SuggestedVagasJson" jsonb,
    "CandidatoId" uuid
);


--
-- Name: JobPositions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobPositions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(40) NOT NULL,
    "Name" character varying(160) NOT NULL,
    "Status" integer NOT NULL,
    "CentroCustoId" uuid,
    "Seniority" integer NOT NULL,
    "Type" character varying(180),
    "Description" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DescricaoPublicacao" text,
    "NivelHierarquicoId" uuid,
    "OccupationalClassification" text,
    "FullDescription" character varying(500),
    "SimilarityIndicator" character varying(1),
    "DesEnvelPagto" character varying(40),
    "NivelCargoId" uuid,
    "TotvsCargoBasicId" integer,
    "TotvsNivCargoId" integer
);


--
-- Name: LocalizationConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LocalizationConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Culture" character varying(20),
    "UiCulture" character varying(20),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: LogEntries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LogEntries" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RequestLogId" uuid NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "EnvironmentName" character varying(80) NOT NULL,
    "EnvironmentNormalized" character varying(16) NOT NULL,
    "DeviceId" character varying(64) NOT NULL,
    "DeviceType" character varying(40),
    "Platform" character varying(40),
    "Browser" character varying(40),
    "DeviceAppVersion" character varying(120),
    "Locale" character varying(200),
    "Order" integer NOT NULL,
    "Level" character varying(20) NOT NULL,
    "Category" character varying(200) NOT NULL,
    "EventId" integer,
    "EventName" character varying(200),
    "Message" character varying(8192) NOT NULL,
    "ExceptionType" character varying(300),
    "ExceptionMessage" character varying(8192),
    "ExceptionStackTrace" character varying(16384),
    "PropertiesJson" jsonb,
    "OccurredAt" timestamp with time zone NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: LogsComunicacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LogsComunicacao" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "ProjetoId" uuid,
    "Tipo" smallint NOT NULL,
    "Assunto" character varying(200),
    "Mensagem" character varying(4000),
    "Destinatario" character varying(200),
    "UsuarioNome" character varying(120),
    "DataUtc" timestamp with time zone NOT NULL
);


--
-- Name: Menus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Menus" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "DisplayName" character varying(160) NOT NULL,
    "Route" character varying(240) NOT NULL,
    "Icon" character varying(120) NOT NULL,
    "Order" integer NOT NULL,
    "ParentId" uuid,
    "PermissionKey" character varying(160) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "OpenInNewTab" boolean DEFAULT false NOT NULL,
    "DisplayNameKey" character varying(200)
);


--
-- Name: Metas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Metas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "CriadaPorId" uuid NOT NULL,
    "Titulo" character varying(300) NOT NULL,
    "Descricao" character varying(2000),
    "ValorMeta" numeric(18,4) NOT NULL,
    "ValorAtual" numeric(18,4) NOT NULL,
    "Unidade" character varying(20) NOT NULL,
    "Prazo" date,
    "Status" smallint NOT NULL,
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: MoodEntries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MoodEntries" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "Mood" character varying(20) NOT NULL,
    "Note" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: MotivosRequisicaoVagaConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MotivosRequisicaoVagaConfig" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Codigo" character varying(60) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Descricao" character varying(500),
    "EfeitoHeadcount" smallint NOT NULL,
    "IsActive" boolean NOT NULL,
    "Ordem" integer NOT NULL,
    "IsSystem" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: NineBoxAssessments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NineBoxAssessments" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "AvaliadorId" uuid NOT NULL,
    "Desempenho" integer NOT NULL,
    "Potencial" integer NOT NULL,
    "Observacoes" character varying(2000),
    "CriadoEmUtc" timestamp with time zone NOT NULL,
    "AtualizadoEmUtc" timestamp with time zone NOT NULL,
    "CicloAvaliacaoId" uuid
);


--
-- Name: NiveisCargo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NiveisCargo" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "CdnNivCargo" integer NOT NULL,
    "NomReduz" character varying(6) NOT NULL,
    "NomComplet" character varying(40) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: NiveisHierarquicos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NiveisHierarquicos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Ordem" integer NOT NULL,
    "Ativo" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: NotificacoesCandidaturaLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificacoesCandidaturaLogs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CandidaturaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "EtapaMacro" smallint NOT NULL,
    "Canal" smallint NOT NULL,
    "Status" smallint NOT NULL,
    "Destino" character varying(200),
    "Mensagem" character varying(4000),
    "ErroMensagem" character varying(1000),
    "CriadoEmUtc" timestamp with time zone NOT NULL
);


--
-- Name: NotificacoesTemplates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificacoesTemplates" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Etapa" smallint NOT NULL,
    "Canal" smallint NOT NULL,
    "Assunto" character varying(240),
    "Corpo" character varying(4000) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Idioma" character varying(10)
);


--
-- Name: NotificationReceipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NotificationReceipts" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NotificationId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "SeenAtUtc" timestamp with time zone,
    "ReadAtUtc" timestamp with time zone,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notifications" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Message" character varying(2000) NOT NULL,
    "Level" character varying(20) NOT NULL,
    "Url" character varying(500),
    "IsRead" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UserId" uuid
);


--
-- Name: OcupacoesHistorico; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OcupacoesHistorico" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid,
    "FuncionarioId" uuid,
    "DataEntrada" timestamp with time zone NOT NULL,
    "DataSaida" timestamp with time zone,
    "MotivoSaida" text,
    "SolicitacaoOrigemId" uuid,
    "IsProvisorio" boolean DEFAULT false NOT NULL,
    "ProvisorioExpiresAtUtc" timestamp with time zone
);


--
-- Name: OneOnOneMeetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."OneOnOneMeetings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ManagerId" uuid NOT NULL,
    "CollaboratorId" uuid NOT NULL,
    "MeetingDate" timestamp with time zone NOT NULL,
    "Subject" character varying(200),
    "Notes" character varying(4000),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PerguntasEntrevistaSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PerguntasEntrevistaSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TemplateId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Texto" character varying(500) NOT NULL,
    "TipoResposta" smallint NOT NULL,
    "Opcoes" character varying(1000),
    "Obrigatoria" boolean DEFAULT false NOT NULL
);


--
-- Name: PermissoesNivelVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PermissoesNivelVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NivelHierarquicoId" uuid NOT NULL,
    "RoleId" uuid NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PessoaBloqueios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PessoaBloqueios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PessoaId" uuid NOT NULL,
    "Motivo" character varying(500),
    "OrigemBloqueio" integer NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "CreatedByUserId" character varying(120)
);


--
-- Name: Pessoas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Pessoas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Email" character varying(180) NOT NULL,
    "Fone" character varying(40),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "LinkedinUrl" character varying(260),
    "ResumoProfissional" character varying(2000),
    "Obs" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Origem" integer DEFAULT 0 NOT NULL,
    "Bairro" character varying(120),
    "Cep" character varying(20),
    "Complemento" character varying(120),
    "Cpf" character varying(14),
    "FoneContato" character varying(40),
    "Logradouro" character varying(200),
    "Numero" character varying(40),
    "Rg" character varying(20),
    "DataNascimento" timestamp with time zone,
    "Latitude" numeric,
    "Longitude" numeric,
    "GeocodificadoEmUtc" timestamp with time zone,
    "Sexo" character varying(1),
    "EstadoCivil" character varying(2),
    "Naturalidade" character varying(120),
    "EstadoNatal" character varying(2),
    "GrauInstrucao" character varying(5),
    "RgOrgEmissor" character varying(20),
    "RgUf" character varying(2),
    "RgDataEmissao" timestamp with time zone,
    "CarteiraTrabalho" character varying(20),
    "CarteiraTrabalhoSerie" character varying(10),
    "CarteiraTrabalhoUf" character varying(2),
    "CarteiraTrabalhoData" timestamp with time zone,
    "NumeroPis" character varying(20),
    "TituloEleitor" character varying(20),
    "TituloEleitorZona" character varying(10),
    "TituloEleitorSecao" character varying(10),
    "CertificadoReservista" character varying(20),
    "CategoriaMilitar" character varying(2),
    "NomePai" character varying(160),
    "NomeMae" character varying(160),
    "Nacionalidade" character varying(60)
);


--
-- Name: PreAdmissaoDependentes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissaoDependentes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PreAdmissaoId" uuid NOT NULL,
    "NomeCompleto" character varying(200) NOT NULL,
    "Parentesco" smallint NOT NULL,
    "Cpf" character varying(14),
    "DataNascimento" date NOT NULL,
    "IsPcd" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PreAdmissaoDocumentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissaoDocumentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PreAdmissaoId" uuid NOT NULL,
    "Tipo" smallint NOT NULL,
    "NomeArquivo" character varying(260) NOT NULL,
    "ContentType" character varying(100) NOT NULL,
    "TamanhoBytes" bigint NOT NULL,
    "StoragePath" character varying(500) NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoRh" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Lado" smallint DEFAULT 0 NOT NULL
);


--
-- Name: PreAdmissaoDocumentosSolicitados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissaoDocumentosSolicitados" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PreAdmissaoId" uuid NOT NULL,
    "TipoDocumento" smallint NOT NULL,
    "Obrigatorio" boolean DEFAULT true NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: PreAdmissoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PreAdmissoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Status" smallint NOT NULL,
    "PreenchidoPor" smallint NOT NULL,
    "CandidatoId" uuid,
    "RevisadoPorId" uuid,
    "AprovadoPorId" uuid,
    "ObservacaoRh" character varying(2000),
    "MotivoRejeicao" character varying(2000),
    "Nome" character varying(160) NOT NULL,
    "Cpf" character varying(14),
    "Rg" character varying(20),
    "RgOrgaoExpedidor" character varying(20),
    "RgDataExpedicao" date,
    "DataNascimento" date,
    "Sexo" smallint NOT NULL,
    "EstadoCivil" smallint NOT NULL,
    "Nacionalidade" character varying(60),
    "NomeMae" character varying(160),
    "NomePai" character varying(160),
    "NaturalCidade" character varying(120),
    "NaturalUf" character varying(2),
    "Passaporte" character varying(30),
    "RnmRne" character varying(30),
    "ValidadeVisto" date,
    "TipoVisto" character varying(60),
    "Cep" character varying(10),
    "Logradouro" character varying(200),
    "Numero" character varying(20),
    "Complemento" character varying(120),
    "Bairro" character varying(120),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "Email" character varying(180),
    "Telefone" character varying(20),
    "Celular" character varying(20),
    "ContatoEmergenciaNome" character varying(160),
    "ContatoEmergenciaFone" character varying(20),
    "BancoCodigo" character varying(10),
    "BancoNome" character varying(80),
    "Agencia" character varying(10),
    "AgenciaDigito" character varying(2),
    "Conta" character varying(20),
    "ContaDigito" character varying(2),
    "TipoConta" smallint,
    "EstabelecimentoCodigo" character varying(10),
    "MatriculaRM" character varying(20),
    "UnitId" uuid,
    "CentroCustoId" uuid,
    "JobPositionId" uuid,
    "DataAdmissao" date,
    "Salario" numeric(18,2),
    "TipoContratacao" smallint,
    "CargaHorariaSemanal" smallint,
    "PisPasep" character varying(20),
    "TituloEleitorNumero" character varying(20),
    "TituloEleitorZona" character varying(10),
    "TituloEleitorSecao" character varying(10),
    "ReservistaNumero" character varying(20),
    "CategoriaCnh" character varying(10),
    "ValidadeCnh" date,
    "Ctps" character varying(20),
    "CtpsSerie" character varying(10),
    "CtpsUf" character varying(2),
    "ValidacaoCpfOk" boolean NOT NULL,
    "ValidacaoCepOk" boolean NOT NULL,
    "ValidacaoBancoOk" boolean NOT NULL,
    "ValidacaoSalarioOk" boolean NOT NULL,
    "ValidacaoSalarioJustificativa" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "SubmittedAtUtc" timestamp with time zone,
    "ApprovedAtUtc" timestamp with time zone,
    "AccessToken" character varying(64),
    "Altura" integer,
    "CartaoSus" character varying(30),
    "CategoriaSalarial" integer,
    "CentroCustoTotvs" character varying(30),
    "CodCargoTotvs" integer,
    "CodTurno" integer,
    "CodVinculoEmpregaticio" integer,
    "CtpsModelo" integer,
    "DocMilitarNumero" character varying(30),
    "DocMilitarRegiao" integer,
    "DocMilitarSerie" character varying(20),
    "DocMilitarTipo" integer,
    "FatorRh" integer,
    "GrauInstrucao" integer,
    "GrupoSanguineo" integer,
    "Peso" integer,
    "PossuiDeficiencia" character varying(1),
    "TipoFuncionario" integer,
    "TituloEleitorCidade" character varying(120),
    "TituloEleitorUf" character varying(2),
    "UnidadeLotacao" character varying(30),
    "Avos13SalCalc" integer,
    "Avos13SalCalcAnterior" integer,
    "Cabelo" integer,
    "Calcula13" character varying(1),
    "CargaAutomTurno" character varying(1),
    "CategoriaTrabalhoESocial" integer,
    "CnhDataExpedicao" date,
    "CnhNumero" character varying(20),
    "CnhOrgaoEmissor" character varying(20),
    "CnhPrimeiraHabilitacao" date,
    "CnhUf" character varying(2),
    "CodClassFuncPontoEletronico" integer,
    "CodEmpresa" character varying(10),
    "CodFpas" integer,
    "CodLocalMarcacao" integer,
    "CodLocalidade" integer,
    "CodNivel" integer,
    "CodPlanoLotacao" integer,
    "CodSindicato" integer,
    "CodTurma" integer,
    "ConsidEmissRAIS" character varying(1),
    "ContribSindicDia" character varying(1),
    "CtpsSerieESocial" character varying(10),
    "Cutis" integer,
    "DataTerminoContrato" integer,
    "DddTelContato" integer,
    "DddTelefone" integer,
    "DescContribSindical" character varying(1),
    "DiasProvFeriasMesAnterior" numeric,
    "DiasProvFeriasMesAtual" numeric,
    "EmailAlternativo" character varying(180),
    "EmitCartPonto" character varying(1),
    "FormaPagamento" integer,
    "FuncDoador" character varying(1),
    "FuncQualificado" character varying(1),
    "IndAdmissao" integer,
    "IndFuncVinculado" integer,
    "Manequim" integer,
    "MatriculaESocial" character varying(30),
    "MunicipioEnderecoIbge" integer,
    "MunicipioNascimentoIbge" integer,
    "NaturezaAtividade" integer,
    "NomeAbreviado" character varying(20),
    "NumCartaoPonto" integer,
    "OcorrenciaCAGED" integer,
    "Olhos" integer,
    "OptanteFgts" character varying(1),
    "OrigemFuncionario" integer,
    "PaisLocalidade" character varying(10),
    "PaisNascimento" character varying(10),
    "PontoReferencia" character varying(120),
    "ProvAcum13Sal" numeric,
    "ProvAcumFerias" numeric,
    "ProvAcumFerias13" numeric,
    "ProvAcumFgts13Sal" numeric,
    "ProvAcumFgtsFerias" numeric,
    "ProvAcumInss13Sal" numeric,
    "ProvAcumInssFerias" numeric,
    "RecebeAdiantamento" character varying(1),
    "RecebeFerias" character varying(1),
    "RecebeInsalub" character varying(1),
    "RecebePericul" character varying(1),
    "RecolheFgts" character varying(1),
    "RecolheInss" character varying(1),
    "RegimeJornada" integer,
    "RegimePrevidenciario" integer,
    "RegimeTrabalhista" integer,
    "RgUfExpedidor" character varying(2),
    "SalarioSimulado" numeric,
    "Sapato" integer,
    "Sindicalizado" character varying(1),
    "TipoAdmissaoESocial" integer,
    "TipoAdmissaoFgts" integer,
    "TipoLogradouroESocial" character varying(5),
    "TipoMaoDeObra" character varying(10),
    "TipoVistoEstrangeiro" integer,
    "CodRegistroExterior" character varying(30),
    "DataOpcaoFgts" date,
    "DocMilitarCircunscricao" integer,
    "LastActivityUtc" timestamp with time zone,
    "NomeSocial" character varying(160),
    "PaisNacionalidade" character varying(10),
    "ResideExterior" character varying(1),
    "WizardCompletionPercent" integer,
    "WizardCurrentStep" integer,
    "AnoChegada" integer,
    "CidadeExterior" character varying(120),
    "CodEnderecoPostalExterior" character varying(20),
    "DataObitoCivil" date,
    "OrgaoEmisPassaporte" integer,
    "PaisEmisPassaporte" character varying(10),
    "PortariaNaturalizacao" character varying(60),
    "Naturalizacao" character varying(60),
    "TipoCertidaoCivil" integer,
    "TipoEstatistica" integer,
    "ValidadeIdentEstrangeiro" date,
    "FuncionarioIdMaterializado" uuid,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "RegIdentidCivilNumero" character varying(20),
    "RegIdentidCivilUf" character varying(2),
    "RegIdentidCivilCidade" character varying(120),
    "RegIdentidCivilOrgEmiss" character varying(20),
    "RegIdentidCivilDataExped" date,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone,
    "VagaId" uuid,
    "IntegracaoResultado" smallint,
    "IntegracaoMensagem" character varying(2000),
    "IntegradaEmUtc" timestamp with time zone,
    "RequisitoCategoriaId" uuid
);


--
-- Name: ProjetoCandidatos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjetoCandidatos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ProjetoId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Status" smallint NOT NULL,
    "FaseAtualId" uuid,
    "Observacoes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: ProjetosVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProjetosVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Numero" integer NOT NULL,
    "Descricao" character varying(240),
    "Status" smallint NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DataInicio" date,
    "DataEncerramento" date
);


--
-- Name: PropostasVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PropostasVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "Status" smallint NOT NULL,
    "Moeda" character varying(3),
    "SalarioOferecido" numeric(18,2),
    "DescricaoBeneficios" character varying(2000),
    "DataPrevistaInicio" date,
    "MensagemPersonalizada" character varying(8000),
    "AccessToken" character varying(64),
    "EnviadaEmUtc" timestamp with time zone,
    "ExpiraEmUtc" timestamp with time zone,
    "VisualizadaEmUtc" timestamp with time zone,
    "RespondidaEmUtc" timestamp with time zone,
    "NomeConfirmadoCandidato" character varying(160),
    "IpOrigemResposta" character varying(60),
    "UserAgentResposta" character varying(400),
    "MotivoRecusa" character varying(2000),
    "CriadaPorUserId" uuid,
    "EnviadaPorUserId" uuid,
    "ObservacaoInternaRh" character varying(500),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "CandidaturaId" uuid
);


--
-- Name: RecruiterMatchingFeedbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RecruiterMatchingFeedbacks" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "RecruiterUserId" character varying(120),
    "Action" smallint NOT NULL,
    "MatchScoreAtAction" integer,
    "RankPositionAtAction" integer,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RenderCoinBalances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RenderCoinBalances" (
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "Balance" numeric(18,4) NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RenderCoinTransactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RenderCoinTransactions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "UserId" uuid NOT NULL,
    "Amount" numeric(18,4) NOT NULL,
    "Reason" character varying(200),
    "SourceType" character varying(40),
    "SourceId" character varying(100),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RequestLogs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RequestLogs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TransactionId" character varying(120) NOT NULL,
    "CorrelationId" character varying(200),
    "TraceId" character varying(200),
    "EnvironmentName" character varying(80) NOT NULL,
    "EnvironmentNormalized" character varying(16) NOT NULL,
    "DeviceId" character varying(64) NOT NULL,
    "DeviceType" character varying(40),
    "Platform" character varying(40),
    "Browser" character varying(40),
    "DeviceAppVersion" character varying(120),
    "Locale" character varying(200),
    "StartedAt" timestamp with time zone NOT NULL,
    "EndedAt" timestamp with time zone,
    "DurationMs" bigint NOT NULL,
    "Method" character varying(16) NOT NULL,
    "Path" character varying(512) NOT NULL,
    "QueryString" character varying(1024),
    "StatusCode" integer,
    "IsSuccess" boolean NOT NULL,
    "UserId" character varying(120),
    "UserName" character varying(200),
    "ClientId" character varying(120),
    "Ip" character varying(80),
    "UserAgent" character varying(400),
    "Host" character varying(200),
    "Controller" character varying(120),
    "Action" character varying(120),
    "RouteTemplate" character varying(512),
    "RequestBodySnippet" character varying(4096),
    "ResponseBodySnippet" character varying(4096),
    "ErrorCount" integer NOT NULL,
    "WarningCount" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


--
-- Name: RespostasCampoPersonalizadoVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RespostasCampoPersonalizadoVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "CandidatoId" uuid NOT NULL,
    "CampoId" uuid NOT NULL,
    "ValorTexto" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: RespostasEntrevistaSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RespostasEntrevistaSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "EntrevistaId" uuid NOT NULL,
    "PerguntaId" uuid NOT NULL,
    "ValorTexto" character varying(2000),
    "ValorEscala" integer,
    "ValorOpcao" character varying(200)
);


--
-- Name: RmSyncAlertas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RmSyncAlertas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Tipo" character varying(40) NOT NULL,
    "EntidadeNome" character varying(40) NOT NULL,
    "EntidadeId" uuid,
    "ChaveRm" character varying(80) NOT NULL,
    "DetectadoEmUtc" timestamp with time zone NOT NULL,
    "CiclosAusente" integer NOT NULL,
    "ResolvidoEmUtc" timestamp with time zone,
    "ResolvidoPorId" uuid,
    "Acao" character varying(120),
    "RunId" uuid
);


--
-- Name: RmSyncCheckpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RmSyncCheckpoints" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Entidade" character varying(60) NOT NULL,
    "LastRecModifiedOn" timestamp with time zone,
    "LastRunAtUtc" timestamp with time zone,
    "LastRunStatus" character varying(20),
    "Notes" character varying(500)
);


--
-- Name: RmSyncRuns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RmSyncRuns" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Entidade" character varying(60) NOT NULL,
    "Operacao" character varying(20) NOT NULL,
    "StartedAtUtc" timestamp with time zone NOT NULL,
    "EndedAtUtc" timestamp with time zone,
    "Status" smallint NOT NULL,
    "TotalLidos" integer NOT NULL,
    "Criados" integer NOT NULL,
    "Atualizados" integer NOT NULL,
    "Ignorados" integer NOT NULL,
    "ErroMensagem" character varying(2000),
    "WatermarkAplicadoUtc" timestamp with time zone,
    "WatermarkNovoUtc" timestamp with time zone
);


--
-- Name: RoleMenus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RoleMenus" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RoleId" uuid NOT NULL,
    "MenuId" uuid NOT NULL,
    "PermissionKey" character varying(160) NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Roles" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Description" character varying(400) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Name" character varying(256),
    "NormalizedName" character varying(256),
    "ConcurrencyStamp" text,
    "AccessMode" smallint DEFAULT 0 NOT NULL,
    "VagasDataScope" smallint DEFAULT 0 NOT NULL,
    "VisibilityScope" smallint DEFAULT 0 NOT NULL,
    "Tipo" smallint DEFAULT 1 NOT NULL
);


--
-- Name: SkillAliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SkillAliases" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SkillId" uuid NOT NULL,
    "AliasName" character varying(180) NOT NULL
);


--
-- Name: Skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Skills" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CanonicalName" character varying(180) NOT NULL,
    "Category" character varying(80),
    "ParentSkillId" uuid,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone
);


--
-- Name: SlaStatusConfigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SlaStatusConfigs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoEntidade" smallint NOT NULL,
    "Status" character varying(80) NOT NULL,
    "SlaHoras" integer NOT NULL,
    "Ativo" boolean NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: SolicitacoesAprovacaoEtapas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesAprovacaoEtapas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SolicitacaoId" uuid NOT NULL,
    "TipoFluxo" smallint NOT NULL,
    "Ordem" integer NOT NULL,
    "Label" character varying(120) NOT NULL,
    "AprovadorId" uuid,
    "RoleFilaId" uuid,
    "Status" smallint NOT NULL,
    "Observacao" text,
    "DataUtc" timestamp with time zone,
    "AcaoEtapa" smallint DEFAULT 0 NOT NULL,
    "MomentoAcao" smallint DEFAULT 0 NOT NULL,
    "AssumedByUserId" uuid,
    "CreatedAtUtc" timestamp with time zone DEFAULT now() NOT NULL,
    "LembretesEnviados" integer DEFAULT 0 NOT NULL,
    "UltimoLembreteUtc" timestamp with time zone,
    "EscaladoEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesBeneficio; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesBeneficio" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "TipoBeneficio" smallint NOT NULL,
    "TipoAlteracao" smallint NOT NULL,
    "Descricao" text NOT NULL,
    "IncluirDependentes" boolean NOT NULL,
    "DependenteIdsJson" text,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesDependente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesDependente" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "TipoSolicitacao" smallint NOT NULL,
    "DependenteId" uuid,
    "NomeCompleto" text NOT NULL,
    "Parentesco" smallint NOT NULL,
    "Cpf" text,
    "DataNascimento" date NOT NULL,
    "IsPcd" boolean NOT NULL,
    "DependenteIR" boolean NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesDesligamento; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesDesligamento" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "DataDesligamento" date NOT NULL,
    "TipoDesligamento" smallint NOT NULL,
    "MotivoDesligamento" text NOT NULL,
    "TipoAvisoPrevio" smallint NOT NULL,
    "DiasAvisoPrevio" integer NOT NULL,
    "ElegivelRecontratacao" boolean NOT NULL,
    "SubstituirPosicao" boolean NOT NULL,
    "SolicitacaoVagaGeradaId" uuid,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "PossuiEstabilidade" boolean DEFAULT false NOT NULL,
    "EmpresaId" uuid,
    "HistoricoMedidasDisciplinares" boolean,
    "UnitId" uuid,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone,
    "SolicitacaoVagaOrigemId" uuid
);


--
-- Name: SolicitacoesEndereco; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesEndereco" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "Cep" text NOT NULL,
    "Logradouro" text NOT NULL,
    "Numero" text,
    "Bairro" text,
    "Complemento" text,
    "Cidade" text NOT NULL,
    "Uf" text NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesFerias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesFerias" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "PeriodoAquisitivo" text,
    "DataInicio" date NOT NULL,
    "DataFim" date NOT NULL,
    "QtdDias" integer NOT NULL,
    "AbonoPecuniario" boolean NOT NULL,
    "DiasAbono" integer NOT NULL,
    "Adiantamento13" boolean NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesPagamentoExtra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesPagamentoExtra" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid,
    "FuncionarioId" uuid NOT NULL,
    "TipoPagamentoExtra" smallint NOT NULL,
    "Valor" numeric NOT NULL,
    "Descricao" character varying(500) NOT NULL,
    "DataPagamento" date NOT NULL,
    "Competencia" character varying(7),
    "Status" smallint NOT NULL,
    "ImportadoPorId" uuid,
    "ImportadaEmUtc" timestamp with time zone,
    "Observacoes" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoResultado" smallint,
    "IntegracaoMensagem" character varying(2000),
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesPromocao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesPromocao" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "FuncionarioId" uuid NOT NULL,
    "DataEfetiva" date NOT NULL,
    "CargoAtualId" uuid,
    "NovoCargoId" uuid NOT NULL,
    "CentroCustoAtualId" uuid,
    "NovoCentroCustoId" uuid,
    "Justificativa" text NOT NULL,
    "Status" smallint NOT NULL,
    "ObservacaoAprovador" text,
    "Observacoes" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "MotivoMovimentacao" smallint,
    "NovaUnidadeId" uuid,
    "HorarioProposto" text,
    "NovaLocalidade" text,
    "NovaPericulosidade" text,
    "NovaRemuneracao" numeric,
    "NovoSalario" numeric,
    "UnitId" uuid,
    "EmpresaId" uuid,
    "CentroCustoId" uuid,
    "UnidadeLotacaoId" uuid,
    "ForaFaixaSalarial" boolean DEFAULT false NOT NULL,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone
);


--
-- Name: SolicitacoesVaga; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SolicitacoesVaga" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SolicitanteId" uuid NOT NULL,
    "AprovadorId" uuid,
    "JobPositionId" uuid,
    "UnitId" uuid,
    "Titulo" character varying(160) NOT NULL,
    "Justificativa" character varying(2000),
    "QtdPosicoes" integer NOT NULL,
    "Urgencia" smallint NOT NULL,
    "Status" smallint NOT NULL,
    "VagaId" uuid,
    "ObservacaoAprovador" character varying(2000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "ApprovedAtUtc" timestamp with time zone,
    "IsConfidencial" boolean DEFAULT false NOT NULL,
    "SubstituidoFuncionarioId" uuid,
    "SubstituidoNome" character varying(160),
    "TipoSolicitacao" smallint DEFAULT 0 NOT NULL,
    "CnhObrigatoria" boolean DEFAULT false NOT NULL,
    "DisponibilidadeViagens" boolean DEFAULT false NOT NULL,
    "EscalaTrabalho" text,
    "MotivoRequisicao" smallint,
    "PrazoDias" integer,
    "TipoContrato" smallint DEFAULT 0 NOT NULL,
    "EmpresaId" uuid,
    "CentroCustoId" uuid,
    "UnidadeLotacaoId" uuid,
    "IntegracaoMensagem" character varying(2000),
    "IntegracaoResultado" smallint,
    "IntegradaEmUtc" timestamp with time zone,
    "TentativasIntegracao" integer DEFAULT 0 NOT NULL,
    "UltimaTentativaUtc" timestamp with time zone,
    "DecisaoRH" smallint,
    "DecisaoRHEmUtc" timestamp with time zone,
    "DecisaoRHPrazoMeses" integer,
    "DecisaoRHRevisadoPorId" uuid,
    "EfetivadoManualmentePorId" uuid,
    "EfetivadoManualmenteEmUtc" timestamp with time zone,
    "DataDesligamento" date,
    "DesligamentoVinculadoId" uuid,
    "DiasAvisoPrevioDesligamento" integer,
    "MotivoDesligamentoTexto" character varying(2000),
    "PossuiEstabilidadeDesligamento" boolean,
    "TipoAvisoPrevioDesligamento" smallint,
    "CandidatoContratadoId" uuid,
    "DecisaoRHPrazoDataAlvo" timestamp with time zone,
    "MotivoRequisicaoId" uuid
);


--
-- Name: SurveyAnswers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyAnswers" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "ResponseId" uuid NOT NULL,
    "QuestionId" uuid NOT NULL,
    "OptionId" uuid,
    "TextAnswer" character varying(2000)
);


--
-- Name: SurveyOptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyOptions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "QuestionId" uuid NOT NULL,
    "Text" character varying(400) NOT NULL,
    "Order" integer NOT NULL
);


--
-- Name: SurveyQuestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyQuestions" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SurveyId" uuid NOT NULL,
    "Text" character varying(2000) NOT NULL,
    "Type" character varying(40),
    "Order" integer NOT NULL
);


--
-- Name: SurveyResponses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SurveyResponses" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "SurveyId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "SubmittedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Surveys" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Title" character varying(240) NOT NULL,
    "Type" character varying(40),
    "StartAtUtc" timestamp with time zone,
    "EndAtUtc" timestamp with time zone,
    "DepartmentsJson" jsonb,
    "CreatedByUserId" uuid,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TalentoCompetencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoCompetencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Tipo" character varying(40) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Nivel" character varying(40) NOT NULL,
    "Evidencia" character varying(300),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "TempoAtuacao" character varying(80)
);


--
-- Name: TalentoCvImportJobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoCvImportJobs" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "TalentoDocumentoId" uuid NOT NULL,
    "Status" integer NOT NULL,
    "EnviarParaGpt" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "FinishedAtUtc" timestamp with time zone,
    "SimilarTalentoId" uuid,
    "SuggestedDataJson" text,
    "ErrorMessage" character varying(2000)
);


--
-- Name: TalentoDocumentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoDocumentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "NomeArquivo" character varying(200) NOT NULL,
    "ContentType" character varying(120),
    "Descricao" character varying(240),
    "StorageFileName" character varying(260),
    "TamanhoBytes" bigint,
    "DataReferencia" character varying(20),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TalentoExperiencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoExperiencias" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Empresa" character varying(160) NOT NULL,
    "Cargo" character varying(160) NOT NULL,
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Local" character varying(160),
    "Atividades" character varying(2400),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "TipoContratacao" character varying(40),
    "NivelHierarquico" character varying(80),
    "NivelSenioridade" character varying(40),
    "ResumoAtividades" character varying(800)
);


--
-- Name: TalentoFormacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoFormacoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Curso" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Tipo" character varying(40),
    "Status" character varying(40),
    "Inicio" character varying(20),
    "Fim" character varying(20),
    "Observacoes" character varying(800),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TalentoTreinamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TalentoTreinamentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TalentoId" uuid NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Instituicao" character varying(160),
    "Ano" character varying(10),
    "Link" character varying(260),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: Talentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Talentos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "PessoaId" uuid NOT NULL,
    "Origem" integer NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "CvProfileJson" text,
    "Versao" integer DEFAULT 1 NOT NULL,
    "Embedding" public.vector(1536),
    "EmbeddingGeneratedAtUtc" timestamp with time zone
);


--
-- Name: TemplatesEntrevistaSaida; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TemplatesEntrevistaSaida" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Nome" character varying(120) NOT NULL,
    "Ativo" boolean DEFAULT false NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantAwsSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantAwsSettings" (
    "Id" uuid NOT NULL,
    "TenantId" text NOT NULL,
    "AccessKeyIdEncrypted" text,
    "SecretAccessKeyEncrypted" text,
    "Region" character varying(50),
    "BucketName" character varying(200),
    "PresignedUrlExpirationMinutes" integer NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantBrandings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantBrandings" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "NomePortal" character varying(80),
    "Subtitulo" character varying(160),
    "RodapeTexto" character varying(160),
    "CorPrimariaHex" character varying(7),
    "CorSecundariaHex" character varying(7),
    "LogoUrl" character varying(512),
    "VersaoExibida" character varying(32),
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: TenantConfiguracoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TenantConfiguracoes" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "RhDeveAprovarAposGestor" boolean NOT NULL,
    "AprovadorRhId" uuid,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DiasProvisaoSubstituicao" integer DEFAULT 30 NOT NULL,
    "DiasAlertaVagaSemFill" integer DEFAULT 60 NOT NULL,
    "SlaAprovacaoHoras" integer DEFAULT 48 NOT NULL,
    "SlaEscalacaoHoras" integer DEFAULT 96 NOT NULL,
    "BloqueiaSalarioForaFaixa" boolean DEFAULT false NOT NULL,
    "AzureAdClientId" text,
    "AzureAdClientSecret" text,
    "AzureAdTenantId" text,
    "BlipNumeroHospedeiro" text,
    "BlipApiKey" text,
    "BlipApiUrl" text,
    "LlmProvider" text,
    "LlmModel" text,
    "EmbeddingProvider" text,
    "EmbeddingModel" text
);


--
-- Name: Turnos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Turnos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "StartTime" character varying(5),
    "EndTime" character varying(5),
    "Notes" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UnidadeLotacaoId" uuid
);


--
-- Name: UnidadesLotacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UnidadesLotacao" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(30) NOT NULL,
    "Description" character varying(120) NOT NULL,
    "Location" character varying(120),
    "Notes" character varying(500),
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Level" integer DEFAULT 1 NOT NULL,
    "OwnerCdnEmpresa" character varying(3),
    "OwnerCdnEstab" character varying(5),
    "OwnerCdnFuncionario" character varying(12),
    "OwnerFuncionarioId" uuid,
    "ParentId" uuid,
    "SequenceNumber" integer,
    "CdnPlanoLotac" character varying(10) NOT NULL
);


--
-- Name: Units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Units" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Code" character varying(40) NOT NULL,
    "Name" character varying(140) NOT NULL,
    "Status" integer NOT NULL,
    "City" character varying(120),
    "Uf" character varying(2),
    "AddressLine" character varying(220),
    "Neighborhood" character varying(120),
    "ZipCode" character varying(12),
    "Email" character varying(180),
    "Phone" character varying(40),
    "ResponsibleName" character varying(140),
    "Type" character varying(120),
    "Headcount" integer NOT NULL,
    "Notes" character varying(1000),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "EmpresaId" uuid,
    "NomAbrevPessoaFisic" text,
    "NomAbrevPessoaJurid" text,
    "NomPessoaJurid" text
);


--
-- Name: UserRoles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserRoles" (
    "UserId" uuid NOT NULL,
    "RoleId" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL
);


--
-- Name: UserUnits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserUnits" (
    "UserId" uuid NOT NULL,
    "UnitId" uuid NOT NULL
);


--
-- Name: Users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Users" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "FullName" character varying(200) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "UserName" character varying(256),
    "NormalizedUserName" character varying(256),
    "Email" character varying(256),
    "NormalizedEmail" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "PasswordHash" text,
    "SecurityStamp" text,
    "ConcurrencyStamp" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "TwoFactorEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp with time zone,
    "LockoutEnabled" boolean NOT NULL,
    "AccessFailedCount" integer NOT NULL,
    "FuncionarioId" uuid
);


--
-- Name: VagaBeneficios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaBeneficios" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Tipo" smallint NOT NULL,
    "Valor" numeric,
    "Recorrencia" smallint NOT NULL,
    "Obrigatorio" boolean NOT NULL,
    "Observacoes" character varying(240),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: VagaEtapas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaEtapas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Nome" character varying(160) NOT NULL,
    "Responsavel" smallint NOT NULL,
    "Modo" smallint NOT NULL,
    "SlaDias" integer,
    "DescricaoInstrucoes" character varying(240),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: VagaPerguntas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaPerguntas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Texto" character varying(220) NOT NULL,
    "Tipo" smallint NOT NULL,
    "Peso" smallint NOT NULL,
    "Obrigatoria" boolean NOT NULL,
    "Knockout" boolean NOT NULL,
    "OpcoesRaw" text,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL
);


--
-- Name: VagaRequisitos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaRequisitos" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "VagaId" uuid NOT NULL,
    "Ordem" integer NOT NULL,
    "Nome" character varying(180) NOT NULL,
    "Peso" smallint NOT NULL,
    "Obrigatorio" boolean NOT NULL,
    "AnosMinimos" integer,
    "Nivel" smallint,
    "Avaliacao" smallint,
    "SinonimosRaw" character varying(400),
    "Observacoes" character varying(240),
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "Categoria" character varying(80)
);


--
-- Name: VagaUnifiedMatchingCaches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."VagaUnifiedMatchingCaches" (
    "VagaId" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "CurrentFiltersHash" character varying(64) NOT NULL,
    "PendingFiltersHash" character varying(64),
    "Status" character varying(20) NOT NULL,
    "StartedAtUtc" timestamp with time zone,
    "ComputedAtUtc" timestamp with time zone,
    "LastAccessAtUtc" timestamp with time zone,
    "ItemsJson" jsonb,
    "LastError" character varying(2000)
);


--
-- Name: Vagas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Vagas" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "Codigo" character varying(40),
    "Titulo" character varying(160) NOT NULL,
    "AreaTime" smallint,
    "Modalidade" smallint,
    "Status" smallint NOT NULL,
    "Senioridade" smallint,
    "QuantidadeVagas" integer NOT NULL,
    "TipoContratacao" smallint,
    "MatchMinimoPercentual" integer NOT NULL,
    "DescricaoInterna" text,
    "CodigoInterno" character varying(40),
    "CodigoCbo" character varying(20),
    "MotivoAbertura" smallint,
    "OrcamentoAprovado" smallint,
    "GestorRequisitante" character varying(120),
    "RecrutadorResponsavel" character varying(120),
    "Prioridade" smallint,
    "ResumoPitch" text,
    "TagsResponsabilidadesRaw" text,
    "TagsKeywordsRaw" text,
    "Confidencial" boolean NOT NULL,
    "AceitaPcd" boolean NOT NULL,
    "Urgente" boolean NOT NULL,
    "GeneroPreferencia" smallint,
    "VagaAfirmativa" boolean NOT NULL,
    "LinguagemInclusiva" boolean NOT NULL,
    "PublicoAfirmativo" character varying(120),
    "ObservacoesPcd" text,
    "ProjetoNome" character varying(160),
    "ProjetoClienteAreaImpactada" character varying(160),
    "ProjetoPrazoPrevisto" character varying(80),
    "ProjetoDescricao" text,
    "Regime" smallint,
    "CargaSemanalHoras" integer,
    "Escala" smallint,
    "HoraEntrada" time without time zone,
    "HoraSaida" time without time zone,
    "Intervalo" interval,
    "Cep" character varying(12),
    "Logradouro" character varying(160),
    "Numero" character varying(20),
    "Bairro" character varying(120),
    "Cidade" character varying(120),
    "Uf" character varying(2),
    "PoliticaTrabalho" character varying(200),
    "ObservacoesDeslocamento" character varying(200),
    "Moeda" smallint,
    "SalarioMinimo" numeric(18,2),
    "SalarioMaximo" numeric(18,2),
    "Periodicidade" smallint,
    "BonusTipo" smallint,
    "BonusPercentual" numeric,
    "ObservacoesRemuneracao" character varying(240),
    "Escolaridade" smallint,
    "FormacaoArea" smallint,
    "ExperienciaMinimaAnos" integer,
    "TagsStackRaw" text,
    "TagsIdiomasRaw" text,
    "Diferenciais" text,
    "ObservacoesProcesso" text,
    "Visibilidade" smallint,
    "DataInicio" date,
    "DataEncerramento" date,
    "CanalLinkedIn" boolean NOT NULL,
    "CanalSiteCarreiras" boolean NOT NULL,
    "CanalIndicacao" boolean NOT NULL,
    "CanalPortaisEmprego" boolean NOT NULL,
    "DescricaoPublica" text,
    "LgpdSolicitarConsentimentoExplicito" boolean NOT NULL,
    "LgpdCompartilharCurriculoInternamente" boolean NOT NULL,
    "LgpdRetencaoAtiva" boolean NOT NULL,
    "LgpdRetencaoMeses" integer,
    "ExigeCnh" boolean NOT NULL,
    "DisponibilidadeParaViagens" boolean NOT NULL,
    "ChecagemAntecedentes" boolean NOT NULL,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "PesoCompetencia" integer DEFAULT 0 NOT NULL,
    "PesoExperiencia" integer DEFAULT 0 NOT NULL,
    "PesoFormacao" integer DEFAULT 0 NOT NULL,
    "PesoLocalidade" integer DEFAULT 0 NOT NULL,
    "DataAbertura" timestamp with time zone,
    "SlaDiasMetaFechamento" integer,
    "RecrutadorResponsavelUserId" uuid,
    "MatchingFiltrosOriginaisRaw" text,
    "MatchingFiltrosRaw" text,
    "NomeEngessado" character varying(200),
    "JobPositionId" uuid,
    "CategoriaSalarialId" uuid,
    "CentroCustoId" uuid,
    "TurnoId" uuid,
    "UnidadeLotacaoId" uuid,
    "EscalaTrabalhoRaw" text,
    "HeadcountAutorizado" integer DEFAULT 1 NOT NULL,
    "IsEstrutural" boolean DEFAULT false NOT NULL,
    "HeadcountProvisorio" integer DEFAULT 0 NOT NULL,
    "HeadcountProvisorioExpiresAtUtc" timestamp with time zone,
    "AlertaVagaSemFillSnoozeAteUtc" timestamp with time zone,
    "HeadcountPendente" integer DEFAULT 0 NOT NULL,
    "EixoVagaId" uuid,
    "TravarFaixaSalarial" boolean DEFAULT false NOT NULL,
    "AlcadaSalarialAprovadaPorUserId" uuid,
    "AlcadaSalarialAprovadaEmUtc" timestamp with time zone,
    "AlcadaSalarialJustificativa" character varying(1000),
    "AlcadaSalarialObservacaoAprovador" character varying(500),
    "PesoIdioma" integer DEFAULT 0 NOT NULL,
    "PesoConhecimentoTecnico" integer DEFAULT 0 NOT NULL,
    "PesoVivenciaEspecifica" integer DEFAULT 0 NOT NULL,
    "LocalidadeMaxDistanciaKm" integer,
    "DescricaoCargoId" uuid,
    embedding public.vector(1536),
    embedding_generated_at_utc timestamp with time zone,
    "HierarquiaId" uuid,
    "IdReqRmOrigem" character varying(40),
    "OrigemDesligamentoId" uuid,
    "OrigemTipo" smallint DEFAULT 0 NOT NULL,
    "CodFuncaoRm" character varying(20),
    "FuncaoNomeRm" character varying(160),
    "CiclosAusenteRm" integer DEFAULT 0 NOT NULL,
    "UltimoCicloRmObservadoUtc" timestamp with time zone
);


--
-- Name: WorkflowsRH; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkflowsRH" (
    "Id" uuid NOT NULL,
    "TenantId" character varying(64) NOT NULL,
    "TipoWorkflow" smallint NOT NULL,
    "VagaId" uuid,
    "PreAdmissaoId" uuid,
    "Status" smallint NOT NULL,
    "ResponsavelId" uuid,
    "DataInicio" timestamp with time zone,
    "DataConclusao" timestamp with time zone,
    "SlaPrazoDias" integer,
    "CreatedAtUtc" timestamp with time zone NOT NULL,
    "UpdatedAtUtc" timestamp with time zone NOT NULL,
    "DesligamentoId" uuid
);


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Name: MotivosRequisicaoVagaConfig MotivosRequisicaoVagaConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MotivosRequisicaoVagaConfig"
    ADD CONSTRAINT "MotivosRequisicaoVagaConfig_pkey" PRIMARY KEY ("Id");


--
-- Name: AgendaEventTypes PK_AgendaEventTypes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgendaEventTypes"
    ADD CONSTRAINT "PK_AgendaEventTypes" PRIMARY KEY ("Id");


--
-- Name: AgendaEvents PK_AgendaEvents; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgendaEvents"
    ADD CONSTRAINT "PK_AgendaEvents" PRIMARY KEY ("Id");


--
-- Name: ApiKeys PK_ApiKeys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ApiKeys"
    ADD CONSTRAINT "PK_ApiKeys" PRIMARY KEY ("Id");


--
-- Name: ApprovalMagicLinks PK_ApprovalMagicLinks; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ApprovalMagicLinks"
    ADD CONSTRAINT "PK_ApprovalMagicLinks" PRIMARY KEY ("Id");


--
-- Name: AprovacoesFaixaSalarial PK_AprovacoesFaixaSalarial; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "PK_AprovacoesFaixaSalarial" PRIMARY KEY ("Id");


--
-- Name: AprovadoresAlternativos PK_AprovadoresAlternativos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovadoresAlternativos"
    ADD CONSTRAINT "PK_AprovadoresAlternativos" PRIMARY KEY ("Id");


--
-- Name: AspNetRoleClaims PK_AspNetRoleClaims; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "PK_AspNetRoleClaims" PRIMARY KEY ("Id");


--
-- Name: AspNetUserClaims PK_AspNetUserClaims; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "PK_AspNetUserClaims" PRIMARY KEY ("Id");


--
-- Name: AspNetUserLogins PK_AspNetUserLogins; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "PK_AspNetUserLogins" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: AspNetUserTokens PK_AspNetUserTokens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "PK_AspNetUserTokens" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: AuditEntityChanges PK_AuditEntityChanges; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityChanges"
    ADD CONSTRAINT "PK_AuditEntityChanges" PRIMARY KEY ("Id");


--
-- Name: AuditEntityPropertyChanges PK_AuditEntityPropertyChanges; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityPropertyChanges"
    ADD CONSTRAINT "PK_AuditEntityPropertyChanges" PRIMARY KEY ("Id");


--
-- Name: AuditEvents PK_AuditEvents; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEvents"
    ADD CONSTRAINT "PK_AuditEvents" PRIMARY KEY ("Id");


--
-- Name: AuditTransactions PK_AuditTransactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditTransactions"
    ADD CONSTRAINT "PK_AuditTransactions" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoCalibragens PK_AvaliacaoCalibragens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "PK_AvaliacaoCalibragens" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoCiclos PK_AvaliacaoCiclos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCiclos"
    ADD CONSTRAINT "PK_AvaliacaoCiclos" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoConvites PK_AvaliacaoConvites; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "PK_AvaliacaoConvites" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoPerguntas PK_AvaliacaoPerguntas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoPerguntas"
    ADD CONSTRAINT "PK_AvaliacaoPerguntas" PRIMARY KEY ("Id");


--
-- Name: AvaliacaoRespostas PK_AvaliacaoRespostas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "PK_AvaliacaoRespostas" PRIMARY KEY ("Id");


--
-- Name: BatchMatchingRunVagas PK_BatchMatchingRunVagas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BatchMatchingRunVagas"
    ADD CONSTRAINT "PK_BatchMatchingRunVagas" PRIMARY KEY ("Id");


--
-- Name: BatchMatchingRuns PK_BatchMatchingRuns; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BatchMatchingRuns"
    ADD CONSTRAINT "PK_BatchMatchingRuns" PRIMARY KEY ("Id");


--
-- Name: CamposPersonalizadosVaga PK_CamposPersonalizadosVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CamposPersonalizadosVaga"
    ADD CONSTRAINT "PK_CamposPersonalizadosVaga" PRIMARY KEY ("Id");


--
-- Name: CandidatoAcessibilidades PK_CandidatoAcessibilidades; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAcessibilidades"
    ADD CONSTRAINT "PK_CandidatoAcessibilidades" PRIMARY KEY ("Id");


--
-- Name: CandidatoAgendaBloqueios PK_CandidatoAgendaBloqueios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaBloqueios"
    ADD CONSTRAINT "PK_CandidatoAgendaBloqueios" PRIMARY KEY ("Id");


--
-- Name: CandidatoAgendaPreferencias PK_CandidatoAgendaPreferencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaPreferencias"
    ADD CONSTRAINT "PK_CandidatoAgendaPreferencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoCertificacoes PK_CandidatoCertificacoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCertificacoes"
    ADD CONSTRAINT "PK_CandidatoCertificacoes" PRIMARY KEY ("Id");


--
-- Name: CandidatoCompetencias PK_CandidatoCompetencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCompetencias"
    ADD CONSTRAINT "PK_CandidatoCompetencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoDocumentos PK_CandidatoDocumentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoDocumentos"
    ADD CONSTRAINT "PK_CandidatoDocumentos" PRIMARY KEY ("Id");


--
-- Name: CandidatoEducacaoItens PK_CandidatoEducacaoItens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoItens"
    ADD CONSTRAINT "PK_CandidatoEducacaoItens" PRIMARY KEY ("Id");


--
-- Name: CandidatoEducacaoResumos PK_CandidatoEducacaoResumos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoResumos"
    ADD CONSTRAINT "PK_CandidatoEducacaoResumos" PRIMARY KEY ("Id");


--
-- Name: CandidatoEmbeddings PK_CandidatoEmbeddings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEmbeddings"
    ADD CONSTRAINT "PK_CandidatoEmbeddings" PRIMARY KEY ("Id");


--
-- Name: CandidatoExperiencias PK_CandidatoExperiencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoExperiencias"
    ADD CONSTRAINT "PK_CandidatoExperiencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoLgpdConsents PK_CandidatoLgpdConsents; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoLgpdConsents"
    ADD CONSTRAINT "PK_CandidatoLgpdConsents" PRIMARY KEY ("Id");


--
-- Name: CandidatoNotificacaoPreferencias PK_CandidatoNotificacaoPreferencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoNotificacaoPreferencias"
    ADD CONSTRAINT "PK_CandidatoNotificacaoPreferencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoPortfolios PK_CandidatoPortfolios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPortfolios"
    ADD CONSTRAINT "PK_CandidatoPortfolios" PRIMARY KEY ("Id");


--
-- Name: CandidatoPreferenciasVaga PK_CandidatoPreferenciasVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPreferenciasVaga"
    ADD CONSTRAINT "PK_CandidatoPreferenciasVaga" PRIMARY KEY ("Id");


--
-- Name: CandidatoProjetos PK_CandidatoProjetos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoProjetos"
    ADD CONSTRAINT "PK_CandidatoProjetos" PRIMARY KEY ("Id");


--
-- Name: CandidatoReferencias PK_CandidatoReferencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoReferencias"
    ADD CONSTRAINT "PK_CandidatoReferencias" PRIMARY KEY ("Id");


--
-- Name: CandidatoStatusHistories PK_CandidatoStatusHistories; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoStatusHistories"
    ADD CONSTRAINT "PK_CandidatoStatusHistories" PRIMARY KEY ("Id");


--
-- Name: CandidatoVagaLlmScores PK_CandidatoVagaLlmScores; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaLlmScores"
    ADD CONSTRAINT "PK_CandidatoVagaLlmScores" PRIMARY KEY ("Id");


--
-- Name: CandidatoVagaMatchingScores PK_CandidatoVagaMatchingScores; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaMatchingScores"
    ADD CONSTRAINT "PK_CandidatoVagaMatchingScores" PRIMARY KEY ("CandidatoId", "VagaId");


--
-- Name: Candidatos PK_Candidatos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidatos"
    ADD CONSTRAINT "PK_Candidatos" PRIMARY KEY ("Id");


--
-- Name: CandidaturaEtapaHistoricos PK_CandidaturaEtapaHistoricos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidaturaEtapaHistoricos"
    ADD CONSTRAINT "PK_CandidaturaEtapaHistoricos" PRIMARY KEY ("Id");


--
-- Name: Candidaturas PK_Candidaturas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidaturas"
    ADD CONSTRAINT "PK_Candidaturas" PRIMARY KEY ("Id");


--
-- Name: Cargos PK_Cargos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cargos"
    ADD CONSTRAINT "PK_Cargos" PRIMARY KEY ("Id");


--
-- Name: CategoriaSalarialSteps PK_CategoriaSalarialSteps; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriaSalarialSteps"
    ADD CONSTRAINT "PK_CategoriaSalarialSteps" PRIMARY KEY ("Id");


--
-- Name: CategoriasSalariais PK_CategoriasSalariais; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriasSalariais"
    ADD CONSTRAINT "PK_CategoriasSalariais" PRIMARY KEY ("Id");


--
-- Name: CelebrationCommentMentions PK_CelebrationCommentMentions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentMentions"
    ADD CONSTRAINT "PK_CelebrationCommentMentions" PRIMARY KEY ("Id");


--
-- Name: CelebrationCommentReactions PK_CelebrationCommentReactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentReactions"
    ADD CONSTRAINT "PK_CelebrationCommentReactions" PRIMARY KEY ("Id");


--
-- Name: CelebrationComments PK_CelebrationComments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationComments"
    ADD CONSTRAINT "PK_CelebrationComments" PRIMARY KEY ("Id");


--
-- Name: CelebrationMentions PK_CelebrationMentions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationMentions"
    ADD CONSTRAINT "PK_CelebrationMentions" PRIMARY KEY ("Id");


--
-- Name: CelebrationPosts PK_CelebrationPosts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationPosts"
    ADD CONSTRAINT "PK_CelebrationPosts" PRIMARY KEY ("Id");


--
-- Name: CentrosCusto PK_CentrosCusto; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "PK_CentrosCusto" PRIMARY KEY ("Id");


--
-- Name: DadosBancarios PK_DadosBancarios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DadosBancarios"
    ADD CONSTRAINT "PK_DadosBancarios" PRIMARY KEY ("Id");


--
-- Name: Dependentes PK_Dependentes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Dependentes"
    ADD CONSTRAINT "PK_Dependentes" PRIMARY KEY ("Id");


--
-- Name: DescricaoCargoItemEmbeddings PK_DescricaoCargoItemEmbeddings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItemEmbeddings"
    ADD CONSTRAINT "PK_DescricaoCargoItemEmbeddings" PRIMARY KEY ("Id");


--
-- Name: DescricaoCargoItens PK_DescricaoCargoItens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItens"
    ADD CONSTRAINT "PK_DescricaoCargoItens" PRIMARY KEY ("Id");


--
-- Name: DescricoesCargo PK_DescricoesCargo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricoesCargo"
    ADD CONSTRAINT "PK_DescricoesCargo" PRIMARY KEY ("Id");


--
-- Name: Desligamentos PK_Desligamentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Desligamentos"
    ADD CONSTRAINT "PK_Desligamentos" PRIMARY KEY ("Id");


--
-- Name: DevelopmentPlanGoals PK_DevelopmentPlanGoals; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlanGoals"
    ADD CONSTRAINT "PK_DevelopmentPlanGoals" PRIMARY KEY ("Id");


--
-- Name: DevelopmentPlans PK_DevelopmentPlans; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlans"
    ADD CONSTRAINT "PK_DevelopmentPlans" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoConfigs PK_DocumentacaoPadraoConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoConfigs"
    ADD CONSTRAINT "PK_DocumentacaoPadraoConfigs" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoHistoricos PK_DocumentacaoPadraoHistoricos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoHistoricos"
    ADD CONSTRAINT "PK_DocumentacaoPadraoHistoricos" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoPorCargoConfigs PK_DocumentacaoPadraoPorCargoConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorCargoConfigs"
    ADD CONSTRAINT "PK_DocumentacaoPadraoPorCargoConfigs" PRIMARY KEY ("Id");


--
-- Name: DocumentacaoPadraoPorNivelCargoConfigs PK_DocumentacaoPadraoPorNivelCargoConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorNivelCargoConfigs"
    ADD CONSTRAINT "PK_DocumentacaoPadraoPorNivelCargoConfigs" PRIMARY KEY ("Id");


--
-- Name: DocumentosColaborador PK_DocumentosColaborador; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentosColaborador"
    ADD CONSTRAINT "PK_DocumentosColaborador" PRIMARY KEY ("Id");


--
-- Name: EixosVaga PK_EixosVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EixosVaga"
    ADD CONSTRAINT "PK_EixosVaga" PRIMARY KEY ("Id");


--
-- Name: EmailAttempts PK_EmailAttempts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailAttempts"
    ADD CONSTRAINT "PK_EmailAttempts" PRIMARY KEY ("Id");


--
-- Name: EmailConfigs PK_EmailConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailConfigs"
    ADD CONSTRAINT "PK_EmailConfigs" PRIMARY KEY ("Id");


--
-- Name: EmailMessages PK_EmailMessages; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailMessages"
    ADD CONSTRAINT "PK_EmailMessages" PRIMARY KEY ("Id");


--
-- Name: EmailTemplates PK_EmailTemplates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailTemplates"
    ADD CONSTRAINT "PK_EmailTemplates" PRIMARY KEY ("Id");


--
-- Name: Empresas PK_Empresas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Empresas"
    ADD CONSTRAINT "PK_Empresas" PRIMARY KEY ("Id");


--
-- Name: EntraIdConfigs PK_EntraIdConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EntraIdConfigs"
    ADD CONSTRAINT "PK_EntraIdConfigs" PRIMARY KEY ("Id");


--
-- Name: EntrevistasSaida PK_EntrevistasSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EntrevistasSaida"
    ADD CONSTRAINT "PK_EntrevistasSaida" PRIMARY KEY ("Id");


--
-- Name: EtapasConfigAprovacao PK_EtapasConfigAprovacao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigAprovacao"
    ADD CONSTRAINT "PK_EtapasConfigAprovacao" PRIMARY KEY ("Id");


--
-- Name: EtapasConfigWorkflowRH PK_EtapasConfigWorkflowRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigWorkflowRH"
    ADD CONSTRAINT "PK_EtapasConfigWorkflowRH" PRIMARY KEY ("Id");


--
-- Name: EtapasWorkflowRH PK_EtapasWorkflowRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasWorkflowRH"
    ADD CONSTRAINT "PK_EtapasWorkflowRH" PRIMARY KEY ("Id");


--
-- Name: ExceptionLogs PK_ExceptionLogs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ExceptionLogs"
    ADD CONSTRAINT "PK_ExceptionLogs" PRIMARY KEY ("Id");


--
-- Name: FaixasSalariais PK_FaixasSalariais; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FaixasSalariais"
    ADD CONSTRAINT "PK_FaixasSalariais" PRIMARY KEY ("Id");


--
-- Name: FasesProcesso PK_FasesProcesso; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FasesProcesso"
    ADD CONSTRAINT "PK_FasesProcesso" PRIMARY KEY ("Id");


--
-- Name: FeedbackItemRatings PK_FeedbackItemRatings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItemRatings"
    ADD CONSTRAINT "PK_FeedbackItemRatings" PRIMARY KEY ("Id");


--
-- Name: FeedbackItems PK_FeedbackItems; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItems"
    ADD CONSTRAINT "PK_FeedbackItems" PRIMARY KEY ("Id");


--
-- Name: FluxosAprovacaoConfig PK_FluxosAprovacaoConfig; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FluxosAprovacaoConfig"
    ADD CONSTRAINT "PK_FluxosAprovacaoConfig" PRIMARY KEY ("Id");


--
-- Name: FuncionarioMovimentacoes PK_FuncionarioMovimentacoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FuncionarioMovimentacoes"
    ADD CONSTRAINT "PK_FuncionarioMovimentacoes" PRIMARY KEY ("Id");


--
-- Name: Funcionarios PK_Funcionarios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "PK_Funcionarios" PRIMARY KEY ("Id");


--
-- Name: GamificationDailyStates PK_GamificationDailyStates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GamificationDailyStates"
    ADD CONSTRAINT "PK_GamificationDailyStates" PRIMARY KEY ("Id");


--
-- Name: Hierarquias PK_Hierarquias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Hierarquias"
    ADD CONSTRAINT "PK_Hierarquias" PRIMARY KEY ("Id");


--
-- Name: HistoricosAlteracaoWorkflowRH PK_HistoricosAlteracaoWorkflowRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "PK_HistoricosAlteracaoWorkflowRH" PRIMARY KEY ("Id");


--
-- Name: HistoricosStatus PK_HistoricosStatus; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosStatus"
    ADD CONSTRAINT "PK_HistoricosStatus" PRIMARY KEY ("Id");


--
-- Name: Holerites PK_Holerites; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holerites"
    ADD CONSTRAINT "PK_Holerites" PRIMARY KEY ("Id");


--
-- Name: InboxAttachments PK_InboxAttachments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxAttachments"
    ADD CONSTRAINT "PK_InboxAttachments" PRIMARY KEY ("Id");


--
-- Name: InboxItems PK_InboxItems; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxItems"
    ADD CONSTRAINT "PK_InboxItems" PRIMARY KEY ("Id");


--
-- Name: JobPositions PK_JobPositions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "PK_JobPositions" PRIMARY KEY ("Id");


--
-- Name: LocalizationConfigs PK_LocalizationConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LocalizationConfigs"
    ADD CONSTRAINT "PK_LocalizationConfigs" PRIMARY KEY ("Id");


--
-- Name: LogEntries PK_LogEntries; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogEntries"
    ADD CONSTRAINT "PK_LogEntries" PRIMARY KEY ("Id");


--
-- Name: LogsComunicacao PK_LogsComunicacao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogsComunicacao"
    ADD CONSTRAINT "PK_LogsComunicacao" PRIMARY KEY ("Id");


--
-- Name: Menus PK_Menus; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Menus"
    ADD CONSTRAINT "PK_Menus" PRIMARY KEY ("Id");


--
-- Name: Metas PK_Metas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Metas"
    ADD CONSTRAINT "PK_Metas" PRIMARY KEY ("Id");


--
-- Name: MoodEntries PK_MoodEntries; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MoodEntries"
    ADD CONSTRAINT "PK_MoodEntries" PRIMARY KEY ("Id");


--
-- Name: NineBoxAssessments PK_NineBoxAssessments; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "PK_NineBoxAssessments" PRIMARY KEY ("Id");


--
-- Name: NiveisCargo PK_NiveisCargo; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NiveisCargo"
    ADD CONSTRAINT "PK_NiveisCargo" PRIMARY KEY ("Id");


--
-- Name: NiveisHierarquicos PK_NiveisHierarquicos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NiveisHierarquicos"
    ADD CONSTRAINT "PK_NiveisHierarquicos" PRIMARY KEY ("Id");


--
-- Name: NotificacoesCandidaturaLogs PK_NotificacoesCandidaturaLogs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificacoesCandidaturaLogs"
    ADD CONSTRAINT "PK_NotificacoesCandidaturaLogs" PRIMARY KEY ("Id");


--
-- Name: NotificacoesTemplates PK_NotificacoesTemplates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificacoesTemplates"
    ADD CONSTRAINT "PK_NotificacoesTemplates" PRIMARY KEY ("Id");


--
-- Name: NotificationReceipts PK_NotificationReceipts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NotificationReceipts"
    ADD CONSTRAINT "PK_NotificationReceipts" PRIMARY KEY ("Id");


--
-- Name: Notifications PK_Notifications; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "PK_Notifications" PRIMARY KEY ("Id");


--
-- Name: OcupacoesHistorico PK_OcupacoesHistorico; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OcupacoesHistorico"
    ADD CONSTRAINT "PK_OcupacoesHistorico" PRIMARY KEY ("Id");


--
-- Name: OneOnOneMeetings PK_OneOnOneMeetings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOnOneMeetings"
    ADD CONSTRAINT "PK_OneOnOneMeetings" PRIMARY KEY ("Id");


--
-- Name: PerguntasEntrevistaSaida PK_PerguntasEntrevistaSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PerguntasEntrevistaSaida"
    ADD CONSTRAINT "PK_PerguntasEntrevistaSaida" PRIMARY KEY ("Id");


--
-- Name: PermissoesNivelVaga PK_PermissoesNivelVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PermissoesNivelVaga"
    ADD CONSTRAINT "PK_PermissoesNivelVaga" PRIMARY KEY ("Id");


--
-- Name: PessoaBloqueios PK_PessoaBloqueios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PessoaBloqueios"
    ADD CONSTRAINT "PK_PessoaBloqueios" PRIMARY KEY ("Id");


--
-- Name: Pessoas PK_Pessoas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Pessoas"
    ADD CONSTRAINT "PK_Pessoas" PRIMARY KEY ("Id");


--
-- Name: PreAdmissaoDependentes PK_PreAdmissaoDependentes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDependentes"
    ADD CONSTRAINT "PK_PreAdmissaoDependentes" PRIMARY KEY ("Id");


--
-- Name: PreAdmissaoDocumentos PK_PreAdmissaoDocumentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentos"
    ADD CONSTRAINT "PK_PreAdmissaoDocumentos" PRIMARY KEY ("Id");


--
-- Name: PreAdmissaoDocumentosSolicitados PK_PreAdmissaoDocumentosSolicitados; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentosSolicitados"
    ADD CONSTRAINT "PK_PreAdmissaoDocumentosSolicitados" PRIMARY KEY ("Id");


--
-- Name: PreAdmissoes PK_PreAdmissoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "PK_PreAdmissoes" PRIMARY KEY ("Id");


--
-- Name: ProjetoCandidatos PK_ProjetoCandidatos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "PK_ProjetoCandidatos" PRIMARY KEY ("Id");


--
-- Name: ProjetosVaga PK_ProjetosVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetosVaga"
    ADD CONSTRAINT "PK_ProjetosVaga" PRIMARY KEY ("Id");


--
-- Name: PropostasVaga PK_PropostasVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "PK_PropostasVaga" PRIMARY KEY ("Id");


--
-- Name: RecruiterMatchingFeedbacks PK_RecruiterMatchingFeedbacks; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RecruiterMatchingFeedbacks"
    ADD CONSTRAINT "PK_RecruiterMatchingFeedbacks" PRIMARY KEY ("Id");


--
-- Name: RenderCoinBalances PK_RenderCoinBalances; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinBalances"
    ADD CONSTRAINT "PK_RenderCoinBalances" PRIMARY KEY ("TenantId", "UserId");


--
-- Name: RenderCoinTransactions PK_RenderCoinTransactions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinTransactions"
    ADD CONSTRAINT "PK_RenderCoinTransactions" PRIMARY KEY ("Id");


--
-- Name: RequestLogs PK_RequestLogs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RequestLogs"
    ADD CONSTRAINT "PK_RequestLogs" PRIMARY KEY ("Id");


--
-- Name: RespostasCampoPersonalizadoVaga PK_RespostasCampoPersonalizadoVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "PK_RespostasCampoPersonalizadoVaga" PRIMARY KEY ("Id");


--
-- Name: RespostasEntrevistaSaida PK_RespostasEntrevistaSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasEntrevistaSaida"
    ADD CONSTRAINT "PK_RespostasEntrevistaSaida" PRIMARY KEY ("Id");


--
-- Name: RmSyncAlertas PK_RmSyncAlertas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RmSyncAlertas"
    ADD CONSTRAINT "PK_RmSyncAlertas" PRIMARY KEY ("Id");


--
-- Name: RmSyncCheckpoints PK_RmSyncCheckpoints; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RmSyncCheckpoints"
    ADD CONSTRAINT "PK_RmSyncCheckpoints" PRIMARY KEY ("Id");


--
-- Name: RmSyncRuns PK_RmSyncRuns; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RmSyncRuns"
    ADD CONSTRAINT "PK_RmSyncRuns" PRIMARY KEY ("Id");


--
-- Name: RoleMenus PK_RoleMenus; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RoleMenus"
    ADD CONSTRAINT "PK_RoleMenus" PRIMARY KEY ("Id");


--
-- Name: Roles PK_Roles; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "PK_Roles" PRIMARY KEY ("Id");


--
-- Name: SkillAliases PK_SkillAliases; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SkillAliases"
    ADD CONSTRAINT "PK_SkillAliases" PRIMARY KEY ("Id");


--
-- Name: Skills PK_Skills; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "PK_Skills" PRIMARY KEY ("Id");


--
-- Name: SlaStatusConfigs PK_SlaStatusConfigs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SlaStatusConfigs"
    ADD CONSTRAINT "PK_SlaStatusConfigs" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesAprovacaoEtapas PK_SolicitacoesAprovacaoEtapas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesAprovacaoEtapas"
    ADD CONSTRAINT "PK_SolicitacoesAprovacaoEtapas" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesBeneficio PK_SolicitacoesBeneficio; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesBeneficio"
    ADD CONSTRAINT "PK_SolicitacoesBeneficio" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesDependente PK_SolicitacoesDependente; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDependente"
    ADD CONSTRAINT "PK_SolicitacoesDependente" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesDesligamento PK_SolicitacoesDesligamento; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "PK_SolicitacoesDesligamento" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesEndereco PK_SolicitacoesEndereco; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesEndereco"
    ADD CONSTRAINT "PK_SolicitacoesEndereco" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesFerias PK_SolicitacoesFerias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesFerias"
    ADD CONSTRAINT "PK_SolicitacoesFerias" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesPagamentoExtra PK_SolicitacoesPagamentoExtra; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "PK_SolicitacoesPagamentoExtra" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesPromocao PK_SolicitacoesPromocao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "PK_SolicitacoesPromocao" PRIMARY KEY ("Id");


--
-- Name: SolicitacoesVaga PK_SolicitacoesVaga; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "PK_SolicitacoesVaga" PRIMARY KEY ("Id");


--
-- Name: SurveyAnswers PK_SurveyAnswers; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyAnswers"
    ADD CONSTRAINT "PK_SurveyAnswers" PRIMARY KEY ("Id");


--
-- Name: SurveyOptions PK_SurveyOptions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyOptions"
    ADD CONSTRAINT "PK_SurveyOptions" PRIMARY KEY ("Id");


--
-- Name: SurveyQuestions PK_SurveyQuestions; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyQuestions"
    ADD CONSTRAINT "PK_SurveyQuestions" PRIMARY KEY ("Id");


--
-- Name: SurveyResponses PK_SurveyResponses; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyResponses"
    ADD CONSTRAINT "PK_SurveyResponses" PRIMARY KEY ("Id");


--
-- Name: Surveys PK_Surveys; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Surveys"
    ADD CONSTRAINT "PK_Surveys" PRIMARY KEY ("Id");


--
-- Name: TalentoCompetencias PK_TalentoCompetencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCompetencias"
    ADD CONSTRAINT "PK_TalentoCompetencias" PRIMARY KEY ("Id");


--
-- Name: TalentoCvImportJobs PK_TalentoCvImportJobs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCvImportJobs"
    ADD CONSTRAINT "PK_TalentoCvImportJobs" PRIMARY KEY ("Id");


--
-- Name: TalentoDocumentos PK_TalentoDocumentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoDocumentos"
    ADD CONSTRAINT "PK_TalentoDocumentos" PRIMARY KEY ("Id");


--
-- Name: TalentoExperiencias PK_TalentoExperiencias; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoExperiencias"
    ADD CONSTRAINT "PK_TalentoExperiencias" PRIMARY KEY ("Id");


--
-- Name: TalentoFormacoes PK_TalentoFormacoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoFormacoes"
    ADD CONSTRAINT "PK_TalentoFormacoes" PRIMARY KEY ("Id");


--
-- Name: TalentoTreinamentos PK_TalentoTreinamentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoTreinamentos"
    ADD CONSTRAINT "PK_TalentoTreinamentos" PRIMARY KEY ("Id");


--
-- Name: Talentos PK_Talentos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Talentos"
    ADD CONSTRAINT "PK_Talentos" PRIMARY KEY ("Id");


--
-- Name: TemplatesEntrevistaSaida PK_TemplatesEntrevistaSaida; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TemplatesEntrevistaSaida"
    ADD CONSTRAINT "PK_TemplatesEntrevistaSaida" PRIMARY KEY ("Id");


--
-- Name: TenantAwsSettings PK_TenantAwsSettings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantAwsSettings"
    ADD CONSTRAINT "PK_TenantAwsSettings" PRIMARY KEY ("Id");


--
-- Name: TenantBrandings PK_TenantBrandings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantBrandings"
    ADD CONSTRAINT "PK_TenantBrandings" PRIMARY KEY ("Id");


--
-- Name: TenantConfiguracoes PK_TenantConfiguracoes; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantConfiguracoes"
    ADD CONSTRAINT "PK_TenantConfiguracoes" PRIMARY KEY ("Id");


--
-- Name: Turnos PK_Turnos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Turnos"
    ADD CONSTRAINT "PK_Turnos" PRIMARY KEY ("Id");


--
-- Name: UnidadesLotacao PK_UnidadesLotacao; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UnidadesLotacao"
    ADD CONSTRAINT "PK_UnidadesLotacao" PRIMARY KEY ("Id");


--
-- Name: Units PK_Units; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Units"
    ADD CONSTRAINT "PK_Units" PRIMARY KEY ("Id");


--
-- Name: UserRoles PK_UserRoles; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "PK_UserRoles" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: UserUnits PK_UserUnits; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserUnits"
    ADD CONSTRAINT "PK_UserUnits" PRIMARY KEY ("UserId", "UnitId");


--
-- Name: Users PK_Users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_Users" PRIMARY KEY ("Id");


--
-- Name: VagaBeneficios PK_VagaBeneficios; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaBeneficios"
    ADD CONSTRAINT "PK_VagaBeneficios" PRIMARY KEY ("Id");


--
-- Name: VagaEtapas PK_VagaEtapas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaEtapas"
    ADD CONSTRAINT "PK_VagaEtapas" PRIMARY KEY ("Id");


--
-- Name: VagaPerguntas PK_VagaPerguntas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaPerguntas"
    ADD CONSTRAINT "PK_VagaPerguntas" PRIMARY KEY ("Id");


--
-- Name: VagaRequisitos PK_VagaRequisitos; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaRequisitos"
    ADD CONSTRAINT "PK_VagaRequisitos" PRIMARY KEY ("Id");


--
-- Name: VagaUnifiedMatchingCaches PK_VagaUnifiedMatchingCaches; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaUnifiedMatchingCaches"
    ADD CONSTRAINT "PK_VagaUnifiedMatchingCaches" PRIMARY KEY ("VagaId");


--
-- Name: Vagas PK_Vagas; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "PK_Vagas" PRIMARY KEY ("Id");


--
-- Name: WorkflowsRH PK_WorkflowsRH; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "PK_WorkflowsRH" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "EmailIndex" ON public."Users" USING btree ("NormalizedEmail");


--
-- Name: IX_AgendaEventTypes_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AgendaEventTypes_TenantId_Code" ON public."AgendaEventTypes" USING btree ("TenantId", "Code");


--
-- Name: IX_AgendaEvents_TenantId_StartAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AgendaEvents_TenantId_StartAtUtc" ON public."AgendaEvents" USING btree ("TenantId", "StartAtUtc");


--
-- Name: IX_AgendaEvents_TypeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AgendaEvents_TypeId" ON public."AgendaEvents" USING btree ("TypeId");


--
-- Name: IX_ApiKeys_TenantId_KeyHash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ApiKeys_TenantId_KeyHash" ON public."ApiKeys" USING btree ("TenantId", "KeyHash");


--
-- Name: IX_ApiKeys_TenantId_Name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ApiKeys_TenantId_Name" ON public."ApiKeys" USING btree ("TenantId", "Name");


--
-- Name: IX_ApprovalMagicLinks_TenantId_Token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ApprovalMagicLinks_TenantId_Token" ON public."ApprovalMagicLinks" USING btree ("TenantId", "Token");


--
-- Name: IX_AprovacoesFaixaSalarial_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_AprovadorId" ON public."AprovacoesFaixaSalarial" USING btree ("AprovadorId");


--
-- Name: IX_AprovacoesFaixaSalarial_FaixaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_FaixaSalarialId" ON public."AprovacoesFaixaSalarial" USING btree ("FaixaSalarialId");


--
-- Name: IX_AprovacoesFaixaSalarial_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_SolicitanteId" ON public."AprovacoesFaixaSalarial" USING btree ("SolicitanteId");


--
-- Name: IX_AprovacoesFaixaSalarial_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovacoesFaixaSalarial_TenantId_Status" ON public."AprovacoesFaixaSalarial" USING btree ("TenantId", "Status");


--
-- Name: IX_AprovadoresAlternativos_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_AprovadorId" ON public."AprovadoresAlternativos" USING btree ("AprovadorId");


--
-- Name: IX_AprovadoresAlternativos_GestorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_GestorId" ON public."AprovadoresAlternativos" USING btree ("GestorId");


--
-- Name: IX_AprovadoresAlternativos_TenantGestor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_TenantGestor" ON public."AprovadoresAlternativos" USING btree ("TenantId", "GestorId");


--
-- Name: IX_AprovadoresAlternativos_TenantId_GestorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AprovadoresAlternativos_TenantId_GestorId" ON public."AprovadoresAlternativos" USING btree ("TenantId", "GestorId");


--
-- Name: IX_AspNetRoleClaims_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AspNetRoleClaims_RoleId" ON public."AspNetRoleClaims" USING btree ("RoleId");


--
-- Name: IX_AspNetUserClaims_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AspNetUserClaims_UserId" ON public."AspNetUserClaims" USING btree ("UserId");


--
-- Name: IX_AspNetUserLogins_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AspNetUserLogins_UserId" ON public."AspNetUserLogins" USING btree ("UserId");


--
-- Name: IX_AuditEntityChanges_AuditEventId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_AuditEventId" ON public."AuditEntityChanges" USING btree ("AuditEventId");


--
-- Name: IX_AuditEntityChanges_AuditTransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_AuditTransactionId" ON public."AuditEntityChanges" USING btree ("AuditTransactionId");


--
-- Name: IX_AuditEntityChanges_TenantId_EntityName; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_TenantId_EntityName" ON public."AuditEntityChanges" USING btree ("TenantId", "EntityName");


--
-- Name: IX_AuditEntityChanges_TenantId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityChanges_TenantId_OccurredAt" ON public."AuditEntityChanges" USING btree ("TenantId", "OccurredAt");


--
-- Name: IX_AuditEntityPropertyChanges_AuditEntityChangeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEntityPropertyChanges_AuditEntityChangeId" ON public."AuditEntityPropertyChanges" USING btree ("AuditEntityChangeId");


--
-- Name: IX_AuditEvents_AuditTransactionId_Order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditEvents_AuditTransactionId_Order" ON public."AuditEvents" USING btree ("AuditTransactionId", "Order");


--
-- Name: IX_AuditTransactions_Path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_Path" ON public."AuditTransactions" USING btree ("Path");


--
-- Name: IX_AuditTransactions_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_StartedAt" ON public."AuditTransactions" USING btree ("StartedAt");


--
-- Name: IX_AuditTransactions_StatusCode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_StatusCode" ON public."AuditTransactions" USING btree ("StatusCode");


--
-- Name: IX_AuditTransactions_TenantId_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_TenantId_StartedAt" ON public."AuditTransactions" USING btree ("TenantId", "StartedAt");


--
-- Name: IX_AuditTransactions_TransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AuditTransactions_TransactionId" ON public."AuditTransactions" USING btree ("TransactionId");


--
-- Name: IX_AuditTransactions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AuditTransactions_UserId" ON public."AuditTransactions" USING btree ("UserId");


--
-- Name: IX_AvaliacaoCalibragens_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_CicloId" ON public."AvaliacaoCalibragens" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoCalibragens_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_FuncionarioId" ON public."AvaliacaoCalibragens" USING btree ("FuncionarioId");


--
-- Name: IX_AvaliacaoCalibragens_NineBoxAssessmentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_NineBoxAssessmentId" ON public."AvaliacaoCalibragens" USING btree ("NineBoxAssessmentId");


--
-- Name: IX_AvaliacaoCalibragens_TenantId_CicloId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AvaliacaoCalibragens_TenantId_CicloId_FuncionarioId" ON public."AvaliacaoCalibragens" USING btree ("TenantId", "CicloId", "FuncionarioId");


--
-- Name: IX_AvaliacaoCalibragens_TenantId_CicloId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCalibragens_TenantId_CicloId_Status" ON public."AvaliacaoCalibragens" USING btree ("TenantId", "CicloId", "Status");


--
-- Name: IX_AvaliacaoCiclos_CriadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCiclos_CriadoPorId" ON public."AvaliacaoCiclos" USING btree ("CriadoPorId");


--
-- Name: IX_AvaliacaoCiclos_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoCiclos_TenantId_Status" ON public."AvaliacaoCiclos" USING btree ("TenantId", "Status");


--
-- Name: IX_AvaliacaoConvites_AvaliadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_AvaliadorId" ON public."AvaliacaoConvites" USING btree ("AvaliadorId");


--
-- Name: IX_AvaliacaoConvites_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_AvaliandoId" ON public."AvaliacaoConvites" USING btree ("AvaliandoId");


--
-- Name: IX_AvaliacaoConvites_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_CicloId" ON public."AvaliacaoConvites" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoConvites_TenantId_AvaliadorId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_TenantId_AvaliadorId_Status" ON public."AvaliacaoConvites" USING btree ("TenantId", "AvaliadorId", "Status");


--
-- Name: IX_AvaliacaoConvites_TenantId_CicloId_AvaliadorId_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_AvaliacaoConvites_TenantId_CicloId_AvaliadorId_AvaliandoId" ON public."AvaliacaoConvites" USING btree ("TenantId", "CicloId", "AvaliadorId", "AvaliandoId");


--
-- Name: IX_AvaliacaoConvites_TenantId_CicloId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoConvites_TenantId_CicloId_Status" ON public."AvaliacaoConvites" USING btree ("TenantId", "CicloId", "Status");


--
-- Name: IX_AvaliacaoPerguntas_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoPerguntas_CicloId" ON public."AvaliacaoPerguntas" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoRespostas_AvaliadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_AvaliadorId" ON public."AvaliacaoRespostas" USING btree ("AvaliadorId");


--
-- Name: IX_AvaliacaoRespostas_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_AvaliandoId" ON public."AvaliacaoRespostas" USING btree ("AvaliandoId");


--
-- Name: IX_AvaliacaoRespostas_CicloId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_CicloId" ON public."AvaliacaoRespostas" USING btree ("CicloId");


--
-- Name: IX_AvaliacaoRespostas_TenantId_CicloId_AvaliandoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_AvaliacaoRespostas_TenantId_CicloId_AvaliandoId" ON public."AvaliacaoRespostas" USING btree ("TenantId", "CicloId", "AvaliandoId");


--
-- Name: IX_BatchMatchingRunVagas_RunId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_BatchMatchingRunVagas_RunId" ON public."BatchMatchingRunVagas" USING btree ("RunId");


--
-- Name: IX_BatchMatchingRuns_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_BatchMatchingRuns_TenantId_CreatedAtUtc" ON public."BatchMatchingRuns" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_CamposPersonalizadosVaga_TenantId_VagaId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CamposPersonalizadosVaga_TenantId_VagaId_Ordem" ON public."CamposPersonalizadosVaga" USING btree ("TenantId", "VagaId", "Ordem");


--
-- Name: IX_CamposPersonalizadosVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CamposPersonalizadosVaga_VagaId" ON public."CamposPersonalizadosVaga" USING btree ("VagaId");


--
-- Name: IX_CandidatoAcessibilidades_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoAcessibilidades_CandidatoId" ON public."CandidatoAcessibilidades" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoAcessibilidades_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoAcessibilidades_TenantId_CandidatoId" ON public."CandidatoAcessibilidades" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoAgendaBloqueios_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoAgendaBloqueios_CandidatoId" ON public."CandidatoAgendaBloqueios" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoAgendaBloqueios_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoAgendaBloqueios_TenantId_CandidatoId" ON public."CandidatoAgendaBloqueios" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoAgendaPreferencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoAgendaPreferencias_CandidatoId" ON public."CandidatoAgendaPreferencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoAgendaPreferencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoAgendaPreferencias_TenantId_CandidatoId" ON public."CandidatoAgendaPreferencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoCertificacoes_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCertificacoes_CandidatoId" ON public."CandidatoCertificacoes" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoCertificacoes_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCertificacoes_TenantId_CandidatoId" ON public."CandidatoCertificacoes" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoCompetencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCompetencias_CandidatoId" ON public."CandidatoCompetencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoCompetencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoCompetencias_TenantId_CandidatoId" ON public."CandidatoCompetencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoDocumentos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoDocumentos_CandidatoId" ON public."CandidatoDocumentos" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoDocumentos_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoDocumentos_TenantId_CandidatoId" ON public."CandidatoDocumentos" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoEducacaoItens_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEducacaoItens_CandidatoId" ON public."CandidatoEducacaoItens" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoEducacaoItens_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEducacaoItens_TenantId_CandidatoId" ON public."CandidatoEducacaoItens" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoEducacaoResumos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEducacaoResumos_CandidatoId" ON public."CandidatoEducacaoResumos" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoEducacaoResumos_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoEducacaoResumos_TenantId_CandidatoId" ON public."CandidatoEducacaoResumos" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoEmbeddings_Ann; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEmbeddings_Ann" ON public."CandidatoEmbeddings" USING ivfflat ("Embedding" public.vector_cosine_ops) WITH (lists='100');


--
-- Name: IX_CandidatoEmbeddings_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEmbeddings_Candidato" ON public."CandidatoEmbeddings" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoEmbeddings_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoEmbeddings_TenantId" ON public."CandidatoEmbeddings" USING btree ("TenantId");


--
-- Name: IX_CandidatoEmbeddings_Tenant_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoEmbeddings_Tenant_Candidato" ON public."CandidatoEmbeddings" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoExperiencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoExperiencias_CandidatoId" ON public."CandidatoExperiencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoExperiencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoExperiencias_TenantId_CandidatoId" ON public."CandidatoExperiencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoLgpdConsents_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoLgpdConsents_CandidatoId" ON public."CandidatoLgpdConsents" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoLgpdConsents_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoLgpdConsents_TenantId_CandidatoId" ON public."CandidatoLgpdConsents" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoNotificacaoPreferencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoNotificacaoPreferencias_CandidatoId" ON public."CandidatoNotificacaoPreferencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoNotificacaoPreferencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoNotificacaoPreferencias_TenantId_CandidatoId" ON public."CandidatoNotificacaoPreferencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoPortfolios_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoPortfolios_CandidatoId" ON public."CandidatoPortfolios" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoPortfolios_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoPortfolios_TenantId_CandidatoId" ON public."CandidatoPortfolios" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoPreferenciasVaga_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoPreferenciasVaga_CandidatoId" ON public."CandidatoPreferenciasVaga" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoPreferenciasVaga_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoPreferenciasVaga_TenantId_CandidatoId" ON public."CandidatoPreferenciasVaga" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoProjetos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoProjetos_CandidatoId" ON public."CandidatoProjetos" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoProjetos_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoProjetos_TenantId_CandidatoId" ON public."CandidatoProjetos" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoReferencias_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoReferencias_CandidatoId" ON public."CandidatoReferencias" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoReferencias_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoReferencias_TenantId_CandidatoId" ON public."CandidatoReferencias" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoStatusHistories_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoStatusHistories_CandidatoId" ON public."CandidatoStatusHistories" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoStatusHistories_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoStatusHistories_TenantId_CandidatoId" ON public."CandidatoStatusHistories" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_CandidatoStatusHistories_TenantId_CandidatoId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoStatusHistories_TenantId_CandidatoId_CreatedAtUtc" ON public."CandidatoStatusHistories" USING btree ("TenantId", "CandidatoId", "CreatedAtUtc");


--
-- Name: IX_CandidatoVagaLlmScores_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaLlmScores_Candidato" ON public."CandidatoVagaLlmScores" USING btree ("CandidatoId");


--
-- Name: IX_CandidatoVagaLlmScores_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaLlmScores_TenantId" ON public."CandidatoVagaLlmScores" USING btree ("TenantId");


--
-- Name: IX_CandidatoVagaLlmScores_Tenant_Vaga_Candidato; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CandidatoVagaLlmScores_Tenant_Vaga_Candidato" ON public."CandidatoVagaLlmScores" USING btree ("TenantId", "VagaId", "CandidatoId");


--
-- Name: IX_CandidatoVagaLlmScores_Vaga; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaLlmScores_Vaga" ON public."CandidatoVagaLlmScores" USING btree ("VagaId");


--
-- Name: IX_CandidatoVagaMatchingScores_VagaId_Score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidatoVagaMatchingScores_VagaId_Score" ON public."CandidatoVagaMatchingScores" USING btree ("VagaId", "Score");


--
-- Name: IX_Candidatos_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_TalentoId" ON public."Candidatos" USING btree ("TalentoId");


--
-- Name: IX_Candidatos_TenantId_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_TenantId_Email" ON public."Candidatos" USING btree ("TenantId", "Email");


--
-- Name: IX_Candidatos_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_TenantId_VagaId" ON public."Candidatos" USING btree ("TenantId", "VagaId");


--
-- Name: IX_Candidatos_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidatos_VagaId" ON public."Candidatos" USING btree ("VagaId");


--
-- Name: IX_CandidaturaEtapaHistoricos_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidaturaEtapaHistoricos_CandidaturaId" ON public."CandidaturaEtapaHistoricos" USING btree ("CandidaturaId");


--
-- Name: IX_CandidaturaEtapaHistoricos_TenantId_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CandidaturaEtapaHistoricos_TenantId_CandidaturaId" ON public."CandidaturaEtapaHistoricos" USING btree ("TenantId", "CandidaturaId");


--
-- Name: IX_Candidaturas_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_CandidatoId" ON public."Candidaturas" USING btree ("CandidatoId");


--
-- Name: IX_Candidaturas_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_TenantId_CandidatoId" ON public."Candidaturas" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_Candidaturas_TenantId_CandidatoId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Candidaturas_TenantId_CandidatoId_VagaId" ON public."Candidaturas" USING btree ("TenantId", "CandidatoId", "VagaId");


--
-- Name: IX_Candidaturas_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_TenantId_VagaId" ON public."Candidaturas" USING btree ("TenantId", "VagaId");


--
-- Name: IX_Candidaturas_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Candidaturas_VagaId" ON public."Candidaturas" USING btree ("VagaId");


--
-- Name: IX_Cargos_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Cargos_IsActive" ON public."Cargos" USING btree ("IsActive");


--
-- Name: IX_Cargos_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Cargos_TenantId_Code" ON public."Cargos" USING btree ("TenantId", "Code");


--
-- Name: IX_CategoriaSalarialSteps_CategoriaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriaSalarialSteps_CategoriaSalarialId" ON public."CategoriaSalarialSteps" USING btree ("CategoriaSalarialId");


--
-- Name: IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId" ON public."CategoriaSalarialSteps" USING btree ("TenantId", "CategoriaSalarialId");


--
-- Name: IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId_Percentu; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CategoriaSalarialSteps_TenantId_CategoriaSalarialId_Percentu" ON public."CategoriaSalarialSteps" USING btree ("TenantId", "CategoriaSalarialId", "Percentual");


--
-- Name: IX_CategoriasSalariais_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriasSalariais_EmpresaId" ON public."CategoriasSalariais" USING btree ("EmpresaId");


--
-- Name: IX_CategoriasSalariais_EstabelecimentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriasSalariais_EstabelecimentoId" ON public."CategoriasSalariais" USING btree ("EstabelecimentoId");


--
-- Name: IX_CategoriasSalariais_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CategoriasSalariais_IsActive" ON public."CategoriasSalariais" USING btree ("IsActive");


--
-- Name: IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Cod; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Cod" ON public."CategoriasSalariais" USING btree ("TenantId", "EmpresaId", "EstabelecimentoId", "Code") WHERE (("EmpresaId" IS NOT NULL) AND ("EstabelecimentoId" IS NOT NULL));


--
-- Name: IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Co~; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CategoriasSalariais_TenantId_EmpresaId_EstabelecimentoId_Co~" ON public."CategoriasSalariais" USING btree ("TenantId", "EmpresaId", "EstabelecimentoId", "Code") WHERE (("EmpresaId" IS NOT NULL) AND ("EstabelecimentoId" IS NOT NULL));


--
-- Name: IX_CelebrationCommentMentions_CommentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentMentions_CommentId" ON public."CelebrationCommentMentions" USING btree ("CommentId");


--
-- Name: IX_CelebrationCommentMentions_CommentId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CelebrationCommentMentions_CommentId_UserId" ON public."CelebrationCommentMentions" USING btree ("CommentId", "UserId");


--
-- Name: IX_CelebrationCommentMentions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentMentions_UserId" ON public."CelebrationCommentMentions" USING btree ("UserId");


--
-- Name: IX_CelebrationCommentReactions_CommentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentReactions_CommentId" ON public."CelebrationCommentReactions" USING btree ("CommentId");


--
-- Name: IX_CelebrationCommentReactions_CommentId_Type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentReactions_CommentId_Type" ON public."CelebrationCommentReactions" USING btree ("CommentId", "Type");


--
-- Name: IX_CelebrationCommentReactions_CommentId_UserId_Type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CelebrationCommentReactions_CommentId_UserId_Type" ON public."CelebrationCommentReactions" USING btree ("CommentId", "UserId", "Type");


--
-- Name: IX_CelebrationCommentReactions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationCommentReactions_UserId" ON public."CelebrationCommentReactions" USING btree ("UserId");


--
-- Name: IX_CelebrationComments_AuthorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationComments_AuthorId" ON public."CelebrationComments" USING btree ("AuthorId");


--
-- Name: IX_CelebrationComments_PostId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationComments_PostId" ON public."CelebrationComments" USING btree ("PostId");


--
-- Name: IX_CelebrationComments_TenantId_PostId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationComments_TenantId_PostId_CreatedAtUtc" ON public."CelebrationComments" USING btree ("TenantId", "PostId", "CreatedAtUtc");


--
-- Name: IX_CelebrationMentions_PostId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationMentions_PostId" ON public."CelebrationMentions" USING btree ("PostId");


--
-- Name: IX_CelebrationMentions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationMentions_UserId" ON public."CelebrationMentions" USING btree ("UserId");


--
-- Name: IX_CelebrationPosts_AuthorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationPosts_AuthorId" ON public."CelebrationPosts" USING btree ("AuthorId");


--
-- Name: IX_CelebrationPosts_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CelebrationPosts_TenantId_CreatedAtUtc" ON public."CelebrationPosts" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_CentrosCusto_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_EmpresaId" ON public."CentrosCusto" USING btree ("EmpresaId");


--
-- Name: IX_CentrosCusto_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_IsActive" ON public."CentrosCusto" USING btree ("IsActive");


--
-- Name: IX_CentrosCusto_OwnerFuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_OwnerFuncionarioId" ON public."CentrosCusto" USING btree ("OwnerFuncionarioId");


--
-- Name: IX_CentrosCusto_ParentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_CentrosCusto_ParentId" ON public."CentrosCusto" USING btree ("ParentId");


--
-- Name: IX_CentrosCusto_TenantId_EmpresaId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_CentrosCusto_TenantId_EmpresaId_Code" ON public."CentrosCusto" USING btree ("TenantId", "EmpresaId", "Code") WHERE ("EmpresaId" IS NOT NULL);


--
-- Name: IX_DadosBancarios_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DadosBancarios_FuncionarioId" ON public."DadosBancarios" USING btree ("FuncionarioId");


--
-- Name: IX_Dependentes_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Dependentes_FuncionarioId" ON public."Dependentes" USING btree ("FuncionarioId");


--
-- Name: IX_Dependentes_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Dependentes_TenantId_FuncionarioId" ON public."Dependentes" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_DescricaoCargoItemEmbeddings_Ann; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItemEmbeddings_Ann" ON public."DescricaoCargoItemEmbeddings" USING ivfflat ("Embedding" public.vector_cosine_ops) WITH (lists='100');


--
-- Name: IX_DescricaoCargoItemEmbeddings_Item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItemEmbeddings_Item" ON public."DescricaoCargoItemEmbeddings" USING btree ("DescricaoCargoItemId");


--
-- Name: IX_DescricaoCargoItemEmbeddings_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItemEmbeddings_TenantId" ON public."DescricaoCargoItemEmbeddings" USING btree ("TenantId");


--
-- Name: IX_DescricaoCargoItemEmbeddings_Tenant_Item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DescricaoCargoItemEmbeddings_Tenant_Item" ON public."DescricaoCargoItemEmbeddings" USING btree ("TenantId", "DescricaoCargoItemId");


--
-- Name: IX_DescricaoCargoItens_DescricaoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItens_DescricaoCargoId" ON public."DescricaoCargoItens" USING btree ("DescricaoCargoId");


--
-- Name: IX_DescricaoCargoItens_TenantId_DescricaoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItens_TenantId_DescricaoCargoId" ON public."DescricaoCargoItens" USING btree ("TenantId", "DescricaoCargoId");


--
-- Name: IX_DescricaoCargoItens_TenantId_DescricaoCargoId_Categoria; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricaoCargoItens_TenantId_DescricaoCargoId_Categoria" ON public."DescricaoCargoItens" USING btree ("TenantId", "DescricaoCargoId", "Categoria");


--
-- Name: IX_DescricoesCargo_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricoesCargo_IsActive" ON public."DescricoesCargo" USING btree ("IsActive");


--
-- Name: IX_DescricoesCargo_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DescricoesCargo_NivelCargoId" ON public."DescricoesCargo" USING btree ("NivelCargoId");


--
-- Name: IX_DescricoesCargo_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DescricoesCargo_TenantId_Code" ON public."DescricoesCargo" USING btree ("TenantId", "Code");


--
-- Name: IX_Desligamentos_ChapaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_ChapaRm" ON public."Desligamentos" USING btree ("ChapaRm");


--
-- Name: IX_Desligamentos_CodStatus; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_CodStatus" ON public."Desligamentos" USING btree ("CodStatus");


--
-- Name: IX_Desligamentos_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_FuncionarioId" ON public."Desligamentos" USING btree ("FuncionarioId");


--
-- Name: IX_Desligamentos_GerouSubstituicao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Desligamentos_GerouSubstituicao" ON public."Desligamentos" USING btree ("GerouSubstituicao");


--
-- Name: IX_Desligamentos_TenantId_IdReqRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Desligamentos_TenantId_IdReqRm" ON public."Desligamentos" USING btree ("TenantId", "IdReqRm");


--
-- Name: IX_DevelopmentPlanGoals_PlanId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlanGoals_PlanId" ON public."DevelopmentPlanGoals" USING btree ("PlanId");


--
-- Name: IX_DevelopmentPlans_OwnerUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_OwnerUserId" ON public."DevelopmentPlans" USING btree ("OwnerUserId");


--
-- Name: IX_DevelopmentPlans_TargetUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_TargetUserId" ON public."DevelopmentPlans" USING btree ("TargetUserId");


--
-- Name: IX_DevelopmentPlans_TenantId_OwnerUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_TenantId_OwnerUserId" ON public."DevelopmentPlans" USING btree ("TenantId", "OwnerUserId");


--
-- Name: IX_DevelopmentPlans_TenantId_TargetUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DevelopmentPlans_TenantId_TargetUserId" ON public."DevelopmentPlans" USING btree ("TenantId", "TargetUserId");


--
-- Name: IX_DocumentacaoPadraoConfigs_TenantId_TipoDocumento; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DocumentacaoPadraoConfigs_TenantId_TipoDocumento" ON public."DocumentacaoPadraoConfigs" USING btree ("TenantId", "TipoDocumento");


--
-- Name: IX_DocumentacaoPadraoHistoricos_CargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_CargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("CargoId");


--
-- Name: IX_DocumentacaoPadraoHistoricos_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_NivelCargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoHistoricos_TenantId_CriadoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_TenantId_CriadoEmUtc" ON public."DocumentacaoPadraoHistoricos" USING btree ("TenantId", "CriadoEmUtc");


--
-- Name: IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_CargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_CargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("TenantId", "Escopo", "CargoId");


--
-- Name: IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoHistoricos_TenantId_Escopo_NivelCargoId" ON public."DocumentacaoPadraoHistoricos" USING btree ("TenantId", "Escopo", "NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoPorCargoConfigs_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorCargoConfigs_JobPositionId" ON public."DocumentacaoPadraoPorCargoConfigs" USING btree ("JobPositionId");


--
-- Name: IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId" ON public."DocumentacaoPadraoPorCargoConfigs" USING btree ("TenantId", "JobPositionId");


--
-- Name: IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId_Ti~; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DocumentacaoPadraoPorCargoConfigs_TenantId_JobPositionId_Ti~" ON public."DocumentacaoPadraoPorCargoConfigs" USING btree ("TenantId", "JobPositionId", "TipoDocumento");


--
-- Name: IX_DocumentacaoPadraoPorNivelCargoConfigs_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorNivelCargoConfigs_NivelCargoId" ON public."DocumentacaoPadraoPorNivelCargoConfigs" USING btree ("NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoId" ON public."DocumentacaoPadraoPorNivelCargoConfigs" USING btree ("TenantId", "NivelCargoId");


--
-- Name: IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoI~; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_DocumentacaoPadraoPorNivelCargoConfigs_TenantId_NivelCargoI~" ON public."DocumentacaoPadraoPorNivelCargoConfigs" USING btree ("TenantId", "NivelCargoId", "TipoDocumento");


--
-- Name: IX_DocumentosColaborador_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentosColaborador_FuncionarioId" ON public."DocumentosColaborador" USING btree ("FuncionarioId");


--
-- Name: IX_DocumentosColaborador_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_DocumentosColaborador_TenantId_FuncionarioId" ON public."DocumentosColaborador" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_EixosVaga_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EixosVaga_IsActive" ON public."EixosVaga" USING btree ("IsActive");


--
-- Name: IX_EixosVaga_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EixosVaga_TenantId_Code" ON public."EixosVaga" USING btree ("TenantId", "Code");


--
-- Name: IX_EmailAttempts_EmailMessageId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailAttempts_EmailMessageId" ON public."EmailAttempts" USING btree ("EmailMessageId");


--
-- Name: IX_EmailAttempts_TenantId_EmailMessageId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailAttempts_TenantId_EmailMessageId" ON public."EmailAttempts" USING btree ("TenantId", "EmailMessageId");


--
-- Name: IX_EmailAttempts_TenantId_StartedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailAttempts_TenantId_StartedAtUtc" ON public."EmailAttempts" USING btree ("TenantId", "StartedAtUtc");


--
-- Name: IX_EmailConfigs_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EmailConfigs_TenantId" ON public."EmailConfigs" USING btree ("TenantId");


--
-- Name: IX_EmailMessages_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_CreatedAtUtc" ON public."EmailMessages" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_EmailMessages_TenantId_IsSystem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_IsSystem" ON public."EmailMessages" USING btree ("TenantId", "IsSystem");


--
-- Name: IX_EmailMessages_TenantId_OwnerUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_OwnerUserId" ON public."EmailMessages" USING btree ("TenantId", "OwnerUserId");


--
-- Name: IX_EmailMessages_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailMessages_TenantId_Status" ON public."EmailMessages" USING btree ("TenantId", "Status");


--
-- Name: IX_EmailTemplates_TenantId_Name_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailTemplates_TenantId_Name_IsActive" ON public."EmailTemplates" USING btree ("TenantId", "Name", "IsActive");


--
-- Name: IX_EmailTemplates_TenantId_Name_Version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EmailTemplates_TenantId_Name_Version" ON public."EmailTemplates" USING btree ("TenantId", "Name", "Version");


--
-- Name: IX_Empresas_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Empresas_TenantId_Code" ON public."Empresas" USING btree ("TenantId", "Code");


--
-- Name: IX_EntraIdConfigs_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EntraIdConfigs_TenantId" ON public."EntraIdConfigs" USING btree ("TenantId");


--
-- Name: IX_EntrevistasSaida_TenantId_DesligamentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EntrevistasSaida_TenantId_DesligamentoId" ON public."EntrevistasSaida" USING btree ("TenantId", "DesligamentoId");


--
-- Name: IX_EntrevistasSaida_TenantId_Token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EntrevistasSaida_TenantId_Token" ON public."EntrevistasSaida" USING btree ("TenantId", "Token");


--
-- Name: IX_EtapasConfigAprovacao_FuncionarioFixoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasConfigAprovacao_FuncionarioFixoId" ON public."EtapasConfigAprovacao" USING btree ("FuncionarioFixoId");


--
-- Name: IX_EtapasConfigAprovacao_RoleFilaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasConfigAprovacao_RoleFilaId" ON public."EtapasConfigAprovacao" USING btree ("RoleFilaId");


--
-- Name: IX_EtapasConfigAprovacao_TenantId_TipoFluxo_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EtapasConfigAprovacao_TenantId_TipoFluxo_Ordem" ON public."EtapasConfigAprovacao" USING btree ("TenantId", "TipoFluxo", "Ordem");


--
-- Name: IX_EtapasConfigWorkflowRH_RoleFilaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasConfigWorkflowRH_RoleFilaId" ON public."EtapasConfigWorkflowRH" USING btree ("RoleFilaId");


--
-- Name: IX_EtapasConfigWorkflowRH_TenantId_TipoWorkflow_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_EtapasConfigWorkflowRH_TenantId_TipoWorkflow_Ordem" ON public."EtapasConfigWorkflowRH" USING btree ("TenantId", "TipoWorkflow", "Ordem");


--
-- Name: IX_EtapasWorkflowRH_ResponsavelId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasWorkflowRH_ResponsavelId" ON public."EtapasWorkflowRH" USING btree ("ResponsavelId");


--
-- Name: IX_EtapasWorkflowRH_WorkflowId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_EtapasWorkflowRH_WorkflowId_Ordem" ON public."EtapasWorkflowRH" USING btree ("WorkflowId", "Ordem");


--
-- Name: IX_ExceptionLogs_TenantId_DeviceId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_DeviceId_OccurredAt" ON public."ExceptionLogs" USING btree ("TenantId", "DeviceId", "OccurredAt");


--
-- Name: IX_ExceptionLogs_TenantId_EnvironmentNormalized_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_EnvironmentNormalized_OccurredAt" ON public."ExceptionLogs" USING btree ("TenantId", "EnvironmentNormalized", "OccurredAt");


--
-- Name: IX_ExceptionLogs_TenantId_ExceptionType; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_ExceptionType" ON public."ExceptionLogs" USING btree ("TenantId", "ExceptionType");


--
-- Name: IX_ExceptionLogs_TenantId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_OccurredAt" ON public."ExceptionLogs" USING btree ("TenantId", "OccurredAt");


--
-- Name: IX_ExceptionLogs_TenantId_StatusCode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_StatusCode" ON public."ExceptionLogs" USING btree ("TenantId", "StatusCode");


--
-- Name: IX_ExceptionLogs_TenantId_TransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ExceptionLogs_TenantId_TransactionId" ON public."ExceptionLogs" USING btree ("TenantId", "TransactionId");


--
-- Name: IX_FaixasSalariais_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FaixasSalariais_JobPositionId" ON public."FaixasSalariais" USING btree ("JobPositionId");


--
-- Name: IX_FaixasSalariais_TenantId_JobPositionId_EstabelecimentoCodigo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FaixasSalariais_TenantId_JobPositionId_EstabelecimentoCodigo" ON public."FaixasSalariais" USING btree ("TenantId", "JobPositionId", "EstabelecimentoCodigo");


--
-- Name: IX_FasesProcesso_ProjetoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FasesProcesso_ProjetoId" ON public."FasesProcesso" USING btree ("ProjetoId");


--
-- Name: IX_FasesProcesso_TenantId_ProjetoId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FasesProcesso_TenantId_ProjetoId_Ordem" ON public."FasesProcesso" USING btree ("TenantId", "ProjetoId", "Ordem");


--
-- Name: IX_FeedbackItemRatings_FeedbackItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItemRatings_FeedbackItemId" ON public."FeedbackItemRatings" USING btree ("FeedbackItemId");


--
-- Name: IX_FeedbackItems_FromUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_FromUserId" ON public."FeedbackItems" USING btree ("FromUserId");


--
-- Name: IX_FeedbackItems_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_TenantId_CreatedAtUtc" ON public."FeedbackItems" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_FeedbackItems_TenantId_FromUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_TenantId_FromUserId" ON public."FeedbackItems" USING btree ("TenantId", "FromUserId");


--
-- Name: IX_FeedbackItems_TenantId_ToUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_TenantId_ToUserId" ON public."FeedbackItems" USING btree ("TenantId", "ToUserId");


--
-- Name: IX_FeedbackItems_ToUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FeedbackItems_ToUserId" ON public."FeedbackItems" USING btree ("ToUserId");


--
-- Name: IX_FluxosAprovacaoConfig_TenantId_TipoFluxo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_FluxosAprovacaoConfig_TenantId_TipoFluxo" ON public."FluxosAprovacaoConfig" USING btree ("TenantId", "TipoFluxo");


--
-- Name: IX_FuncionarioMovimentacoes_ChapaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FuncionarioMovimentacoes_ChapaRm" ON public."FuncionarioMovimentacoes" USING btree ("ChapaRm");


--
-- Name: IX_FuncionarioMovimentacoes_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FuncionarioMovimentacoes_FuncionarioId" ON public."FuncionarioMovimentacoes" USING btree ("FuncionarioId");


--
-- Name: IX_FuncionarioMovimentacoes_TenantId_IdReqRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_FuncionarioMovimentacoes_TenantId_IdReqRm" ON public."FuncionarioMovimentacoes" USING btree ("TenantId", "IdReqRm");


--
-- Name: IX_FuncionarioMovimentacoes_TipoMovimentacao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_FuncionarioMovimentacoes_TipoMovimentacao" ON public."FuncionarioMovimentacoes" USING btree ("TipoMovimentacao");


--
-- Name: IX_Funcionarios_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_CentroCustoId" ON public."Funcionarios" USING btree ("CentroCustoId");


--
-- Name: IX_Funcionarios_GestorDiretoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_GestorDiretoId" ON public."Funcionarios" USING btree ("GestorDiretoId");


--
-- Name: IX_Funcionarios_HierarquiaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_HierarquiaId" ON public."Funcionarios" USING btree ("HierarquiaId");


--
-- Name: IX_Funcionarios_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_JobPositionId" ON public."Funcionarios" USING btree ("JobPositionId");


--
-- Name: IX_Funcionarios_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_NivelCargoId" ON public."Funcionarios" USING btree ("NivelCargoId");


--
-- Name: IX_Funcionarios_NivelHierarquicoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_NivelHierarquicoId" ON public."Funcionarios" USING btree ("NivelHierarquicoId");


--
-- Name: IX_Funcionarios_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_PessoaId" ON public."Funcionarios" USING btree ("PessoaId");


--
-- Name: IX_Funcionarios_TenantId_CdnEmpresa_CdnEstab_CdnFuncionario; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Funcionarios_TenantId_CdnEmpresa_CdnEstab_CdnFuncionario" ON public."Funcionarios" USING btree ("TenantId", "CdnEmpresa", "CdnEstab", "CdnFuncionario") WHERE ("CdnFuncionario" IS NOT NULL);


--
-- Name: IX_Funcionarios_TenantId_CodSituacaoRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_TenantId_CodSituacaoRm" ON public."Funcionarios" USING btree ("TenantId", "CodSituacaoRm");


--
-- Name: IX_Funcionarios_TenantId_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_TenantId_Email" ON public."Funcionarios" USING btree ("TenantId", "Email") WHERE ("Email" IS NOT NULL);


--
-- Name: IX_Funcionarios_TenantId_MatriculaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_TenantId_MatriculaRm" ON public."Funcionarios" USING btree ("TenantId", "MatriculaRm");


--
-- Name: IX_Funcionarios_UnidadeLotacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_UnidadeLotacaoId" ON public."Funcionarios" USING btree ("UnidadeLotacaoId");


--
-- Name: IX_Funcionarios_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_UnitId" ON public."Funcionarios" USING btree ("UnitId");


--
-- Name: IX_Funcionarios_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Funcionarios_UserId" ON public."Funcionarios" USING btree ("UserId");


--
-- Name: IX_GamificationDailyStates_TenantId_LastCheckInDate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_GamificationDailyStates_TenantId_LastCheckInDate" ON public."GamificationDailyStates" USING btree ("TenantId", "LastCheckInDate");


--
-- Name: IX_GamificationDailyStates_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_GamificationDailyStates_TenantId_UserId" ON public."GamificationDailyStates" USING btree ("TenantId", "UserId");


--
-- Name: IX_GamificationDailyStates_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_GamificationDailyStates_UserId" ON public."GamificationDailyStates" USING btree ("UserId");


--
-- Name: IX_Hierarquias_Estrutura; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Hierarquias_Estrutura" ON public."Hierarquias" USING btree ("Estrutura");


--
-- Name: IX_Hierarquias_HierarquiaSuperiorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Hierarquias_HierarquiaSuperiorId" ON public."Hierarquias" USING btree ("HierarquiaSuperiorId");


--
-- Name: IX_Hierarquias_IdHierarquiaSuperiorRm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Hierarquias_IdHierarquiaSuperiorRm" ON public."Hierarquias" USING btree ("IdHierarquiaSuperiorRm");


--
-- Name: IX_Hierarquias_TenantId_IdHierarquiaRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Hierarquias_TenantId_IdHierarquiaRm" ON public."Hierarquias" USING btree ("TenantId", "IdHierarquiaRm");


--
-- Name: IX_HistoricosAlteracaoWorkflowRH_AlteradoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosAlteracaoWorkflowRH_AlteradoPorId" ON public."HistoricosAlteracaoWorkflowRH" USING btree ("AlteradoPorId");


--
-- Name: IX_HistoricosAlteracaoWorkflowRH_EtapaWorkflowId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosAlteracaoWorkflowRH_EtapaWorkflowId" ON public."HistoricosAlteracaoWorkflowRH" USING btree ("EtapaWorkflowId");


--
-- Name: IX_HistoricosAlteracaoWorkflowRH_WorkflowId_DataAlteracaoUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosAlteracaoWorkflowRH_WorkflowId_DataAlteracaoUtc" ON public."HistoricosAlteracaoWorkflowRH" USING btree ("WorkflowId", "DataAlteracaoUtc");


--
-- Name: IX_HistoricosStatus_TenantId_AlteradoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_AlteradoEmUtc" ON public."HistoricosStatus" USING btree ("TenantId", "AlteradoEmUtc");


--
-- Name: IX_HistoricosStatus_TenantId_TipoEntidade_DentroDoSla; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_TipoEntidade_DentroDoSla" ON public."HistoricosStatus" USING btree ("TenantId", "TipoEntidade", "DentroDoSla");


--
-- Name: IX_HistoricosStatus_TenantId_TipoEntidade_EntidadeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_TipoEntidade_EntidadeId" ON public."HistoricosStatus" USING btree ("TenantId", "TipoEntidade", "EntidadeId");


--
-- Name: IX_HistoricosStatus_TenantId_TipoEntidade_StatusNovo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_HistoricosStatus_TenantId_TipoEntidade_StatusNovo" ON public."HistoricosStatus" USING btree ("TenantId", "TipoEntidade", "StatusNovo");


--
-- Name: IX_Holerites_EnviadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Holerites_EnviadoPorId" ON public."Holerites" USING btree ("EnviadoPorId");


--
-- Name: IX_Holerites_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Holerites_FuncionarioId" ON public."Holerites" USING btree ("FuncionarioId");


--
-- Name: IX_InboxAttachments_InboxItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxAttachments_InboxItemId" ON public."InboxAttachments" USING btree ("InboxItemId");


--
-- Name: IX_InboxAttachments_TenantId_InboxItemId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxAttachments_TenantId_InboxItemId" ON public."InboxAttachments" USING btree ("TenantId", "InboxItemId");


--
-- Name: IX_InboxItems_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_CandidatoId" ON public."InboxItems" USING btree ("CandidatoId");


--
-- Name: IX_InboxItems_TenantId_Origem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_TenantId_Origem" ON public."InboxItems" USING btree ("TenantId", "Origem");


--
-- Name: IX_InboxItems_TenantId_RecebidoEm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_TenantId_RecebidoEm" ON public."InboxItems" USING btree ("TenantId", "RecebidoEm");


--
-- Name: IX_InboxItems_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_TenantId_Status" ON public."InboxItems" USING btree ("TenantId", "Status");


--
-- Name: IX_InboxItems_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_InboxItems_VagaId" ON public."InboxItems" USING btree ("VagaId");


--
-- Name: IX_JobPositions_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_JobPositions_CentroCustoId" ON public."JobPositions" USING btree ("CentroCustoId");


--
-- Name: IX_JobPositions_NivelCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_JobPositions_NivelCargoId" ON public."JobPositions" USING btree ("NivelCargoId");


--
-- Name: IX_JobPositions_NivelHierarquicoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_JobPositions_NivelHierarquicoId" ON public."JobPositions" USING btree ("NivelHierarquicoId");


--
-- Name: IX_JobPositions_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_JobPositions_TenantId_Code" ON public."JobPositions" USING btree ("TenantId", "Code");


--
-- Name: IX_JobPositions_TenantId_TotvsCargoBasicId_TotvsNivCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_JobPositions_TenantId_TotvsCargoBasicId_TotvsNivCargoId" ON public."JobPositions" USING btree ("TenantId", "TotvsCargoBasicId", "TotvsNivCargoId") WHERE (("TotvsCargoBasicId" IS NOT NULL) AND ("TotvsNivCargoId" IS NOT NULL));


--
-- Name: IX_LocalizationConfigs_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_LocalizationConfigs_TenantId" ON public."LocalizationConfigs" USING btree ("TenantId");


--
-- Name: IX_LogEntries_RequestLogId_Order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_RequestLogId_Order" ON public."LogEntries" USING btree ("RequestLogId", "Order");


--
-- Name: IX_LogEntries_TenantId_Category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_Category" ON public."LogEntries" USING btree ("TenantId", "Category");


--
-- Name: IX_LogEntries_TenantId_DeviceId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_DeviceId_OccurredAt" ON public."LogEntries" USING btree ("TenantId", "DeviceId", "OccurredAt");


--
-- Name: IX_LogEntries_TenantId_EnvironmentNormalized_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_EnvironmentNormalized_OccurredAt" ON public."LogEntries" USING btree ("TenantId", "EnvironmentNormalized", "OccurredAt");


--
-- Name: IX_LogEntries_TenantId_Level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_Level" ON public."LogEntries" USING btree ("TenantId", "Level");


--
-- Name: IX_LogEntries_TenantId_OccurredAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogEntries_TenantId_OccurredAt" ON public."LogEntries" USING btree ("TenantId", "OccurredAt");


--
-- Name: IX_LogsComunicacao_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogsComunicacao_CandidatoId" ON public."LogsComunicacao" USING btree ("CandidatoId");


--
-- Name: IX_LogsComunicacao_ProjetoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogsComunicacao_ProjetoId" ON public."LogsComunicacao" USING btree ("ProjetoId");


--
-- Name: IX_LogsComunicacao_TenantId_CandidatoId_DataUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_LogsComunicacao_TenantId_CandidatoId_DataUtc" ON public."LogsComunicacao" USING btree ("TenantId", "CandidatoId", "DataUtc");


--
-- Name: IX_Menus_TenantId_PermissionKey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Menus_TenantId_PermissionKey" ON public."Menus" USING btree ("TenantId", "PermissionKey");


--
-- Name: IX_Menus_TenantId_Route; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Menus_TenantId_Route" ON public."Menus" USING btree ("TenantId", "Route");


--
-- Name: IX_Metas_CriadaPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_CriadaPorId" ON public."Metas" USING btree ("CriadaPorId");


--
-- Name: IX_Metas_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_FuncionarioId" ON public."Metas" USING btree ("FuncionarioId");


--
-- Name: IX_Metas_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_TenantId_FuncionarioId" ON public."Metas" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_Metas_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Metas_TenantId_Status" ON public."Metas" USING btree ("TenantId", "Status");


--
-- Name: IX_MoodEntries_TenantId_UserId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_MoodEntries_TenantId_UserId_CreatedAtUtc" ON public."MoodEntries" USING btree ("TenantId", "UserId", "CreatedAtUtc");


--
-- Name: IX_MoodEntries_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_MoodEntries_UserId" ON public."MoodEntries" USING btree ("UserId");


--
-- Name: IX_MotivosRequisicaoVagaConfig_TenantId_Codigo; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_MotivosRequisicaoVagaConfig_TenantId_Codigo" ON public."MotivosRequisicaoVagaConfig" USING btree ("TenantId", "Codigo");


--
-- Name: IX_MotivosRequisicaoVagaConfig_TenantId_IsActive_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_MotivosRequisicaoVagaConfig_TenantId_IsActive_Ordem" ON public."MotivosRequisicaoVagaConfig" USING btree ("TenantId", "IsActive", "Ordem");


--
-- Name: IX_NineBoxAssessments_AvaliadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_AvaliadorId" ON public."NineBoxAssessments" USING btree ("AvaliadorId");


--
-- Name: IX_NineBoxAssessments_CicloAvaliacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_CicloAvaliacaoId" ON public."NineBoxAssessments" USING btree ("CicloAvaliacaoId");


--
-- Name: IX_NineBoxAssessments_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_FuncionarioId" ON public."NineBoxAssessments" USING btree ("FuncionarioId");


--
-- Name: IX_NineBoxAssessments_TenantId_CicloAvaliacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_TenantId_CicloAvaliacaoId" ON public."NineBoxAssessments" USING btree ("TenantId", "CicloAvaliacaoId");


--
-- Name: IX_NineBoxAssessments_TenantId_CriadoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_TenantId_CriadoEmUtc" ON public."NineBoxAssessments" USING btree ("TenantId", "CriadoEmUtc");


--
-- Name: IX_NineBoxAssessments_TenantId_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NineBoxAssessments_TenantId_FuncionarioId" ON public."NineBoxAssessments" USING btree ("TenantId", "FuncionarioId");


--
-- Name: IX_NiveisHierarquicos_TenantId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NiveisHierarquicos_TenantId_Ordem" ON public."NiveisHierarquicos" USING btree ("TenantId", "Ordem");


--
-- Name: IX_NotificacoesCandidaturaLogs_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificacoesCandidaturaLogs_TenantId_CandidatoId" ON public."NotificacoesCandidaturaLogs" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_NotificacoesCandidaturaLogs_TenantId_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificacoesCandidaturaLogs_TenantId_CandidaturaId" ON public."NotificacoesCandidaturaLogs" USING btree ("TenantId", "CandidaturaId");


--
-- Name: IX_NotificacoesTemplates_TenantId_Etapa_Canal_Idioma; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_NotificacoesTemplates_TenantId_Etapa_Canal_Idioma" ON public."NotificacoesTemplates" USING btree ("TenantId", "Etapa", "Canal", "Idioma");


--
-- Name: IX_NotificationReceipts_TenantId_NotificationId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificationReceipts_TenantId_NotificationId" ON public."NotificationReceipts" USING btree ("TenantId", "NotificationId");


--
-- Name: IX_NotificationReceipts_TenantId_NotificationId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_NotificationReceipts_TenantId_NotificationId_UserId" ON public."NotificationReceipts" USING btree ("TenantId", "NotificationId", "UserId");


--
-- Name: IX_NotificationReceipts_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_NotificationReceipts_TenantId_UserId" ON public."NotificationReceipts" USING btree ("TenantId", "UserId");


--
-- Name: IX_Notifications_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_TenantId_CreatedAtUtc" ON public."Notifications" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_Notifications_TenantId_IsRead; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_TenantId_IsRead" ON public."Notifications" USING btree ("TenantId", "IsRead");


--
-- Name: IX_Notifications_TenantId_UserId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_TenantId_UserId_CreatedAtUtc" ON public."Notifications" USING btree ("TenantId", "UserId", "CreatedAtUtc");


--
-- Name: IX_Notifications_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Notifications_UserId" ON public."Notifications" USING btree ("UserId");


--
-- Name: IX_OcupacoesHistorico_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_FuncionarioId" ON public."OcupacoesHistorico" USING btree ("FuncionarioId");


--
-- Name: IX_OcupacoesHistorico_TenantId_FuncionarioId_DataSaida; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_TenantId_FuncionarioId_DataSaida" ON public."OcupacoesHistorico" USING btree ("TenantId", "FuncionarioId", "DataSaida");


--
-- Name: IX_OcupacoesHistorico_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_TenantId_VagaId" ON public."OcupacoesHistorico" USING btree ("TenantId", "VagaId");


--
-- Name: IX_OcupacoesHistorico_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OcupacoesHistorico_VagaId" ON public."OcupacoesHistorico" USING btree ("VagaId");


--
-- Name: IX_OneOnOneMeetings_CollaboratorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_CollaboratorId" ON public."OneOnOneMeetings" USING btree ("CollaboratorId");


--
-- Name: IX_OneOnOneMeetings_ManagerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_ManagerId" ON public."OneOnOneMeetings" USING btree ("ManagerId");


--
-- Name: IX_OneOnOneMeetings_TenantId_CollaboratorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_TenantId_CollaboratorId" ON public."OneOnOneMeetings" USING btree ("TenantId", "CollaboratorId");


--
-- Name: IX_OneOnOneMeetings_TenantId_ManagerId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_TenantId_ManagerId" ON public."OneOnOneMeetings" USING btree ("TenantId", "ManagerId");


--
-- Name: IX_OneOnOneMeetings_TenantId_MeetingDate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_OneOnOneMeetings_TenantId_MeetingDate" ON public."OneOnOneMeetings" USING btree ("TenantId", "MeetingDate");


--
-- Name: IX_PerguntasEntrevistaSaida_TemplateId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PerguntasEntrevistaSaida_TemplateId" ON public."PerguntasEntrevistaSaida" USING btree ("TemplateId");


--
-- Name: IX_PerguntasEntrevistaSaida_TenantId_TemplateId_Ordem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PerguntasEntrevistaSaida_TenantId_TemplateId_Ordem" ON public."PerguntasEntrevistaSaida" USING btree ("TenantId", "TemplateId", "Ordem");


--
-- Name: IX_PermissoesNivelVaga_NivelHierarquicoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PermissoesNivelVaga_NivelHierarquicoId" ON public."PermissoesNivelVaga" USING btree ("NivelHierarquicoId");


--
-- Name: IX_PermissoesNivelVaga_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PermissoesNivelVaga_RoleId" ON public."PermissoesNivelVaga" USING btree ("RoleId");


--
-- Name: IX_PermissoesNivelVaga_TenantId_NivelHierarquicoId_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_PermissoesNivelVaga_TenantId_NivelHierarquicoId_RoleId" ON public."PermissoesNivelVaga" USING btree ("TenantId", "NivelHierarquicoId", "RoleId");


--
-- Name: IX_PessoaBloqueios_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PessoaBloqueios_PessoaId" ON public."PessoaBloqueios" USING btree ("PessoaId");


--
-- Name: IX_PessoaBloqueios_TenantId_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_PessoaBloqueios_TenantId_PessoaId" ON public."PessoaBloqueios" USING btree ("TenantId", "PessoaId");


--
-- Name: IX_Pessoas_TenantId_Cpf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Pessoas_TenantId_Cpf" ON public."Pessoas" USING btree ("TenantId", "Cpf");


--
-- Name: IX_Pessoas_TenantId_Email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Pessoas_TenantId_Email" ON public."Pessoas" USING btree ("TenantId", "Email");


--
-- Name: IX_PreAdmissaoDependentes_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDependentes_PreAdmissaoId" ON public."PreAdmissaoDependentes" USING btree ("PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDependentes_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDependentes_TenantId_PreAdmissaoId" ON public."PreAdmissaoDependentes" USING btree ("TenantId", "PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentosSolicitados_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentosSolicitados_PreAdmissaoId" ON public."PreAdmissaoDocumentosSolicitados" USING btree ("PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentosSolicitados_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentosSolicitados_TenantId_PreAdmissaoId" ON public."PreAdmissaoDocumentosSolicitados" USING btree ("TenantId", "PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentos_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentos_PreAdmissaoId" ON public."PreAdmissaoDocumentos" USING btree ("PreAdmissaoId");


--
-- Name: IX_PreAdmissaoDocumentos_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissaoDocumentos_TenantId_PreAdmissaoId" ON public."PreAdmissaoDocumentos" USING btree ("TenantId", "PreAdmissaoId");


--
-- Name: IX_PreAdmissoes_AprovadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_AprovadoPorId" ON public."PreAdmissoes" USING btree ("AprovadoPorId");


--
-- Name: IX_PreAdmissoes_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_CandidatoId" ON public."PreAdmissoes" USING btree ("CandidatoId");


--
-- Name: IX_PreAdmissoes_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_CentroCustoId" ON public."PreAdmissoes" USING btree ("CentroCustoId");


--
-- Name: IX_PreAdmissoes_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_JobPositionId" ON public."PreAdmissoes" USING btree ("JobPositionId");


--
-- Name: IX_PreAdmissoes_RevisadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_RevisadoPorId" ON public."PreAdmissoes" USING btree ("RevisadoPorId");


--
-- Name: IX_PreAdmissoes_TenantId_AccessToken; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_TenantId_AccessToken" ON public."PreAdmissoes" USING btree ("TenantId", "AccessToken") WHERE ("AccessToken" IS NOT NULL);


--
-- Name: IX_PreAdmissoes_TenantId_Cpf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_TenantId_Cpf" ON public."PreAdmissoes" USING btree ("TenantId", "Cpf");


--
-- Name: IX_PreAdmissoes_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_TenantId_Status" ON public."PreAdmissoes" USING btree ("TenantId", "Status");


--
-- Name: IX_PreAdmissoes_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_UnitId" ON public."PreAdmissoes" USING btree ("UnitId");


--
-- Name: IX_PreAdmissoes_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PreAdmissoes_VagaId" ON public."PreAdmissoes" USING btree ("VagaId") WHERE ("VagaId" IS NOT NULL);


--
-- Name: IX_ProjetoCandidatos_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetoCandidatos_CandidatoId" ON public."ProjetoCandidatos" USING btree ("CandidatoId");


--
-- Name: IX_ProjetoCandidatos_FaseAtualId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetoCandidatos_FaseAtualId" ON public."ProjetoCandidatos" USING btree ("FaseAtualId");


--
-- Name: IX_ProjetoCandidatos_ProjetoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetoCandidatos_ProjetoId" ON public."ProjetoCandidatos" USING btree ("ProjetoId");


--
-- Name: IX_ProjetoCandidatos_TenantId_ProjetoId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ProjetoCandidatos_TenantId_ProjetoId_CandidatoId" ON public."ProjetoCandidatos" USING btree ("TenantId", "ProjetoId", "CandidatoId");


--
-- Name: IX_ProjetosVaga_TenantId_VagaId_Numero; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_ProjetosVaga_TenantId_VagaId_Numero" ON public."ProjetosVaga" USING btree ("TenantId", "VagaId", "Numero");


--
-- Name: IX_ProjetosVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_ProjetosVaga_VagaId" ON public."ProjetosVaga" USING btree ("VagaId");


--
-- Name: IX_PropostasVaga_AccessToken; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_PropostasVaga_AccessToken" ON public."PropostasVaga" USING btree ("AccessToken");


--
-- Name: IX_PropostasVaga_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_CandidatoId" ON public."PropostasVaga" USING btree ("CandidatoId");


--
-- Name: IX_PropostasVaga_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_CandidaturaId" ON public."PropostasVaga" USING btree ("CandidaturaId");


--
-- Name: IX_PropostasVaga_TenantId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_TenantId_CandidatoId" ON public."PropostasVaga" USING btree ("TenantId", "CandidatoId");


--
-- Name: IX_PropostasVaga_TenantId_CandidaturaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_TenantId_CandidaturaId" ON public."PropostasVaga" USING btree ("TenantId", "CandidaturaId");


--
-- Name: IX_PropostasVaga_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_TenantId_VagaId" ON public."PropostasVaga" USING btree ("TenantId", "VagaId");


--
-- Name: IX_PropostasVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_PropostasVaga_VagaId" ON public."PropostasVaga" USING btree ("VagaId");


--
-- Name: IX_RecruiterMatchingFeedbacks_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RecruiterMatchingFeedbacks_TenantId_VagaId" ON public."RecruiterMatchingFeedbacks" USING btree ("TenantId", "VagaId");


--
-- Name: IX_RecruiterMatchingFeedbacks_VagaId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RecruiterMatchingFeedbacks_VagaId_CandidatoId" ON public."RecruiterMatchingFeedbacks" USING btree ("VagaId", "CandidatoId");


--
-- Name: IX_RenderCoinBalances_TenantId_Balance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinBalances_TenantId_Balance" ON public."RenderCoinBalances" USING btree ("TenantId", "Balance");


--
-- Name: IX_RenderCoinBalances_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinBalances_UserId" ON public."RenderCoinBalances" USING btree ("UserId");


--
-- Name: IX_RenderCoinTransactions_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinTransactions_TenantId_CreatedAtUtc" ON public."RenderCoinTransactions" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_RenderCoinTransactions_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinTransactions_TenantId_UserId" ON public."RenderCoinTransactions" USING btree ("TenantId", "UserId");


--
-- Name: IX_RenderCoinTransactions_TenantId_UserId_SourceType_SourceId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RenderCoinTransactions_TenantId_UserId_SourceType_SourceId" ON public."RenderCoinTransactions" USING btree ("TenantId", "UserId", "SourceType", "SourceId");


--
-- Name: IX_RenderCoinTransactions_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RenderCoinTransactions_UserId" ON public."RenderCoinTransactions" USING btree ("UserId");


--
-- Name: IX_RequestLogs_TenantId_DeviceId_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_DeviceId_StartedAt" ON public."RequestLogs" USING btree ("TenantId", "DeviceId", "StartedAt");


--
-- Name: IX_RequestLogs_TenantId_EnvironmentNormalized_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_EnvironmentNormalized_StartedAt" ON public."RequestLogs" USING btree ("TenantId", "EnvironmentNormalized", "StartedAt");


--
-- Name: IX_RequestLogs_TenantId_Path; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_Path" ON public."RequestLogs" USING btree ("TenantId", "Path");


--
-- Name: IX_RequestLogs_TenantId_StartedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_StartedAt" ON public."RequestLogs" USING btree ("TenantId", "StartedAt");


--
-- Name: IX_RequestLogs_TenantId_StatusCode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_StatusCode" ON public."RequestLogs" USING btree ("TenantId", "StatusCode");


--
-- Name: IX_RequestLogs_TenantId_TransactionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_TransactionId" ON public."RequestLogs" USING btree ("TenantId", "TransactionId");


--
-- Name: IX_RequestLogs_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RequestLogs_TenantId_UserId" ON public."RequestLogs" USING btree ("TenantId", "UserId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_CampoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_CampoId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("CampoId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_CandidatoId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("CandidatoId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_TenantId_VagaId_CandidatoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_TenantId_VagaId_CandidatoId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("TenantId", "VagaId", "CandidatoId");


--
-- Name: IX_RespostasCampoPersonalizadoVaga_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasCampoPersonalizadoVaga_VagaId" ON public."RespostasCampoPersonalizadoVaga" USING btree ("VagaId");


--
-- Name: IX_RespostasEntrevistaSaida_EntrevistaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasEntrevistaSaida_EntrevistaId" ON public."RespostasEntrevistaSaida" USING btree ("EntrevistaId");


--
-- Name: IX_RespostasEntrevistaSaida_PerguntaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasEntrevistaSaida_PerguntaId" ON public."RespostasEntrevistaSaida" USING btree ("PerguntaId");


--
-- Name: IX_RespostasEntrevistaSaida_TenantId_EntrevistaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RespostasEntrevistaSaida_TenantId_EntrevistaId" ON public."RespostasEntrevistaSaida" USING btree ("TenantId", "EntrevistaId");


--
-- Name: IX_RmSyncAlertas_TenantId_ResolvidoEmUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RmSyncAlertas_TenantId_ResolvidoEmUtc" ON public."RmSyncAlertas" USING btree ("TenantId", "ResolvidoEmUtc");


--
-- Name: IX_RmSyncAlertas_TenantId_Tipo_ChaveRm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RmSyncAlertas_TenantId_Tipo_ChaveRm" ON public."RmSyncAlertas" USING btree ("TenantId", "Tipo", "ChaveRm");


--
-- Name: IX_RmSyncCheckpoints_TenantId_Entidade; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RmSyncCheckpoints_TenantId_Entidade" ON public."RmSyncCheckpoints" USING btree ("TenantId", "Entidade");


--
-- Name: IX_RmSyncRuns_TenantId_Entidade_StartedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RmSyncRuns_TenantId_Entidade_StartedAtUtc" ON public."RmSyncRuns" USING btree ("TenantId", "Entidade", "StartedAtUtc" DESC);


--
-- Name: IX_RmSyncRuns_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RmSyncRuns_TenantId_Status" ON public."RmSyncRuns" USING btree ("TenantId", "Status");


--
-- Name: IX_RoleMenus_MenuId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RoleMenus_MenuId" ON public."RoleMenus" USING btree ("MenuId");


--
-- Name: IX_RoleMenus_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_RoleMenus_RoleId" ON public."RoleMenus" USING btree ("RoleId");


--
-- Name: IX_RoleMenus_TenantId_RoleId_MenuId_PermissionKey; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_RoleMenus_TenantId_RoleId_MenuId_PermissionKey" ON public."RoleMenus" USING btree ("TenantId", "RoleId", "MenuId", "PermissionKey");


--
-- Name: IX_Roles_TenantId_NormalizedName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Roles_TenantId_NormalizedName" ON public."Roles" USING btree ("TenantId", "NormalizedName");


--
-- Name: IX_SkillAliases_SkillId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SkillAliases_SkillId" ON public."SkillAliases" USING btree ("SkillId");


--
-- Name: IX_SkillAliases_TenantId_AliasName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_SkillAliases_TenantId_AliasName" ON public."SkillAliases" USING btree ("TenantId", "AliasName");


--
-- Name: IX_Skills_ParentSkillId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Skills_ParentSkillId" ON public."Skills" USING btree ("ParentSkillId");


--
-- Name: IX_Skills_TenantId_CanonicalName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Skills_TenantId_CanonicalName" ON public."Skills" USING btree ("TenantId", "CanonicalName");


--
-- Name: IX_SlaStatusConfigs_TenantId_TipoEntidade_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_SlaStatusConfigs_TenantId_TipoEntidade_Status" ON public."SlaStatusConfigs" USING btree ("TenantId", "TipoEntidade", "Status");


--
-- Name: IX_SolicitacoesAprovacaoEtapas_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_AprovadorId" ON public."SolicitacoesAprovacaoEtapas" USING btree ("AprovadorId");


--
-- Name: IX_SolicitacoesAprovacaoEtapas_FilaPendente; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_FilaPendente" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "RoleFilaId", "Status") WHERE ("RoleFilaId" IS NOT NULL);


--
-- Name: IX_SolicitacoesAprovacaoEtapas_Solicitacao; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_Solicitacao" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "SolicitacaoId", "TipoFluxo");


--
-- Name: IX_SolicitacoesAprovacaoEtapas_TenantId_RoleFilaId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_TenantId_RoleFilaId_Status" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "RoleFilaId", "Status") WHERE ("RoleFilaId" IS NOT NULL);


--
-- Name: IX_SolicitacoesAprovacaoEtapas_TenantId_SolicitacaoId_TipoFluxo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesAprovacaoEtapas_TenantId_SolicitacaoId_TipoFluxo" ON public."SolicitacoesAprovacaoEtapas" USING btree ("TenantId", "SolicitacaoId", "TipoFluxo");


--
-- Name: IX_SolicitacoesBeneficio_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesBeneficio_SolicitanteId" ON public."SolicitacoesBeneficio" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesDependente_DependenteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDependente_DependenteId" ON public."SolicitacoesDependente" USING btree ("DependenteId");


--
-- Name: IX_SolicitacoesDependente_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDependente_SolicitanteId" ON public."SolicitacoesDependente" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesDesligamento_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_EmpresaId" ON public."SolicitacoesDesligamento" USING btree ("EmpresaId");


--
-- Name: IX_SolicitacoesDesligamento_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_FuncionarioId" ON public."SolicitacoesDesligamento" USING btree ("FuncionarioId");


--
-- Name: IX_SolicitacoesDesligamento_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_SolicitanteId" ON public."SolicitacoesDesligamento" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesDesligamento_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesDesligamento_UnitId" ON public."SolicitacoesDesligamento" USING btree ("UnitId");


--
-- Name: IX_SolicitacoesEndereco_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesEndereco_SolicitanteId" ON public."SolicitacoesEndereco" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesFerias_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesFerias_SolicitanteId" ON public."SolicitacoesFerias" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesPagamentoExtra_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPagamentoExtra_FuncionarioId" ON public."SolicitacoesPagamentoExtra" USING btree ("FuncionarioId");


--
-- Name: IX_SolicitacoesPagamentoExtra_ImportadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPagamentoExtra_ImportadoPorId" ON public."SolicitacoesPagamentoExtra" USING btree ("ImportadoPorId");


--
-- Name: IX_SolicitacoesPagamentoExtra_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPagamentoExtra_SolicitanteId" ON public."SolicitacoesPagamentoExtra" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesPromocao_CargoAtualId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_CargoAtualId" ON public."SolicitacoesPromocao" USING btree ("CargoAtualId");


--
-- Name: IX_SolicitacoesPromocao_CentroCustoAtualId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_CentroCustoAtualId" ON public."SolicitacoesPromocao" USING btree ("CentroCustoAtualId");


--
-- Name: IX_SolicitacoesPromocao_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_FuncionarioId" ON public."SolicitacoesPromocao" USING btree ("FuncionarioId");


--
-- Name: IX_SolicitacoesPromocao_NovaUnidadeId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_NovaUnidadeId" ON public."SolicitacoesPromocao" USING btree ("NovaUnidadeId");


--
-- Name: IX_SolicitacoesPromocao_NovoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_NovoCargoId" ON public."SolicitacoesPromocao" USING btree ("NovoCargoId");


--
-- Name: IX_SolicitacoesPromocao_NovoCentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_NovoCentroCustoId" ON public."SolicitacoesPromocao" USING btree ("NovoCentroCustoId");


--
-- Name: IX_SolicitacoesPromocao_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_SolicitanteId" ON public."SolicitacoesPromocao" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesPromocao_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesPromocao_UnitId" ON public."SolicitacoesPromocao" USING btree ("UnitId");


--
-- Name: IX_SolicitacoesVaga_AprovadorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_AprovadorId" ON public."SolicitacoesVaga" USING btree ("AprovadorId");


--
-- Name: IX_SolicitacoesVaga_CandidatoContratadoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_CandidatoContratadoId" ON public."SolicitacoesVaga" USING btree ("CandidatoContratadoId");


--
-- Name: IX_SolicitacoesVaga_DecisaoRHRevisadoPorId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_DecisaoRHRevisadoPorId" ON public."SolicitacoesVaga" USING btree ("DecisaoRHRevisadoPorId");


--
-- Name: IX_SolicitacoesVaga_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_JobPositionId" ON public."SolicitacoesVaga" USING btree ("JobPositionId");


--
-- Name: IX_SolicitacoesVaga_MotivoRequisicaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_MotivoRequisicaoId" ON public."SolicitacoesVaga" USING btree ("MotivoRequisicaoId");


--
-- Name: IX_SolicitacoesVaga_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_SolicitanteId" ON public."SolicitacoesVaga" USING btree ("SolicitanteId");


--
-- Name: IX_SolicitacoesVaga_SubstituidoFuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_SubstituidoFuncionarioId" ON public."SolicitacoesVaga" USING btree ("SubstituidoFuncionarioId");


--
-- Name: IX_SolicitacoesVaga_TenantId_SolicitanteId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_TenantId_SolicitanteId" ON public."SolicitacoesVaga" USING btree ("TenantId", "SolicitanteId");


--
-- Name: IX_SolicitacoesVaga_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_TenantId_Status" ON public."SolicitacoesVaga" USING btree ("TenantId", "Status");


--
-- Name: IX_SolicitacoesVaga_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SolicitacoesVaga_UnitId" ON public."SolicitacoesVaga" USING btree ("UnitId");


--
-- Name: IX_SurveyAnswers_ResponseId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyAnswers_ResponseId" ON public."SurveyAnswers" USING btree ("ResponseId");


--
-- Name: IX_SurveyAnswers_TenantId_ResponseId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyAnswers_TenantId_ResponseId" ON public."SurveyAnswers" USING btree ("TenantId", "ResponseId");


--
-- Name: IX_SurveyOptions_QuestionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyOptions_QuestionId" ON public."SurveyOptions" USING btree ("QuestionId");


--
-- Name: IX_SurveyOptions_TenantId_QuestionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyOptions_TenantId_QuestionId" ON public."SurveyOptions" USING btree ("TenantId", "QuestionId");


--
-- Name: IX_SurveyQuestions_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyQuestions_SurveyId" ON public."SurveyQuestions" USING btree ("SurveyId");


--
-- Name: IX_SurveyQuestions_TenantId_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyQuestions_TenantId_SurveyId" ON public."SurveyQuestions" USING btree ("TenantId", "SurveyId");


--
-- Name: IX_SurveyResponses_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyResponses_SurveyId" ON public."SurveyResponses" USING btree ("SurveyId");


--
-- Name: IX_SurveyResponses_TenantId_SurveyId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyResponses_TenantId_SurveyId" ON public."SurveyResponses" USING btree ("TenantId", "SurveyId");


--
-- Name: IX_SurveyResponses_TenantId_SurveyId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_SurveyResponses_TenantId_SurveyId_UserId" ON public."SurveyResponses" USING btree ("TenantId", "SurveyId", "UserId");


--
-- Name: IX_SurveyResponses_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_SurveyResponses_TenantId_UserId" ON public."SurveyResponses" USING btree ("TenantId", "UserId");


--
-- Name: IX_Surveys_TenantId_CreatedAtUtc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Surveys_TenantId_CreatedAtUtc" ON public."Surveys" USING btree ("TenantId", "CreatedAtUtc");


--
-- Name: IX_TalentoCompetencias_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCompetencias_TalentoId" ON public."TalentoCompetencias" USING btree ("TalentoId");


--
-- Name: IX_TalentoCompetencias_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCompetencias_TenantId_TalentoId" ON public."TalentoCompetencias" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoCvImportJobs_TalentoDocumentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TalentoDocumentoId" ON public."TalentoCvImportJobs" USING btree ("TalentoDocumentoId");


--
-- Name: IX_TalentoCvImportJobs_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TalentoId" ON public."TalentoCvImportJobs" USING btree ("TalentoId");


--
-- Name: IX_TalentoCvImportJobs_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TenantId_Status" ON public."TalentoCvImportJobs" USING btree ("TenantId", "Status");


--
-- Name: IX_TalentoCvImportJobs_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoCvImportJobs_TenantId_TalentoId" ON public."TalentoCvImportJobs" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoDocumentos_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoDocumentos_TalentoId" ON public."TalentoDocumentos" USING btree ("TalentoId");


--
-- Name: IX_TalentoDocumentos_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoDocumentos_TenantId_TalentoId" ON public."TalentoDocumentos" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoExperiencias_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoExperiencias_TalentoId" ON public."TalentoExperiencias" USING btree ("TalentoId");


--
-- Name: IX_TalentoExperiencias_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoExperiencias_TenantId_TalentoId" ON public."TalentoExperiencias" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoFormacoes_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoFormacoes_TalentoId" ON public."TalentoFormacoes" USING btree ("TalentoId");


--
-- Name: IX_TalentoFormacoes_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoFormacoes_TenantId_TalentoId" ON public."TalentoFormacoes" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_TalentoTreinamentos_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoTreinamentos_TalentoId" ON public."TalentoTreinamentos" USING btree ("TalentoId");


--
-- Name: IX_TalentoTreinamentos_TenantId_TalentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TalentoTreinamentos_TenantId_TalentoId" ON public."TalentoTreinamentos" USING btree ("TenantId", "TalentoId");


--
-- Name: IX_Talentos_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Talentos_PessoaId" ON public."Talentos" USING btree ("PessoaId");


--
-- Name: IX_Talentos_TenantId_PessoaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Talentos_TenantId_PessoaId" ON public."Talentos" USING btree ("TenantId", "PessoaId");


--
-- Name: IX_TemplatesEntrevistaSaida_TenantId_Ativo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TemplatesEntrevistaSaida_TenantId_Ativo" ON public."TemplatesEntrevistaSaida" USING btree ("TenantId", "Ativo");


--
-- Name: IX_TenantBrandings_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantBrandings_TenantId" ON public."TenantBrandings" USING btree ("TenantId");


--
-- Name: IX_TenantConfiguracoes_AprovadorRhId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_TenantConfiguracoes_AprovadorRhId" ON public."TenantConfiguracoes" USING btree ("AprovadorRhId");


--
-- Name: IX_TenantConfiguracoes_TenantId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_TenantConfiguracoes_TenantId" ON public."TenantConfiguracoes" USING btree ("TenantId");


--
-- Name: IX_Turnos_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Turnos_IsActive" ON public."Turnos" USING btree ("IsActive");


--
-- Name: IX_Turnos_TenantId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Turnos_TenantId_Code" ON public."Turnos" USING btree ("TenantId", "Code");


--
-- Name: IX_Turnos_UnidadeLotacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Turnos_UnidadeLotacaoId" ON public."Turnos" USING btree ("UnidadeLotacaoId");


--
-- Name: IX_UnidadesLotacao_IsActive; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UnidadesLotacao_IsActive" ON public."UnidadesLotacao" USING btree ("IsActive");


--
-- Name: IX_UnidadesLotacao_OwnerFuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UnidadesLotacao_OwnerFuncionarioId" ON public."UnidadesLotacao" USING btree ("OwnerFuncionarioId");


--
-- Name: IX_UnidadesLotacao_ParentId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UnidadesLotacao_ParentId" ON public."UnidadesLotacao" USING btree ("ParentId");


--
-- Name: IX_UnidadesLotacao_TenantId_CdnPlanoLotac_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_UnidadesLotacao_TenantId_CdnPlanoLotac_Code" ON public."UnidadesLotacao" USING btree ("TenantId", "CdnPlanoLotac", "Code");


--
-- Name: IX_Units_EmpresaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Units_EmpresaId" ON public."Units" USING btree ("EmpresaId");


--
-- Name: IX_Units_TenantId_EmpresaId_Code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Units_TenantId_EmpresaId_Code" ON public."Units" USING btree ("TenantId", "EmpresaId", "Code") WHERE ("EmpresaId" IS NOT NULL);


--
-- Name: IX_UserRoles_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserRoles_RoleId" ON public."UserRoles" USING btree ("RoleId");


--
-- Name: IX_UserRoles_TenantId_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserRoles_TenantId_RoleId" ON public."UserRoles" USING btree ("TenantId", "RoleId");


--
-- Name: IX_UserRoles_TenantId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserRoles_TenantId_UserId" ON public."UserRoles" USING btree ("TenantId", "UserId");


--
-- Name: IX_UserUnits_UnitId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_UserUnits_UnitId" ON public."UserUnits" USING btree ("UnitId");


--
-- Name: IX_Users_FuncionarioId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Users_FuncionarioId" ON public."Users" USING btree ("FuncionarioId");


--
-- Name: IX_Users_TenantId_NormalizedEmail; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Users_TenantId_NormalizedEmail" ON public."Users" USING btree ("TenantId", "NormalizedEmail");


--
-- Name: IX_Users_TenantId_NormalizedUserName; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_Users_TenantId_NormalizedUserName" ON public."Users" USING btree ("TenantId", "NormalizedUserName");


--
-- Name: IX_VagaBeneficios_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaBeneficios_TenantId_VagaId" ON public."VagaBeneficios" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaBeneficios_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaBeneficios_VagaId" ON public."VagaBeneficios" USING btree ("VagaId");


--
-- Name: IX_VagaEtapas_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaEtapas_TenantId_VagaId" ON public."VagaEtapas" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaEtapas_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaEtapas_VagaId" ON public."VagaEtapas" USING btree ("VagaId");


--
-- Name: IX_VagaPerguntas_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaPerguntas_TenantId_VagaId" ON public."VagaPerguntas" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaPerguntas_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaPerguntas_VagaId" ON public."VagaPerguntas" USING btree ("VagaId");


--
-- Name: IX_VagaRequisitos_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaRequisitos_TenantId_VagaId" ON public."VagaRequisitos" USING btree ("TenantId", "VagaId");


--
-- Name: IX_VagaRequisitos_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaRequisitos_VagaId" ON public."VagaRequisitos" USING btree ("VagaId");


--
-- Name: IX_VagaUnifiedMatchingCaches_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_VagaUnifiedMatchingCaches_TenantId_Status" ON public."VagaUnifiedMatchingCaches" USING btree ("TenantId", "Status");


--
-- Name: IX_VagaUnifiedMatchingCaches_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_VagaUnifiedMatchingCaches_TenantId_VagaId" ON public."VagaUnifiedMatchingCaches" USING btree ("TenantId", "VagaId");


--
-- Name: IX_Vagas_CategoriaSalarialId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_CategoriaSalarialId" ON public."Vagas" USING btree ("CategoriaSalarialId");


--
-- Name: IX_Vagas_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_CentroCustoId" ON public."Vagas" USING btree ("CentroCustoId");


--
-- Name: IX_Vagas_DescricaoCargoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_DescricaoCargoId" ON public."Vagas" USING btree ("DescricaoCargoId");


--
-- Name: IX_Vagas_EixoVagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_EixoVagaId" ON public."Vagas" USING btree ("EixoVagaId");


--
-- Name: IX_Vagas_HierarquiaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_HierarquiaId" ON public."Vagas" USING btree ("HierarquiaId");


--
-- Name: IX_Vagas_IdReqRmOrigem; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_IdReqRmOrigem" ON public."Vagas" USING btree ("IdReqRmOrigem");


--
-- Name: IX_Vagas_JobPositionId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_JobPositionId" ON public."Vagas" USING btree ("JobPositionId");


--
-- Name: IX_Vagas_OrigemDesligamentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_OrigemDesligamentoId" ON public."Vagas" USING btree ("OrigemDesligamentoId");


--
-- Name: IX_Vagas_OrigemTipo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_OrigemTipo" ON public."Vagas" USING btree ("OrigemTipo");


--
-- Name: IX_Vagas_RecrutadorResponsavelUserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_RecrutadorResponsavelUserId" ON public."Vagas" USING btree ("RecrutadorResponsavelUserId");


--
-- Name: IX_Vagas_TenantId_CentroCustoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_TenantId_CentroCustoId" ON public."Vagas" USING btree ("TenantId", "CentroCustoId");


--
-- Name: IX_Vagas_TenantId_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_TenantId_Status" ON public."Vagas" USING btree ("TenantId", "Status");


--
-- Name: IX_Vagas_TurnoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_TurnoId" ON public."Vagas" USING btree ("TurnoId");


--
-- Name: IX_Vagas_UnidadeLotacaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_Vagas_UnidadeLotacaoId" ON public."Vagas" USING btree ("UnidadeLotacaoId");


--
-- Name: IX_WorkflowsRH_DesligamentoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_DesligamentoId" ON public."WorkflowsRH" USING btree ("DesligamentoId");


--
-- Name: IX_WorkflowsRH_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_PreAdmissaoId" ON public."WorkflowsRH" USING btree ("PreAdmissaoId");


--
-- Name: IX_WorkflowsRH_ResponsavelId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_ResponsavelId" ON public."WorkflowsRH" USING btree ("ResponsavelId");


--
-- Name: IX_WorkflowsRH_TenantId_PreAdmissaoId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_TenantId_PreAdmissaoId" ON public."WorkflowsRH" USING btree ("TenantId", "PreAdmissaoId") WHERE ("PreAdmissaoId" IS NOT NULL);


--
-- Name: IX_WorkflowsRH_TenantId_TipoWorkflow_Status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_TenantId_TipoWorkflow_Status" ON public."WorkflowsRH" USING btree ("TenantId", "TipoWorkflow", "Status");


--
-- Name: IX_WorkflowsRH_TenantId_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_TenantId_VagaId" ON public."WorkflowsRH" USING btree ("TenantId", "VagaId") WHERE ("VagaId" IS NOT NULL);


--
-- Name: IX_WorkflowsRH_VagaId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_WorkflowsRH_VagaId" ON public."WorkflowsRH" USING btree ("VagaId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RoleNameIndex" ON public."Roles" USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "UserNameIndex" ON public."Users" USING btree ("NormalizedUserName");


--
-- Name: idx_candidatos_embedding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_candidatos_embedding ON public."Candidatos" USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_vagas_embedding; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vagas_embedding ON public."Vagas" USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: AgendaEvents FK_AgendaEvents_AgendaEventTypes_TypeId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AgendaEvents"
    ADD CONSTRAINT "FK_AgendaEvents_AgendaEventTypes_TypeId" FOREIGN KEY ("TypeId") REFERENCES public."AgendaEventTypes"("Id") ON DELETE RESTRICT;


--
-- Name: AprovacoesFaixaSalarial FK_AprovacoesFaixaSalarial_FaixasSalariais_FaixaSalarialId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "FK_AprovacoesFaixaSalarial_FaixasSalariais_FaixaSalarialId" FOREIGN KEY ("FaixaSalarialId") REFERENCES public."FaixasSalariais"("Id") ON DELETE CASCADE;


--
-- Name: AprovacoesFaixaSalarial FK_AprovacoesFaixaSalarial_Funcionarios_AprovadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "FK_AprovacoesFaixaSalarial_Funcionarios_AprovadorId" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: AprovacoesFaixaSalarial FK_AprovacoesFaixaSalarial_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovacoesFaixaSalarial"
    ADD CONSTRAINT "FK_AprovacoesFaixaSalarial_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: AprovadoresAlternativos FK_AprovadoresAlternativos_Aprovador; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovadoresAlternativos"
    ADD CONSTRAINT "FK_AprovadoresAlternativos_Aprovador" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: AprovadoresAlternativos FK_AprovadoresAlternativos_Gestor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AprovadoresAlternativos"
    ADD CONSTRAINT "FK_AprovadoresAlternativos_Gestor" FOREIGN KEY ("GestorId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: AspNetRoleClaims FK_AspNetRoleClaims_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "FK_AspNetRoleClaims_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserClaims FK_AspNetUserClaims_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "FK_AspNetUserClaims_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserLogins FK_AspNetUserLogins_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "FK_AspNetUserLogins_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserTokens FK_AspNetUserTokens_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "FK_AspNetUserTokens_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: AuditEntityChanges FK_AuditEntityChanges_AuditEvents_AuditEventId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityChanges"
    ADD CONSTRAINT "FK_AuditEntityChanges_AuditEvents_AuditEventId" FOREIGN KEY ("AuditEventId") REFERENCES public."AuditEvents"("Id") ON DELETE SET NULL;


--
-- Name: AuditEntityChanges FK_AuditEntityChanges_AuditTransactions_AuditTransactionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityChanges"
    ADD CONSTRAINT "FK_AuditEntityChanges_AuditTransactions_AuditTransactionId" FOREIGN KEY ("AuditTransactionId") REFERENCES public."AuditTransactions"("Id") ON DELETE CASCADE;


--
-- Name: AuditEntityPropertyChanges FK_AuditEntityPropertyChanges_AuditEntityChanges_AuditEntityCha; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEntityPropertyChanges"
    ADD CONSTRAINT "FK_AuditEntityPropertyChanges_AuditEntityChanges_AuditEntityCha" FOREIGN KEY ("AuditEntityChangeId") REFERENCES public."AuditEntityChanges"("Id") ON DELETE CASCADE;


--
-- Name: AuditEvents FK_AuditEvents_AuditTransactions_AuditTransactionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditEvents"
    ADD CONSTRAINT "FK_AuditEvents_AuditTransactions_AuditTransactionId" FOREIGN KEY ("AuditTransactionId") REFERENCES public."AuditTransactions"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoCalibragens FK_AvaliacaoCalibragens_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "FK_AvaliacaoCalibragens_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoCalibragens FK_AvaliacaoCalibragens_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "FK_AvaliacaoCalibragens_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoCalibragens FK_AvaliacaoCalibragens_NineBoxAssessments_NineBoxAssessmentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCalibragens"
    ADD CONSTRAINT "FK_AvaliacaoCalibragens_NineBoxAssessments_NineBoxAssessmentId" FOREIGN KEY ("NineBoxAssessmentId") REFERENCES public."NineBoxAssessments"("Id") ON DELETE SET NULL;


--
-- Name: AvaliacaoCiclos FK_AvaliacaoCiclos_Funcionarios_CriadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoCiclos"
    ADD CONSTRAINT "FK_AvaliacaoCiclos_Funcionarios_CriadoPorId" FOREIGN KEY ("CriadoPorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoConvites FK_AvaliacaoConvites_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "FK_AvaliacaoConvites_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoConvites FK_AvaliacaoConvites_Funcionarios_AvaliadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "FK_AvaliacaoConvites_Funcionarios_AvaliadorId" FOREIGN KEY ("AvaliadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoConvites FK_AvaliacaoConvites_Funcionarios_AvaliandoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoConvites"
    ADD CONSTRAINT "FK_AvaliacaoConvites_Funcionarios_AvaliandoId" FOREIGN KEY ("AvaliandoId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoPerguntas FK_AvaliacaoPerguntas_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoPerguntas"
    ADD CONSTRAINT "FK_AvaliacaoPerguntas_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoRespostas FK_AvaliacaoRespostas_AvaliacaoCiclos_CicloId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "FK_AvaliacaoRespostas_AvaliacaoCiclos_CicloId" FOREIGN KEY ("CicloId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE CASCADE;


--
-- Name: AvaliacaoRespostas FK_AvaliacaoRespostas_Funcionarios_AvaliadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "FK_AvaliacaoRespostas_Funcionarios_AvaliadorId" FOREIGN KEY ("AvaliadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: AvaliacaoRespostas FK_AvaliacaoRespostas_Funcionarios_AvaliandoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AvaliacaoRespostas"
    ADD CONSTRAINT "FK_AvaliacaoRespostas_Funcionarios_AvaliandoId" FOREIGN KEY ("AvaliandoId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: BatchMatchingRunVagas FK_BatchMatchingRunVagas_BatchMatchingRuns_RunId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BatchMatchingRunVagas"
    ADD CONSTRAINT "FK_BatchMatchingRunVagas_BatchMatchingRuns_RunId" FOREIGN KEY ("RunId") REFERENCES public."BatchMatchingRuns"("Id") ON DELETE CASCADE;


--
-- Name: CamposPersonalizadosVaga FK_CamposPersonalizadosVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CamposPersonalizadosVaga"
    ADD CONSTRAINT "FK_CamposPersonalizadosVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoAcessibilidades FK_CandidatoAcessibilidades_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAcessibilidades"
    ADD CONSTRAINT "FK_CandidatoAcessibilidades_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoAgendaBloqueios FK_CandidatoAgendaBloqueios_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaBloqueios"
    ADD CONSTRAINT "FK_CandidatoAgendaBloqueios_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoAgendaPreferencias FK_CandidatoAgendaPreferencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoAgendaPreferencias"
    ADD CONSTRAINT "FK_CandidatoAgendaPreferencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoCertificacoes FK_CandidatoCertificacoes_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCertificacoes"
    ADD CONSTRAINT "FK_CandidatoCertificacoes_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoCompetencias FK_CandidatoCompetencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoCompetencias"
    ADD CONSTRAINT "FK_CandidatoCompetencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoDocumentos FK_CandidatoDocumentos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoDocumentos"
    ADD CONSTRAINT "FK_CandidatoDocumentos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoEducacaoItens FK_CandidatoEducacaoItens_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoItens"
    ADD CONSTRAINT "FK_CandidatoEducacaoItens_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoEducacaoResumos FK_CandidatoEducacaoResumos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEducacaoResumos"
    ADD CONSTRAINT "FK_CandidatoEducacaoResumos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoEmbeddings FK_CandidatoEmbeddings_Candidato; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoEmbeddings"
    ADD CONSTRAINT "FK_CandidatoEmbeddings_Candidato" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoExperiencias FK_CandidatoExperiencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoExperiencias"
    ADD CONSTRAINT "FK_CandidatoExperiencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoLgpdConsents FK_CandidatoLgpdConsents_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoLgpdConsents"
    ADD CONSTRAINT "FK_CandidatoLgpdConsents_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoNotificacaoPreferencias FK_CandidatoNotificacaoPreferencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoNotificacaoPreferencias"
    ADD CONSTRAINT "FK_CandidatoNotificacaoPreferencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoPortfolios FK_CandidatoPortfolios_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPortfolios"
    ADD CONSTRAINT "FK_CandidatoPortfolios_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoPreferenciasVaga FK_CandidatoPreferenciasVaga_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoPreferenciasVaga"
    ADD CONSTRAINT "FK_CandidatoPreferenciasVaga_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoProjetos FK_CandidatoProjetos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoProjetos"
    ADD CONSTRAINT "FK_CandidatoProjetos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoReferencias FK_CandidatoReferencias_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoReferencias"
    ADD CONSTRAINT "FK_CandidatoReferencias_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoStatusHistories FK_CandidatoStatusHistories_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoStatusHistories"
    ADD CONSTRAINT "FK_CandidatoStatusHistories_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaLlmScores FK_CandidatoVagaLlmScores_Candidato; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaLlmScores"
    ADD CONSTRAINT "FK_CandidatoVagaLlmScores_Candidato" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaLlmScores FK_CandidatoVagaLlmScores_Vaga; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaLlmScores"
    ADD CONSTRAINT "FK_CandidatoVagaLlmScores_Vaga" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaMatchingScores FK_CandidatoVagaMatchingScores_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaMatchingScores"
    ADD CONSTRAINT "FK_CandidatoVagaMatchingScores_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: CandidatoVagaMatchingScores FK_CandidatoVagaMatchingScores_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidatoVagaMatchingScores"
    ADD CONSTRAINT "FK_CandidatoVagaMatchingScores_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: Candidatos FK_Candidatos_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidatos"
    ADD CONSTRAINT "FK_Candidatos_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE SET NULL;


--
-- Name: Candidatos FK_Candidatos_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidatos"
    ADD CONSTRAINT "FK_Candidatos_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE RESTRICT;


--
-- Name: CandidaturaEtapaHistoricos FK_CandidaturaEtapaHistoricos_Candidaturas_CandidaturaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CandidaturaEtapaHistoricos"
    ADD CONSTRAINT "FK_CandidaturaEtapaHistoricos_Candidaturas_CandidaturaId" FOREIGN KEY ("CandidaturaId") REFERENCES public."Candidaturas"("Id") ON DELETE CASCADE;


--
-- Name: Candidaturas FK_Candidaturas_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidaturas"
    ADD CONSTRAINT "FK_Candidaturas_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: Candidaturas FK_Candidaturas_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Candidaturas"
    ADD CONSTRAINT "FK_Candidaturas_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE RESTRICT;


--
-- Name: CategoriaSalarialSteps FK_CategoriaSalarialSteps_CategoriasSalariais_CategoriaSalaria~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriaSalarialSteps"
    ADD CONSTRAINT "FK_CategoriaSalarialSteps_CategoriasSalariais_CategoriaSalaria~" FOREIGN KEY ("CategoriaSalarialId") REFERENCES public."CategoriasSalariais"("Id") ON DELETE CASCADE;


--
-- Name: CategoriasSalariais FK_CategoriasSalariais_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriasSalariais"
    ADD CONSTRAINT "FK_CategoriasSalariais_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: CategoriasSalariais FK_CategoriasSalariais_Units_EstabelecimentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CategoriasSalariais"
    ADD CONSTRAINT "FK_CategoriasSalariais_Units_EstabelecimentoId" FOREIGN KEY ("EstabelecimentoId") REFERENCES public."Units"("Id") ON DELETE SET NULL;


--
-- Name: CelebrationCommentMentions FK_CelebrationCommentMentions_CelebrationComments_CommentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentMentions"
    ADD CONSTRAINT "FK_CelebrationCommentMentions_CelebrationComments_CommentId" FOREIGN KEY ("CommentId") REFERENCES public."CelebrationComments"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationCommentMentions FK_CelebrationCommentMentions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentMentions"
    ADD CONSTRAINT "FK_CelebrationCommentMentions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationCommentReactions FK_CelebrationCommentReactions_CelebrationComments_CommentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentReactions"
    ADD CONSTRAINT "FK_CelebrationCommentReactions_CelebrationComments_CommentId" FOREIGN KEY ("CommentId") REFERENCES public."CelebrationComments"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationCommentReactions FK_CelebrationCommentReactions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationCommentReactions"
    ADD CONSTRAINT "FK_CelebrationCommentReactions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationComments FK_CelebrationComments_CelebrationPosts_PostId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationComments"
    ADD CONSTRAINT "FK_CelebrationComments_CelebrationPosts_PostId" FOREIGN KEY ("PostId") REFERENCES public."CelebrationPosts"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationComments FK_CelebrationComments_Users_AuthorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationComments"
    ADD CONSTRAINT "FK_CelebrationComments_Users_AuthorId" FOREIGN KEY ("AuthorId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationMentions FK_CelebrationMentions_CelebrationPosts_PostId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationMentions"
    ADD CONSTRAINT "FK_CelebrationMentions_CelebrationPosts_PostId" FOREIGN KEY ("PostId") REFERENCES public."CelebrationPosts"("Id") ON DELETE CASCADE;


--
-- Name: CelebrationMentions FK_CelebrationMentions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationMentions"
    ADD CONSTRAINT "FK_CelebrationMentions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CelebrationPosts FK_CelebrationPosts_Users_AuthorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CelebrationPosts"
    ADD CONSTRAINT "FK_CelebrationPosts_Users_AuthorId" FOREIGN KEY ("AuthorId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: CentrosCusto FK_CentrosCusto_CentrosCusto_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "FK_CentrosCusto_CentrosCusto_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."CentrosCusto"("Id") ON DELETE RESTRICT;


--
-- Name: CentrosCusto FK_CentrosCusto_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "FK_CentrosCusto_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: CentrosCusto FK_CentrosCusto_Funcionarios_OwnerFuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CentrosCusto"
    ADD CONSTRAINT "FK_CentrosCusto_Funcionarios_OwnerFuncionarioId" FOREIGN KEY ("OwnerFuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: DadosBancarios FK_DadosBancarios_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DadosBancarios"
    ADD CONSTRAINT "FK_DadosBancarios_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: Dependentes FK_Dependentes_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Dependentes"
    ADD CONSTRAINT "FK_Dependentes_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: DescricaoCargoItemEmbeddings FK_DescricaoCargoItemEmbeddings_Item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItemEmbeddings"
    ADD CONSTRAINT "FK_DescricaoCargoItemEmbeddings_Item" FOREIGN KEY ("DescricaoCargoItemId") REFERENCES public."DescricaoCargoItens"("Id") ON DELETE CASCADE;


--
-- Name: DescricaoCargoItens FK_DescricaoCargoItens_DescricoesCargo_DescricaoCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricaoCargoItens"
    ADD CONSTRAINT "FK_DescricaoCargoItens_DescricoesCargo_DescricaoCargoId" FOREIGN KEY ("DescricaoCargoId") REFERENCES public."DescricoesCargo"("Id") ON DELETE CASCADE;


--
-- Name: DescricoesCargo FK_DescricoesCargo_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DescricoesCargo"
    ADD CONSTRAINT "FK_DescricoesCargo_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE SET NULL;


--
-- Name: Desligamentos FK_Desligamentos_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Desligamentos"
    ADD CONSTRAINT "FK_Desligamentos_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: DevelopmentPlanGoals FK_DevelopmentPlanGoals_DevelopmentPlans_PlanId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlanGoals"
    ADD CONSTRAINT "FK_DevelopmentPlanGoals_DevelopmentPlans_PlanId" FOREIGN KEY ("PlanId") REFERENCES public."DevelopmentPlans"("Id") ON DELETE CASCADE;


--
-- Name: DevelopmentPlans FK_DevelopmentPlans_Users_OwnerUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlans"
    ADD CONSTRAINT "FK_DevelopmentPlans_Users_OwnerUserId" FOREIGN KEY ("OwnerUserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: DevelopmentPlans FK_DevelopmentPlans_Users_TargetUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DevelopmentPlans"
    ADD CONSTRAINT "FK_DevelopmentPlans_Users_TargetUserId" FOREIGN KEY ("TargetUserId") REFERENCES public."Users"("Id") ON DELETE SET NULL;


--
-- Name: DocumentacaoPadraoHistoricos FK_DocumentacaoPadraoHistoricos_JobPositions_CargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoHistoricos"
    ADD CONSTRAINT "FK_DocumentacaoPadraoHistoricos_JobPositions_CargoId" FOREIGN KEY ("CargoId") REFERENCES public."JobPositions"("Id") ON DELETE SET NULL;


--
-- Name: DocumentacaoPadraoHistoricos FK_DocumentacaoPadraoHistoricos_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoHistoricos"
    ADD CONSTRAINT "FK_DocumentacaoPadraoHistoricos_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE SET NULL;


--
-- Name: DocumentacaoPadraoPorCargoConfigs FK_DocumentacaoPadraoPorCargoConfigs_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorCargoConfigs"
    ADD CONSTRAINT "FK_DocumentacaoPadraoPorCargoConfigs_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE CASCADE;


--
-- Name: DocumentacaoPadraoPorNivelCargoConfigs FK_DocumentacaoPadraoPorNivelCargoConfigs_NiveisCargo_NivelCar~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentacaoPadraoPorNivelCargoConfigs"
    ADD CONSTRAINT "FK_DocumentacaoPadraoPorNivelCargoConfigs_NiveisCargo_NivelCar~" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE CASCADE;


--
-- Name: DocumentosColaborador FK_DocumentosColaborador_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DocumentosColaborador"
    ADD CONSTRAINT "FK_DocumentosColaborador_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: EmailAttempts FK_EmailAttempts_EmailMessages_EmailMessageId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailAttempts"
    ADD CONSTRAINT "FK_EmailAttempts_EmailMessages_EmailMessageId" FOREIGN KEY ("EmailMessageId") REFERENCES public."EmailMessages"("Id") ON DELETE CASCADE;


--
-- Name: EtapasConfigAprovacao FK_EtapasConfigAprovacao_Funcionarios_FuncionarioFixoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigAprovacao"
    ADD CONSTRAINT "FK_EtapasConfigAprovacao_Funcionarios_FuncionarioFixoId" FOREIGN KEY ("FuncionarioFixoId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: EtapasConfigAprovacao FK_EtapasConfigAprovacao_Roles_RoleFilaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigAprovacao"
    ADD CONSTRAINT "FK_EtapasConfigAprovacao_Roles_RoleFilaId" FOREIGN KEY ("RoleFilaId") REFERENCES public."Roles"("Id") ON DELETE SET NULL;


--
-- Name: EtapasConfigWorkflowRH FK_EtapasConfigWorkflowRH_Roles_RoleFilaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasConfigWorkflowRH"
    ADD CONSTRAINT "FK_EtapasConfigWorkflowRH_Roles_RoleFilaId" FOREIGN KEY ("RoleFilaId") REFERENCES public."Roles"("Id") ON DELETE SET NULL;


--
-- Name: EtapasWorkflowRH FK_EtapasWorkflowRH_Funcionarios_ResponsavelId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasWorkflowRH"
    ADD CONSTRAINT "FK_EtapasWorkflowRH_Funcionarios_ResponsavelId" FOREIGN KEY ("ResponsavelId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: EtapasWorkflowRH FK_EtapasWorkflowRH_WorkflowsRH_WorkflowId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EtapasWorkflowRH"
    ADD CONSTRAINT "FK_EtapasWorkflowRH_WorkflowsRH_WorkflowId" FOREIGN KEY ("WorkflowId") REFERENCES public."WorkflowsRH"("Id") ON DELETE CASCADE;


--
-- Name: FaixasSalariais FK_FaixasSalariais_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FaixasSalariais"
    ADD CONSTRAINT "FK_FaixasSalariais_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE SET NULL;


--
-- Name: FasesProcesso FK_FasesProcesso_ProjetosVaga_ProjetoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FasesProcesso"
    ADD CONSTRAINT "FK_FasesProcesso_ProjetosVaga_ProjetoId" FOREIGN KEY ("ProjetoId") REFERENCES public."ProjetosVaga"("Id") ON DELETE CASCADE;


--
-- Name: FeedbackItemRatings FK_FeedbackItemRatings_FeedbackItems_FeedbackItemId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItemRatings"
    ADD CONSTRAINT "FK_FeedbackItemRatings_FeedbackItems_FeedbackItemId" FOREIGN KEY ("FeedbackItemId") REFERENCES public."FeedbackItems"("Id") ON DELETE CASCADE;


--
-- Name: FeedbackItems FK_FeedbackItems_Users_FromUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItems"
    ADD CONSTRAINT "FK_FeedbackItems_Users_FromUserId" FOREIGN KEY ("FromUserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: FeedbackItems FK_FeedbackItems_Users_ToUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FeedbackItems"
    ADD CONSTRAINT "FK_FeedbackItems_Users_ToUserId" FOREIGN KEY ("ToUserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: FuncionarioMovimentacoes FK_FuncionarioMovimentacoes_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FuncionarioMovimentacoes"
    ADD CONSTRAINT "FK_FuncionarioMovimentacoes_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Funcionarios_GestorDiretoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Funcionarios_GestorDiretoId" FOREIGN KEY ("GestorDiretoId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Hierarquias_HierarquiaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Hierarquias_HierarquiaId" FOREIGN KEY ("HierarquiaId") REFERENCES public."Hierarquias"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE RESTRICT;


--
-- Name: Funcionarios FK_Funcionarios_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_NiveisHierarquicos_NivelHierarquicoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_NiveisHierarquicos_NivelHierarquicoId" FOREIGN KEY ("NivelHierarquicoId") REFERENCES public."NiveisHierarquicos"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Pessoas_PessoaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Pessoas_PessoaId" FOREIGN KEY ("PessoaId") REFERENCES public."Pessoas"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: Funcionarios FK_Funcionarios_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE RESTRICT;


--
-- Name: Funcionarios FK_Funcionarios_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Funcionarios"
    ADD CONSTRAINT "FK_Funcionarios_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE SET NULL;


--
-- Name: GamificationDailyStates FK_GamificationDailyStates_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GamificationDailyStates"
    ADD CONSTRAINT "FK_GamificationDailyStates_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: Hierarquias FK_Hierarquias_Hierarquias_HierarquiaSuperiorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Hierarquias"
    ADD CONSTRAINT "FK_Hierarquias_Hierarquias_HierarquiaSuperiorId" FOREIGN KEY ("HierarquiaSuperiorId") REFERENCES public."Hierarquias"("Id") ON DELETE RESTRICT;


--
-- Name: HistoricosAlteracaoWorkflowRH FK_HistoricosAlteracaoWorkflowRH_EtapasWorkflowRH_EtapaWorkflo~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "FK_HistoricosAlteracaoWorkflowRH_EtapasWorkflowRH_EtapaWorkflo~" FOREIGN KEY ("EtapaWorkflowId") REFERENCES public."EtapasWorkflowRH"("Id") ON DELETE SET NULL;


--
-- Name: HistoricosAlteracaoWorkflowRH FK_HistoricosAlteracaoWorkflowRH_Funcionarios_AlteradoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "FK_HistoricosAlteracaoWorkflowRH_Funcionarios_AlteradoPorId" FOREIGN KEY ("AlteradoPorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: HistoricosAlteracaoWorkflowRH FK_HistoricosAlteracaoWorkflowRH_WorkflowsRH_WorkflowId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HistoricosAlteracaoWorkflowRH"
    ADD CONSTRAINT "FK_HistoricosAlteracaoWorkflowRH_WorkflowsRH_WorkflowId" FOREIGN KEY ("WorkflowId") REFERENCES public."WorkflowsRH"("Id") ON DELETE CASCADE;


--
-- Name: Holerites FK_Holerites_Funcionarios_EnviadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holerites"
    ADD CONSTRAINT "FK_Holerites_Funcionarios_EnviadoPorId" FOREIGN KEY ("EnviadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: Holerites FK_Holerites_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Holerites"
    ADD CONSTRAINT "FK_Holerites_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: InboxAttachments FK_InboxAttachments_InboxItems_InboxItemId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxAttachments"
    ADD CONSTRAINT "FK_InboxAttachments_InboxItems_InboxItemId" FOREIGN KEY ("InboxItemId") REFERENCES public."InboxItems"("Id") ON DELETE CASCADE;


--
-- Name: InboxItems FK_InboxItems_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxItems"
    ADD CONSTRAINT "FK_InboxItems_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE SET NULL;


--
-- Name: InboxItems FK_InboxItems_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InboxItems"
    ADD CONSTRAINT "FK_InboxItems_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE SET NULL;


--
-- Name: JobPositions FK_JobPositions_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "FK_JobPositions_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: JobPositions FK_JobPositions_NiveisCargo_NivelCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "FK_JobPositions_NiveisCargo_NivelCargoId" FOREIGN KEY ("NivelCargoId") REFERENCES public."NiveisCargo"("Id");


--
-- Name: JobPositions FK_JobPositions_NiveisHierarquicos_NivelHierarquicoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPositions"
    ADD CONSTRAINT "FK_JobPositions_NiveisHierarquicos_NivelHierarquicoId" FOREIGN KEY ("NivelHierarquicoId") REFERENCES public."NiveisHierarquicos"("Id");


--
-- Name: LogsComunicacao FK_LogsComunicacao_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogsComunicacao"
    ADD CONSTRAINT "FK_LogsComunicacao_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: LogsComunicacao FK_LogsComunicacao_ProjetosVaga_ProjetoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LogsComunicacao"
    ADD CONSTRAINT "FK_LogsComunicacao_ProjetosVaga_ProjetoId" FOREIGN KEY ("ProjetoId") REFERENCES public."ProjetosVaga"("Id") ON DELETE SET NULL;


--
-- Name: Metas FK_Metas_Funcionarios_CriadaPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Metas"
    ADD CONSTRAINT "FK_Metas_Funcionarios_CriadaPorId" FOREIGN KEY ("CriadaPorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: Metas FK_Metas_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Metas"
    ADD CONSTRAINT "FK_Metas_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: MoodEntries FK_MoodEntries_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MoodEntries"
    ADD CONSTRAINT "FK_MoodEntries_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: NineBoxAssessments FK_NineBoxAssessments_AvaliacaoCiclos_CicloAvaliacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "FK_NineBoxAssessments_AvaliacaoCiclos_CicloAvaliacaoId" FOREIGN KEY ("CicloAvaliacaoId") REFERENCES public."AvaliacaoCiclos"("Id") ON DELETE SET NULL;


--
-- Name: NineBoxAssessments FK_NineBoxAssessments_Funcionarios_AvaliadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "FK_NineBoxAssessments_Funcionarios_AvaliadorId" FOREIGN KEY ("AvaliadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: NineBoxAssessments FK_NineBoxAssessments_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NineBoxAssessments"
    ADD CONSTRAINT "FK_NineBoxAssessments_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: Notifications FK_Notifications_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "FK_Notifications_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: OcupacoesHistorico FK_OcupacoesHistorico_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OcupacoesHistorico"
    ADD CONSTRAINT "FK_OcupacoesHistorico_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: OcupacoesHistorico FK_OcupacoesHistorico_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OcupacoesHistorico"
    ADD CONSTRAINT "FK_OcupacoesHistorico_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: OneOnOneMeetings FK_OneOnOneMeetings_Users_CollaboratorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOnOneMeetings"
    ADD CONSTRAINT "FK_OneOnOneMeetings_Users_CollaboratorId" FOREIGN KEY ("CollaboratorId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: OneOnOneMeetings FK_OneOnOneMeetings_Users_ManagerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."OneOnOneMeetings"
    ADD CONSTRAINT "FK_OneOnOneMeetings_Users_ManagerId" FOREIGN KEY ("ManagerId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: PerguntasEntrevistaSaida FK_PerguntasEntrevistaSaida_TemplatesEntrevistaSaida_TemplateId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PerguntasEntrevistaSaida"
    ADD CONSTRAINT "FK_PerguntasEntrevistaSaida_TemplatesEntrevistaSaida_TemplateId" FOREIGN KEY ("TemplateId") REFERENCES public."TemplatesEntrevistaSaida"("Id") ON DELETE CASCADE;


--
-- Name: PermissoesNivelVaga FK_PermissoesNivelVaga_NiveisHierarquicos_NivelHierarquicoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PermissoesNivelVaga"
    ADD CONSTRAINT "FK_PermissoesNivelVaga_NiveisHierarquicos_NivelHierarquicoId" FOREIGN KEY ("NivelHierarquicoId") REFERENCES public."NiveisHierarquicos"("Id") ON DELETE CASCADE;


--
-- Name: PermissoesNivelVaga FK_PermissoesNivelVaga_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PermissoesNivelVaga"
    ADD CONSTRAINT "FK_PermissoesNivelVaga_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: PessoaBloqueios FK_PessoaBloqueios_Pessoas_PessoaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PessoaBloqueios"
    ADD CONSTRAINT "FK_PessoaBloqueios_Pessoas_PessoaId" FOREIGN KEY ("PessoaId") REFERENCES public."Pessoas"("Id") ON DELETE RESTRICT;


--
-- Name: PreAdmissaoDependentes FK_PreAdmissaoDependentes_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDependentes"
    ADD CONSTRAINT "FK_PreAdmissaoDependentes_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE CASCADE;


--
-- Name: PreAdmissaoDocumentosSolicitados FK_PreAdmissaoDocumentosSolicitados_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentosSolicitados"
    ADD CONSTRAINT "FK_PreAdmissaoDocumentosSolicitados_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE CASCADE;


--
-- Name: PreAdmissaoDocumentos FK_PreAdmissaoDocumentos_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissaoDocumentos"
    ADD CONSTRAINT "FK_PreAdmissaoDocumentos_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE CASCADE;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Funcionarios_AprovadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Funcionarios_AprovadoPorId" FOREIGN KEY ("AprovadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: PreAdmissoes FK_PreAdmissoes_Funcionarios_RevisadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Funcionarios_RevisadoPorId" FOREIGN KEY ("RevisadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: PreAdmissoes FK_PreAdmissoes_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE SET NULL;


--
-- Name: PreAdmissoes FK_PreAdmissoes_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PreAdmissoes"
    ADD CONSTRAINT "FK_PreAdmissoes_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE SET NULL;


--
-- Name: ProjetoCandidatos FK_ProjetoCandidatos_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "FK_ProjetoCandidatos_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE RESTRICT;


--
-- Name: ProjetoCandidatos FK_ProjetoCandidatos_FasesProcesso_FaseAtualId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "FK_ProjetoCandidatos_FasesProcesso_FaseAtualId" FOREIGN KEY ("FaseAtualId") REFERENCES public."FasesProcesso"("Id") ON DELETE SET NULL;


--
-- Name: ProjetoCandidatos FK_ProjetoCandidatos_ProjetosVaga_ProjetoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetoCandidatos"
    ADD CONSTRAINT "FK_ProjetoCandidatos_ProjetosVaga_ProjetoId" FOREIGN KEY ("ProjetoId") REFERENCES public."ProjetosVaga"("Id") ON DELETE CASCADE;


--
-- Name: ProjetosVaga FK_ProjetosVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProjetosVaga"
    ADD CONSTRAINT "FK_ProjetosVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: PropostasVaga FK_PropostasVaga_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "FK_PropostasVaga_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE RESTRICT;


--
-- Name: PropostasVaga FK_PropostasVaga_Candidaturas_CandidaturaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "FK_PropostasVaga_Candidaturas_CandidaturaId" FOREIGN KEY ("CandidaturaId") REFERENCES public."Candidaturas"("Id") ON DELETE SET NULL;


--
-- Name: PropostasVaga FK_PropostasVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropostasVaga"
    ADD CONSTRAINT "FK_PropostasVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE RESTRICT;


--
-- Name: RenderCoinBalances FK_RenderCoinBalances_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinBalances"
    ADD CONSTRAINT "FK_RenderCoinBalances_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: RenderCoinTransactions FK_RenderCoinTransactions_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RenderCoinTransactions"
    ADD CONSTRAINT "FK_RenderCoinTransactions_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE RESTRICT;


--
-- Name: RespostasCampoPersonalizadoVaga FK_RespostasCampoPersonalizadoVaga_CamposPersonalizadosVaga_Ca~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "FK_RespostasCampoPersonalizadoVaga_CamposPersonalizadosVaga_Ca~" FOREIGN KEY ("CampoId") REFERENCES public."CamposPersonalizadosVaga"("Id") ON DELETE CASCADE;


--
-- Name: RespostasCampoPersonalizadoVaga FK_RespostasCampoPersonalizadoVaga_Candidatos_CandidatoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "FK_RespostasCampoPersonalizadoVaga_Candidatos_CandidatoId" FOREIGN KEY ("CandidatoId") REFERENCES public."Candidatos"("Id") ON DELETE CASCADE;


--
-- Name: RespostasCampoPersonalizadoVaga FK_RespostasCampoPersonalizadoVaga_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasCampoPersonalizadoVaga"
    ADD CONSTRAINT "FK_RespostasCampoPersonalizadoVaga_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: RespostasEntrevistaSaida FK_RespostasEntrevistaSaida_EntrevistasSaida_EntrevistaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasEntrevistaSaida"
    ADD CONSTRAINT "FK_RespostasEntrevistaSaida_EntrevistasSaida_EntrevistaId" FOREIGN KEY ("EntrevistaId") REFERENCES public."EntrevistasSaida"("Id") ON DELETE CASCADE;


--
-- Name: RespostasEntrevistaSaida FK_RespostasEntrevistaSaida_PerguntasEntrevistaSaida_PerguntaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RespostasEntrevistaSaida"
    ADD CONSTRAINT "FK_RespostasEntrevistaSaida_PerguntasEntrevistaSaida_PerguntaId" FOREIGN KEY ("PerguntaId") REFERENCES public."PerguntasEntrevistaSaida"("Id") ON DELETE RESTRICT;


--
-- Name: RoleMenus FK_RoleMenus_Menus_MenuId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RoleMenus"
    ADD CONSTRAINT "FK_RoleMenus_Menus_MenuId" FOREIGN KEY ("MenuId") REFERENCES public."Menus"("Id") ON DELETE CASCADE;


--
-- Name: RoleMenus FK_RoleMenus_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RoleMenus"
    ADD CONSTRAINT "FK_RoleMenus_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: SkillAliases FK_SkillAliases_Skills_SkillId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SkillAliases"
    ADD CONSTRAINT "FK_SkillAliases_Skills_SkillId" FOREIGN KEY ("SkillId") REFERENCES public."Skills"("Id") ON DELETE CASCADE;


--
-- Name: Skills FK_Skills_Skills_ParentSkillId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Skills"
    ADD CONSTRAINT "FK_Skills_Skills_ParentSkillId" FOREIGN KEY ("ParentSkillId") REFERENCES public."Skills"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesAprovacaoEtapas FK_SolicitacoesAprovacaoEtapas_Funcionarios_AprovadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesAprovacaoEtapas"
    ADD CONSTRAINT "FK_SolicitacoesAprovacaoEtapas_Funcionarios_AprovadorId" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesBeneficio FK_SolicitacoesBeneficio_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesBeneficio"
    ADD CONSTRAINT "FK_SolicitacoesBeneficio_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDependente FK_SolicitacoesDependente_Dependentes_DependenteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDependente"
    ADD CONSTRAINT "FK_SolicitacoesDependente_Dependentes_DependenteId" FOREIGN KEY ("DependenteId") REFERENCES public."Dependentes"("Id");


--
-- Name: SolicitacoesDependente FK_SolicitacoesDependente_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDependente"
    ADD CONSTRAINT "FK_SolicitacoesDependente_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id");


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesDesligamento FK_SolicitacoesDesligamento_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesDesligamento"
    ADD CONSTRAINT "FK_SolicitacoesDesligamento_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id");


--
-- Name: SolicitacoesEndereco FK_SolicitacoesEndereco_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesEndereco"
    ADD CONSTRAINT "FK_SolicitacoesEndereco_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesFerias FK_SolicitacoesFerias_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesFerias"
    ADD CONSTRAINT "FK_SolicitacoesFerias_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPagamentoExtra FK_SolicitacoesPagamentoExtra_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "FK_SolicitacoesPagamentoExtra_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPagamentoExtra FK_SolicitacoesPagamentoExtra_Funcionarios_ImportadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "FK_SolicitacoesPagamentoExtra_Funcionarios_ImportadoPorId" FOREIGN KEY ("ImportadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: SolicitacoesPagamentoExtra FK_SolicitacoesPagamentoExtra_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPagamentoExtra"
    ADD CONSTRAINT "FK_SolicitacoesPagamentoExtra_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_CentrosCusto_CentroCustoAtualId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoAtualId" FOREIGN KEY ("CentroCustoAtualId") REFERENCES public."CentrosCusto"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_CentrosCusto_NovoCentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_CentrosCusto_NovoCentroCustoId" FOREIGN KEY ("NovoCentroCustoId") REFERENCES public."CentrosCusto"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_JobPositions_CargoAtualId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_JobPositions_CargoAtualId" FOREIGN KEY ("CargoAtualId") REFERENCES public."JobPositions"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_JobPositions_NovoCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_JobPositions_NovoCargoId" FOREIGN KEY ("NovoCargoId") REFERENCES public."JobPositions"("Id") ON DELETE CASCADE;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Units_NovaUnidadeId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Units_NovaUnidadeId" FOREIGN KEY ("NovaUnidadeId") REFERENCES public."Units"("Id");


--
-- Name: SolicitacoesPromocao FK_SolicitacoesPromocao_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesPromocao"
    ADD CONSTRAINT "FK_SolicitacoesPromocao_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id");


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Candidatos_CandidatoContratadoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Candidatos_CandidatoContratadoId" FOREIGN KEY ("CandidatoContratadoId") REFERENCES public."Candidatos"("Id");


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_AprovadorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_AprovadorId" FOREIGN KEY ("AprovadorId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_DecisaoRHRevisadoPorId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_DecisaoRHRevisadoPorId" FOREIGN KEY ("DecisaoRHRevisadoPorId") REFERENCES public."Funcionarios"("Id");


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_SolicitanteId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_SolicitanteId" FOREIGN KEY ("SolicitanteId") REFERENCES public."Funcionarios"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Funcionarios_SubstituidoFuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Funcionarios_SubstituidoFuncionarioId" FOREIGN KEY ("SubstituidoFuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_MotivosRequisicaoVagaConfig_MotivoRequisic~; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_MotivosRequisicaoVagaConfig_MotivoRequisic~" FOREIGN KEY ("MotivoRequisicaoId") REFERENCES public."MotivosRequisicaoVagaConfig"("Id") ON DELETE RESTRICT;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: SolicitacoesVaga FK_SolicitacoesVaga_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SolicitacoesVaga"
    ADD CONSTRAINT "FK_SolicitacoesVaga_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE RESTRICT;


--
-- Name: SurveyAnswers FK_SurveyAnswers_SurveyResponses_ResponseId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyAnswers"
    ADD CONSTRAINT "FK_SurveyAnswers_SurveyResponses_ResponseId" FOREIGN KEY ("ResponseId") REFERENCES public."SurveyResponses"("Id") ON DELETE CASCADE;


--
-- Name: SurveyOptions FK_SurveyOptions_SurveyQuestions_QuestionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyOptions"
    ADD CONSTRAINT "FK_SurveyOptions_SurveyQuestions_QuestionId" FOREIGN KEY ("QuestionId") REFERENCES public."SurveyQuestions"("Id") ON DELETE CASCADE;


--
-- Name: SurveyQuestions FK_SurveyQuestions_Surveys_SurveyId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyQuestions"
    ADD CONSTRAINT "FK_SurveyQuestions_Surveys_SurveyId" FOREIGN KEY ("SurveyId") REFERENCES public."Surveys"("Id") ON DELETE CASCADE;


--
-- Name: SurveyResponses FK_SurveyResponses_Surveys_SurveyId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SurveyResponses"
    ADD CONSTRAINT "FK_SurveyResponses_Surveys_SurveyId" FOREIGN KEY ("SurveyId") REFERENCES public."Surveys"("Id") ON DELETE CASCADE;


--
-- Name: TalentoCompetencias FK_TalentoCompetencias_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCompetencias"
    ADD CONSTRAINT "FK_TalentoCompetencias_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoCvImportJobs FK_TalentoCvImportJobs_TalentoDocumentos_TalentoDocumentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCvImportJobs"
    ADD CONSTRAINT "FK_TalentoCvImportJobs_TalentoDocumentos_TalentoDocumentoId" FOREIGN KEY ("TalentoDocumentoId") REFERENCES public."TalentoDocumentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoCvImportJobs FK_TalentoCvImportJobs_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoCvImportJobs"
    ADD CONSTRAINT "FK_TalentoCvImportJobs_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoDocumentos FK_TalentoDocumentos_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoDocumentos"
    ADD CONSTRAINT "FK_TalentoDocumentos_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoExperiencias FK_TalentoExperiencias_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoExperiencias"
    ADD CONSTRAINT "FK_TalentoExperiencias_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoFormacoes FK_TalentoFormacoes_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoFormacoes"
    ADD CONSTRAINT "FK_TalentoFormacoes_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: TalentoTreinamentos FK_TalentoTreinamentos_Talentos_TalentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TalentoTreinamentos"
    ADD CONSTRAINT "FK_TalentoTreinamentos_Talentos_TalentoId" FOREIGN KEY ("TalentoId") REFERENCES public."Talentos"("Id") ON DELETE CASCADE;


--
-- Name: Talentos FK_Talentos_Pessoas_PessoaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Talentos"
    ADD CONSTRAINT "FK_Talentos_Pessoas_PessoaId" FOREIGN KEY ("PessoaId") REFERENCES public."Pessoas"("Id") ON DELETE RESTRICT;


--
-- Name: TenantConfiguracoes FK_TenantConfiguracoes_Funcionarios_AprovadorRhId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TenantConfiguracoes"
    ADD CONSTRAINT "FK_TenantConfiguracoes_Funcionarios_AprovadorRhId" FOREIGN KEY ("AprovadorRhId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: Turnos FK_Turnos_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Turnos"
    ADD CONSTRAINT "FK_Turnos_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE SET NULL;


--
-- Name: UnidadesLotacao FK_UnidadesLotacao_Funcionarios_OwnerFuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UnidadesLotacao"
    ADD CONSTRAINT "FK_UnidadesLotacao_Funcionarios_OwnerFuncionarioId" FOREIGN KEY ("OwnerFuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: UnidadesLotacao FK_UnidadesLotacao_UnidadesLotacao_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UnidadesLotacao"
    ADD CONSTRAINT "FK_UnidadesLotacao_UnidadesLotacao_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."UnidadesLotacao"("Id") ON DELETE RESTRICT;


--
-- Name: Units FK_Units_Empresas_EmpresaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Units"
    ADD CONSTRAINT "FK_Units_Empresas_EmpresaId" FOREIGN KEY ("EmpresaId") REFERENCES public."Empresas"("Id") ON DELETE SET NULL;


--
-- Name: UserRoles FK_UserRoles_Roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "FK_UserRoles_Roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."Roles"("Id") ON DELETE CASCADE;


--
-- Name: UserRoles FK_UserRoles_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserRoles"
    ADD CONSTRAINT "FK_UserRoles_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: UserUnits FK_UserUnits_Units_UnitId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserUnits"
    ADD CONSTRAINT "FK_UserUnits_Units_UnitId" FOREIGN KEY ("UnitId") REFERENCES public."Units"("Id") ON DELETE CASCADE;


--
-- Name: UserUnits FK_UserUnits_Users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserUnits"
    ADD CONSTRAINT "FK_UserUnits_Users_UserId" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id") ON DELETE CASCADE;


--
-- Name: Users FK_Users_Funcionarios_FuncionarioId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "FK_Users_Funcionarios_FuncionarioId" FOREIGN KEY ("FuncionarioId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: VagaBeneficios FK_VagaBeneficios_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaBeneficios"
    ADD CONSTRAINT "FK_VagaBeneficios_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaEtapas FK_VagaEtapas_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaEtapas"
    ADD CONSTRAINT "FK_VagaEtapas_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaPerguntas FK_VagaPerguntas_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaPerguntas"
    ADD CONSTRAINT "FK_VagaPerguntas_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaRequisitos FK_VagaRequisitos_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaRequisitos"
    ADD CONSTRAINT "FK_VagaRequisitos_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: VagaUnifiedMatchingCaches FK_VagaUnifiedMatchingCaches_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."VagaUnifiedMatchingCaches"
    ADD CONSTRAINT "FK_VagaUnifiedMatchingCaches_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE CASCADE;


--
-- Name: Vagas FK_Vagas_CategoriasSalariais_CategoriaSalarialId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_CategoriasSalariais_CategoriaSalarialId" FOREIGN KEY ("CategoriaSalarialId") REFERENCES public."CategoriasSalariais"("Id");


--
-- Name: Vagas FK_Vagas_CentrosCusto_CentroCustoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_CentrosCusto_CentroCustoId" FOREIGN KEY ("CentroCustoId") REFERENCES public."CentrosCusto"("Id") ON DELETE RESTRICT;


--
-- Name: Vagas FK_Vagas_DescricoesCargo_DescricaoCargoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_DescricoesCargo_DescricaoCargoId" FOREIGN KEY ("DescricaoCargoId") REFERENCES public."DescricoesCargo"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_Desligamentos_OrigemDesligamentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Desligamentos_OrigemDesligamentoId" FOREIGN KEY ("OrigemDesligamentoId") REFERENCES public."Desligamentos"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_EixosVaga_EixoVagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_EixosVaga_EixoVagaId" FOREIGN KEY ("EixoVagaId") REFERENCES public."EixosVaga"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_Hierarquias_HierarquiaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Hierarquias_HierarquiaId" FOREIGN KEY ("HierarquiaId") REFERENCES public."Hierarquias"("Id") ON DELETE SET NULL;


--
-- Name: Vagas FK_Vagas_JobPositions_JobPositionId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_JobPositions_JobPositionId" FOREIGN KEY ("JobPositionId") REFERENCES public."JobPositions"("Id");


--
-- Name: Vagas FK_Vagas_Turnos_TurnoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Turnos_TurnoId" FOREIGN KEY ("TurnoId") REFERENCES public."Turnos"("Id");


--
-- Name: Vagas FK_Vagas_UnidadesLotacao_UnidadeLotacaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_UnidadesLotacao_UnidadeLotacaoId" FOREIGN KEY ("UnidadeLotacaoId") REFERENCES public."UnidadesLotacao"("Id");


--
-- Name: Vagas FK_Vagas_Users_RecrutadorResponsavelUserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Vagas"
    ADD CONSTRAINT "FK_Vagas_Users_RecrutadorResponsavelUserId" FOREIGN KEY ("RecrutadorResponsavelUserId") REFERENCES public."Users"("Id") ON DELETE SET NULL;


--
-- Name: WorkflowsRH FK_WorkflowsRH_Funcionarios_ResponsavelId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_Funcionarios_ResponsavelId" FOREIGN KEY ("ResponsavelId") REFERENCES public."Funcionarios"("Id") ON DELETE SET NULL;


--
-- Name: WorkflowsRH FK_WorkflowsRH_PreAdmissoes_PreAdmissaoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_PreAdmissoes_PreAdmissaoId" FOREIGN KEY ("PreAdmissaoId") REFERENCES public."PreAdmissoes"("Id") ON DELETE SET NULL;


--
-- Name: WorkflowsRH FK_WorkflowsRH_SolicitacoesDesligamento_DesligamentoId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_SolicitacoesDesligamento_DesligamentoId" FOREIGN KEY ("DesligamentoId") REFERENCES public."SolicitacoesDesligamento"("Id");


--
-- Name: WorkflowsRH FK_WorkflowsRH_Vagas_VagaId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowsRH"
    ADD CONSTRAINT "FK_WorkflowsRH_Vagas_VagaId" FOREIGN KEY ("VagaId") REFERENCES public."Vagas"("Id") ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict QAmxMxuwmw2sf3aCARohi2QZRAOIFKf9CCHWOcZA46SRaxnaJOLslnwy4Gc3tvZ

